<?php

namespace App;
use Illuminate\Http\Request;
use App\User;
use App\pickupdeliveryuser;
use App\IroningVendor;
use App\Admin;
use App\ServiceAreas;
use App\UserAddresses;
use App\TimeSlots;
use App\Pincode;
use App\Promocode;
use App\Categories;
use App\CategoryList;
use App\Bookings;
use App\BookingItems;
use App\Warehouses;
use Auth;
use DateTime;
use Validator;
use DB;
use Carbon\Carbon;
use PDF;
use Mail;
use Excel;

class CommonFunctions{
	
	
	
	function send($id){
		
		
		$GetUser = User::Select('id','name','mobile')->Where('id',$id)->first();
		
		return $GetUser;
		
	}
	
	
	//Edit Pickupuser function
	function EditPickupUser($id){
		
		$GetDetails = pickupdeliveryuser::Select('pickupdeliveryusers.id','pickupdeliveryusers.name','pickupdeliveryusers.mobile','pickupdeliveryusers.email','image','pickupdeliveryusers.gender','pickupdeliveryusers.dob','pickupdeliveryusers.address','pickupdeliveryusers.Is_active','serviceAreaId','pickupdeliveryusers.warehouseId','warehouses.name as outlet','Pincode.area','Pincode.code')
		                                  ->leftjoin('Pincode','Pincode.id', '=', 'pickupdeliveryusers.serviceAreaId')
										  ->leftjoin('warehouses','warehouses.id','=','pickupdeliveryusers.warehouseId')
		                                  ->Where(['pickupdeliveryusers.id' => $id])
										  ->get();
										  
									  
								// echo json_encode($GetDetails);die;		  
        $GetBookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','users.mobile','Bookings.addressId','bookingDate','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots',DB::raw('DATE_FORMAT(PickupSuccessDate, "%d-%m-%Y") as pick_date'))
		                         ->Join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
								 ->join('users','users.id','=','Bookings.userId')
								 ->Where(['Bookings.pickupDeliveryUserId'=>$id,'Bookings.PickupSuccess'=>1])
								 ->orderBy('Bookings.id','desc')
								 ->get();
        
        $DeliveryService = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','Bookings.DeliveryUserId','users.name','users.mobile','Bookings.addressId','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots',DB::raw('DATE_FORMAT(DeliverySuccessDate, "%d-%m-%Y") as delivery_date'))
		                         ->Join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
								 ->join('users','users.id','=','Bookings.userId')
								 ->Where(['Bookings.DeliveryUserId'=>$id,'Bookings.Status'=>'COMPLETED'])
								 ->orderBy('Bookings.id','desc')
								 ->get();		
		
	    foreach($GetDetails as $GetArea){
			 
			 $AreaId =$GetArea->warehouseId;			 
		 }
		 
         
		 $pickup_count = Bookings::select('id','pickupDeliveryUserId','cancelReason')
		                             ->Where(['pickupDeliveryUserId'=>$id,'PickupSuccess'=>'1'])
									 ->count();
									 
		$delivery_count = Bookings::select('id','DeliveryUserId','cancelReason')
		                             ->Where(['DeliveryUserId'=>$id,'DeliverySuccess'=>'1'])
									 ->count();							 

		  
		 $SelectAreas = Pincode::Select('id','warehouseId','area','code')->Where('warehouseId',$AreaId)->get();						 
		
	    return array("GetDetails"=>$GetDetails,"Bookings"=>$GetBookings,"SelectAreas"=>$SelectAreas,"Delivery"=>$DeliveryService,'pickup_count'=>$pickup_count,'delivery_count'=>$delivery_count);
	}
	
	
	//Get Pincode 
	function GetPincode(){
		
		$GetPin = Pincode::Select('id','warehouseId','area','code')->get();
		return $GetPin;
	}
	
	
	//Sent Otp
	public function SentOtp($mobile,$message){
		
		  $mobile_num = '91'.$mobile;

		  $message_new  = rawurlencode($message);
		  $ch       = curl_init('http://websmsapp.in/api/mt/SendSMS?User=Ironbox&Password=12345&senderid=IRONBX&channel=Trans&DCS=0&flashsms=0&number='.$mobile_num.'&text='.$message_new.'&route=9');
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$response = curl_exec($ch);
			curl_close($ch);
            //echo json_encode($response);
	
			
	}
	
	
	function text_local_sms($mobile,$message){

	$apiKey = urlencode('N2rOSfgRLWk-Kf0LiORQacEPf5As9JuPMePLQv9KYX');
    
    // Message details
    $numbers = array($mobile);
    $sender = urlencode('IRONBX');
    // $newone = 'Your OTP for Login is '.$otp.'.';
    $message_1 = rawurlencode($message);
 
    $numbers = implode(',', $numbers);
 
    // Prepare data for POST request
    $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message_1);
 
    // Send the POST request with cURL
    $ch = curl_init('https://api.textlocal.in/send/');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
	
	return $response;

	}
	
	
	//Pickupuser Active
	
	public function PickupUserIsActive($id){
		
		$CheckActive = pickupdeliveryuser::Select('id','Is_active')->Where(['id'=>$id, 'Is_active'=> 1])->count();
		
		if($CheckActive > 0){
		
		$ActiveUser = pickupdeliveryuser::Select('id','Is_active')->Where('id',$id)->update(['Is_active'=>0]);
		
		return 0;
		
		}else{
         $ActiveUser = pickupdeliveryuser::Select('id','Is_active')->Where('id',$id)->update(['Is_active'=>1]);
		 return 0;
		}
		
	}
	
	public function IroningVendorIsActive($id){
		
		$CheckActive = IroningVendor::Select('id','Is_active')->Where(['id'=>$id, 'Is_active'=> 1])->count();
		
		if($CheckActive > 0){
		
		$ActiveUser = IroningVendor::Select('id','Is_active')->Where('id',$id)->update(['Is_active'=>0]);
		
		return 0;
		
		}else{
         $ActiveUser = IroningVendor::Select('id','Is_active')->Where('id',$id)->update(['Is_active'=>1]);
		 return 0;
		}
		
	}
	
	//Vendor Info
	public function VendorInfo($id){
		
		$VendorInfo = IroningVendor::Select('id','name','mobile','email','image','dob','gender','Is_active')
		                             ->Where('id',$id)
									 ->first();
		
		$GetBookings = Bookings::Select('Bookings.id','bookingId','VendorUserId','users.name as username','bookingDate','bookingTimeSlot')
		                         ->join('users','users.id','=','Bookings.userId')
		                         ->Where(['Bookings.VendorUserId'=>$id])
								 ->orderBy('Bookings.id','DESC')
								 ->get();
								 

		 
		$jobs = Bookings::select('id','VendorUserId')->Where(['VendorUserId'=>$id,'StartJob'=>'2'])->count();
		 
		 // echo json_encode($jobs_1);die;
		
		return array("Vendor"=>$VendorInfo,"Bookings"=>$GetBookings,'jobs'=>$jobs);
	}
	
	//AddMainCategory
	public function AddMainCategory($name,$price,$quantity){
		
		$AddCategory = CategoryList::insert([
		                        'name' =>$name,
								'Price' =>$price,
								'Qty' =>$quantity
		                    ]);
	    return $AddCategory;					
	}
	
	
	//View Booking Details
	public function ViewBook($id){

 
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','paymentType','Bookings.quantity','Bookings.Status','bill_image','ConfirmOrder','WaytoPickup','OrderConfirmDate','WaytoPickupDate','PickupSuccess','PickupSuccessDate','start_time','job_completed','WaytoDelivery','DeliveryDate','DeliverySuccess','DeliverySuccessDate','CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode','first_offer')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  //->join('UserAddresses.serviceAreaId' , '=', 'Pincode','Pincode.id' )
		                      ->Where(['Bookings.id'=>$id])
		                      ->get();
							  
			foreach($Bookings as $Book){
              
			  $order_dt = explode(" ",$Book->OrderConfirmDate);
			  $Book->order_date = date("d-m-Y", strtotime($order_dt[0]));
			  $Book->order_time = $order_dt[1];
			  
			  if($Book->WaytoPickup == 1){
				  
			  $wayto_pick_dt = explode(" ",$Book->WaytoPickupDate);
			  $Book->WaytoPick_date = date("d-m-Y", strtotime($wayto_pick_dt[0]));
			  $Book->WaytoPick_time = $wayto_pick_dt[1];
			  
			  }
			  
			  if($Book->PickupSuccess == 1){
			  
              $pickup_dt =  explode(" ",$Book->PickupSuccessDate);
			  $Book->pick_date = date("d-m-Y", strtotime($pickup_dt[0]));
			  $Book->pick_time = $pickup_dt[1];
			  
			  }
			  
			  if($Book->start_time != null){
				  
				  $work_start = explode(" ",$Book->start_time);
				  $Book->work_date = date("d-m-Y", strtotime($work_start[0]));
				  $Book->work_time  = $work_start[1];
				  
			  }
			  
			  if($Book->job_completed != null){
				  
				  $work_end = explode(" ",$Book->job_completed);
				  $Book->wr_end_date = date("d-m-Y", strtotime($work_end[0]));
				  $Book->wr_end_time  = $work_end[1];
				  
			  }
			  
			  if($Book->WaytoDelivery == 1){
			  
			  $wayto_deliv_dt = explode(" ",$Book->DeliveryDate);
			  $Book->Waytodeliv_date = date("d-m-Y", strtotime($wayto_deliv_dt[0]));
			  $Book->Waytodeliv_time = $wayto_deliv_dt[1];
			  
			  }
			  
			  if($Book->DeliverySuccess == 1){

			  $delivery_dt =  explode(" ",$Book->DeliverySuccessDate);
			  $Book->delivery_date = date("d-m-Y", strtotime($delivery_dt[0]));
			  $Book->delivery_time = $delivery_dt[1];
			  
			  }
			  
			  if(!$Book->cancelReason == 0 && !$Book->cancelReason == null){
				  
				  $cancel_dt =  explode(" ",$Book->CancelDate);
				  $Book->cancel_date = date("d-m-Y", strtotime($cancel_dt[0]));
			      $Book->cancel_time = $cancel_dt[1];
				 
			  }
			  
			  if($Book->first_offer == 1){
				  $Book->discount_amount = 50;
			  }

			}			

		  $Deliveyuser = Bookings::Select('Bookings.id','Bookings.DeliveryUserId','pickupdeliveryusers.name','pickupdeliveryusers.mobile','pickupdeliveryusers.address')
		                     ->join('pickupdeliveryusers','pickupdeliveryusers.id', '=' , 'Bookings.DeliveryUserId')
							 ->Where(['Bookings.id'=>$id])
							 ->get();
							 
			$IroningVendor = Bookings::Select('Bookings.id','Bookings.VendorUserId','IroningVendors.name','IroningVendors.mobile')
		                     ->join('IroningVendors','IroningVendors.id', '=' , 'Bookings.VendorUserId')
							 ->Where(['Bookings.id'=>$id])
							 ->get();				 
							 

			$GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','CategoryList.Price','NewCategories.groupName','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => $id])
								  ->get();		
			foreach($GetOrder as $Amt){
                 
               $priceamt = $Amt->Price;
               $Amt -> amount = "Rs.".$priceamt * $Amt->quantity; 
			   $Amt -> Price = "Rs.".$priceamt;
			}
			
			
			$Rating = DB::table('UserRating')->Select('UserRating.id','UserRating.bookingId','forPickup','forService','forDelivery','comments')
			                                 ->join('Bookings','Bookings.id','=','UserRating.bookingId')
											 ->where(['UserRating.bookingId'=>$id])
											 ->get();
											 
											 

			// echo json_encode($Rating);die;
             return array("Deliveyuser"=>$Deliveyuser,"Bookings"=>$Bookings,"GetOrder"=>$GetOrder,"Ironing"=>$IroningVendor,'Rating'=>$Rating);			 
	}
	
	
	
	public function DeliveryOrder(){
		
		
		$now = date('Y-m-d');
		
		$Order = Bookings::Select('Bookings.id','Bookings.bookingId','users.name','users.mobile','bookingDate','TimeSlots.fromSlots','TimeSlots.toSlots','UserAddresses.serviceAreaId','Pincode.area','OrderAssign',DB::raw('DATE_FORMAT(delivery_date, "%d-%m-%Y") as delivery_date'))
		               ->join('users','users.id', '=' , 'Bookings.userId')
					   ->join('TimeSlots','TimeSlots.id', '=' , 'Bookings.bookingTimeSlot')
					   ->join('UserAddresses','UserAddresses.id', '=' , 'Bookings.addressId')
					   ->join('Pincode','Pincode.id', '=', 'UserAddresses.serviceAreaId')
					   ->where('pick_date','<=',$now)
					   ->orwhere('delivery_date','<=',$now)
		               //->Where('Bookings.DeliveryUserId', '=' , null)
		               ->whereIn('Bookings.Status', ['CONFIRMED'])
					   ->get();
		foreach($Order as $ord){

        if($ord->OrderAssign == 1){
			
			$ord->Order_for = 'PICKUP';
		}else{
			
			$ord->Order_for = 'DELIVERY';
		}

		}		
		
		return $Order;
		
	}
	
	//EditMainCategory
	public function EditMainCategory($id){
		
		$GetCategory = CategoryList::Select('id','name','Price','Qty')->Where(['id'=>$id])->get();
		return  $GetCategory;
	}
	
	//Update CategoryList
	public function UpdateMainCategory($id,$name,$price,$qty){
	
		$UpdateCategoty =DB::table('CategoryList')->where('id',$id)
				                   ->update(['name' => $name,'Price'=>$price,'Qty'=>$qty]);
		
	    return $UpdateCategoty;	
		
	}
	
	//Get ManiCategory
	
	public function GetCategory(){
		
		$Category = CategoryList::Select('id','name','Price')->get();
		
		$CategoryList = DB::table('NewCategories')->Select('id','name','image','groupName')->Where('status','1')->get();

		return array("Category"=>$Category,"CategoryList"=>$CategoryList);	
		
	}
	
	
	//Get Users List
	public function GetUsers(){
		$Users = User::Select('id','name','mobile','email','otp','alternate_number','dob','gender')
		               ->whereNotNull('email')
					   ->orderBy('id', 'desc')
		               ->get();	   
				   
		return $Users;
		
	}
	
	public function GetPickupUser(){
		
		$UserList = pickupdeliveryuser::Select('pickupdeliveryusers.id','pickupdeliveryusers.name','pickupdeliveryusers.mobile','email','serviceAreaId','pickupdeliveryusers.warehouseId','Is_active','Pincode.area','Pincode.code','otp')
		                                ->leftjoin('Pincode','Pincode.id', '=', 'pickupdeliveryusers.serviceAreaId')
										->Where('pickupdeliveryusers.name', '!=' , null)
										->Where('pickupdeliveryusers.Is_active', '!=' , 2)
										->orderBy('pickupdeliveryusers.name','ASC')
										//->whereNull('pickupdeliveryusers.serviceAreaId')
		                                ->get();		
										
		return 	$UserList;					
		
	}
	
	//User details
	public function GetUserDetails($id){
		
		$GetUser = User::Select('id','name','mobile','email','image','alternate_number','dob','gender','referral_code','wallet_amount','created_at',DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as join_date'))                 
		                 ->Where('id',$id)
		                 ->get();
						 
		
		
        $GetBookings = Bookings::Select('Bookings.id','Bookings.bookingId','userId','bookingDate','bookingTimeSlot','Bookings.Status','TimeSlots.fromSlots','TimeSlots.toSlots')
                                 ->join('TimeSlots','TimeSlots.id','=','Bookings.bookingTimeSlot')
								 ->Where(['Bookings.userId'=>$id])
								 ->OrderBy('id','desc')
                                 ->get();	

		$Address = UserAddresses::Select('UserAddresses.id','userId','serviceAreaId','Pincode.code','title','flatNo','landmark','address')
								  ->leftjoin('Pincode','Pincode.id','=','UserAddresses.serviceAreaId')
                           		  ->Where('userId',$id)
                                  ->get();
        foreach($Address as $Addr){

          if($Addr->landmark == null){
			  
			  $Addr->landmark = "";
		  }
		  
		}

        $total_orders = Bookings::Where('userId',$id)->count();		
        $pending_orders = Bookings::Where(['userId'=>$id,'Status'=>'CONFIRMED'])->count();	 	
        $complete_order = Bookings::Where(['userId'=>$id,'Status'=>'COMPLETED'])->count();		
        $cancel_order = Bookings::Where(['userId'=>$id,'Status'=>'CANCELLED'])->count();
		
		$order_details = [];
        $stdarr = (object) array();
    	$stdarr->total = $total_orders;
    	$stdarr->pending = $pending_orders;
    	$stdarr->complete = $complete_order;
    	$stdarr->cancel = $cancel_order;
		
		array_push($order_details,$stdarr);
		// echo json_encode($Address);die;
		
         return array("User"=>$GetUser,"Bookings"=>$GetBookings,'UserAddress'=>$Address,'orders'=>$order_details);								 
		//return $GetUser;				 
	}
	
	/************PROMO CODE***************/
	
	
	//New Promocode
	public function NewPromocode($promocode,$discount,$max_amount,$expiry_from,$expiry_to,$no_expiry,$payment_type,$pincode,$description,$image){

		
		if($expiry_from == '' && $expiry_to == ''){
			
			$no_expiry = "Yes";
		}
		
		$input['image'] = time() . '.' . $image->getClientOriginalExtension();
        $destinationPath = public_path('/images/offers');
        $image->move($destinationPath, $input['image']);
		
		$NewPromo = Promocode::insert([
		                       'promocode'=>$promocode,
							   'discount'=>$discount,
							   'maximum_amount'=>$max_amount,
							   'expiry_from'=>$expiry_from,
							   'expiry_to'=>$expiry_to,
							   'no_expiry'=>$no_expiry,
							   'offer_type'=>$payment_type,
							   'images'=>$input['image'],
							   'description'=>$description
		                    ]);
							
		$GetId = Promocode::Select('id')->orderBy('id', 'DESC')->limit(1)->first();	

		if(!empty($pincode)){
			
		
		
         for($i=0;$i<count($pincode);$i++){
			 
			 $PincodePromo = DB::table('promocode_area')->insert([
			  
			                               'promocode_Id'=>$GetId->id,
										   'serviceArea_Id'=>$pincode[$i]
			                           ]);
		 }	

	}		 
		
		return $NewPromo;
	}
	
	//Update Promocode
	public function UpdatePromcode($id,$promocode,$discount,$max_amount,$expiry_from,$expiry_to,$no_expiry,$payment_type,$pincode,$description,$image){
		
		if($image == ''){
			
			$UpdatePromo = Promocode::Where('id',$id)->update([
		                       'promocode'=>$promocode,
							   'discount'=>$discount,
							   'maximum_amount'=>$max_amount,
							   'expiry_from'=>$expiry_from,
							   'expiry_to'=>$expiry_to,
							   'no_expiry'=>$no_expiry,
							   'offer_type'=>$payment_type,
							   'description'=>$description
		                    ]);
							
		if(!empty($pincode)){
           
		   $DeletePromo = DB::table('promocode_area')->Where('promocode_Id',$id)->delete();
           for($i=0;$i<count($pincode);$i++){
			 
			 $PincodePromo = DB::table('promocode_area')->insert([
			  
			                               'promocode_Id'=>$id,
										   'serviceArea_Id'=>$pincode[$i]
			                           ]);
		    }	

		}		
		
		return $UpdatePromo;
			
			
			
		}else{
			
			$input['image'] = time() . '.' . $image->getClientOriginalExtension();
        $destinationPath = public_path('/images/offers');
        $image->move($destinationPath, $input['image']);
			
		 $UpdatePromo = Promocode::Where('id',$id)->update([
		                       'promocode'=>$promocode,
							   'discount'=>$discount,
							   'maximum_amount'=>$max_amount,
							   'expiry_from'=>$expiry_from,
							   'expiry_to'=>$expiry_to,
							   'no_expiry'=>$no_expiry,
							   'offer_type'=>$payment_type,
							   'image'=>$input['image'],
							   'description'=>$description
		                    ]);
							
		if(!empty($pincode)){
           
		   $DeletePromo = DB::table('promocode_area')->Where('promocode_Id',$id)->delete();
           for($i=0;$i<count($pincode);$i++){
			 
			 $PincodePromo = DB::table('promocode_area')->insert([
			  
			                               'promocode_Id'=>$id,
										   'serviceArea_Id'=>$pincode[$i]
			                           ]);
		    }	

		}		
		
		return $UpdatePromo;
		}
		
		
	}
	
	
	
	public function wallet_trasnaction($id){
		
		$Trans_amt = DB::table('wallet_transaction')->Select('wallet_transaction.bookingId','Bookings.bookingId','orderId','transactionId','amount','transation_status','type','payment_date')
		                               ->leftjoin('Bookings','Bookings.id','=','wallet_transaction.bookingId')
		                               // ->join('users','users.id', '=', 'wallet_transaction.userId')
		                               ->where('wallet_transaction.userId',$id)
									   ->get();
									   
			foreach($Trans_amt as $trans){
				
				if($trans->bookingId == null){
					
					$trans->bookingId = "";

				}
				
				    $pay_date  = explode(" ",$trans->payment_date);
		   
					$trans->payment_date = date("d-m-Y", strtotime($pay_date[0]));
			}
			
			return $Trans_amt;
		
	}
	
	
	public function get_function_day(){
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
							  
		return $Bookings;					  
		
	}
	
	public function get_function_week(){
		
		
		$now = Carbon::now();
	   
	   $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->whereBetween('DeliverySuccessDate', [Carbon::now()->startOfWeek(),Carbon::now()->endOfWeek()])
		                      ->get()
							  ->toArray();
							  
		return $Bookings;
	}
	
	public function get_function_month(){
		
		$month = date('m');
	   
	   $now = Carbon::now();
	   
	  $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->whereMonth('DeliverySuccessDate', $month)
		                      ->get()
							  ->toArray();
							  
			return $Bookings;
		
	}
	
	public function get_function_year(){
		
		 $year = date('Y');
		 $now = Carbon::now();
		 $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->whereYear('DeliverySuccessDate', $year)
		                      ->get()
							  ->toArray();
		
		return $Bookings;
	}
	
	
	//Pincode excel download

	public function get_excel_pincode($Bookings,$description){
		
		// if(count($Bookings) != 0){
		Excel::create("".$description."", function($excel) use ($Bookings,$description) {
            $excel->sheet('mySheet', function($sheet) use ($Bookings,$description)
            {   
			    $sheet->row(1, ["".$description.""]);
			    // $sheet->row(2, ["Name : 'fdfdf'"]);
			    // $sheet->row(3, ["Mobile : 'dfjnh'"]);
				
                $sheet->mergeCells('A1:F1');
                // $sheet->mergeCells('A2:D2');
                // $sheet->mergeCells('A3:D3');
				
				$sheet->getStyle('A1:F1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A5', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B5', function($cell) {$cell->setValue('BookindId');   });
                $sheet->cell('C5', function($cell) {$cell->setValue('Name');   });
                $sheet->cell('D5', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('E5', function($cell) {$cell->setValue('Email');   });
                $sheet->cell('F5', function($cell) {$cell->setValue('Booking date');   });
                $sheet->cell('G5', function($cell) {$cell->setValue('Delivery date');   });
                $sheet->cell('H5', function($cell) {$cell->setValue('Time Slots');   });
                $sheet->cell('I5', function($cell) {$cell->setValue('Pincode');   });
                $sheet->cell('J5', function($cell) {$cell->setValue('address');   });
                $sheet->cell('K5', function($cell) {$cell->setValue('quantity');   });
                $sheet->cell('L5', function($cell) {$cell->setValue('Status');   });
                $sheet->cell('M5', function($cell) {$cell->setValue('paymentType');   });
                $sheet->cell('N5', function($cell) {$cell->setValue('totalPayment');   });
                $sheet->cell('O5', function($cell) {$cell->setValue('discount_amount');   });
                $sheet->cell('P5', function($cell) {$cell->setValue('promocode');   });
                $sheet->cell('Q5', function($cell) {$cell->setValue('Cancel reasons');   });
                $sheet->cell('R5', function($cell) {$cell->setValue('Order date');   });
                $sheet->cell('S5', function($cell) {$cell->setValue('Order time');   });
                $sheet->cell('T5', function($cell) {$cell->setValue('Way to pickup date');   });
                $sheet->cell('U5', function($cell) {$cell->setValue('Way to pickup time');   });
                $sheet->cell('V5', function($cell) {$cell->setValue('Pickup success date');   });
                $sheet->cell('W5', function($cell) {$cell->setValue('Pickup success time');   });
                $sheet->cell('X5', function($cell) {$cell->setValue('Way to delivery date');   });
                $sheet->cell('Y5', function($cell) {$cell->setValue('Way to delivery time');   });
                $sheet->cell('Z5', function($cell) {$cell->setValue('delivery date');   });
                $sheet->cell('AA5', function($cell) {$cell->setValue('delivery time');   });
                if (!empty($Bookings)) {
                    foreach ($Bookings as $key => $value) {
						
						if($value['reasons'] == null){
							
							$value['reasons'] = "";
						 }

                        $i= $key+6;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['bookingId']); 
                        $sheet->cell('C'.$i, $value['username']); 
                        $sheet->cell('D'.$i, $value['usermobile']); 
                        $sheet->cell('E'.$i, $value['useremail']); 
                        $sheet->cell('F'.$i, $value['bookingDate']); 
                        $sheet->cell('G'.$i, $value['delivery_date']); 
                        $sheet->cell('H'.$i, $value['fromSlots'].'-'.$value['toSlots']); 
                        $sheet->cell('I'.$i, $value['code']); 
                        $sheet->cell('J'.$i, $value['address']); 
                        $sheet->cell('K'.$i, $value['quantity']); 
                        $sheet->cell('L'.$i, $value['Status']); 
                        $sheet->cell('M'.$i, $value['paymentType']); 
                        $sheet->cell('N'.$i, $value['totalPayment']); 
                        $sheet->cell('O'.$i, $value['discount_amount']); 
                        $sheet->cell('P'.$i, $value['promocode']); 
                        $sheet->cell('Q'.$i, $value['reasons']); 
                        $sheet->cell('R'.$i, $value['confirm_date']); 
                        $sheet->cell('S'.$i, $value['confirm_time']); 
                        $sheet->cell('T'.$i, $value['waypick_date']); 
                        $sheet->cell('U'.$i, $value['waypick_time']); 
                        $sheet->cell('V'.$i, $value['pickup_date']); 
                        $sheet->cell('W'.$i, $value['pickup_time']); 
                        $sheet->cell('X'.$i, $value['waydeli_date']); 
                        $sheet->cell('Y'.$i, $value['waydeli_time']); 
                        $sheet->cell('Z'.$i, $value['deli_date']); 
                        $sheet->cell('AA'.$i, $value['delivery_time']); 
                    }
                }
            });
        })->export('xls');
		// }
		
	}
	
	
	public function get_excel_revunue($Bookings,$description){
		
		// if(count($Bookings) != 0){
		Excel::create("".$description."", function($excel) use ($Bookings,$description) {
            $excel->sheet('mySheet', function($sheet) use ($Bookings,$description)
            {   
			    $sheet->row(1, ["".$description.""]);
			    // $sheet->row(2, ["Name : 'fdfdf'"]);
			    // $sheet->row(3, ["Mobile : 'dfjnh'"]);
				
                $sheet->mergeCells('A1:F1');
                // $sheet->mergeCells('A2:D2');
                // $sheet->mergeCells('A3:D3');
				
				$sheet->getStyle('A1:F1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A5', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B5', function($cell) {$cell->setValue('BookindId');   });
                $sheet->cell('C5', function($cell) {$cell->setValue('Name');   });
                $sheet->cell('D5', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('E5', function($cell) {$cell->setValue('Email');   });
                $sheet->cell('F5', function($cell) {$cell->setValue('Booking date');   });
                $sheet->cell('G5', function($cell) {$cell->setValue('Delivery date');   });
                $sheet->cell('H5', function($cell) {$cell->setValue('Time Slots');   });
                $sheet->cell('I5', function($cell) {$cell->setValue('quantity');   });
                $sheet->cell('J5', function($cell) {$cell->setValue('Status');   });
                $sheet->cell('K5', function($cell) {$cell->setValue('paymentType');   });
                $sheet->cell('L5', function($cell) {$cell->setValue('totalPayment');   });
                $sheet->cell('M5', function($cell) {$cell->setValue('discount_amount');   });
                $sheet->cell('N5', function($cell) {$cell->setValue('promocode');   });
                if (!empty($Bookings)) {
                    foreach ($Bookings as $key => $value) {
						
						if($value['reasons'] == null){
							
							$value['reasons'] = "";
						 }

                        $i= $key+6;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['bookingId']); 
                        $sheet->cell('C'.$i, $value['username']); 
                        $sheet->cell('D'.$i, $value['usermobile']); 
                        $sheet->cell('E'.$i, $value['useremail']); 
                        $sheet->cell('F'.$i, $value['bookingDate']); 
                        $sheet->cell('G'.$i, $value['delivery_date']); 
                        $sheet->cell('H'.$i, $value['fromSlots'].'-'.$value['toSlots']);  
                        $sheet->cell('I'.$i, $value['quantity']); 
                        $sheet->cell('J'.$i, $value['Status']); 
                        $sheet->cell('K'.$i, $value['paymentType']); 
                        $sheet->cell('L'.$i, $value['totalPayment']); 
                        $sheet->cell('M'.$i, $value['discount_amount']); 
                        $sheet->cell('N'.$i, $value['promocode']); 

                    }
                }
            });
        })->export('xls');
		// }
		
	}
	
	
	
	
	public function get_wallet_report($transaction,$description){
		
		
		$encode= json_decode( json_encode($transaction), true);
		
		
		
		
		Excel::create("wallet-report-".date('d-m-Y')."", function($excel) use ($encode,$description) {
            $excel->sheet('mySheet', function($sheet) use ($encode,$description)
            {   
			    $sheet->row(1, ["".$description.""]);
				
                $sheet->mergeCells('A1:D1');
				
				$sheet->getStyle('A1:D1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A4', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B4', function($cell) {$cell->setValue('Name');   });
                $sheet->cell('C4', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('D4', function($cell) {$cell->setValue('OrderId');   });
                $sheet->cell('E4', function($cell) {$cell->setValue('TransactionId');   });
                $sheet->cell('F4', function($cell) {$cell->setValue('Amount');   });
                $sheet->cell('G4', function($cell) {$cell->setValue('Type');   });
                $sheet->cell('H4', function($cell) {$cell->setValue('transation_status');   });
                $sheet->cell('I4', function($cell) {$cell->setValue('payment_mode');   });
                $sheet->cell('J4', function($cell) {$cell->setValue('Bank Name');   });
                $sheet->cell('K4', function($cell) {$cell->setValue('Payment date');   });
                $sheet->cell('L4', function($cell) {$cell->setValue('Payment Time');   });
                if (!empty($encode)) {
                    foreach ($encode as $key => $value) {
						
                        $i= $key+5;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['name']); 
                        $sheet->cell('C'.$i, $value['mobile']); 
                        $sheet->cell('D'.$i, $value['orderId']); 
                        $sheet->cell('E'.$i, $value['transactionId']); 
                        $sheet->cell('F'.$i, $value['amount']); 
                        $sheet->cell('G'.$i, $value['type']); 
                        $sheet->cell('H'.$i, $value['transation_status']); 
                        $sheet->cell('I'.$i, $value['payment_mode']); 
                        $sheet->cell('J'.$i, $value['bank_name']); 
                        $sheet->cell('K'.$i, $value['payment_date']); 
                        $sheet->cell('L'.$i, $value['payment_time']); 
                        
                    }
                }
            });
        })->export('xls');
		
		
	}
	
	
	
	public function get_cloth_day(){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
		
	}
	
	
	public function get_cloth_week(){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW())  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
	}
	
	public function get_cloth_month(){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
	}
	
	public function get_cloth_year(){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
	}
	
	
	
	
	public function get_excel_clothes($query_fnc,$description,$Vendorname){
		
		
		
		Excel::create("clothes-report-".date('d-m-Y')."", function($excel) use ($query_fnc,$description,$Vendorname) {
            $excel->sheet('mySheet', function($sheet) use ($query_fnc,$description,$Vendorname)
            {   
			    $sheet->row(1, ["".$description.""]);
				
                $sheet->mergeCells('A1:D1');
				
				$sheet->getStyle('A1:D1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);

				$sheet->row(2, ["".$Vendorname.""]);
				$sheet->cell('A2', function($cell) {$cell->setValue('Username:');   });
				$sheet->cell('B2', $Vendorname); 

				$sheet->getStyle('A2:B2')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  12,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));

                $j=1;
                $sheet->cell('A4', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B4', function($cell) {$cell->setValue('Date');   });
                $sheet->cell('C4', function($cell) {$cell->setValue('BookingID');   });
                $sheet->cell('D4', function($cell) {$cell->setValue('Quantity');   });
                $sheet->cell('E4', function($cell) {$cell->setValue('Total Payment');   });
                 if (!empty($query_fnc)) {
                    foreach ($query_fnc as $key => $value) {
						
                        $i= $key+5;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['start_time']); 
                        $sheet->cell('C'.$i, $value['bookingId']); 
                        $sheet->cell('D'.$i, $value['quantity']); 
                        $sheet->cell('E'.$i, $value['totalPayment']); 
                        
                    }
                }
            });
        })->export('xls');
		
	}
	
	
	
	
	public function get_excel_clothes_reports($query_fnc,$description){
		
		
		
		Excel::create("clothes-report-".date('d-m-Y')."", function($excel) use ($query_fnc,$description) {
            $excel->sheet('mySheet', function($sheet) use ($query_fnc,$description)
            {   
			    $sheet->row(1, ["".$description.""]);
				
                $sheet->mergeCells('A1:D1');
				
				$sheet->getStyle('A1:D1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A4', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B4', function($cell) {$cell->setValue('Clothes');   });
                $sheet->cell('C4', function($cell) {$cell->setValue('Category Name');   });
                $sheet->cell('D4', function($cell) {$cell->setValue('Price');   });
                $sheet->cell('E4', function($cell) {$cell->setValue('Quantity');   });
                $sheet->cell('F4', function($cell) {$cell->setValue('Total Orders');   });
                $sheet->cell('G4', function($cell) {$cell->setValue('Amount');   });
                if (!empty($query_fnc)) {
                    foreach ($query_fnc as $key => $value) {
						
                        $i= $key+5;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['name']); 
                        $sheet->cell('C'.$i, $value['categoty_name']); 
                        $sheet->cell('D'.$i, $value['Price']); 
                        $sheet->cell('E'.$i, $value['quantity']); 
                        $sheet->cell('F'.$i, $value['orders']); 
                        $sheet->cell('G'.$i, $value['amount']); 
                        
                    }
                }
            });
        })->export('xls');
		
	}
	
	
/****************************************** Outlet function ***********************************/



	public function get_function_pin_day($outletId){
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
							  
		return $Bookings;					  
		
	}
	
	
	
	public function get_function_pin_week($outletId){
		
		
		$now = Carbon::now();
	   
	   $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->whereBetween('DeliverySuccessDate', [Carbon::now()->startOfWeek(),Carbon::now()->endOfWeek()])
		                      ->get()
							  ->toArray();
							  
		return $Bookings;
	}
	
	public function get_function_pin_month($outletId){
		
		$month = date('m');
	   
	   $now = Carbon::now();
	   
	  $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->whereMonth('DeliverySuccessDate', $month)
		                      ->get()
							  ->toArray();
							  
			return $Bookings;
		
	}
	
	public function get_function_pin_year($outletId){
		
		 $year = date('Y');
		 $now = Carbon::now();
		 $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->whereYear('DeliverySuccessDate', $year)
		                      ->get()
							  ->toArray();
		
		return $Bookings;
	}



/*********************** Outlet clothes function ***********************************/

     
     public function get_outlet_cloth_day($outletId){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$outletId."'  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
		
	}

	
		public function get_outlet_cloth_week($outletId){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND Bookings.warehouseId='".$outletId."'  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
	}
	
	public function get_outlet_cloth_month($outletId){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$outletId."'  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
	}
	
	public function get_outlet_cloth_year($outletId){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$outletId."'  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
	}
	
	
	function download_orders($type){
		
		
		if($type == 'total'){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      // ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  // ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
							  
		// return $Bookings;
		
		$description = "Total orders (".date('d-m-Y').")";
	   
		$Reports = $this->get_excel_pincode($Bookings,$description);
		
		}if($type == 'Completed'){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  // ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
							  
		// return $Bookings;
		
		$description = "Completed orders (".date('d-m-Y').")";
	   
		$Reports = $this->get_excel_pincode($Bookings,$description);
			
		}elseif($type == 'Pending'){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'CONFIRMED'])
							  // ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
							  
		// return $Bookings;
		
		$description = "Pending orders (".date('d-m-Y').")";
	   
		$Reports = $this->get_excel_pincode($Bookings,$description);
			
		}elseif($type == 'Cancelled'){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'CANCELLED'])
							  // ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
							  
		// return $Bookings;
		
		$description = "Cancelled orders (".date('d-m-Y').")";
	   
		$Reports = $this->get_excel_pincode($Bookings,$description);
			
		}
		
		
		
	}
	
	
	public function get_out_cloth_day($outletId){
		
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$outletId."'  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
		
	}
	
	
	public function get_out_cloth_week($outletId){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND Bookings.warehouseId='".$outletId."'  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
	}
	
	public function get_out_cloth_month($outletId){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$outletId."'  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
	}
	
	public function get_out_cloth_year($outletId){
		
		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$outletId."'  Group by Booking_Items.categoryId"); 
		
		return json_decode( json_encode($day_rep), true);
		
	}
	
	
	
	function pickuser_graph_rep($id,$type,$pickupId){
		
		if($type == 'graph'){
			
			switch ($id) {
			case "1":
			
			$Rep = DB::select("SELECT COUNT(*)as orders,SUM(quantity) as qty,DAY(PickupSuccessDate) as ord_date,MONTH(PickupSuccessDate) as ord_month, YEAR(PickupSuccessDate) as ord_year FROM Bookings Where   PickupSuccess ='1' AND pickupDeliveryUserId ='".$pickupId."' AND DAY(PickupSuccessDate) = DAY(NOW()) AND MONTH(PickupSuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(PickupSuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' GROUP BY MONTH(PickupSuccessDate), DAY(PickupSuccessDate),  YEAR(PickupSuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($Rep as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($Rep);
			
			break;
			
			case "2":
			
			$Rep = DB::select("SELECT COUNT(*)as orders,SUM(quantity) as qty,DAY(PickupSuccessDate) as ord_date,MONTH(PickupSuccessDate) as ord_month, YEAR(PickupSuccessDate) as ord_year FROM Bookings Where   PickupSuccess ='1' AND pickupDeliveryUserId ='".$pickupId."' AND  YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND Status='COMPLETED' GROUP BY MONTH(PickupSuccessDate), DAY(PickupSuccessDate),  YEAR(PickupSuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($Rep as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($Rep);
			
			break;
			
			case "3":
			
			$Rep = DB::select("SELECT COUNT(*)as orders,SUM(quantity) as qty,DAY(PickupSuccessDate) as ord_date,MONTH(PickupSuccessDate) as ord_month, YEAR(PickupSuccessDate) as ord_year FROM Bookings Where   PickupSuccess ='1' AND pickupDeliveryUserId ='".$pickupId."' AND MONTH(PickupSuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(PickupSuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' GROUP BY MONTH(PickupSuccessDate), DAY(PickupSuccessDate),  YEAR(PickupSuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($Rep as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($Rep);
			
			break;
			
			case "4":
			
			
			$Rep = DB::select("SELECT COUNT(*)as orders,SUM(quantity) as qty,DAY(PickupSuccessDate) as ord_date,MONTH(PickupSuccessDate) as ord_month, YEAR(PickupSuccessDate) as ord_year FROM Bookings Where   PickupSuccess ='1' AND pickupDeliveryUserId ='".$pickupId."' AND  YEAR(PickupSuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' GROUP BY MONTH(PickupSuccessDate), DAY(PickupSuccessDate),  YEAR(PickupSuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($Rep as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($Rep);
			
			break;
			
			
			default:
				echo "Invalid data";
			}
		  }else{
		
		switch ($id) {
			case "1":
			
			$report_1 = DB::SELECT("select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where pickupDeliveryUserId='".$pickupId."' AND Bookings.PickupSuccess='1' AND PickupSuccess='1' AND DAY(PickupSuccessDate) = DAY(NOW()) AND MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where DeliveryUserId='".$pickupId."' AND DeliverySuccess='1' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate	) = YEAR(NOW())  order by id desc");
		
		
		    $description = "pickup delivery today report (".date('d-m-Y').")";			 
			$query_fnc =  json_decode( json_encode($report_1), true);
			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
			
			break;
			
			case "2":
			
			$report_1 = DB::SELECT("select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where pickupDeliveryUserId='".$pickupId."' AND Bookings.PickupSuccess='1' AND PickupSuccess='1' AND YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) UNION ALL select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where DeliveryUserId='".$pickupId."' AND DeliverySuccess='1' AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())  order by id desc");
		
		
		    $description = "pickup delivery week report (".date('d-m-Y').")";			 
			$query_fnc =  json_decode( json_encode($report_1), true);
			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
			
			break;
			
			case "3":
			
			$report_1 = DB::SELECT("select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where pickupDeliveryUserId='".$pickupId."' AND Bookings.PickupSuccess='1' AND PickupSuccess='1' AND MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where DeliveryUserId='".$pickupId."' AND DeliverySuccess='1'  AND MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  order by id desc");
		
		
		    $description = "pickup delivery month report (".date('d-m-Y').")";			 
			$query_fnc =  json_decode( json_encode($report_1), true);
			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
			
			break;
			
			case "4":
			
			case "3":
			
			$report_1 = DB::SELECT("select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where pickupDeliveryUserId='".$pickupId."' AND Bookings.PickupSuccess='1' AND PickupSuccess='1' AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where DeliveryUserId='".$pickupId."' AND DeliverySuccess='1'  AND YEAR(DeliverySuccessDate) = YEAR(NOW())  order by id desc");
		
		
		    $description = "pickup delivery month report (".date('d-m-Y').")";			 
			$query_fnc =  json_decode( json_encode($report_1), true);
			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
			
			break;
			
			
			default:
				echo "Invalid data";
			
		}
	  }
		
	}
	
	
	function PickupDayGraph($id){
		
		$TodayRep = DB::select("SELECT COUNT(*)as orders,SUM(quantity) as qty,DAY(PickupSuccessDate) as ord_date,MONTH(PickupSuccessDate) as ord_month, YEAR(PickupSuccessDate) as ord_year FROM Bookings Where   PickupSuccess ='1' AND pickupDeliveryUserId ='".$id."' AND DAY(PickupSuccessDate) = DAY(NOW()) AND MONTH(PickupSuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(PickupSuccessDate) = YEAR(CURRENT_DATE()) GROUP BY MONTH(PickupSuccessDate), DAY(PickupSuccessDate),  YEAR(PickupSuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($TodayRep as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($TodayRep);
		
	}
	
	
	
	function search_pickup_down($fromdate,$todate,$pickupId){
		
		$report_1 = DB::SELECT("select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where pickupDeliveryUserId='".$pickupId."' AND Bookings.PickupSuccess='1' AND PickupSuccess='1' AND DATE(Bookings.PickupSuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' UNION ALL select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where DeliveryUserId='".$pickupId."' AND DeliverySuccess='1'  AND DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  order by id desc");
		
		
		    $description = "pickup delivery report (".date('d-m-Y').")";			 
			$query_fnc =  json_decode( json_encode($report_1), true);
			$Reports = $this->get_excel_pincode($query_fnc,$description);
		
	}
	
	
	
	function out_vendor_report($vendorId){
		
		
		$Today = DB::select("select  COUNT(Booking_Items.id) as orders,groupName,SUM(Booking_Items.quantity) * CategoryList.Price as amount,SUM(Booking_Items.quantity) as quantity,NewCategories.name from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where Bookings.VendorUserId='".$vendorId."'  AND StartJob='2' AND DAY(Bookings.job_completed) = DAY(NOW()) AND MONTH(Bookings.job_completed) = MONTH(Bookings.job_completed) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) Group by Booking_Items.categoryId");
		
		
		$Week = DB::select("select  COUNT(Booking_Items.id) as orders,groupName,SUM(Booking_Items.quantity) * CategoryList.Price as amount,SUM(Booking_Items.quantity) as quantity,NewCategories.name from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where Bookings.VendorUserId='".$vendorId."'  AND StartJob='2' AND  YEARWEEK(Bookings.job_completed) = YEARWEEK(NOW()) Group by Booking_Items.categoryId");
		
		
		
		$Month = DB::select("select  COUNT(Booking_Items.id) as orders,groupName,SUM(Booking_Items.quantity) * CategoryList.Price as amount,SUM(Booking_Items.quantity) as quantity,NewCategories.name from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where Bookings.VendorUserId='".$vendorId."'  AND StartJob='2' AND MONTH(Bookings.job_completed) = MONTH(Bookings.job_completed) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) Group by Booking_Items.categoryId");
		
		
		$Year = DB::select("select  COUNT(Booking_Items.id) as orders,groupName,SUM(Booking_Items.quantity) * CategoryList.Price as amount,SUM(Booking_Items.quantity) as quantity,NewCategories.name from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where Bookings.VendorUserId='".$vendorId."'  AND StartJob='2' AND  YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) Group by Booking_Items.categoryId");
		
		
		
		$today_rep = DB::Select("select COUNT(id) as orders,VendorUserId,SUM(totalPayment) as total,SUM(quantity) as qty from Bookings Where VendorUserId='".$vendorId."' AND  StartJob='2' AND DAY(Bookings.job_completed) = DAY(NOW()) AND MONTH(Bookings.job_completed) = MONTH(Bookings.job_completed) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) group by VendorUserId");
		
		$week_rep = DB::Select("select COUNT(id) as orders,VendorUserId,SUM(totalPayment) as total,SUM(quantity) as qty from Bookings Where VendorUserId='".$vendorId."' AND StartJob='2' AND YEARWEEK(Bookings.job_completed) = YEARWEEK(NOW()) group by VendorUserId");
		
		$month_rep = DB::Select("select COUNT(id) as orders,VendorUserId,SUM(totalPayment) as total,SUM(quantity) as qty from Bookings Where VendorUserId='".$vendorId."' AND  StartJob='2' AND MONTH(Bookings.job_completed) = MONTH(Bookings.job_completed) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) group by VendorUserId");
		
		
		$year_rep = DB::Select("select COUNT(id) as orders,VendorUserId,SUM(totalPayment) as total,SUM(quantity) as qty from Bookings Where VendorUserId='".$vendorId."' AND  StartJob='2' AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) group by VendorUserId");
		
		
		 return array('Day'=>$Today,'Week'=>$Week,'Month'=>$Month,'Year'=>$Year,'today_rep'=>$today_rep,'week_rep'=>$week_rep,'month_rep'=>$month_rep,'year_rep'=>$year_rep);
		
	}
	
	
	function search_vendor_rep($fromdate,$todate,$vendorId){
		
		$report = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y')as start_time,bookingId,quantity,totalPayment from Bookings  Where Bookings.VendorUserId='".$vendorId."'  AND StartJob='2' AND DATE(Bookings.job_completed) BETWEEN '".$fromdate."' AND '".$todate."'  ORDER BY start_time");
		
		return $report;
	}
	
	
	function search_vendor_download($fromdate,$todate,$vendorId,$VendorName){
		
		$year_rep = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y') as start_time,bookingId,quantity,totalPayment from Bookings  Where StartJob='2' AND Bookings.VendorUserId='".$vendorId."' AND DATE(Bookings.job_completed) BETWEEN '".$fromdate."' AND '".$todate."' AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE())   ORDER BY start_time"); 
			$newfromDate = date("d-m-Y", strtotime($fromdate));
			$newtoDate = date("d-m-Y", strtotime($todate));
			
			$description = "Vendor cloths reports  (From - ".$newfromDate." -To- ".$newtoDate.")";			 
			$query_fnc =  json_decode( json_encode($year_rep), true);
			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description,$VendorName);
		
	}
	
	
	public function get_UserNotUse($User,$description){
		
		
		$encode= json_decode( json_encode($User), true);
		
		
		
		
		Excel::create("User-report", function($excel) use ($encode,$description) {
            $excel->sheet('mySheet', function($sheet) use ($encode,$description)
            {   
			    $sheet->row(1, ["".$description.""]);
				
                $sheet->mergeCells('A1:D1');
				
				$sheet->getStyle('A1:D1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A4', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B4', function($cell) {$cell->setValue('Name');   });
                $sheet->cell('C4', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('D4', function($cell) {$cell->setValue('Email');   });
                $sheet->cell('E4', function($cell) {$cell->setValue('last_booking');   });
                if (!empty($encode)) {
                    foreach ($encode as $key => $value) {
						
                        $i= $key+5;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['name']); 
                        $sheet->cell('C'.$i, $value['mobile']); 
                        $sheet->cell('D'.$i, $value['email']); 
                        $sheet->cell('E'.$i, $value['last_booking']);  
                        
                    }
                }
            });
        })->export('xls');
		
		
	}
	
	
	
	
	function active_nonactive_rep($Bookings,$description){
		
		
		Excel::create("".$description."", function($excel) use ($Bookings,$description) {
            $excel->sheet('mySheet', function($sheet) use ($Bookings,$description)
            {   
			    $sheet->row(1, ["".$description.""]);

                $sheet->mergeCells('A1:F1');

				
				$sheet->getStyle('A1:F1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A5', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B5', function($cell) {$cell->setValue('name');   });
                $sheet->cell('C5', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('D5', function($cell) {$cell->setValue('Email');   });
                $sheet->cell('E5', function($cell) {$cell->setValue('Alternate number');   });
                $sheet->cell('F5', function($cell) {$cell->setValue('DOB');   });
                $sheet->cell('G5', function($cell) {$cell->setValue('Gender');   });
                $sheet->cell('H5', function($cell) {$cell->setValue('Referral code');   });
                $sheet->cell('I5', function($cell) {$cell->setValue('Wallet amount');   });
                $sheet->cell('J5', function($cell) {$cell->setValue('Last booking');   });
                $sheet->cell('K5', function($cell) {$cell->setValue('Join date');   });

                if (!empty($Bookings)) {
                    foreach ($Bookings as $key => $value) {
						

                        $i= $key+6;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['name']); 
                        $sheet->cell('C'.$i, $value['mobile']); 
                        $sheet->cell('D'.$i, $value['email']); 
                        $sheet->cell('E'.$i, $value['alternate_number']); 
                        $sheet->cell('F'.$i, $value['dob']); 
                        $sheet->cell('G'.$i, $value['gender']); 
                        $sheet->cell('H'.$i, $value['referral_code']); 
                        $sheet->cell('I'.$i, $value['wallet_amount']); 
                        $sheet->cell('J'.$i, $value['last_booking']); 
                        $sheet->cell('K'.$i, $value['created_at']); 
                    }
                }
            });
        })->export('xls');
		
	}
	
	
	
}
















?>