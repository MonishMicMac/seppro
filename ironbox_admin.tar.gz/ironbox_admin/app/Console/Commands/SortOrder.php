<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\User;
class SortOrder extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sort:list';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Order Sort';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        User::Where('id',4)->update(['name'=>'Sma']);
    }
}
