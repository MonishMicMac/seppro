<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CreditPoints extends Model
{
    protected $table='CreditPoints';
}
