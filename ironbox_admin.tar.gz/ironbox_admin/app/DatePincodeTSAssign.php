<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DatePincodeTSAssign extends Model
{
    protected $table='DatePincodeTSAssign';
}
