<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Http\Requests;
use App\User;
use App\pickupdeliveryuser;
use App\PushNotifications;
use App\IroningVendor;
use App\Admin;
use App\ServiceAreas;
use App\UserAddresses;
use App\TimeSlots;
use App\Pincode;
use App\Promocode;
use App\Categories;
use App\CategoryList;
use App\Bookings;
use App\BookingItems;
use App\Warehouses;
use App\CustomerSupport;
use App\CommonFunctions;
use App\DatePincodeTSAssign;
use App\LeaveAssign;
use App\CreditPoints;
use Carbon\Carbon;
use Auth;
use Mail;
use DateTime;
use Validator;
use DB;
use PDF;

class AdminController extends Controller
{
/**
* Create a new controller instance.
*
* @return void
*/
public function __construct()
{
    $this->middleware('auth:admin');
}

/**
* Show the application dashboard.
*
* @return \Illuminate\Http\Response
*/
public function index()
{


    $data = DB::select("select COUNT(Bookings.id) as orders,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id GROUP BY Bookings.bookingTimeSlot");

    $newdata = DB::select("select  COUNT(Booking_Items.id) as orders,groupName,Booking_Items.categoryId,NewCategories.name from Booking_Items inner join NewCategories on Booking_Items.categoryId = NewCategories.id inner join CategoryList on NewCategories.categoryId = CategoryList.id Where CategoryList.id='1' Group by Booking_Items.categoryId");

// echo json_encode($newdata);die;


    $price = DB::select("select CategoryList.id,CategoryList.name,CategoryList.Price,SUM(Booking_Items.quantity) as qty from  Booking_Items inner join NewCategories on Booking_Items.categoryId = NewCategories.id inner join CategoryList on NewCategories.categoryId = CategoryList.id   GROUP BY CategoryList.id" );



// $data3 = DB::select("select Bookings.id from Bookings inner join Booking_Items on Bookings.id = Booking_Items.bookingId Where Bookings.Status='COMPLETED'  GROUP BY Booking_Items.bookingId");

// foreach($price as $pri){

// $pri->price_amount = $pri->qty * $pri->Price; 

// }

    $User = DB::select("select COUNT(Bookings.userId) as total,users.id,users.name from users inner join Bookings on users.id = Bookings.userId Where Bookings.created_at < NOW() - INTERVAL 30 DAY Group by users.id");

// echo json_encode($User);die;


    $current_date = date("d-m-Y");


    $pickup = DB::select("select order_delivery.userId,pickupdeliveryusers.name,pickupdeliveryusers.mobile from order_delivery inner join pickupdeliveryusers on order_delivery.userId = pickupdeliveryusers.id  Where service_date='".$current_date."'"); 


    $Users = User::Select('id')->whereNotNull('email')->count();
    $PickupUser = pickupdeliveryuser::Select('id')->Where('name','!=',null)->Where('Is_active','!=',2)->count();
    $Ironing = IroningVendor::Select('id')->Where('name','!=',null)->Where('Is_active','!=',2)->count();
    $Bookings = Bookings::Select('id')->Where(['Status'=>'COMPLETED'])->count();
    $Cancel = Bookings::Select('id')->Where(['Status'=>'CANCELLED'])->count();
    $Confirm = Bookings::Select('id')->Where(['Status'=>'CONFIRMED'])->count();
    $warehours = Warehouses::Select('id')->where('status','1')->count();
    $Slots = TimeSlots::Select('id')->count();
    $Orders = Bookings::Select('id')->count();
    $inactive_users = DB::select("select count(*) as total from users where last_booking IS NULL AND name IS NOT NULL");
    $active_user = DB::select("select count(*) as total from users where last_booking IS NOT NULL");

    $Inactive = $inactive_users[0]->total;
    $active = $active_user[0]->total;

    return view('admin',['Users' => $Users,"PickupUser"=>$PickupUser,"Ironing"=>$Ironing,"Bookings"=>$Bookings,'pickup'=>$pickup,'Cancel'=>$Cancel,'Confirm'=>$Confirm,'warehours'=>$warehours,'Slots'=>$Slots,'Orders'=>$Orders,'active'=>$active,'Inactive'=>$Inactive]);
}


//Order List View
public function OrderList(Request $Request){

    $BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess','ConfirmOrder','CancelDate','cancelReason','CancelReason.reasons','StartJob')
    ->join('users','users.id','=','Bookings.userId')
    ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
    ->leftjoin('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
    ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
// ->Where(['Bookings.Status'=>'CONFIRMED'])
    ->orderBy('Bookings.id', 'desc')
    ->paginate(10);
    foreach($BookingsList as $Book){

        if($Book->ConfirmOrder == 1){
            $Book->Status='BOOKING CONFIRM';
        }

        if($Book->WaytoPickup == 1){
            $Book->Status='WAY TO PICKUP';
        }

        if($Book->PickupSuccess == 1){
            $Book->Status='PICKUPED';
        }
        if($Book->StartJob == 1){
            $Book->Status='IRONING STARTED';
        }

        if($Book->StartJob == 2){
            $Book->Status='IRONING COMPLETED';
        }

        if($Book->WaytoDelivery == 1){
            $Book->Status='WAY TO DELIVERY';
        }

        if($Book->DeliverySuccess == 1){
            $Book->Status='COMPLETED';
        }


    }

    return view('OrderList',['Bookings' => $BookingsList]);
}


public function SearchOrderList(Request $Request){

    $fromdate_in = $Request->fromdate;
    $todate_in = $Request->todate;
    $bookId = $Request->bookId;

    if($Request->input('orderlist') == 'download'){


        $fromdate = date("y-m-d", strtotime($fromdate_in));
        $todate = date("y-m-d", strtotime($todate_in));

        $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','Bookings.pick_date','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
        ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
        ->join('users','users.id', '=', 'Bookings.userId')
        ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
        ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
        ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
        ->join('Pincode','Pincode.id','=','Bookings.service_area' )
        ->whereRaw("DATE(pick_date) BETWEEN '".$fromdate."' AND '".$todate."'")
        ->get()
        ->toArray();

        $description = "Order List (".$fromdate_in." - ".$todate_in.")";

        $CommonFunction = new CommonFunctions();
        $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);die;

    }

    $fromdate = date("y-m-d", strtotime($fromdate_in));
    $todate = date("y-m-d", strtotime($todate_in));

    if(empty($fromdate_in) && empty($todate_in) && empty($bookId)){


        $BookingsList = [];	
        return view('OrderList',['Bookings' => $BookingsList]);die;
    }

    if($fromdate_in && $todate_in ){

        $BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess','ConfirmOrder','CancelDate','cancelReason','CancelReason.reasons','StartJob')
        ->join('users','users.id','=','Bookings.userId')
        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
        ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
        ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
        ->whereRaw("DATE(pick_date) BETWEEN '".$fromdate."' AND '".$todate."'")
        ->orderBy('Bookings.id', 'desc')
        ->paginate(10);		

        foreach($BookingsList as $Book){

            if($Book->ConfirmOrder == 1){
                $Book->Status='BOOKING CONFIRM';
            }

            if($Book->WaytoPickup == 1){
                $Book->Status='WAY TO PICKUP';
            }

            if($Book->PickupSuccess == 1){
                $Book->Status='PICKUPED';
            }
            if($Book->StartJob == 1){
                $Book->Status='IRONING STARTED';
            }

            if($Book->StartJob == 2){
                $Book->Status='IRONING COMPLETED';
            }

            if($Book->WaytoDelivery == 1){
                $Book->Status='WAY TO DELIVERY';
            }

            if($Book->DeliverySuccess == 1){
                $Book->Status='COMPLETED';
            }


        }

        return view('OrderList',['Bookings' => $BookingsList->appends(Input::except('page'))]);
    }elseif($bookId){

        $pre= "IB".$bookId;

        $get_id = Bookings::Select('id','bookingId')->Where('bookingId',$pre)->first();

        if(count($get_id) == 0 ){

            $BookingsList = [];	
            return view('OrderList',['Bookings' => $BookingsList]);die;
        }

        $BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess','ConfirmOrder','CancelDate','cancelReason','CancelReason.reasons','StartJob')
        ->join('users','users.id','=','Bookings.userId')
        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
        ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
        ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
        ->Where(['Bookings.id'=>$get_id->id])
        ->orderBy('Bookings.id', 'desc')
        ->paginate(10);

        foreach($BookingsList as $Book){

            if($Book->ConfirmOrder == 1){
                $Book->Status='BOOKING CONFIRM';
            }

            if($Book->WaytoPickup == 1){
                $Book->Status='WAY TO PICKUP';
            }

            if($Book->PickupSuccess == 1){
                $Book->Status='PICKUPED';
            }
            if($Book->StartJob == 1){
                $Book->Status='IRONING STARTED';
            }

            if($Book->StartJob == 2){
                $Book->Status='IRONING COMPLETED';
            }

            if($Book->WaytoDelivery == 1){
                $Book->Status='WAY TO DELIVERY';
            }

            if($Book->DeliverySuccess == 1){
                $Book->Status='COMPLETED';
            }


        }

        return view('OrderList',['Bookings' => $BookingsList->appends(Input::except('page'))]);			

    }else{			



        $BookingsList = [];	
        return view('OrderList',['Bookings' => $BookingsList]);
    }
}

public function CompletedOrders(Request $Request){


    $BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess','ConfirmOrder','CancelDate','cancelReason','CancelReason.reasons')
    ->join('users','users.id','=','Bookings.userId')
    ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
    ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
    ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
    ->Where(['Bookings.Status'=>'COMPLETED'])
    ->orderBy('Bookings.id', 'desc')
    ->get();
    foreach($BookingsList as $Book){

        if($Book->ConfirmOrder == 1){
            $Book->Status='BOOKING CONFIRM';
        }

        if($Book->WaytoPickup == 1){
            $Book->Status='WAY TO PICKUP';
        }

        if($Book->PickupSuccess == 1){
            $Book->Status='PICKUPED';
        }

        if($Book->WaytoDelivery == 1){
            $Book->Status='WAY TO DELIVERY';
        }

        if($Book->DeliverySuccess == 1){
            $Book->Status='COMPLETED';
        }


    }
// echo json_encode($BookingsList);die;		 				
    return view('orders.completed-order',['Bookings' => $BookingsList]);

}


//Check Order Status
public function OrderConfirm(Request $Request){


    $BookingsList = Bookings::Select('id')->where('id',$Request->id)
    ->Update(['Status' => 'Order Confirm']);



    $BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','Status')
    ->join('users','users.id','=','Bookings.userId')
    ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
    ->get();

    return view('OrderList',['Bookings' => $BookingsList]);

}

public function ViewBookings(Request $Request){

    $id = $Request->id;

    $CommonFunction = new CommonFunctions();

    $BookingsDetails = $CommonFunction->ViewBook($id);

    $Bookings = $BookingsDetails['Bookings'];
    $DeliveyuserDetails = $BookingsDetails['Deliveyuser'];
    $BookingItems = $BookingsDetails['GetOrder'];
    $IroningVendor = $BookingsDetails['Ironing'];
    $Rating = $BookingsDetails['Rating'];
// echo json_encode($Bookings);die;
// if(!empty($BookingItems)){

// echo "hii";
// }die;

//echo $IroningVendor;die;
// echo  json_encode($IroningVendor);die;

// echo $newboo =$BookingsDetails['Bookings'];die;
// $newboo =$BookingsDetails['Bookings'][0]->DeliveryUserId;

    return view('admin.ViewBookings',['Bookings' => $Bookings,'Deliveyuser'=>$DeliveyuserDetails,"GetOrders"=>$BookingItems,"Ironing"=>$IroningVendor,'Rating'=>$Rating]);	
}


//View PickupUser List
public function PickupUser(Request $Request){

    $CommonFunction = new CommonFunctions();

    $PickupUsers = $CommonFunction->GetPickupUser();

    return view('admin.PickupUserList',['User' => $PickupUsers]);

}

//EditPickupUser
public function EditPickupUser(Request $Request,$id){


    $CommonFunction = new CommonFunctions();

    $PickupUsers = $CommonFunction->EditPickupUser($id);

    $Pincode = $CommonFunction->GetPincode();


    $warehouse = DB::table('warehouses')->Select('id','name')->Where('status','1')->get();

    $PickupUser = $PickupUsers['GetDetails'];

    $bookings = $PickupUsers['Bookings'];
    $SelectAreas = $PickupUsers['SelectAreas'];
    $DeliveryService = $PickupUsers['Delivery'];
    $pickup_count = $PickupUsers['pickup_count'];
    $delivery_count = $PickupUsers['delivery_count'];

    return view('admin.EditPickupUser',['User' => $PickupUser, 'Code' => $Pincode,'houses'=>$warehouse,'UserBookings'=>$bookings,"Area"=>$SelectAreas,"Delivery"=>$DeliveryService,'pickup_count'=>$pickup_count,'delivery_count'=>$delivery_count]);

}

//AddService Man
public function AddNewService(Request $Request){

    $userid = $Request->id;
    $warehousId = $Request->warehousId;
    $pincode = $Request->pincode;
    $active_user = $Request->active_user1;
    $comments = $Request->comments;



    $UpdateService = pickupdeliveryuser::Select('id','warehouseId','serviceAreaId')
    ->Where('id',$userid)
    ->update(['warehouseId'=>$warehousId, 'serviceAreaId'=>$pincode]);

    $User = pickupdeliveryuser::Select('id','name','email')->Where('id',$userid)->first();
    $Email = $User->email;

    if($comments){
        $admin_comments = DB::table('block_users')->insert(['userId'=>$userid,'type'=>'Pickup','comments'=>$comments]);
    }

    if($active_user){

        $ActiveUser = pickupdeliveryuser::Select('id','Is_active')->Where('id',$userid)->update(['Is_active'=>1]);


        if($comments){
            Mail::send([], [], function($message) use ($Email,$comments) {
                $message->from('customercare@ironbox.co.in');
                $message->to($Email);
                $message->subject('IronBox active status');

                $mail = $comments;

                $message->setBody(

                    $mail

                    ,'text/html');
            });
        }

        $CommonFunction = new CommonFunctions();

        $PickupUsers = $CommonFunction->GetPickupUser();

        return view('admin.PickupUserList',['User' => $PickupUsers]);

    }else{

        $ActiveUser = pickupdeliveryuser::Select('id','Is_active')->Where('id',$userid)->update(['Is_active'=>0]);
        if($comments){
            Mail::send([], [], function($message) use ($Email,$comments) {
                $message->from('customercare@ironbox.co.in');
                $message->to($Email);
                $message->subject('IronBox active status');

                $mail = $comments;

                $message->setBody(

                    $mail

                    ,'text/html');
            });
        }
        $CommonFunction = new CommonFunctions();

        $PickupUsers = $CommonFunction->GetPickupUser();

        return view('admin.PickupUserList',['User' => $PickupUsers]);
    }


}

public function GetServicearea(Request $Request){

    $id = $Request->id;
    $GetArea = Pincode::Select('id','area','code')->Where(['warehouseId'=>$id])->get();
    return $GetArea;

}


//View Ironman List
public function IroningVendor(Request $Request){

    $UserList = IroningVendor::Select('id','name','mobile','email','dob','Is_active')
    ->Where('name','!=',null)
    ->Where('Is_active', '!=' , 2)
    ->orderBy('name','ASC')
    ->get();

    return view('admin.IroningVendorList',['User' => $UserList]);
//echo $UserList;

}

//DeleteIroningVendor

public function DeleteIroningVendor (Request $Request){
    $vendorid=$Request->id;

    $delete=DB::table('IroningVendors')
    ->where('id', $vendorid)
    ->update(['Is_active' => 2]);

    return back();
}

//view service area
public function ServiceArea(Request $Request){

    $PincodeCode = Pincode::Select('id','warehouseId','area','code')->where('status','1')->get();

    $Warehouses = Warehouses::Select('id','name','address','latitude','longitude')->Where('status','1')->get();

    return view('admin.ServiceArea',['code' => $PincodeCode,'Outlet'=>$Warehouses]);
}


//Add ServiceArea 
public function AddServiceArea(Request $Request){

    $warehousename = $Request->warehousename;
    $pincode = $Request->pincode;
    $areaname = $Request->areaname;

    $AddPincode = Pincode::insert([
        'warehouseId' =>$warehousename,
        'area' => $areaname,
        'code' => $pincode

    ]);

    $PincodeCode = Pincode::Select('id','warehouseId','area','code')->where('status','1')->get();

    $Warehouses = Warehouses::Select('id','name','address','latitude','longitude')->Where('status','1')->get();

    return view('admin.ServiceArea',['code' => $PincodeCode,'Outlet'=>$Warehouses]);
}


public function UpdateService(Request $Request,$id){

    $get_pincode = Pincode::select('id','warehouseId','area','code')->where('id',$id)->get();

    $Warehouses = Warehouses::Select('id','name')->Where('status','1')->get();

    return view('admin.edit-service',['pincode'=>$get_pincode,'outlet'=>$Warehouses]);
}

public function UpdatePincodeArea(Request $Request){

    $id = $Request->id;
    $pincode = $Request->pincode;
    $areaname = $Request->areaname;
    $warehousename = $Request->warehousename;

    $update = Pincode::Where('id',$id)->update([
        'warehouseId'=>$warehousename,
        'area'=>$areaname,
        'code'=>$pincode
    ]);

    $PincodeCode = Pincode::Select('id','warehouseId','area','code')->where('status','1')->get();

    $Warehouses = Warehouses::Select('id','name','address','latitude','longitude')->Where('status','1')->get();

    return view('admin.ServiceArea',['code' => $PincodeCode,'Outlet'=>$Warehouses]);

}

//Check Pincode

public function CheckPincode(Request $Request){

    $checkPin = Pincode::Where('code',$Request->pincode)->count();

    if($checkPin > 0){

        return 1;

    }else{

        return 0;
    }

}

//Edit CheckPincode
public function EditCheckPincode(Request $Request){

    $checkPin = Pincode::Where('id',$Request->id)->get();

    $outlet = Warehouses::get();

// echo json_encode(array("pincode"=>$checkPin,"outlet"=>$outlet));	

    echo $checkPin;
// return  json_encode(array('pincode'=>$checkPin,'outlet'=>$outlet));
}


//Edit pincode
public function EditPincode(Request $Request){

    $id = $Request->id;
    $Warehouses = $Request->warehousename;
    $Pincode = $Request->pincode;

    echo $Pincode; echo $Warehouses;

}

public function EditPinCheck(Request $Request){

//echo $Request->id;

    $checkPin = Pincode::Where(['code' => $Request->pincode,'id' =>$Request->id ])
//->Where('id', '!=' , $Request->id)
    ->count();
    if($checkPin > 0){
        echo "1";

    }else{

        $check = Pincode::Where(['code' => $Request->pincode])
//->Where('id', '!=' , $Request->id)
        ->count();
        if($check){	

            echo "2";

        }else{

            echo "3";
        } 
    }
}

//Edit Save pincode

public function EditPincodeSave(Request $Request){

    $id =  $Request->id;
    $pincode = $Request->pincode;
    $Eareaname = $Request->Eareaname;
    $warehouse = $Request->warehousename;

    $UpdatePin = Pincode::Where('id',$id)->update([
        'warehouseId' => $warehouse,
        'area' => $Eareaname,
        'code' => $pincode

    ]);

    $PincodeCode = Pincode::Select('id','warehouseId','area','code')->where('status','1')->get();
    $Warehouses = Warehouses::Select('id','name','address','latitude','longitude')->Where('status','1')->get();

    return view('admin.ServiceArea',['code' => $PincodeCode,'Outlet'=>$Warehouses]);
}


//DeletePincode
public function DeletePincode(Request $Request){

    $id = $Request->id;

    $DeletePincode = Pincode::Select('id')->Where(['id' => $id])->update(['status'=>'2']);  

    $PincodeCode = Pincode::Select('id','warehouseId','area','code')->where('status','1')->get();

    $Warehouses = Warehouses::Select('id','name','address','latitude','longitude')->Where('status','1')->get();

    return view('admin.ServiceArea',['code' => $PincodeCode,'Outlet'=>$Warehouses]);


}

//TimeSlots view

public function TimeSlot(Request $Request){

    $TimeSlot = TimeSlots::Where('status','1')->get(); 

    foreach($TimeSlot as $Slots){

//$fromtime  =  explode(" ",$Slots->fromSlots);

        $Slots->TimeSlot = $Slots->fromSlots." "."-"." ".$Slots->toSlots;
    }		

//echo $TimeSlot; die;

    return view('admin.TimeSlot',['slot' => $TimeSlot]);

}


//View Slot
public function ViewSlot(Request $Request){

    $id = $Request->id;

    $TimeSlot = TimeSlots::Where('id',$id)->first(); 

    echo $TimeSlot;

}


//Add Time Slot
public function AddSlot(Request $Request){

    $fromSlot = $Request->Fslot;
    $toSlots = $Request->Tslot;

    $AddSlot = TimeSlots::insert([
        'fromSlots'=>$fromSlot,
        'toSlots'=>$toSlots,
    ]);
    $TimeSlot = TimeSlots::Where('status','1')->get(); 	   
    foreach($TimeSlot as $Slots){

        $Slots->TimeSlot = $Slots->fromSlots." "."-"." ".$Slots->toSlots;
    }		

    return view('admin.TimeSlot',['slot' => $TimeSlot]);	   

}

//Delete Slot
public function DeleteSlot(Request $Request){

    $id = $Request->id;


    $Delete = TimeSlots::Where('id',$id)->update(['status'=>'2']);
    $TimeSlot = TimeSlots::Where('status',1)->get(); 
    foreach($TimeSlot as $Slots){

        $Slots->TimeSlot = $Slots->fromSlots." "."-"." ".$Slots->toSlots;
    }		

    return view('admin.TimeSlot',['slot' => $TimeSlot]);
}

//Update Slot
public function UpdateEditSlot(Request $Request){

    $id = $Request->id;
    $fromSlot = $Request->Fslot;
    $toSlots = $Request->Tslot;

    $UpdateSlot = TimeSlots::Where('id',$id)->update([
        'fromSlots' => $fromSlot,
        'toSlots' => $toSlots
    ]);

    $TimeSlot = TimeSlots::Where('status',1)->get();  
    foreach($TimeSlot as $Slots){

        $Slots->TimeSlot = $Slots->fromSlots." "."-"." ".$Slots->toSlots;
    }		

    return view('admin.TimeSlot',['slot' => $TimeSlot]);							


}

//Vendor Active
Public function IroningVendorActive(Request $Request){

    $id = $Request->id;

    $CommonFunction = new CommonFunctions();
    $newresponse = $CommonFunction->IroningVendorIsActive($id);
    return  $newresponse;
}

//Vendor Details
public function VendorDetails(Request $Request,$id){

    $CommonFunction = new CommonFunctions();
    $response = $CommonFunction->VendorInfo($id);

    $VendorDetail = $response['Vendor'];
    $GetBookings = $response['Bookings'];
    $jobs = $response['jobs'];

    return view('admin.VendorDetails',['VendorInfo'=>$VendorDetail,'Bookings'=>$GetBookings,'jobs'=>$jobs]);
}

//Active Pickup User
public function PickUpuserActive(Request $Request){

    $id = $Request->id;

    $CommonFunction = new CommonFunctions();
    $newresponse = $CommonFunction->PickupUserIsActive($id);
    return  $newresponse;

}

public function PickUpuserBlock(Request $Request){

    $active_user = $Request->active_user;
    $comments = $Request->comments;
    $userid = $Request->userid;

// echo $active_user;die;

    $User = pickupdeliveryuser::Select('id','name','email')->Where('id',$userid)->first();
    $Email = $User->email;

    if($active_user == 1){

        $ActiveUser = pickupdeliveryuser::Select('id','Is_active')->Where('id',$userid)->update(['Is_active'=>0]);

        Mail::send([], [], function($message) use ($Email,$comments) {
            $message->from('customercare@ironbox.co.in');
            $message->to($Email);
            $message->subject('IronBox active status');

            $mail = $comments;

            $message->setBody(

                $mail

                ,'text/html');
        });

        $CommonFunction = new CommonFunctions();

        $PickupUsers = $CommonFunction->GetPickupUser();

        return view('admin.PickupUserList',['User' => $PickupUsers]);

    }else{

        $ActiveUser = pickupdeliveryuser::Select('id','Is_active')->Where('id',$userid)->update(['Is_active'=>1]);

        Mail::send([], [], function($message) use ($Email,$comments) {
            $message->from('customercare@ironbox.co.in');
            $message->to($Email);
            $message->subject('IronBox active status');

            $mail = $comments;

            $message->setBody(

                $mail

                ,'text/html');
        });

        $CommonFunction = new CommonFunctions();

        $PickupUsers = $CommonFunction->GetPickupUser();

        return view('admin.PickupUserList',['User' => $PickupUsers]);
    }

}

public function VendorBlock(Request $Request){

    $active_user = $Request->active_user;
    $comments = $Request->comments;
    $userid = $Request->userid;

    $User = IroningVendor::Select('id','name','email')->Where('id',$userid)->first();
// $Email = $User->email;

    if($active_user == 1){

        $ActiveUser = IroningVendor::Select('id','Is_active')->Where('id',$userid)->update(['Is_active'=>0]);

// Mail::send([], [], function($message) use ($Email,$comments) {
// $message->from('customercare@ironbox.co.in');
// $message->to($Email);
// $message->subject('IronBox active status');

// $mail = $comments;

// $message->setBody(

// $mail

// ,'text/html');
// });

        $UserList = IroningVendor::Select('id','name','mobile','email','dob','Is_active')->get();

        return view('admin.IroningVendorList',['User' => $UserList]);

    }else{

        $ActiveUser = IroningVendor::Select('id','Is_active')->Where('id',$userid)->update(['Is_active'=>1]);

// Mail::send([], [], function($message) use ($Email,$comments) {
// $message->from('customercare@ironbox.co.in');
// $message->to($Email);
// $message->subject('IronBox active status');

// $mail = $comments;

// $message->setBody(

// $mail

// ,'text/html');
// });

        $UserList = IroningVendor::Select('id','name','mobile','email','dob','Is_active')->get();

        return view('admin.IroningVendorList',['User' => $UserList]);
    }

}


//Order Delivery
public function DeliveryOrderList(Request $Request){

    $CommonFunction = new CommonFunctions();
    $Order = $CommonFunction->DeliveryOrder();

    return view('admin.DeliveryOrder',['DeliveryOrder'=>$Order]);

}


public function EditPickupUserSave(Request $Request){

    echo $Request->pincode;
}


public function GetDemo(Request $Request){

    $id = '1';
    $CommonFunction = new CommonFunctions();



//$CommonFunction->send($id);

    $newresponse = $CommonFunction->send($id);

    echo json_encode($newresponse);


}

///Map View
public function DeliveryManLocation(Request $Request){

    return view('admin.map');
}


public function GetDeliveryLocation(Request $Request){

    $Get = pickupdeliveryuser::Select('name','latitude','longitude')
    ->orderBy('id', 'ASC')
    ->get();
    foreach($Get as $add){

        $value [] =array($add->name,$add->latitude,$add->longitude); 
    }			


    return $value;		  
}

public function GetRoutes(Request $Request){

    $UserId = $Request->id;      
// $UserId = 3;      


    $GetWarehouse = pickupdeliveryuser::select('pickupdeliveryusers.id','warehouses.address as title','warehouses.latitude as lat','warehouses.longitude as lng')
    ->join('warehouses','warehouses.id','=','pickupdeliveryusers.warehouseId')
    ->Where('pickupdeliveryusers.id',$UserId)
    ->get();
    foreach($GetWarehouse as $Warehouse){

        $Warehouse->type = "outlet";
    }		


    $js_decode = json_decode($GetWarehouse);							 

    $pickup =  pickupdeliveryuser::select('id','latitude as lat','longitude as lng')->Where('pickupdeliveryusers.id',$UserId)->get();

// $jss_decode = json_decode($pickup);

    $newarr = [];

    $pick_date = date("d-m-Y");
    $delivery_date = date("Y-m-d");

    $order = DB::select("select Bookings.id,Bookings.userId,Bookings.pickupDeliveryUserId,Bookings.DeliveryUserId,Bookings.bookingId,Bookings.warehouseId,Bookings.bookingTimeSlot ,OrderAssign,Bookings.Status,Bookings.paidStatus,UserAddresses.latitude,UserAddresses.longitude,UserAddresses.	address,warehouses.latitude as war_lat,warehouses.longitude as war_lng from Bookings inner join UserAddresses on UserAddresses.id=Bookings.addressId inner join warehouses on warehouses.id=Bookings.warehouseId where Bookings.id in (SELECT Bookings.id as booking_id from Bookings  where pickupDeliveryUserId= '".$UserId."' AND bookingDate='".$pick_date."' AND Status='CONFIRMED' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$UserId."' AND delivery_date='".$delivery_date."' AND Status='CONFIRMED' AND Bookings.cancelReason IS NULL ) order by sort_order asc");

    foreach($order as $ord){
        $stdarr = (object) array();




        $stdarr->id = $ord->id;
        $stdarr->lat = $ord->latitude;
        $stdarr->lng = $ord->longitude;
        $stdarr->title = $ord->address;

        if($ord->OrderAssign == 0){

            $stdarr->type = 'C';			

        }else{

            $stdarr->type = 'CN'; 
        }

        array_push($newarr,$stdarr);
    }

// echo $order;	
    $merge_arr = [];

    $merge_arr  = array_merge($js_decode,$newarr);

    return array("location"=>$merge_arr,"pickup"=>$pickup);

}

public function DeliveryRoutes(Request $Request,$id){

    return view('admin.map',['id'=>$id]);

}

//Categories

public function Categories(Request $Request){

    $Categories = CategoryList::Select('id','name','price','Qty')->get();
    return view('admin.Categories',['CategoryList' => $Categories]);


}


//Add Category
public function AddMainCategory(Request $Request){

    $name = $Request->cname;
    $price = $Request->price;
    $quantity = $Request->quantity;


    $CommonFunction = new CommonFunctions();

    $newresponse = $CommonFunction->AddMainCategory($name,$price,$quantity);

    $Categories = CategoryList::Select('id','name','price','Qty')->get();
    return view('admin.Categories',['CategoryList' => $Categories]);

}


//Edit Category
public function EditCategory(Request $Request){

    $id = $Request->id;
    $CommonFunction = new CommonFunctions();
    $newresponse = $CommonFunction->EditMainCategory($id);

//$GetCategory = CategoryList::Select('id','name','Price','Qty')->Where(['id'=>$id])->get();

    return $newresponse;  
}


//Update Categories
public function UpdateCategory(Request $Request){

    $id = $Request->id;
    $name = $Request->cname;
    $price = $Request->price;
    $qty = $Request->quantity;	
    $CommonFunction = new CommonFunctions();
    $newresponse = $CommonFunction->UpdateMainCategory($id,$name,$price,$qty);
//echo "success";

    $Categories = CategoryList::Select('id','name','price','Qty')->get();
    return view('admin.Categories',['CategoryList' => $Categories]);

}

public function delete_main_category(Request $Request){

    $id = $Request->id;

    $delete = CategoryList::Where('id',$id)->update(['status'=>'2']);

    $Categories = CategoryList::Select('id','name','price','Qty')->Where('status','1')->get();
    return view('admin.Categories',['CategoryList' => $Categories]);

}


public function SaveSubCategory(Request $Request){

    $MainCategory = $Request->MainCategory;
    $name = $Request->name;
    $image = $Request->file('image');
    $groupname = $Request->groupname;

    $input['image'] = time() . '.' . $image->getClientOriginalExtension();
    $destinationPath = public_path('/images/Icons/');
    $image->move($destinationPath, $input['image']);

    $Category = DB::table('NewCategories')->insert([
        'categoryId' =>$MainCategory,
        'name'=>$name,
        'image'=>$input['image'],
        'groupName'=>$groupname
    ]);
    $CommonFunction = new CommonFunctions();
    $Categories = $CommonFunction->GetCategory();



    $CategoryList = $Categories['Category'];
    $Items = $Categories['CategoryList'];

    return view('admin.SubCategory',['Category'=>$CategoryList,'ItemsList'=>$Items]);					  

}

//GetGroup Name
public function GetGroupName(Request $Request){

    $SubCategory = DB::table('SubCategory')->Select('id','name')->Where('categoryId',$Request->id)->get();
    return $SubCategory;
}

//Add SubCategories
public function SubCategories(Request $Request){

    $CommonFunction = new CommonFunctions();
    $Categories = $CommonFunction->GetCategory();

    $CategoryList = $Categories['Category'];
    $Items = $Categories['CategoryList'];

    return view('admin.SubCategory',['Category'=>$CategoryList,'ItemsList'=>$Items]);
}


//EditItems
public function EditCategoryItems(Request $Request,$id){

    $GetItems = DB::table('NewCategories')
    ->Select('id','categoryId','name','image','groupName')
    ->Where('id',$id)
    ->get();
    foreach($GetItems as $Items){
        $CategoryId = $Items->categoryId;
    }

    $GetGroupName = DB::table('SubCategory')->Where('categoryId',$CategoryId)->get();
    $CommonFunction = new CommonFunctions();
    $Categories = $CommonFunction->GetCategory();

    $CategoryList = $Categories['Category'];

    return view('admin.EditCategoryItems',['Category'=>$CategoryList,'Items'=>$GetItems,'Group'=>$GetGroupName]);					
}


//UpdateCategory Items
public function UpdateCategoryItems(Request $Request){

    $id = $Request->id;
    $MainCategory = $Request->MainCategory;
    $name = $Request->name;
    $groupname= $Request->groupname;
    $image = $Request->file('image');


    if(!$image){

        $UpdateItems = DB::table('NewCategories')->Where('id',$id)->update([
            'categoryId'=>$MainCategory,
            'name'=>$name,
            'groupName'=>$groupname

        ]);

        $CommonFunction = new CommonFunctions();
        $Categories = $CommonFunction->GetCategory();

        $CategoryList = $Categories['Category'];
        $Items = $Categories['CategoryList'];

        return view('admin.SubCategory',['Category'=>$CategoryList,'ItemsList'=>$Items]);

    }else{
        $image = $Request->file('image');  
        $input['image'] = time() . '.' . $image->getClientOriginalExtension();
        $destinationPath = public_path('/images/Icons');
        $image->move($destinationPath, $input['image']);

        $UpdateItems = DB::table('NewCategories')->Where('id',$id)->update([
            'categoryId'=>$MainCategory,
            'name'=>$name,
            'image'=>$input['image'],
            'groupName'=>$groupname

        ]);

        $CommonFunction = new CommonFunctions();
        $Categories = $CommonFunction->GetCategory();

        $CategoryList = $Categories['Category'];
        $Items = $Categories['CategoryList'];

        return view('admin.SubCategory',['Category'=>$CategoryList,'ItemsList'=>$Items]);

    }
}

//delete category
public function delete_sub_category(Request $Request){


    $id = $Request->id;
    $update_status = DB::table('NewCategories')->Where('id',$id)->update(['status'=>2]);
    $CommonFunction = new CommonFunctions();
    $Categories = $CommonFunction->GetCategory();

    $CategoryList = $Categories['Category'];
    $Items = $Categories['CategoryList'];

    return view('admin.SubCategory',['Category'=>$CategoryList,'ItemsList'=>$Items]);

}

//Users List
public function UsersList(Request $Request){

    $CommonFunction = new CommonFunctions();
    $List = $CommonFunction->GetUsers();

    return view('admin.UsersList',['UserList'=>$List]);
}

//User Details
public function UserDetails(Request $Request,$id){

    $CommonFunction = new CommonFunctions();
    $Details = $CommonFunction->GetUserDetails($id);

    $UserDetails = $Details['User'];
    $BookingsDetails = $Details['Bookings'];
    $UserAddr = $Details['UserAddress'];
    $order = $Details['orders'];
// echo $UserAddr;die;

    return view('admin.UserDetails',['GetUserDetails'=>$UserDetails,'BookingsList'=>$BookingsDetails,'Address'=>$UserAddr,'order'=>$order]);
}

//Order Assign
public function OrderAssign(Request $Request,$id){

    $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.warehouseId','Bookings.userId','users.name as username','users.mobile','users.image','Bookings.pickupDeliveryUserId','Bookings.DeliveryUserId','pickupdeliveryusers.id as pickup_user','pickupdeliveryusers.name as pickup_username','Bookings.addressId','Bookings.warehouseId','UserAddresses.landmark','UserAddresses.address','Pincode.id as ServiceAreaId')
    ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
    ->join('users','users.id','=','Bookings.userId')
    ->leftjoin('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
    ->join('Pincode','Pincode.id', '=', 'UserAddresses.serviceAreaId')
    ->Where(['Bookings.id'=>$id])
    ->first();

    $deliveryuser = Bookings::Select('Bookings.id as book_id','Bookings.bookingId','Bookings.DeliveryUserId','pickupdeliveryusers.id as delivery_user','pickupdeliveryusers.name as delivery_username','Bookings.bookingTimeSlot','Bookings.bookingDate','TimeSlots.fromSlots','TimeSlots.toSlots')	
    ->leftjoin('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.DeliveryUserId')
    ->join('TimeSlots','TimeSlots.id','=','Bookings.bookingTimeSlot')
    ->Where(['Bookings.id'=>$id])
    ->first();								   

    $GetArea = pickupdeliveryuser::Select('id','name','serviceAreaId')
    ->Where(['warehouseId'=>$Bookings->warehouseId,'Is_active'=>1])		
    ->get();										   
    return view('admin.AssignDelivery',['Assign'=>$Bookings,'Area'=>$GetArea,'delivery'=>$deliveryuser]);		

}


/*****************************************PROMO CODE***********************/

//view promocode

public function AddPromocode(Request $Request){


    $GetPromo = Promocode::Select('id','promocode','discount','maximum_amount','offer_type','images')->Where('status',1)->get();
    $GetPincode = Pincode::Select('id','area','code','status')->Where('status',1)->get();


    return view('admin.Promocode',['Promocode'=>$GetPromo,'Pincode'=>$GetPincode]);

}

//New Promocode
public function AddNewPromo(Request $Request){

    $promocode = $Request->promocode;
    $discount  = $Request->discount;
    $max_amount  = $Request->max_amount;
    $expiry_from  = $Request->expiry_from;
    $expiry_to  = $Request->expiry_to;
    $no_expiry  = $Request->no_expiry;
    $payment_type  = $Request->payment_type;
    $pincode  = $Request->pincode;
    $description  = $Request->description;
//$image  = $Request->image;


    $image = $Request->file('image');  


//print_r($pincode);die;

    $CommonFunction = new CommonFunctions();
    $response = $CommonFunction->NewPromocode($promocode,$discount,$max_amount,$expiry_from,$expiry_to,$no_expiry,$payment_type,$pincode,$description,$image);


    $GetPincode = Pincode::Select('id','area','code','status')->Where('status',1)->get();
    $GetPromo = Promocode::Select('id','promocode','discount','maximum_amount')->Where('status',1)->get();
    return view('admin.Promocode',['Promocode'=>$GetPromo,'Pincode'=>$GetPincode]);

}

//Edit promocode
public function EditPromoCode(Request $Request,$id){

    $GetCode = Promocode::Select('id','promocode','discount','maximum_amount','expiry_from','expiry_to','no_expiry','payment_type','offer_type','description','images')
    ->Where('id',$id)
    ->get();
    $SelectAreas = DB::table('promocode_area')->Select('id','promocode_Id','serviceArea_Id')->Where(['promocode_Id'=>$id])->get();		

    $GetPincode = Pincode::Select('id','area','code','status')->Where('status',1)->get();		
    return view('admin.EditPromocode',['Promocode'=>$GetCode,'Pincode'=>$GetPincode,'Area'=>$SelectAreas]);				  
}

//Update Promocode
public function UpdatePromo(Request $Request){

    $id = $Request->id;
    $promocode = $Request->promocode;
    $discount  = $Request->discount;
    $max_amount  = $Request->max_amount;
    $expiry_from  = $Request->expiry_from;
    $expiry_to  = $Request->expiry_to;
    $no_expiry  = $Request->no_expiry;
    $payment_type  = $Request->payment_type;
    $pincode  = $Request->pincode;
    $description  = $Request->description;
    $image = $Request->file('image'); 


    $CommonFunction = new CommonFunctions();
    $response = $CommonFunction->UpdatePromcode($id,$promocode,$discount,$max_amount,$expiry_from,$expiry_to,$no_expiry,$payment_type,$pincode,$description,$image);

    $GetPincode = Pincode::Select('id','area','code','status')->Where('status',1)->get();
    $GetPromo = Promocode::Select('id','promocode','discount','maximum_amount')->Where('status',1)->get();
    return view('admin.Promocode',['Promocode'=>$GetPromo,'Pincode'=>$GetPincode]);
}


//Delete promocode
public function DeletePromo(Request $Request){

    $id = $Request->id;

    $DeletePromo = Promocode::Select('id')->Where('id',$id)->update(['status'=>2]);


    $GetPromo = Promocode::Select('id','promocode','discount','maximum_amount','offer_type')->Where('status',1)->get();
    $GetPincode = Pincode::Select('id','area','code','status')->Where('status',1)->get();


    return view('admin.Promocode',['Promocode'=>$GetPromo,'Pincode'=>$GetPincode]);

}


//check promo code
public function CheckPromocode(Request $Request){

    $promocode = $Request->promocode;

    $CheckPromo = Promocode::Select('id','promocode')->Where('promocode',$promocode)->count();

    return $CheckPromo;

}

//EditCheckPromocode
public function EditCheckPromocode(Request $Request){

    $promo_code = $Request->promocode;
    $id = $Request->id;
//return $id;die;
    $used_promo = DB::table('promocode')->where(['promocode'=>$promo_code,'id'=>$id])->count();

    if($used_promo > 0){

        echo "1"; 
    }else{

        $check_promo = DB::table('promocode')->where('promocode',$promo_code)->count();
        if($check_promo > 0){
            echo "2";
        }else{
            echo "3";
        } 

    }

}


//AssignPickup
public function AssignPickup(Request $Request){

    $pickup_user = $Request->pickup_user;
    $bookingId = $Request->bookingId;

    $update =  Bookings::Select('id','pickupDeliveryUserId')->Where('id',$bookingId)->update(['pickupDeliveryUserId'=>$pickup_user]);

    $CommonFunction = new CommonFunctions();
    $Order = $CommonFunction->DeliveryOrder();

    return view('admin.DeliveryOrder',['DeliveryOrder'=>$Order]);
}

//AssignDelivery
public function AssignDelivery(Request $Request){

    $bookingId = $Request->bookingId;
    $delivery_user = $Request->delivery_user;

// echo $delivery_user;die;

    $update =  Bookings::Select('id','DeliveryUserId')->Where('id',$bookingId)->update(['DeliveryUserId'=>$delivery_user]);

    $CommonFunction = new CommonFunctions();
    $Order = $CommonFunction->DeliveryOrder();

    return view('admin.DeliveryOrder',['DeliveryOrder'=>$Order]);
}

//Manage Outlet
public function Outlet(Request $Request){

    $GetOutlet = Warehouses::Select('id','name','address','latitude','longitude')->Where('status','1')->get();

    return view('admin.Outlet',['Outlet'=>$GetOutlet]);
}

//Add Outlet
public function SaveOutlet(Request $Request){

    $name = $Request->outletname;
    $authorizedperson = $Request->authorizedperson;
    $email = $Request->email;
    $password = bcrypt($Request->password);
    $address = $Request->address;
    $latitude = $Request->latitude;
    $longitude = $Request->longitude;
    $phone_number = $Request->phone_number;
    $manager_name = $Request->manager_name;
    $manager_email = $Request->manager_email;
    $manager_mobile = $Request->manager_mobile;


    $validator = Validator::make($Request->all(), [
        'email'=>'required|email|unique:warehouses'
    ]);

    if ($validator->fails()) {
        return redirect()->route('get.outlet')->withErrors($validator)->withInput();
    }

    try{

        $Outlet = Warehouses::insert([
            'name'=>$name,
            'authorized_person'=>$authorizedperson,
            'address'=>$address,
            'email'=>$email,
            'phoneNumber'=>$phone_number,
            'password'=>$password,
            'latitude'=>$latitude,
            'longitude'=>$longitude,
            'manager_name'=>$manager_name,
            'manager_email'=>$manager_email,
            'manager_mobile'=>$manager_mobile
        ]);
    }catch (\Illuminate\Database\QueryException  $ex) {

        return redirect()->route('get.outlet');

        die;
    }

    $GetOutlet = Warehouses::Select('id','name','address','latitude','longitude')->Where('status','1')->get();
    return view('admin.Outlet',['Outlet'=>$GetOutlet]);
}

//View Outlet
public function ViewOutlet(Request $Request,$id){

    $id = $Request->id;

// $GetOutlet = Warehouses::Select('id','name','address','latitude','longitude')->Where('id',$id)->first();

    $GetOutlet = Warehouses::Select('id','name','address','email','latitude','longitude','authorized_person','phoneNumber','manager_name','manager_email','manager_mobile')->Where(['id'=>$id,'status'=>'1'])->get();

    return view('admin.EditOutlet',['Outlet'=>$GetOutlet]);

}

public function UpdateOutlet(Request $Request){

    $id = $Request->id;
    $name = $Request->outletname;
    $authorizedperson = $Request->authorizedperson;

// echo $authorizedperson;die;
    $email = $Request->email;
    $address = $Request->address;
    $latitude = $Request->latitude;
    $longitude = $Request->longitude;
    $phone_number = $Request->phone_number;
    $manager_name = $Request->manager_name;
    $manager_email = $Request->manager_email;
    $manager_mobile = $Request->manager_mobile;  

    $validator = Validator::make($Request->all(), [

        'email'  =>  'required|email|unique:warehouses,email,'.$id,
    ]);


    if ($validator->fails()) {
        return redirect()->route('view.outlet',['id'=>$Request->id])->withErrors($validator)->withInput();

    }
    try{

        $UpdateWarehouses = DB::table('warehouses')->Where('id',$id)->update([
            'name'=>$name,
            'authorized_person'=>$authorizedperson,
            'address'=>$address,
            'email'=>$email,
            'phoneNumber'=>$phone_number,
            'latitude'=>$latitude,
            'longitude'=>$longitude,
            'manager_name'=>$manager_name,
            'manager_email'=>$manager_email,
            'manager_mobile'=>$manager_mobile
        ]);

    }catch (\Illuminate\Database\QueryException  $ex) {

        return redirect()->route('get.outlet');  

        die;
    }
    $GetOutlet = Warehouses::Select('id','name','address','latitude','longitude')->Where('status','1')->get();
    return view('admin.Outlet',['Outlet'=>$GetOutlet]);									  
}

public function DeleteOutlet(Request $Request){

    $id = $Request->id; 

    $Outlet = Warehouses::Select('id')->Where('id',$id)->update(['status'=>'2']);
    $GetOutlet = Warehouses::Select('id','name','address','latitude','longitude')->Where('status','1')->get();
    return view('admin.Outlet',['Outlet'=>$GetOutlet]);
}


//Customer support
public function CustomerSupport(Request $Request){

    $Support= CustomerSupport::Select('CustomerSupport.id','userId','complaint_id','users.name','users.mobile','Comments','complaints_type','Is_open',DB::raw('DATE_FORMAT(CustomerSupport.createdAt, "%d-%m-%Y") as comp_date'))
    ->join('users','users.id','=','CustomerSupport.userId')
    ->orderBy('CustomerSupport.id','desc')
    ->get();

    $complaint_type  = DB::table('compliant_type')->select('id','compliant_name')->get();	
    return view('admin.CustometSupport',['Customer'=>$Support,'complaint'=>$complaint_type]);

}

public function Addcomplaints(Request $Request){

    $mobile = $Request->mobile;

    $user = User::Where('mobile',$mobile)->first();

    if(count($user) == 0){

        $Support= CustomerSupport::Select('CustomerSupport.id','userId','complaint_id','users.name','users.mobile','Comments','complaints_type','Is_open',DB::raw('DATE_FORMAT(CustomerSupport.createdAt, "%d-%m-%Y") as comp_date'))
        ->join('users','users.id','=','CustomerSupport.userId')
        ->orderBy('CustomerSupport.id','desc')
        ->get();
        session()->flash('error_message', 'Invalid mobile number');
        $complaint_type  = DB::table('compliant_type')->select('id','compliant_name')->get();	
        return view('admin.CustometSupport',['Customer'=>$Support,'complaint'=>$complaint_type]);

    }
    $complaintId = 'COM'.mt_rand(100000000, 999999999);
    $Support = CustomerSupport::insert([
        'UserId' => $user->id,
        'complaint_id'=>$complaintId,
        'Comments' => $Request->complaints,
        'complaints_type'=>$Request->type_complaints
    ]);
    $Data = User::Select('id','name','mobile','email')->Where('id',$user->id)->first();

    $sender='customercare@ironbox.co.in';
    $name = $Data->name;
    $mobile = $Data->mobile;
    $email = $Data->email;
    $content = $Request->complaints;  

    Mail::send([], [], function($message) use ($sender,$name,$mobile,$email,$content,$complaintId) {
        $message->from($email);
        $message->to($sender);
        $message->subject('Ironbox customer complaints');

        $mail = "<html lang='en'>
        <head>
        <style>
        .block{width: 450px;margin: 0 auto;padding: 12px;border:1px solid #000;}
        .left{float:left;}
        .top_head{display: inline-block;width:100%;}
        .top_table{width:100%;}
        .right{float:left;position:relative;left:100px}
        .logo{float: left;}
        .logo img{width:54px;height:50px;}
        .addr{width:200px;}
        p{padding:0; margin:0;}
        h5,h3{padding:0; margin:0;}
        .mr15{margin-top:15px;}
        .border{border: 1px dashed #000; margin-top:15px;}
        .pickup {text-align:center;}
        tr.line td {border-top:1pt solid black;}
        .head_title p{text-align:center;font-weight:bold;}
        .tcenter{text-align:center;}
        .top{padding-top: 27px;}
        </style>
        </head>
        <body>
        <div class='block'>
        <div class='top_head'>
        <div class='head_title'>
        <p>Customer complaints</p>
        </div>
        <div class='logo'>
        <img src='http://139.59.37.241/Ironman/public/images/ironbox.png'>
        </div>
        <div class='top_table'>
        <table style='margin-left: 15%;'>
        <tr>
        <td><strong>Ironbox</strong></td>
        </tr>
        <tr>
        <td>Unit of Zero degree south</td>
        </tr>
        </table>
        </div>
        </div>
        <div class='mr15'>

        <p><strong>complaint ID : </strong> ".$complaintId."</p>
        <p><strong>Name : </strong> ".$name."</p>
        <p><strong>Mobile : </strong> ".$mobile."</p>
        <p><strong>E-mail : </strong> ".$email."</p><br>
        <p>".$content."</p>
        </div>

        </div>
        </div>
        </body>
        </html>";
        $message->setBody(

            $mail

            ,'text/html');
    });

    $Support= CustomerSupport::Select('CustomerSupport.id','userId','complaint_id','users.name','users.mobile','Comments','complaints_type','Is_open',DB::raw('DATE_FORMAT(CustomerSupport.createdAt, "%d-%m-%Y") as comp_date'))
    ->join('users','users.id','=','CustomerSupport.userId')
    ->orderBy('CustomerSupport.id','desc')
    ->get();
    $complaint_type  = DB::table('compliant_type')->select('id','compliant_name')->get();	
    return view('admin.CustometSupport',['Customer'=>$Support,'complaint'=>$complaint_type]);

}


//View complients
public function ViewComplaint(Request $Request,$id){

    $Support= CustomerSupport::Select('CustomerSupport.id','userId','complaint_id','users.name','users.mobile','Comments','complaints_type','Is_open',DB::raw('DATE_FORMAT(CustomerSupport.createdAt, "%d-%m-%Y") as comp_date'))
    ->join('users','users.id','=','CustomerSupport.userId')
    ->Where(['CustomerSupport.id'=>$id])
    ->get();

    return view('admin.ViewComplients',['Support'=>$Support]);
}

public function UpdateComplient(Request $Request){

    $complaint_id = $Request->complaint_id;
    $Is_open = $Request->Is_open;

    $authId = Auth::user()->id;

    $role='superadmin';

// echo $Is_open;die;

    if($Is_open == 0){


        $update = CustomerSupport::where('id',$complaint_id)->update(['Is_open'=>1,'role'=>$role,'open_by'=>$authId]);


    }else{

        $update = CustomerSupport::where('id',$complaint_id)->update(['Is_open'=>0,'role'=>$role,'open_by'=>$authId]);
    }


    $Support= CustomerSupport::Select('CustomerSupport.id','userId','complaint_id','users.name','users.mobile','Comments','complaints_type','Is_open',DB::raw('DATE_FORMAT(CustomerSupport.createdAt, "%d-%m-%Y") as comp_date'))
    ->join('users','users.id','=','CustomerSupport.userId')
    ->orderBy('CustomerSupport.id','desc')
    ->get();
    $complaint_type  = DB::table('compliant_type')->select('id','compliant_name')->get();	
    return view('admin.CustometSupport',['Customer'=>$Support,'complaint'=>$complaint_type]);


}

//DeletePickupUser

public function DeletePicupUser (Request $Request){
    $PickupUserId=$Request->id;

    $delete=DB::table('pickupdeliveryusers')
    ->where('id', $PickupUserId)
    ->update(['Is_active' => 2]);

    return back();
}


//Reports 
public function PickupUserReport (Request $Request,$id){


    $userId = $id; 
    $CommonFunction = new CommonFunctions();

    $PickupUsers = $CommonFunction->EditPickupUser($id);
    $PickupUser = $PickupUsers['GetDetails'];

    $TodayReport = DB::Select("SELECT id,bookingId,bookingDate,Status, 'Pickup'  FROM Bookings WHERE pickupDeliveryUserId='".$id."' AND PickupSuccess='1' AND DAY(PickupSuccessDate) = DAY(NOW()) AND MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT id,bookingId,bookingDate,Status, 'Delivery' FROM Bookings WHERE DeliveryUserId='".$id."' AND DeliverySuccess='1' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate	) = YEAR(NOW()) order by id desc");


    $WeekReport = DB::Select("SELECT id,bookingId,bookingDate,Status, 'Pickup'  FROM Bookings WHERE pickupDeliveryUserId='".$id."'  AND YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) UNION ALL SELECT id,bookingId,bookingDate,Status, 'Delivery' FROM Bookings WHERE DeliveryUserId='".$id."' AND DeliverySuccess='1' AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())  order by id desc");


    $MonthReport = DB::Select("SELECT id,bookingId,bookingDate,Status, 'Pickup'  FROM Bookings WHERE pickupDeliveryUserId='".$id."' AND PickupSuccess='1' AND MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT id,bookingId,bookingDate,Status, 'Delivery' FROM Bookings WHERE DeliveryUserId='".$id."' AND DeliverySuccess='1'  AND MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by id desc");

    $YearReport = DB::Select("SELECT id,bookingDate,bookingId,Status, 'Pickup'  FROM Bookings WHERE pickupDeliveryUserId='".$id."' AND PickupSuccess='1'  AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT id,bookingDate,bookingId,Status, 'Delivery' FROM Bookings WHERE DeliveryUserId='".$id."' AND DeliverySuccess='1'  AND YEAR(DeliverySuccessDate	) = YEAR(NOW()) order by id desc");

    $Days = DB::Select("SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'Pickup' FROM Bookings WHERE pickupDeliveryUserId='".$id."' AND PickupSuccess='1' AND DAY(PickupSuccessDate) = DAY(NOW()) AND MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'delivery' FROM Bookings WHERE DeliveryUserId='".$id."' AND DeliverySuccess='1' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate	) = YEAR(NOW())");

    $Weeks = DB::Select("SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'Pickup' FROM Bookings WHERE pickupDeliveryUserId='".$id."' AND PickupSuccess='1'  AND YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) UNION ALL SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'delivery' FROM Bookings WHERE DeliveryUserId='".$id."' AND DeliverySuccess='1' AND  YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())");


    $Months = DB::Select("SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'Pickup' FROM Bookings WHERE pickupDeliveryUserId='".$id."' AND PickupSuccess='1' AND  MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'delivery' FROM Bookings WHERE DeliveryUserId='".$id."' AND DeliverySuccess='1' AND  MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate	) = YEAR(NOW())");

    $Years = DB::Select("SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'Pickup' FROM Bookings WHERE pickupDeliveryUserId='".$id."' AND PickupSuccess='1'  AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'delivery' FROM Bookings WHERE DeliveryUserId='".$id."' AND DeliverySuccess='1' AND  YEAR(DeliverySuccessDate	) = YEAR(NOW())");







// echo json_encode($Days);die; 

    return view('report.PickupUser',['User' => $PickupUser,'userId'=>$userId,'TodayOrder'=>$TodayReport,'WeekOrder'=>$WeekReport,'MonthOrder'=>$MonthReport,'YearOrder'=>$YearReport,'Days'=>$Days,'Months'=>$Months,'Years'=>$Years,'Weeks'=>$Weeks]);

}

//pickup user graph
public function PickUpuserGraph(Request $Request){

    $id = $Request->id;

    $CommonFunction = new CommonFunctions();
    $response = $CommonFunction->PickupDayGraph($id);

    return $response;


}


//vendor report
public function VendorReport(Request $Request,$id){

    $CommonFunction = new CommonFunctions();
    $response = $CommonFunction->VendorInfo($id);

    $VendorDetail = $response['Vendor'];


    $Today = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y') as start_time,bookingId,quantity,totalPayment from Bookings Where Bookings.VendorUserId='".$id."'  AND StartJob='2' AND DAY(Bookings.job_completed) = DAY(NOW()) AND MONTH(Bookings.job_completed) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) ORDER BY start_time");


    $Week = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y') as start_time,bookingId,quantity,totalPayment from Bookings Where Bookings.VendorUserId='".$id."'  AND StartJob='2' AND  YEARWEEK(Bookings.job_completed) = YEARWEEK(NOW()) ORDER BY start_time");



    $Month = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y') as start_time,bookingId,quantity,totalPayment from Bookings Where Bookings.VendorUserId='".$id."'  AND StartJob='2' AND MONTH(Bookings.job_completed) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) ORDER BY start_time");


    $Year = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y') as start_time,bookingId,quantity,totalPayment from Bookings Where Bookings.VendorUserId='".$id."'  AND StartJob='2' AND  YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) ORDER BY start_time");



    $today_rep = DB::Select("select COUNT(id) as orders,VendorUserId,SUM(totalPayment) as total,SUM(quantity) as qty from Bookings Where VendorUserId='".$id."' AND  StartJob='2' AND DAY(Bookings.job_completed) = DAY(NOW()) AND MONTH(Bookings.job_completed) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) group by VendorUserId");

    $week_rep = DB::Select("select COUNT(id) as orders,VendorUserId,SUM(totalPayment) as total,SUM(quantity) as qty from Bookings Where VendorUserId='".$id."' AND StartJob='2' AND YEARWEEK(Bookings.job_completed) = YEARWEEK(NOW()) group by VendorUserId");

    $month_rep = DB::Select("select COUNT(id) as orders,VendorUserId,SUM(totalPayment) as total,SUM(quantity) as qty from Bookings Where VendorUserId='".$id."' AND  StartJob='2' AND MONTH(Bookings.job_completed) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) group by VendorUserId");


    $year_rep = DB::Select("select COUNT(id) as orders,VendorUserId,SUM(totalPayment) as total,SUM(quantity) as qty from Bookings Where VendorUserId='".$id."' AND  StartJob='2' AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) group by VendorUserId");

    $userId = $id;

    $category = DB::table('CategoryList')->select('id','name')->get();

    $cate_first = DB::table('CategoryList')->select('id','name')->first(); 

    return view('report.VendorReport',['Pickup'=>$Month,'userId'=>$userId,'Day'=>$Today,'Week'=>$Week,'Month'=>$Month,'Year'=>$Year,'category'=>$category,'cate_first'=>$cate_first,'today_rep'=>$today_rep,'week_rep'=>$week_rep,'month_rep'=>$month_rep,'year_rep'=>$year_rep,'VendorInfo'=>$VendorDetail]);		 

}


//vendor graph
public function VendorGraph(Request $Request){

    $id = $Request->id;

    $month = date('m');
    $year = date('Y');

    $GetData = DB::select("SELECT COUNT(*)as orders,DAY(created_at) AS day FROM Bookings Where MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())  AND PickupSuccess ='1' AND VendorUserId ='".$id."' GROUP BY MONTH(created_at), DAY(created_at)");

    foreach($GetData as $Data){

        $Data->order_date = $Data->day.'-'.$month.'-'.$year;
    }
    return json_encode($GetData);

}

public function VendorClothesGraph(Request $Request){

    $id = $Request->id;
    $cate_id = $Request->cate_id;


    $report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where Bookings.VendorUserId='".$id."' AND  CategoryList.id='".$cate_id."' AND StartJob='2' AND MONTH(Bookings.job_completed) = MONTH(NOW()) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) Group by Booking_Items.categoryId");


    return json_encode($report);

}



//Daily Sales Graph
public function TodaySales(Request $Request){

// $data = DB::select("select CategoryList.id,CategoryList.name,COUNT(CategoryList.id) as cate_val,SUM(Booking_Items.quantity) as qty from  Booking_Items inner join NewCategories on Booking_Items.categoryId = NewCategories.id inner join CategoryList on NewCategories.categoryId = CategoryList.id Where MONTH(Booking_Items.updatedAt) = MONTH(CURRENT_DATE()) AND YEAR(Booking_Items.updatedAt) = YEAR(CURRENT_DATE()) GROUP BY CategoryList.id" );


    $data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId   Group by CategoryList.id");



    if(count($data) == 0){

        $category = DB::table('CategoryList')->select('id','name')->get();

        foreach($category as $cate){

            $cate->quantity = "";
        }

        return json_encode($category);die;
    }



// $pdfview = "<table style='width:100%'> 

// <tr>
// <td><strong>Items</strong></td>
// <td><strong>Qty</strong></td>
// <td><strong>Total</strong></td>
// </tr>
// </table>";

// $pdf = PDF::loadHTML( $pdfview
// ,'text/html');
// return $pdf->stream('document.pdf');
// return $pdf->download('invoice.pdf');




    return json_encode($data);

}


public function Pie_Chart_clothes(Request $Request){

// $Clothes = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id   Group by Booking_Items.categoryId");

    $Clothes = DB::select("select NewCategories.name as label,groupName,SUM(Booking_Items.quantity) as value from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where Bookings.DeliverySuccess='1'  Group by Booking_Items.categoryId");



    foreach($Clothes as $Report){

        $Report->label  = $Report->groupName. " / " . $Report->label;
        $Report->value  = (int)$Report->value;
        unset($Report->groupName);

    }

    return $Clothes; 

}

//Payment type graph
public function PaymentTypeGraph(Request $Request){

    $PaymentType = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where   DeliverySuccess ='1' GROUP by Bookings.paymentType");
    $paytype = [];
    if(count($PaymentType) == 0){



        $payarr = (object) array();
        $payarr_2 = (object) array();
        $payarr_3 = (object) array();
        $payarr->paymentType ='Cash';
        $payarr->total ='';
        $payarr_2->paymentType ='Card';
        $payarr_2->total ='';
        $payarr_3->paymentType ='Wallet';
        $payarr_3->total ='';

        array_push($paytype,$payarr,$payarr_2,$payarr_3);

        return json_encode($paytype);;die;

    }

    return json_encode($PaymentType);
}



//Order Assign
public function PickupOrderAssign(Request $Request,$id){

    $current_date = date('d-m-Y');
    $GetBookings = [];
    $PickupUser = [];
    $delivery_bookings = [];
    $deliveryUser = [];

    $GetBookings = Bookings::Select('Bookings.id','bookingId','bookingDate','pickupDeliveryUserId','service_area','warehouseId','users.name','users.mobile')
    ->join('users','users.id','=','Bookings.userId')
    ->Where(['pickupDeliveryUserId'=>$id,'Bookings.Status'=>'CONFIRMED','Bookings.OrderAssign'=>'1','bookingDate'=>$current_date])
    ->get();

    if(count($GetBookings) > 0){

        foreach($GetBookings as $Bookings){

            $Area = $Bookings->warehouseId;
        }

        $PickupUser = pickupdeliveryuser::Select('id','name','mobile')
        ->Where(['warehouseId'=>$Area])
        ->Where('id','!=',$id)
        ->Where('Is_active',1)
        ->get();
    }

    $curr = date('Y-m-d');

    $delivery_bookings = Bookings::Select('Bookings.id','bookingId',DB::raw('DATE_FORMAT(delivery_date, "%d-%m-%Y") as delivery_date'),'DeliveryUserId','service_area','warehouseId','users.name','users.mobile')
    ->join('users','users.id','=','Bookings.userId')
    ->Where(['DeliveryUserId'=>$id,'Bookings.Status'=>'CONFIRMED','Bookings.OrderAssign'=>'2','delivery_date'=>$curr])
    ->get();

    if(count($delivery_bookings) > 0){

        foreach($delivery_bookings as $Bookings){

            $AreaId = $Bookings->warehouseId;
        }

        $deliveryUser = pickupdeliveryuser::Select('id','name','mobile')
        ->Where(['warehouseId'=>$AreaId])
        ->Where('id','!=',$id)
        ->Where('Is_active',1)
        ->get();
    }										




    return view('admin.AssignPickuporder',['Bookings'=>$GetBookings,'User'=>$PickupUser,'delivery_bookings'=>$delivery_bookings,'deliveryUser'=>$deliveryUser]);

}

//Update order assign
public function UpdateOrderAssign(Request $Request){


    $UserId = $Request->pickup_user;

    for($i=0;$i<count($Request->bookingId);$i++){

        $book_id=$Request->bookingId[$i];
// echo $book_id;
        $update = Bookings::Where(['id'=>$book_id])->update(['pickupDeliveryUserId'=>$UserId]);
    }

    $CommonFunction = new CommonFunctions();

    $PickupUsers = $CommonFunction->GetPickupUser();

    return view('admin.PickupUserList',['User' => $PickupUsers]);
}

public function UpdateDeliveryAssign(Request $Request){

    $UserId = $Request->delivery_user;

// echo $UserId;die;

    for($i=0;$i<count($Request->bookingId4);$i++){

        $book_id=$Request->bookingId4[$i];

        $update = Bookings::Where(['id'=>$book_id])->update(['DeliveryUserId'=>$UserId]);
    }

    $CommonFunction = new CommonFunctions();

    $PickupUsers = $CommonFunction->GetPickupUser();

    return view('admin.PickupUserList',['User' => $PickupUsers]);

}


//ReportsView
public function ReportsView(Request $Request){
    return view('report.ReportsView');

}

//Highest Order
public function HighestOrder(Request $Request){

    $Dayrep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Pincode.code,Bookings.Status FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by Bookings.id desc");

    $Weekrep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Pincode.code,Bookings.Status FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND  YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW()) order by Bookings.id desc");


    $Monthrep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Pincode.code,Bookings.Status FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by Bookings.id desc");

    $Yearrep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Pincode.code,Bookings.Status FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by Bookings.id desc");


    $OrderDay = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");

    $OrderWeek = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND  YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())   GROUP by Bookings.service_area");

    $OrderMonth = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");

    $OrderYear = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");

// echo json_encode($OrderYear);die;

    $pincode = DB::table('Pincode')->select('id','area','code')->Where('status',1)->get();

    $order_summery = DB::Select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED'  GROUP by Bookings.service_area");


    return view('report.HighOrder',['Day'=>$OrderDay,'Week'=>$OrderWeek,'Month'=>$OrderMonth,'Year'=>$OrderYear,'pincode'=>$pincode,'summary'=>$order_summery,'Dayrep'=>$Dayrep,'Weekrep'=>$Weekrep,'Monthrep'=>$Monthrep,'Yearrep'=>$Yearrep]);


}

//Highest order
public function HighestOrderGraph(Request $Request){


// $HighestOrder = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");

    $HighestOrder = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");



    if(count($HighestOrder) == 0){

        $pin = DB::table('Pincode')->select('id','code')->get();

        foreach($pin as $code){

            $code->orders = "";
        }
        return json_encode($pin);die;
    }

    return json_encode($HighestOrder);
}

public function PaymentTypeView(Request $Request){

    $PaymentTypeDay = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");

    $PaymentTypeWeek = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");

    $PaymentTypeMonth = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");

    $PaymentTypeYear = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");

    /*************** view details **************************/

    $DayRep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.Status,Bookings.paymentType FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' order by Bookings.id desc");

    $WeekRep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.Status,Bookings.paymentType FROM Bookings Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW())  AND DeliverySuccess ='1' order by Bookings.id desc");

    $MonthRep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.Status,Bookings.paymentType FROM Bookings Where MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate)  AND DeliverySuccess ='1' order by Bookings.id desc");


    $YearRep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.Status,Bookings.paymentType FROM Bookings Where YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' order by Bookings.id desc");

    $summary = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where  DeliverySuccess ='1' GROUP by Bookings.paymentType");




    return view('report.ReportPaymentType',['Day'=>$PaymentTypeDay,'Month'=>$PaymentTypeMonth,'Week'=>$PaymentTypeWeek,'Year'=>$PaymentTypeYear,'DayRep'=>$DayRep,'WeekRep'=>$WeekRep,'MonthRep'=>$MonthRep,'YearRep'=>$YearRep,'summary'=>$summary]);
}

//ReportPaymentType
public function ReportPaymentType(Request $Request){

    $paytype = array(array('orders'=>'','paymentType'=>'Cash'),array('orders'=>'','paymentType'=>'Card'),array('orders'=>'','paymentType'=>'Wallet'));

    $PaymentReport = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");


    if(count($PaymentReport)  == 0){

        return json_encode($paytype);die;
    }

    return json_encode($PaymentReport);


}


// success cancel report
public function OrderCompletedView(Request $Request){


    $complete_day  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED'  AND DAY(CancelDate) = DAY(NOW()) AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW())");  

    foreach($complete_day as $list){

        if($list->Status == null){  

            $list->Status = "";
        }
    }

    $complete_week  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED'  AND YEARWEEK(CancelDate) = YEARWEEK(NOW()) ");

    foreach($complete_week as $list){

        if($list->Status == null){  

            $list->Status = "";
        }
    }

    $complete_month  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED'  AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW())");

    foreach($complete_month as $list){

        if($list->Status == null){  

            $list->Status = "";
        }

    } 

    $complete_year  =   DB::select("select COUNT(*) as orders,Status FROM Bookings  Where Status='COMPLETED'  AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED' AND  YEAR(CancelDate) = YEAR(NOW())");

    foreach($complete_year as $list){

        if($list->Status == null){  

            $list->Status = "";
        }
    } 





    $DayRep  =   DB::select("SELECT *
        FROM (
        (SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'COMPLETED' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()))
        UNION
        (SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'CANCELLED' AND DAY(CancelDate) = DAY(NOW()) AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW()))
        ) AS i
        ORDER BY id DESC");

    $WeekRe  =   DB::select("SELECT *
        FROM (
        (SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'COMPLETED' AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW()))
        UNION
        (SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'CANCELLED'  AND YEARWEEK(CancelDate) = YEARWEEK(NOW()))
        ) AS i
        ORDER BY id DESC");						


    $MonthRep  =   DB::select("SELECT *
        FROM (
        (SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'COMPLETED' AND   MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()))
        UNION
        (SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'CANCELLED' AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW()))
        ) AS i
        ORDER BY id DESC");

    $YearRep  =   DB::select("SELECT *
        FROM (
        (SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()))
        UNION
        (SELECT Bookings.id,Bookings.bookingId,Status,bookingDate,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'CANCELLED'  AND YEAR(CancelDate) = YEAR(NOW()))
        ) AS i
        ORDER BY id DESC");					



    $summary = DB::select("select COUNT(*) as orders,Status from Bookings Where Status='COMPLETED' GROUP BY Status UNION ALL select COUNT(*) as orders,Status from Bookings Where Status='CANCELLED' GROUP BY Status");


// echo json_encode($summary);die;


    return view('report.OrderSuccess',['Day'=>$complete_day,'Week'=>$complete_week,'Month'=>$complete_month,'Year'=>$complete_year,'DayRep'=>$DayRep,'WeekRe'=>$WeekRe,'MonthRep'=>$MonthRep,'YearRep'=>$YearRep,'summary'=>$summary]);

}



// success cancel report graph
public function OrderStatusGraph(Request $Request){

// $completed = DB::select("select COUNT(id)as orders, Status FROM Bookings Where Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) GROUP by Status");
// $cancel = DB::select("select COUNT(id)as orders, Status FROM Bookings Where Status='CANCELLED' AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW()) GROUP by Status");

// $completearr = [];

// if(count($completed) > 0){
// foreach($completed as $comp){


// $stdarr = (object) array();
// $stdarr->orders = $comp->orders;
// $stdarr->Status = $comp->Status;

// $arr1 = $stdarr;
// }

// }else{
// $arr1 = "";
// }

// if(count($cancel) > 0){

// foreach($cancel as $can){


// $stdarr_2 = (object) array();
// $stdarr_2->orders = $can->orders;
// $stdarr_2->Status = $can->Status; 

// $arr2 = $stdarr_2;
// }

// }else{

// $arr2 = "";
// }

// array_push($completearr,$stdarr,$arr2);

    $completearr  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED' AND DAY(CancelDate) = DAY(NOW())  AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW())"); 	


    foreach($completearr as $list){

        if($list->Status == null){  

            $list->Status = "";
        }
    } 			

    return  json_encode($completearr); 

}

//promocode report
public function PromocodeView(Request $Request){

    $Days = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where DAY(DeliverySuccessDate) = DAY(NOW()) AND promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by Bookings.id desc");


    $Weekly = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND promode_code !=0 AND Bookings.Status='COMPLETED'  order by Bookings.id desc");

    $Monthly = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by Bookings.id desc");

    $Yearly = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by Bookings.id desc");

    $PromoDay = DB::select("select COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where DAY(DeliverySuccessDate) = DAY(NOW()) AND promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) GROUP by Bookings.promode_code");


    $PromoWeek = DB::select("select COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND promode_code !=0 AND Bookings.Status='COMPLETED' GROUP by Bookings.promode_code");

    $PromoMonth = DB::select("select COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) GROUP by Bookings.promode_code");


    $PromoYear = DB::select("select COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) GROUP by Bookings.promode_code");


    $promo_list = DB::table('promocode')->select('id','promocode','status')->Where('status',1)->get();

    $summary = DB::Select("select COUNT(Bookings.promode_code) as orders,promocode.promocode,SUM(totalPayment) as total, SUM(discount_amount) as discount from Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code != '0' AND Bookings.Status='COMPLETED'  group by Bookings.promode_code");


    return view('report.PromocodeView',['Day'=>$PromoDay,'Week'=>$PromoWeek,'Month'=>$PromoMonth,'Year'=>$PromoYear,'Days'=>$Days,'Weekly'=>$Weekly,'Monthly'=>$Monthly,'Yearly'=>$Yearly,'Promo'=>$promo_list,'summary'=>$summary]); 

}

public function PromocodeGraph(Request $Request){

    $promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) GROUP by Bookings.promode_code");

    return json_encode($promocode);  
}

public function MostBookings(Request $Request){


    $User = DB::select("select userId,COUNT(*) as orders,users.name as code FROM Bookings inner join users on Bookings.userId = users.id Where Status='COMPLETED' GROUP by userId order by orders desc limit 5");

    return json_encode($User);
}

public function TotalRevenue(Request $Request){

    $TodayRep = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");

    foreach($TodayRep as $Data){

        $Data->revenue_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
    }

    $WeekRep = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND Status='COMPLETED' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate), YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");

    foreach($WeekRep as $Data){

        $Data->revenue_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
    }

    $MonthRep = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");

    foreach($MonthRep as $Data){

        $Data->revenue_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
    }


    $YearRep = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where  YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");

    foreach($YearRep as $Data){

        $Data->revenue_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
    }

    /************* old one *********************/

    $TodayRep = DB::select("select id,bookingId,bookingDate,Status from Bookings Where Status='COMPLETED' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) order by Bookings.id desc");

    $WeekRep = DB::select("select id,bookingId,bookingDate,Status from Bookings Where Status='COMPLETED' AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW()) order by Bookings.id desc");

    $MonthRep = DB::select("select id,bookingId,bookingDate,Status from Bookings Where Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE())");

    $YearRep = DB::select("select id,bookingId,bookingDate,Status from Bookings Where Status='COMPLETED' AND  YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) order by Bookings.id desc");

// echo json_encode($YearRep);die;

    $Days = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty FROM Bookings Where  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' ");

    $Weekly = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty FROM Bookings Where YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW()) AND Status='COMPLETED' ");

    $Monthly = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty FROM Bookings Where  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED'");

    $Yearly = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty FROM Bookings Where  YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' ");


    $summary = DB::select("select COUNT(*) as booking,SUM(totalPayment) as revenue,SUM(quantity) as quantity from Bookings Where Status='COMPLETED' ");


// echo json_encode($summary);die;

    return view('report.revenue',['Day'=>$TodayRep,'Week'=>$WeekRep,'Month'=>$MonthRep,'Year'=>$YearRep,'Days'=>$Days,'Weekly'=>$Weekly,'Monthly'=>$Monthly,'Yearly'=>$Yearly,'summary'=>$summary]);
}


public function TotalRevenueGraph(Request $Request){

    $TodayRep = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");

    foreach($TodayRep as $Data){

        $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
    }

    return json_encode($TodayRep);


}


public function ClothesRevenue(Request $Request){


    $price = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId  Group by CategoryList.id");

    if(count($price) == 0){

        $category = DB::table('CategoryList')->select('id','name')->get();

        foreach($category as $cate){

            $cate->price_amount = "";
        }

        return json_encode($category);
    }else{

        return json_encode($price); 
    }		

}

public function ReportClothes(Request $Request){


    $TodayRev = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");

    $WeekRev = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW())  Group by CategoryList.id");

    $MonthRev = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");

    $YearRev = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");

    $category = DB::table('CategoryList')->select('id','name')->Where('status',1)->get();

    $summary = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId WHERE DeliverySuccess='1'   Group by CategoryList.id");


    return view('report.clothes',['Day'=>$TodayRev,'Week'=>$WeekRev,'Month'=>$MonthRev,'Year'=>$YearRev,'category'=>$category,'summary'=>$summary]);

}

public function MonthClothSales(Request $Request){


    $data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW())  Group by CategoryList.id");

    return json_encode($data); 

}

public function MonthClothRevenue(Request $Request){

    $price = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) Group by CategoryList.id");



    return json_encode($price);  

}

public function UserNotUse(Request $Request){


    $User = DB::select("SELECT `name`,`mobile`,`email`,last_booking FROM `users` Where last_booking < NOW() - INTERVAL 30 DAY Group by id ORDER BY `users`.`last_booking`  DESC");

    foreach($User as $data){

        $data->last_booking = date("d-m-Y", strtotime($data->last_booking)); 
    }

    return view('report.user',['User'=>$User]);
}

public function TimeSlotReport(Request $Request){


    $Dayrep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by Bookings.id desc");


    $Weekrep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND  YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW()) order by Bookings.id desc");


    $Monthrep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND   MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by Bookings.id desc");


    $Yearrep = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND    YEAR(DeliverySuccessDate) = YEAR(NOW()) order by Bookings.id desc");


    $TodayReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY Bookings.bookingTimeSlot");


    $WeekReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) GROUP BY Bookings.bookingTimeSlot");

    $MonthReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY Bookings.bookingTimeSlot");


    $YearReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY Bookings.bookingTimeSlot");

    $time_slot = DB::table('TimeSlots')->select('id','fromSlots','toSlots','status')->Where('status',1)->get();


    $summary = DB::select("select COUNT(Bookings.id) as booking,SUM(Bookings.totalPayment) as revenue,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED'  GROUP BY Bookings.bookingTimeSlot");


// echo json_encode($summary);die;

    return view('report.timeslots',['Day'=>$TodayReport,'Week'=>$WeekReport,'Month'=>$MonthReport,'Year'=>$YearReport,'Dayrep'=>$Dayrep,'Weekrep'=>$Weekrep,'Monthrep'=>$Monthrep,'Yearrep'=>$Yearrep,'Slot'=>$time_slot,'summary'=>$summary]);
}

public function HighSlotGraph(Request $Request){


    $MonthReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY Bookings.bookingTimeSlot");

    return json_encode($MonthReport);
}


public function WalletReportTrans(Request $Request){

    $id = $Request->id;

    $CommonFunction = new CommonFunctions();
    $wallet = $CommonFunction->wallet_trasnaction($id);

    return view('report.wallet-transaction',['id'=>$id,'Transc'=>$wallet]);

}

//clothes category report
public function ClothesCategory(Request $Request){

    $category = DB::table('CategoryList')->select('id','name')->get();

    $category_first = DB::table('CategoryList')->select('id')->first();

    $id = $category_first->id;




    $Today = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())   Group by Booking_Items.categoryId");  


    $Week = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where  YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW())   Group by Booking_Items.categoryId"); 

    $Month = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where  YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW())   Group by Booking_Items.categoryId"); 

    $Month = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())   Group by Booking_Items.categoryId");

    $Year = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())   Group by Booking_Items.categoryId");


    return view('report.category-clothes',['id'=>$category_first->id,'category'=>$category,'Day'=>$Today,'Week'=>$Week,'Month'=>$Month,'Year'=>$Year]);

}


public function category_clothes_report(Request $Request){

    $id = $Request->id;
    $type = $Request->type;

    switch ($type) {
        case "1":

        $report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");

        return json_encode($report);


        break;
        case "2":

        $report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where   YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");

        return json_encode($report);


        break;
        case "3":

        $report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");

        return json_encode($report);

        break;
        case "4":

        $report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where   YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");

        return json_encode($report);

        break;

        default:
        $report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");

        return json_encode($report);

    }






}

public function AvgCost(Request $Request){


    /**********Today***********/
    $Today = DB::select("SELECT sum(a1.quantity) as quantity,a2.categoryId as maincatid,a3.price as price,a3.name as Categoryname,sum(a1.quantity) * a3.price as payments FROM `Booking_Items` as a1 LEFT OUTER JOIN NewCategories as a2 on a1.categoryId=a2.id  left outer join CategoryList as a3 on a3.id=a2.categoryId WHERE a1.delivery='1' and  DAY(a1.updatedAt) = DAY(NOW()) AND MONTH(a1.updatedAt) = MONTH(CURRENT_DATE()) AND YEAR(a1.updatedAt) = YEAR(NOW()) GROUP BY a2.categoryId");


    $arr = [];
    $qu = [];


    if(count($Today) > 0){

        foreach($Today as $rep){

            $stdday = (object) array();

            $stdday->Categoryname  = $rep->Categoryname;
            $stdday->payments  = $rep->payments;
            $stdday->quantity  = $rep->quantity;

            $today_sum  = $rep->payments / $rep->quantity;

            $today_avg  =  round($today_sum * 100);

            $stdday->avg_cost  = $today_avg;

            array_push($arr, $stdday);

            array_push($qu, $rep->quantity);
        }

        $Totalquantity1=array_sum($qu);
        $stdday=$arr;


    }else{

        $stdday = (object) array();
        $stdday->Categoryname  ="";
        $stdday->payments  = 0;
        $stdday->quantity  = 0;
        $stdday->avg_cost  = 0;
        array_push($arr, $stdday);
        $Totalquantity1 = 0;
        $stdday=$arr;
    }
//$Today = DB::select("select SUM(totalPayment) as payment ,SUM(quantity) as quantity from Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1'");

//    if(json_encode(!$Today[0]->payment) == null){

// if(count($Today) > 0){

// 	$arr = [];
// 	foreach($Today as $rep){

// 	$stdday = (object) array();
// 	$stdday->payment  = $rep->payment;
// 	$stdday->quantity  = $rep->quantity;

// 	$today_sum  = $rep->payment / $rep->quantity;

// 	$today_avg  =  round($today_sum * 100 / 118, 2);

// 	$stdday->avg_cost  = $today_avg;

// 	array_push($arr,$stdday);
// }

// }else{

// 	$stdday = (object) array();
// 	$stdday->payment  = 0;
// 	$stdday->quantity  = 0;
// 	$stdday->avg_cost  = 0;
// }

// }else{

// 	$stdday = (object) array();
// 	$stdday->payment  = 0;
// 	$stdday->quantity  = 0;
// 	$stdday->avg_cost  = 0;
// }



    /**********Week***********/

    $Week = DB::select("SELECT sum(a1.quantity) as quantity,a2.categoryId as maincatid,a3.price as price,a3.name as Categoryname,sum(a1.quantity) * a3.price as payments FROM `Booking_Items` as a1 LEFT OUTER JOIN NewCategories as a2 on a1.categoryId=a2.id  left outer join CategoryList as a3 on a3.id=a2.categoryId WHERE a1.delivery='1' and  YEARWEEK(a1.updatedAt) = YEARWEEK(NOW()) GROUP BY a2.categoryId");

    $arr = [];
    $qu = [];


    if(count($Week) > 0){

        foreach($Week as $rep){

            $stdweek = (object) array();

            $stdweek->Categoryname  = $rep->Categoryname;
            $stdweek->payments  = $rep->payments;
            $stdweek->quantity  = $rep->quantity;

            $week_sum  = $rep->payments / $rep->quantity;

            $week_avg  =  round($week_sum * 100);

            $stdweek->avg_cost  = $week_avg;

            array_push($arr, $stdweek);

            array_push($qu, $rep->quantity);
        }

        $Totalquantity2=array_sum($qu);
        $stdweek=$arr;

    }else{

        $stdweek = (object) array();
        $stdweek->Categoryname  = "";
        $stdweek->payments  = 0;
        $stdweek->quantity  = 0;
        $stdweek->avg_cost  = 0;
        array_push($arr, $stdweek);
        $Totalquantity2 = 0;
        $stdweek=$arr;
    }

// echo json_encode($Week[0]->payment);die;   

// if(!$Week[0]->payment == null){


// if(count($Week) > 0){

// 	$arr = [];
// 	foreach($Week as $rep){

// 	$stdweek = (object) array();
// 	$stdweek->payment  = $rep->payment;
// 	$stdweek->quantity  = $rep->quantity;

// 	$week_sum  = $rep->payment / $rep->quantity;

// 	$week_avg  =  round($week_sum * 100 / 118, 2);

// 	$stdweek->avg_cost  = $week_avg;

// 	array_push($arr,$stdweek);
// }

// }else{

// 	$stdweek = (object) array();
// 	$stdweek->payment  = 0;
// 	$stdweek->quantity  = 0;
// 	$stdweek->avg_cost  = 0;
// }

// }else{

// 	$stdweek = (object) array();
// 	$stdweek->payment  = 0;
// 	$stdweek->quantity  = 0;
// 	$stdweek->avg_cost  = 0;
// }



    /*********Month************/


    $Month = DB::select("SELECT sum(a1.quantity) as quantity,a2.categoryId as maincatid,a3.price as price,a3.name as Categoryname,sum(a1.quantity) * a3.price as payments FROM `Booking_Items` as a1 LEFT OUTER JOIN NewCategories as a2 on a1.categoryId=a2.id  left outer join CategoryList as a3 on a3.id=a2.categoryId WHERE a1.delivery='1' and  MONTH(a1.updatedAt) = MONTH(CURRENT_DATE()) AND YEAR(a1.updatedAt) = YEAR(NOW()) GROUP BY a2.categoryId");

    $arr = [];
    $qu = [];


    if(count($Month) > 0){

        foreach($Month as $rep){

            $stdmonth = (object) array();

            $stdmonth->Categoryname  = $rep->Categoryname;
            $stdmonth->payments  = $rep->payments;
            $stdmonth->quantity  = $rep->quantity;

            $month_sum  = $rep->payments / $rep->quantity;

            $month_avg  =  round($month_sum * 100);

            $stdmonth->avg_cost  = $month_avg;

            array_push($arr, $stdmonth);

            array_push($qu, $rep->quantity);
        }

        $Totalquantity3=array_sum($qu);
        $stdmonth=$arr;

    }else{

        $stdmonth = (object) array();
        $stdmonth->Categoryname ="";
        $stdmonth->payments  = 0;
        $stdmonth->quantity  = 0;
        $stdmonth->avg_cost  = 0;
        array_push($arr, $stdmonth);
        $Totalquantity3 = 0;
        $stdmonth=$arr;
    }


// echo json_encode ($Month[0]->payment);die;

// if(!$Month[0]->payment == null){



// if(count($Month) > 0){

// 	$arr = [];

// 	foreach($Month as $rep){

// 	$stdmonth = (object) array();
// 	$stdmonth->payment  = $rep->payment;
// 	$stdmonth->quantity  = $rep->quantity;

// 	$month_sum  = $rep->payment / $rep->quantity;

// 	$month_avg  =  round($month_sum * 100 / 118, 2);

// 	$stdmonth->avg_cost  = $month_avg;

// 	array_push($arr,$stdmonth);
// }


// }else{

// 	$stdmonth = (object) array();
// 	$stdmonth->payment  = 0;
// 	$stdmonth->quantity  = 0;
// 	$stdmonth->avg_cost  = 0;
// }

// }else{

// 	$stdmonth = (object) array();
// 	$stdmonth->payment  = 0;
// 	$stdmonth->quantity  = 0;
// 	$stdmonth->avg_cost  = 0;


// }

// echo json_encode($stdmonth);die;

    /*********Year************/
    $Year = DB::select("SELECT sum(a1.quantity) as quantity,a2.categoryId as maincatid,a3.price as price,a3.name as Categoryname,sum(a1.quantity) * a3.price as payments FROM `Booking_Items` as a1 LEFT OUTER JOIN NewCategories as a2 on a1.categoryId=a2.id  left outer join CategoryList as a3 on a3.id=a2.categoryId WHERE a1.delivery='1' and  YEAR(a1.updatedAt) = YEAR(NOW())GROUP BY a2.categoryId");


    $arr = [];
    $qu = [];


    if(count($Year) > 0){

        foreach($Year as $rep){

            $stdyear = (object) array();

            $stdyear->Categoryname  = $rep->Categoryname;
            $stdyear->payments  = $rep->payments;
            $stdyear->quantity  = $rep->quantity;

            $year_sum  = $rep->payments / $rep->quantity;

            $year_avg  =  round($year_sum * 100);

            $stdyear->avg_cost  = $year_avg;

            array_push($arr, $stdyear);

            array_push($qu, $rep->quantity);
        }

        $Totalquantity4=array_sum($qu);
        $stdyear=$arr;

    }else{

        $stdyear = (object) array();
        $stdyear->Categoryname  ="";
        $stdyear->payments  = 0;
        $stdyear->quantity  = 0;
        $stdyear->avg_cost  = 0;
        array_push($arr, $stdyear);
        $Totalquantity4 = 0;
        $stdyear=$arr;
    }


// echo json_encode($stdmonth);die;




//return view('report.AvgCost',['Today'=>$stdday,'Week'=>$stdweek,'Month'=>$stdmonth,'Year'=>$stdyear]);
    return view('report.AvgCost',['Year'=>$stdyear,'Total4'=>$Totalquantity4,'Month'=>$stdmonth,'Total3'=>$Totalquantity3,'Week'=>$stdweek,'Total2'=>$Totalquantity2,'Today'=>$stdday,'Total1'=>$Totalquantity1]);
}



public function PickDelivery(Request $Request){


// $pickup = DB::select('select pickupDeliveryUserId,DAY(DeliverySuccessDate) from Bookings Where pickupDeliveryUserId ="2" AND Status="COMPLETED" GROUP BY DeliverySuccessDate');

    $pickup = DB::select('select DATE(DeliverySuccessDate) as created_month FROM Bookings Where pickupDeliveryUserId ="2" AND Status="COMPLETED" GROUP BY DATE(DeliverySuccessDate)');

    $delivery = DB::select('select DATE(DeliverySuccessDate) as created_month FROM Bookings Where DeliveryUserId ="1" AND Status="COMPLETED" GROUP BY DATE(DeliverySuccessDate)');

    $arr = [];

    foreach($pickup as $pick){

        foreach($delivery as $dev){

            if($pick->created_month !== $dev->created_month){

                $stdarr = (object) array();			  

                $stdarr->created_month = $pick->created_month;  

                array_push($arr,$stdarr);
            }
        }

    }

    echo json_encode($arr); 

}


//New Bookings

public function NewBooking(Request $Request){

    $slot = TimeSlots::Where('status',1)->get();

    return view('admin.new-booking',['slot'=>$slot]);
}


public function UserMobile(Request $Request){


    $mobile = $Request->mobile;

    $user = User::Select('id','name','mobile')->Where('mobile',$mobile)->first();

    if(count($user) == 1){

        $UserAddresses = UserAddresses::Where('userId',$user->id)->get();

        return array("address"=>$UserAddresses,'user'=>$user);

    }else{



        return 0; 
    }




}


public function EditOrders(Request $Request,$id){

    $Clothes = DB::select("Select id,name,groupName from NewCategories");

    $CommonFunction = new CommonFunctions();

    $BookingsDetails = $CommonFunction->ViewBook($id);

    $Bookings = $BookingsDetails['Bookings'];
    $DeliveyuserDetails = $BookingsDetails['Deliveyuser'];
    $BookingItems = $BookingsDetails['GetOrder'];

    return view('admin.edit-booking',['Clothes'=>$Clothes,'GetOrder'=>$BookingItems,'Bookings'=>$Bookings]);

}


public function UpdateBookings(Request $Request){

    $id = $Request->bookingId;
    $sum = 0;

    $old_Bookings = Bookings::Select('id','totalPayment','discount_amount','first_offer','promode_code')->Where(['id'=>$id])->first();
    $delete_items = BookingItems::Where('bookingId',$id)->delete();


    for($i=0;$i<count($Request->clothes);$i++){

        $categoryId = $Request->clothes[$i];
        $quantity = $Request->qty[$i];

        $GetAmt = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','CategoryList.Qty')
        ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
        ->Where(['NewCategories.id'=>$categoryId])
        ->get();
        $sum+= $quantity;			 
        foreach($GetAmt as $Amount){

            $amountValue [] = $Amount->price * $quantity;


        }

        BookingItems::insert([
            'bookingId'=>$id,
            'quantity'=>$quantity,
            'categoryId'=>$categoryId

        ]);

    }
    $totalPayment = array_sum($amountValue);



    $grand = $totalPayment - $old_Bookings->discount_amount;
    $update = Bookings::Where('id',$id)->update(['quantity'=>$sum,'totalPayment'=>$grand]);
    if($old_Bookings->first_offer == 1){

        $grand_1 =  $grand - 50;

        $update = Bookings::Where('id',$id)->update(['quantity'=>$sum,'totalPayment'=>$grand_1]);


    }

    if(!$old_Bookings->promode_code == 0){

        $get_promo = Promocode::Select('id','discount','maximum_amount')->Where(['id'=>$old_Bookings->promode_code])->first();
        $grandtotal = $totalPayment - ($totalPayment * ($get_promo->discount/100));

        $discount = $totalPayment - $grandtotal;

        $dis = round($discount);
        $grand = round($grandtotal);

        $update = Bookings::Where('id',$id)->update(['quantity'=>$sum,'totalPayment'=>$grand,'discount_amount'=>$dis,'update_orders'=>1]);

    }

    return redirect()->route('edit.order',['id'=>$id]);

}

public function UserProfile(Request $Request){


    $mobile = $Request->mobile;

    $profile = User::Select('id','name','mobile','email')->Where('mobile',$mobile)->first();

    if($profile){

        return $profile;
    }else{

        return 0;
    }

}


public function push_notifications(Request $Request){


    $get_push = DB::table('push_notifications')->select('title','body','message',DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as sent_date'))->get();

// echo json_encode($get_push);die;

    return view('admin.admin-push',['push'=>$get_push]);
}


public function admin_sent_push(Request $Request){

    $title = $Request->title;
    $body = $Request->body;
    $message = $Request->message;


    $users = User::select('id','name','deviceToken','os')->get();

    $arraydata = array("BookingId"=>"","message"=>$body,"deliverystatus"=>"");

    foreach($users as $result){

        $fcm = new PushNotifications();
        $newresponse = $fcm->SentPush($title,$body,$result->deviceToken,$result->os,$arraydata);
    }
    $userid=Auth::User()->id;


    $push = DB::table('push_notifications')->insert([
        'title'=>$title,
        'body'=>$body,
        'message'=>$message,
        'senderId'=>$userid,
        'sender_role'=>'Super admin'
    ]);


    $get_push = DB::table('push_notifications')->select('title','body','message',DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as sent_date'))->get();


    return view('admin.admin-push',['push'=>$get_push]);


}


public function DownloadOrders(Request $Request){

    $type = $Request->type;


    $CommonFunction = new CommonFunctions();
    $response = $CommonFunction->download_orders($type);

}



public function GalleryPage(Request $Request){

    $get_gallery = DB::table('HomeGallery')->Where('status',1)->orderBy('id','DESC')->get();

    foreach($get_gallery as $gallery){

        $gallery->images = "http://13.126.228.76/ironbox_admin/public/images/Gallery/".$gallery->images;
    }

    return view('admin.gallery',['gallery'=>$get_gallery]);
}

public function AddGallery(Request $Request){

    $title =  $Request->title;
    $image = $Request->file('image');

    $input['image'] = time() . '.' . $image->getClientOriginalExtension();
    $destinationPath = public_path('/images/Gallery/');
    $image->move($destinationPath, $input['image']);

    $insert = DB::table('HomeGallery')->insert([
        'title'=>$title,
        'images'=>$input['image']
    ]);

    $get_gallery = DB::table('HomeGallery')->Where('status',1)->orderBy('id','DESC')->get();
    foreach($get_gallery as $gallery){

        $gallery->images = "http://13.126.228.76/ironbox_admin/public/images/Gallery/".$gallery->images;
    }

    return view('admin.gallery',['gallery'=>$get_gallery]); 

}

public function DeleteGallery(Request $Request){

    $id = $Request->id;

    $insert = DB::table('HomeGallery')->Where('id',$id)->update(['status'=>2]);
    $get_gallery = DB::table('HomeGallery')->Where('status',1)->orderBy('id','DESC')->get();
    foreach($get_gallery as $gallery){

        $gallery->images = "http://13.126.228.76/ironbox_admin/public/images/Gallery/".$gallery->images;
    }
    return view('admin.gallery',['gallery'=>$get_gallery]);

}

public function EditGallery(Request $Request,$id){

    $get_gallery = DB::table('HomeGallery')->Where('id',$id)->get();
    foreach($get_gallery as $gallery){

        $gallery->images = "http://13.126.228.76/ironbox_admin/public/images/Gallery/".$gallery->images;
    }

    return view('admin.edit-gallery',['gallery'=>$get_gallery]);
}

public function UpdateGallery(Request $Request){

    $id =  $Request->id;
    $title =  $Request->title;
    $image = $Request->file('image');

    if(!$image){

        $insert = DB::table('HomeGallery')->where('id',$id)->update(['title'=>$title]);

    }else{

        $input['image'] = time() . '.' . $image->getClientOriginalExtension();
        $destinationPath = public_path('/images/Gallery/');
        $image->move($destinationPath, $input['image']);

        $insert = DB::table('HomeGallery')->where('id',$id)->update([
            'title'=>$title,
            'images'=>$input['image']
        ]);

    }
    $get_gallery = DB::table('HomeGallery')->Where('status',1)->orderBy('id','DESC')->get();
    foreach($get_gallery as $gallery){

        $gallery->images = "http://13.126.228.76/ironbox_admin/public/images/Gallery/".$gallery->images;
    }
    return view('admin.gallery',['gallery'=>$get_gallery]);
}




public function PendingOrders(Request $Request){


    $BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess','ConfirmOrder','CancelDate','cancelReason','CancelReason.reasons')
    ->join('users','users.id','=','Bookings.userId')
    ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
    ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
    ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
    ->where(['Bookings.Status'=>'CONFIRMED'])
    ->orderBy('Bookings.id', 'desc')
    ->get();

    foreach($BookingsList as $Book){
        if($Book->ConfirmOrder == 1){
            $Book->Status='BOOKING CONFIRM';
        }

        if($Book->WaytoPickup == 1){
            $Book->Status='WAY TO PICKUP';
        }

        if($Book->PickupSuccess == 1){
            $Book->Status='PICKUPED';
        }
        if($Book->StartJob == 1){
            $Book->Status='IRONING STARTED';
        }

        if($Book->StartJob == 2){
            $Book->Status='IRONING COMPLETED';
        }

        if($Book->WaytoDelivery == 1){
            $Book->Status='WAY TO DELIVERY';
        }

        if($Book->DeliverySuccess == 1){
            $Book->Status='COMPLETED';
        }


    }

    return view('orders.pending-orders',['Bookings' => $BookingsList]);
}


public function CalcelledOrders(Request $Request){

    $BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess','ConfirmOrder','CancelDate','cancelReason','CancelReason.reasons')
    ->join('users','users.id','=','Bookings.userId')
    ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
    ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
    ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
    ->where(['Bookings.Status'=>'CANCELLED'])
    ->orderBy('Bookings.id', 'desc')
    ->get();

    foreach($BookingsList as $Book){

        if($Book->ConfirmOrder == 1){
            $Book->Status='BOOKING CONFIRM';
        }

        if($Book->WaytoPickup == 1){
            $Book->Status='WAY TO PICKUP';
        }

        if($Book->PickupSuccess == 1){
            $Book->Status='PICKUPED';
        }

        if($Book->WaytoDelivery == 1){
            $Book->Status='WAY TO DELIVERY';
        }

        if($Book->DeliverySuccess == 1){
            $Book->Status='COMPLETED';
        }


    }

    return view('orders.cancelled-orders',['Bookings' => $BookingsList]);

}


public function OrderCancel(Request $Request){

    $bookingId = $Request->id;

    $canceldate =   date("Y-m-d H:i:s", time());

    $cancel = "CANCELLED";

    $check_cancel = Bookings::select('id','Status')->Where('id',$bookingId)->first();

    if($check_cancel->Status == 'CONFIRMED'){

        $updateStatus  = Bookings::Where('id',$bookingId)->update(['Status' => $cancel,'CancelDate'=>$canceldate, 'cancelReason' =>5]);

        $BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess','ConfirmOrder','CancelDate','cancelReason','CancelReason.reasons')
        ->join('users','users.id','=','Bookings.userId')
        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
        ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
        ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
        ->orderBy('Bookings.id', 'desc')
        ->paginate(10);
        foreach($BookingsList as $Book){

            if($Book->ConfirmOrder == 1){
                $Book->Status='BOOKING CONFIRM';
            }

            if($Book->WaytoPickup == 1){
                $Book->Status='WAY TO PICKUP';
            }

            if($Book->PickupSuccess == 1){
                $Book->Status='PICKUPED';
            }

            if($Book->WaytoDelivery == 1){
                $Book->Status='WAY TO DELIVERY';
            }

            if($Book->DeliverySuccess == 1){
                $Book->Status='COMPLETED';
            }


        }

        return view('OrderList',['Bookings' => $BookingsList]);

    }else{


        $BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess','ConfirmOrder','CancelDate','cancelReason','CancelReason.reasons')
        ->join('users','users.id','=','Bookings.userId')
        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
        ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
        ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
        ->orderBy('Bookings.id', 'desc')
        ->paginate(10);
        foreach($BookingsList as $Book){

            if($Book->ConfirmOrder == 1){
                $Book->Status='BOOKING CONFIRM';
            }

            if($Book->WaytoPickup == 1){
                $Book->Status='WAY TO PICKUP';
            }

            if($Book->PickupSuccess == 1){
                $Book->Status='PICKUPED';
            }

            if($Book->WaytoDelivery == 1){
                $Book->Status='WAY TO DELIVERY';
            }

            if($Book->DeliverySuccess == 1){
                $Book->Status='COMPLETED';
            }


        }

        return view('OrderList',['Bookings' => $BookingsList]);



    }

}



public function AssignPendingOrder(Request $Request,$id){


    $check_outlet = pickupdeliveryuser::select('id','warehouseId')->where('id',$id)->first();

    $PickupUser = pickupdeliveryuser::Select('id','name','mobile')
    ->Where(['warehouseId'=>$check_outlet->warehouseId])
    ->Where('id','!=',$id)
    ->Where('Is_active',1)
    ->get();



    $current_date = date('Y-m-d');

    $pending_order = DB::Select("select Bookings.id,Bookings.userId,Bookings.bookingId,Bookings.bookingDate,pick_date,Bookings.delivery_date,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.bookingTimeSlot ,quantity,OrderAssign,ConfirmOrder,WaytoPickup,PickupSuccess,StartJob,WaytoDelivery,DeliverySuccess,Bookings.Status,Bookings.paidStatus,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.paymentType,users.name,users.mobile from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id inner join users on users.id = Bookings.userId where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$id."' AND OrderAssign ='1' AND pick_date < '".$current_date."' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$id."' AND delivery_date < '".$current_date."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) order by delivery_date ASC, pick_date ASC");

    foreach($pending_order as $order){

        if($order->OrderAssign == 1){

            $order->order_for = 'Pickup';
        }else{

            $order->order_for = 'Delivery';
        }


        if($order->ConfirmOrder == 1){
            $order->Status='BOOKING CONFIRM';
        }

        if($order->WaytoPickup == 1){
            $order->Status='WAY TO PICKUP';
        }

        if($order->PickupSuccess == 1){
            $order->Status='PICKUPED';
        }
        if($order->StartJob == 1){
            $order->Status='IRONING STARTED';
        }

        if($order->StartJob == 2){
            $order->Status='IRONING COMPLETED';
        }

        if($order->WaytoDelivery == 1){
            $order->Status='WAY TO DELIVERY';
        }

        if($order->DeliverySuccess == 1){
            $order->Status='COMPLETED';
        }
    }		 

// echo json_encode($pending_order);die;

    return view('admin.pending-assign',['Bookings' => $pending_order,'User'=>$PickupUser]);

}


public function UpdatePendingAssign(Request $Request){

    $UserId = $Request->pickup_user;

    for($i=0;$i<count($Request->bookingId);$i++){

        $book_id=$Request->bookingId[$i];
        $check_status = Bookings::select('id','OrderAssign')->where('id',$book_id)->first();

        if($check_status->OrderAssign == 1){
            $update = Bookings::Where(['id'=>$book_id])->update(['pickupDeliveryUserId'=>$UserId]);

        }else{

            $update = Bookings::Where(['id'=>$book_id])->update(['DeliveryUserId'=>$UserId]);
        }
    }

    $CommonFunction = new CommonFunctions();

    $PickupUsers = $CommonFunction->GetPickupUser();

    return view('admin.PickupUserList',['User' => $PickupUsers]);
}



public function DeletedPickupUser(Request $Request){


    $UserList = pickupdeliveryuser::Select('pickupdeliveryusers.id','pickupdeliveryusers.name','pickupdeliveryusers.mobile','email','serviceAreaId','pickupdeliveryusers.warehouseId','Is_active','Pincode.area','Pincode.code')
    ->leftjoin('Pincode','Pincode.id', '=', 'pickupdeliveryusers.serviceAreaId')
    ->Where('pickupdeliveryusers.Is_active', '=' , 2)
    ->orderBy('pickupdeliveryusers.name','ASC')
    ->get();	

    return view('admin.DeletedPickupUser',['User' => $UserList]);
}

//////////////////////////////////////////////////// MIC & MAC ////////////////////////////////////////////////////

///////////////////////////// TimeSlot Assign ////////////////////////////

public function DateTimeSlotAssign(Request $Request){

    $all_months=DatePincodeTSAssign::Select('month')->groupBy('month')->orderBy('id', 'ASC')->get();

    $months=array();
    $j=0;
    foreach ($all_months as $one_month) {
        $months[]=$one_month['month'];
        $j++;
    }
    $lm=explode(" ",$months[$j-1]);
    $last_month=strtotime($lm[1].'-'.$lm[0].'-1');
    for ($h=1; $h <= 3; $h++) { 
        $months[]=date("M Y", strtotime("+$h month", $last_month));
    }

    $month=$Request->month;
    $mn=date("m",strtotime($month));
    $yn=date("Y",strtotime($month));

    $last_day=cal_days_in_month(CAL_GREGORIAN,$mn,$yn);

    $dates=array();
    for ($i=1; $i <= $last_day; $i++) { 
        $dates[]=date('Y-m-d',strtotime($yn.'-'.$mn.'-'.$i));
    }

    $TimeSlots = TimeSlots::Select('*')->Where('status', '=' , 1)->get();
    $Warehouses = Warehouses::Select('*')->Where('status', '=' , 1)->get();

    $stored_dates=DatePincodeTSAssign::Select('date')->Where('month', $month)->groupBy('date')->get();
    $all_leaves=LeaveAssign::Select('date','reason')->whereRaw("DATE_FORMAT(date,'%b %Y')='$month'")->get();

    $fetchArray=array();
    $fetchArray_ts=array();
    foreach ($stored_dates as $fdates) {
        $all_dates=$fdates['date'];

        $all_whs=array();
        $all_ts=array();
        $stored_whs=DatePincodeTSAssign::Select('wh_id','name')->leftjoin('warehouses','warehouses.id', '=', 'DatePincodeTSAssign.wh_id')->Where('month', $month)->Where('date', $fdates['date'])->groupBy('wh_id')->get();
        foreach ($stored_whs as $whs) {
            $all_whs[$fdates['date']][]=$whs['wh_id'].'$'.$whs['name'];

            $stored_ts=DatePincodeTSAssign::Select('time_id','fromSlots','toSlots','slot_count')->leftjoin('TimeSlots','TimeSlots.id', '=', 'DatePincodeTSAssign.time_id')->Where('month', $month)->Where('date', $fdates['date'])->Where('wh_id', $whs['wh_id'])->get();
            foreach ($stored_ts as $ts) {
                $all_ts[$fdates['date']][$whs['wh_id'].'$'.$whs['name']][]=$ts['time_id'].'$'.$ts['fromSlots'].'-'.$ts['toSlots'].'$'.$ts['slot_count'];
            }
        }

        array_push($fetchArray, $all_whs);
        array_push($fetchArray_ts, $all_ts);
    }

    return view('admin.DateTimeSlotAssign',['months' => $months,'time_slots' => $TimeSlots,'warehouses' => $Warehouses,'dates' => $dates,'sel_month' => $month,'fetchArray' => $fetchArray,'fetchArray_ts' => $fetchArray_ts,'all_leaves' => $all_leaves]);
}

public function DateTimeSlotAssignAction(Request $Request){
    $month=$Request->month;
    $all_leave=$Request->leave;
    $all_details=$Request->all_details;
    $cur_date=date('Y-m-d');

    DatePincodeTSAssign::where('month', $month)->whereRaw("date>='$cur_date'")->delete();

    if(!empty($all_details)){
        foreach ($all_details as $details) {
            $detail=explode(' $ ',$details);
            if($detail[0]>=$cur_date){
                $data['month']=$month;
                $data['date']=$detail[0];
                $data['wh_id']=$detail[1];
                $data['time_id']=$detail[2];
                $data['slot_count']=$detail[3];

                DatePincodeTSAssign::insert($data);
            }
        }
    }

    LeaveAssign::whereRaw("DATE_FORMAT(date,'%b %Y')='$month'")->whereRaw("date>='$cur_date'")->delete();

    if(!empty($all_leave)){
        foreach ($all_leave as $leave) {
            if($leave>=$cur_date){
                $data1['date']=$leave;
                $data1['leave']=1;
                $leave_reason='leave_reason_'.$leave;
                $data1['reason']=($Request->$leave_reason=='')?'-':$Request->$leave_reason;

                LeaveAssign::insert($data1);
            }
        }
    }

    return redirect()->route('admin.datetimeslotassign.month',['month'=>$month]);
}
///////////////////////////// TimeSlot Assign ////////////////////////////


///////////////////////////// Credit Points ////////////////////////////

public function CreditPoints(Request $Request){
    $credit_points=CreditPoints::Select('*')->get();
    return view('admin.CreditPoints',['credit_points' => $credit_points]);
}

public function CreditPointsAction(Request $Request){

    $data['refferal_points']=$Request->refferal_points;
    $data['reffered_points']=$Request->reffered_points;
    $data['per_order']=$Request->per_order;
    $data['exp_days']=$Request->exp_days;

    CreditPoints::where('id',1)->update($data);

    return redirect()->route('admin.creditpoints');
}
///////////////////////////// Credit Points ////////////////////////////

//////////////////////////////////////////////////// MIC & MAC ////////////////////////////////////////////////////

}
