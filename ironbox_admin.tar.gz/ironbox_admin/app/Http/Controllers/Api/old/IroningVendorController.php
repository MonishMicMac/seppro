<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\User;
use App\pickupdeliveryuser;
use App\IroningVendor;
use App\Admin;
use App\ServiceAreas;
use App\UserAddresses;
use App\PushNotifications;
use App\TimeSlots;
use App\CommonFunctions;
use App\Categories;
use App\Bookings;
use App\BookingItems;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Session;
use GuzzleHttp\Exception\BadResponseException;
use Guzzle\Http\Exception\ServerErrorResponseException;
use Mail;
use Auth;
use DateTime;
use Validator;
use DB;

class IroningVendorController extends Controller
{
    public function AccessLogin(Request $Request){
		
		$email = $Request->email;
		
		$GetUser=IroningVendor::Where(['email'=>$email])->first();
		
		
		
		$token = $GetUser->createToken('Token Name')->accessToken;
                   $response['error']="false";
                   $response['error_message']="Login Successfully";
                   
                   
                   $response['access_token']=$token;
				   $response['id']=$GetUser->id;
				   
		
		echo json_encode($response);
	}
	
	
	public function AccessLoginUser(Request $Request){
		
		print_r(Auth::guard('IroningVendorapi')->user()->name);
	}
	
	
   /********************START**************************/


   //Vendor Login
    public function VendorLogin(Request $Request){
		
		$mobile = $Request->mobile;
		$deviceToken = $Request->deviceToken;
		
		$validator = Validator::make($Request->all(), [
				   'mobile' => 'required|digits:10|numeric',
				]);
				

				if ($validator->fails()) {

				   $response['error']="Not mobile";
				   $response['error_message']="Please enter valid number";
				   echo json_encode($response);
				   die;
				}
		$CommonFunction = new CommonFunctions();
		if($mobile && $deviceToken){
		
			  $User=IroningVendor::Where(['mobile'=>$mobile])->count();
			  //echo $User;die;
			  
			  if($User > 0){
				  
				   $otp = mt_rand(1000, 9999);
				   $message = "your verification code for Ironbox login is:".$otp;
				   $newresponse = $CommonFunction->SentOtp($mobile,$message);
				   $UserInfo =IroningVendor::where('mobile',$mobile)
				                   ->update(['otp' => $otp,'deviceToken'=>$deviceToken]);
								   
                    
				   $response['error']="false";
                   $response['error_message']="Otp Sent Successfully";
				   $response['Otp']=$otp;
                    								   
				  
			  }else{
				  
				  $otp = mt_rand(1000, 9999);
				  $message = "your verification code for Ironbox login is:".$otp;
				   $newresponse = $CommonFunction->SentOtp($mobile,$message);
				  IroningVendor::insert([
                  'mobile'=>$mobile,
                  'otp'=>$otp,
				  'deviceToken'=>$deviceToken
                  ]);
				  
				   $response['error']="false";
				   $response['Otp']=$otp;
                   $response['error_message']="Otp Sent Successfully";
			  }
			    
		}else{
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
			
		}
		echo json_encode($response);
	}



    //Check Otp
	public function VendorCheckOtp(Request $Request){
		
		$mobile = $Request->mobile;
		$otp = $Request->otp;
		
		$validator = Validator::make($Request->all(), [
				   'mobile' => 'required|digits:10|numeric',
				]);
				

				if ($validator->fails()) {

				   $response['error']="Not mobile";
				   $response['error_message']="Please enter valid number";
				   echo json_encode($response);
				   die;
				}
		
		if($mobile && $otp){
			
		 $User=IroningVendor::Where(['mobile'=>$mobile, 'otp'=> $otp])->count();	
		 if($User > 0){
			 
			   $GetUser=IroningVendor::Where(['mobile'=>$mobile])->first();
  
	               if($GetUser->dob == ''){

                   $token = $GetUser->createToken('Token Name')->accessToken;
                   $response['error']="false";
                   $response['error_message']="Login Successfully";
                   
                   
                   $response['access_token']=$token;
				   $response['id']=$GetUser->id;
				   $response['type']="NotRegister";
				   $response['mobile']=$GetUser->mobile;
					
				   }else{

                   $token = $GetUser->createToken('Token Name')->accessToken;
                   $response['error']="false";
                   $response['error_message']="Login Successfully";
                   
                   
                   $response['access_token']=$token;
				   $response['id']=$GetUser->id;
				   $response['name']=$GetUser->name;
				   $response['image']=$GetUser->image;
				   $response['type']="Register";
				   $response['mobile']=$GetUser->mobile;
				   $response['gender']=$GetUser->gender;
				   $response['dob']=$GetUser->dob;
				   }				   
			      
		 }else{
			 
			$response['error']="true";
            $response['error_message']="Invalid Otp";
			 
		 }
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
		echo json_encode($response);
	}
	
	//Resent otp
	public function ResentOtp(Request $Request){

	   if($Request->mobile){
	   
	   $GetUser = IroningVendor::Select('id','mobile','otp')->Where('mobile',$Request->mobile)->first();
		if(count($GetUser) == 1){
			
			$message = "your verification code for Ironbox login is:".$GetUser->otp;
				   
			$CommonFunction = new CommonFunctions();	   
		    $newresponse = $CommonFunction->SentOtp($Request->mobile,$message);
		
			$response['error']='false';
			$response['Otp']=$GetUser->otp;
		
		}else{
			
			$response['error']='true';
		    $response['error_message']='Invalid User';
		}
		
	    }else{
		   
		   $response['error']='true';
		    $response['error_message']='Invalid User';
	   }
		
		echo json_encode($response);
	}
	
	//Edit User Profile
	public function EditVendorProfile(Request $Request){
		
		$UserId = Auth::guard('IroningVendorapi')->user()->id;
		 
		
		$GetUser = IroningVendor::Select('mobile')->Where('id',$UserId)->count();
		
		      // $validator = Validator::make($Request->all(), [
				   // 'email' => 'required|email',
				// ]);
				

				// if ($validator->fails()) {
					
				   // $response['error']="Not mobile";
				   // $response['error_message']="Please enter valid email";
				   // echo json_encode($response);
				   // die;
					
				// }
		
		
		//print($GetUser);
		$name = $Request->name;
		$dob  = $Request->dob;
		$gender = $Request->gender;
		$image = $Request->image;
		
		if($name && $dob && $gender){
			
	
			
			$GetUser = IroningVendor::Where('id',$UserId)->Update([
			'name' => $name,
			'image'=>$image,
			'dob'  => $dob,
			'gender' => $gender

			]);
			 
			 $UserDetails = IroningVendor::Select('id','name','mobile','image','gender','dob')
			                      ->Where('id',$UserId)->first();
			
			$response['error']="false";
			$response['error_message']="Profile Update Successfully";
			$response['UserDetails']=$UserDetails;
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		echo json_encode($response);
	}
	
	
	//Home
	public function Home(Request $Request){
		
		$UserId = Auth::guard('IroningVendorapi')->user()->id;
		
		$check_login = IroningVendor::Select('id','status')->Where(['id'=>$UserId,'Is_active'=>1])->count();
		
		if($check_login == 1){
			
			$Is_admin = 1;
		}else{
			
			$Is_admin = 1;
			//make it 0
		}
		$response['error']="false";
		$response['Is_admin']=$Is_admin;
		echo json_encode($response);
	}
	
	//View Items
	public function ViewItems(Request $Request){
		
		$bookingId = $Request->bookingId;
		
		if($bookingId){
			
			$CheckBooking = Bookings::Select('id','StartJob','quantity')->Where(['id'=>$bookingId,'StartJob'=>0])->first();
			
			if(count($CheckBooking) == 1){
			
			   $GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => $bookingId])
								  ->get();  
			   
			   $response['error']="false";
			   $response['bookingId']=$CheckBooking->id;
			   $response['total_clothes']=$CheckBooking->quantity;
			   $response['response']=$GetOrder;
			
			}else{
				
				$response['error']="true";
                $response['error_message']="Ironing already started";
			}
			
		 }else{
			
			$response['error']="true";
            $response['error_message']="BookingId missing";
		}
		echo json_encode($response);
	}
	
	//Job status
	public function StartJob(Request $Request){
		
		$UserId = Auth::guard('IroningVendorapi')->user()->id;
		$bookingId = $Request->bookingId;
		
		echo $bookingId;die;
		
		if($bookingId){
			date_default_timezone_set('Asia/Kolkata');
			$CheckBooking = Bookings::Select('id','StartJob','quantity')
			                         ->Where(['id'=>$bookingId,'StartJob'=>0])
									 ->first();
			//echo $CheckBooking;die;
			 if(count($CheckBooking) == 1){
				
				$UpdateStatus = Bookings::Select('id','VendorUserId','StartJob','JobStatus')
				                         ->Where('id',$bookingId)
				                         ->update(['VendorUserId'=>$UserId,'StartJob'=>1,'JobStatus'=>1]);
				$GetDetails = Bookings::Select('Bookings.id','Bookings.bookingId','bookingDate','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','quantity')
				                        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
										->Where(['Bookings.id'=>$bookingId])
										->first();
									
				
				$response['error']="false";
                $response['error_message']="Job started successfully";
                $response['job_key']='0';
				$response['bookingId']=$GetDetails->id;
				$response['bookId']=$GetDetails->bookingId;
				$response['bookingDate']=date("d-m-Y");
				$response['TimeSlots']=date("H:i:s");
				//$response['TimeSlots']=$GetDetails->fromSlots. " - ". $GetDetails->toSlots;
				$response['quantity']=$GetDetails->quantity;
				
			 }else{
				
				$completed =  date("Y-m-d H:i:s", time());
				$UpdateStatus = Bookings::Select('id','DeliveryUserId','OrderAssign','StartJob','JobStatus')->Where('id',$bookingId)
				                         ->update(['StartJob'=>2,'JobStatus'=>0,'DeliveryUserId'=>2,'OrderAssign'=>2,'job_completed'=>$completed]);
				$GetDetails = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','bookingDate','bookingTimeSlot','Bookings.addressId','TimeSlots.fromSlots','TimeSlots.toSlots','quantity')
				                        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
										->Where(['Bookings.id'=>$bookingId])
										->first();
				//$AddId = $GetDetails->addressId;						
				//$assign_delivery = $this->AssignDelivery($AddId);						
				//echo $GetDetails;
				//die;					
                $fcm = new PushNotifications();
				$GetUserData = User::Select('id','name','deviceToken','os')->where('id',$GetDetails->userId)->first();
				$title = "Order status";
				$body ="Job completed successfully";
				$token = $GetUserData->deviceToken;
				$os = $GetUserData->os;
				$arraydata = array("BookingId"=>"","message"=>$body,"deliverystatus"=>"");
				$newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);				
				
										
				$response['error']="false";
                $response['error_message']="Job already completed successfully";
				$response['job_key']='1';
				$response['bookingId']=$GetDetails->id;
				$response['bookId']=$GetDetails->bookingId;
				$response['bookingDate']=date("d-m-Y");
				$response['TimeSlots']=date("H:i:s");
				//$response['TimeSlots']=$GetDetails->fromSlots. " - ". $GetDetails->toSlots;
				$response['quantity']=$GetDetails->quantity;
			}
			
		 }else{
			$response['error']="true";
            $response['error_message']="BookingId missing";
		}
		echo json_encode($response);
	}
	
	//Assign Delivery
	function AssignDelivery($AddId){

		$serviceId = UserAddresses::Where('id',$AddId)->value('serviceAreaId');
		
		$GetDeliveryUser = pickupdeliveryuser::Select('id','serviceAreaId')->Where(['serviceAreaId'=>$serviceId,'Is_active'=>1])->get();
		
		foreach($GetDeliveryUser as $Delivery){
			
			   //$Orders = DB::select("select count(*) as orders from Bookings where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$Delivery->id."' AND OrderAssign ='1' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$Delivery->id."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ");
			   
		       $Orders = DB::select("select Bookings.id,OrderAssign from Bookings where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$Delivery->id."' AND OrderAssign ='1' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$Delivery->id."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ");

             $Delivery->orderWeight = count($Orders);			   
             //$Delivery->orderWeight = $Orders;			   
			
		}
		
		//echo json_encode($GetDeliveryUser);die;
		
		$encode = json_encode($GetDeliveryUser);
		
		$new_array = json_decode($encode);
		
		usort($new_array,array("App\Http\Controllers\Api\IroningVendorController", "sortorder"));;
		
		echo json_encode($new_array[0]->id);
	}
	
	public function sortorder($a, $b){

        return $a->orderWeight > 5;
        //return $a->orderWeight > $b->orderWeight;
      
    }

	//Current Orders
	public function CurrentOrder(Request $Request){
		$UserId = Auth::guard('IroningVendorapi')->user()->id;
		
		
		$GetOrder = Bookings::Select('Bookings.id','Bookings.bookingId','VendorUserId','users.name','Bookings.bookingDate','TimeSlots.fromSlots','TimeSlots.toSlots','quantity','Bookings.totalPayment','JobStatus')
		                      ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('users','users.id', '=', 'Bookings.userId')
		                      ->Where(['Bookings.VendorUserId'=>$UserId,'Bookings.JobStatus'=>1])
							  ->get();
		foreach($GetOrder as $Orders){
               //echo $Orders->id;die;
          $Orders->TimeSlots = $Orders->fromSlots. " - ". $Orders->toSlots;
		  $Orders->bookingDate = date("d-m-Y");
		  
		  $GetOrderList = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','CategoryList.Price','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => $Orders->id])
								  ->get();
			   
			    $Orders->BookingItems=$GetOrderList;
			
		  
		}		
							  
		if(count($GetOrder)> 0){
			$response['error']="false";
            $response['response']=$GetOrder;
			
		}else{
			$response['error']="true";
            $response['error_message']="No order available";
		}
		echo json_encode($response);
	}
	
	
	//Get Order
	public function GetOrders(Request $Request){

		$bookingId = $Request->bookingId;
		//echo $bookingId;die;    
		
		if($bookingId){
			
		$GetUser = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','users.mobile','fromSlots','toSlots','Bookings.bookingTimeSlot','Bookings.quantity','Bookings.totalPayment','Bookings.taxamount','Bookings.PickupSuccessDate','Bookings.DeliverySuccessDate')
                             ->join('users','users.id', '=', 'Bookings.userId')
                             ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							 ->Where(['Bookings.id'=>$bookingId])
                             ->first();
        
							 
		  $GetUser->taxamount  ="Rs.".round($GetUser->taxamount, 2);
		  $GetUser->totalPayment  ="Rs.".$GetUser->totalPayment;
		  if(!$GetUser->DeliverySuccessDate == 0){
		    $deliverytime  = explode(" ",$GetUser->DeliverySuccessDate);
		    $GetUser->deliverytime = $deliverytime[1];
		  }else{
			   $GetUser->deliverytime = "";
		  }
		  
		  if(!$GetUser->PickupSuccessDate == 0){
		  $pickuptime  = explode(" ",$GetUser->PickupSuccessDate);
		  $GetUser->pickuptime = $pickuptime[1];
		  }else{
			  $GetUser->pickuptime = "";
		  }

		  //echo $GetUser;die;
       // foreach($GetUser as $User){

        //$User->TimeSlot = $User->fromSlots. " - " .$User->toSlots; 		 
 		 
		$GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.Price','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => $bookingId])
								  ->get();
				
//echo json_encode($GetOrder);die;				
			foreach($GetOrder as $Amt){
                 
               $priceamt = $Amt->Price;
               $Amt -> amount = "Rs.".$priceamt * $Amt->quantity; 
			   $Amt -> Price = "Rs.".$priceamt;
			} 						  
         //$User->BookingItems = $GetOrder;
		//}		
			

		
		if(count($GetOrder) > 0){

			 $response['error']="false";
			 $response['UserInfo']=$GetUser;
			  // $response['id']=$GetUser->id;
			  // $response['userId']=$GetUser->userId;
			  // $response['bookingTimeSlot']=$GetUser->bookingTimeSlot;
			  // $response['quantity']=$GetUser->quantity;
			  // $response['totalPayment']="Rs.".$GetUser->totalPayment;
			  // $response['taxamount']="Rs.".round($GetUser->taxamount, 2);
              $response['BookingItems']=$GetOrder;

		}else{

              $response['error']="true";
              $response['error_message']="No Items Available";
		}			
		
		 }else{
			
			$response['error']="true";
            $response['error_message']="BookingId missing";
			
		}
		echo json_encode($response);
		
	}
	
	
	
	//Scan Order
	public function ScanOrder(Request $Request){
		
		$UserId = Auth::guard('IroningVendorapi')->user()->id;

		$bookingId = $Request->bookingId;
		
		if($bookingId){
			
		$Check_cancel = Bookings::Select('id','Status')
								  ->Where(['Bookings.id'=>$bookingId])
								  ->WhereIn('Status',['CANCELLED','COMPLETED'])
								  ->first();
									
		if(count($Check_cancel) == 1){
			   $response['error']="true";
			   $response['error_message']="This booking ID is duplicate or cancelled";
			   echo json_encode($response);
			   die;
		  }
		$GetDetails = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','bookingDate','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','quantity','Bookings.totalPayment')
				                        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
										->join('users', 'users.id','=','Bookings.userId')
										//->whereIn('Status',['0','2'])
										->Where(['Bookings.id'=>$bookingId])
										->first();
		  $GetDetails->TimeSlots = $GetDetails->fromSlots. " - ". $GetDetails->toSlots;	
          
		  if(count($GetDetails) == 0){
			   $response['error']="false";
			   $response['error_message']="Invalid BookingId";
			   echo json_encode($response);
			   die;
		  }
		  
		  $GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.Price','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => $bookingId])
								  ->get();
							
			foreach($GetOrder as $Amt){
                 
               $priceamt = $Amt->Price;
               $Amt -> amount = "Rs.".$priceamt * $Amt->quantity; 
			   $Amt -> Price = "Rs.".$priceamt;
			}  
		  
		  $GetDetails->BookingItems = $GetOrder;
		  $response['error']="false";
		  $response['error_message']="Order scan completed";
		  $response['response']=$GetDetails;
		}else{
			
			$response['error']="true";
            $response['error_message']="BookingId missing";
		}
		echo json_encode($response);
	}
	
	
	//OrderHistory
	public function OrderHistory(Request $Request){
		
		$UserId = Auth::guard('IroningVendorapi')->user()->id;

		$page_number = $Request->page_number;
		
		if($page_number == ''){
			
			$response['error']="true";
            $response['error_message']="Mandatory parameters are missing";
	
			echo json_encode($response);
			die;
		}
		
		if($page_number == '0')
         {
         $page_number = '0';
             
         }else{
             $page_number = $page_number - 1;
         
         }
		  $page_offset=($page_number * 5);
		
		$GetDetails = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','bookingDate','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','quantity','job_completed')
				                        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
										->join('users', 'users.id','=','Bookings.userId')
										->Where(['Bookings.VendorUserId'=>$UserId,'StartJob'=>2])
										->orderBy('Bookings.job_completed', 'DESC')
										->offset($page_offset)
								        ->limit(5)
										->get();
		foreach($GetDetails as $Orders){

          $Orders->TimeSlots = $Orders->fromSlots. " - ". $Orders->toSlots;
		  $completed_date  = explode(" ",$Orders->job_completed);
		  
		   $cdate = $completed_date[0]; 
		   $Orders->bookingDate = date("d-m-Y", strtotime($cdate)); 
		}

		$PageCount = Bookings::Select('Bookings.id','Bookings.userId','users.name','bookingDate','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','quantity')
				                        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
										->join('users', 'users.id','=','Bookings.userId')
										->Where(['Bookings.VendorUserId'=>$UserId,'StartJob'=>2])
										->get();
		 $total = count($PageCount)/5;  
         $NumOfPage = ceil($total);	
		if(count($GetDetails) > 0){
			$response['error']="false";
			$response['pages']=$NumOfPage;
            $response['response']=$GetDetails;
		}else{
			$response['error']="true";
            $response['error_message']="No order history";
		}
		echo json_encode($response);
	}
	
	
	//UploadBill
	public function UploadBill(Request $Request){
		
		$UserId = Auth::guard('IroningVendorapi')->user()->id;
		
		$bookingId = $Request->bookingId;
		$image = $Request->image;
		
		if($bookingId && $image){
			
		$Check_cancel = Bookings::Select('id','Status')
							  ->WhereIn('Status',['CANCELLED','COMPLETED'])
							  ->Where(['Bookings.id'=>$bookingId,'Status'=>'CANCELLED'])
							  ->first();
									
		if(count($Check_cancel) == 1){
			   $response['error']="true";
			   $response['error_message']="Order cancelled by user";
			   echo json_encode($response);
			   die;
		  }
		
		$CheckBooking = Bookings::Select('id','bookingId','VendorUserId')->Where(['id'=>$bookingId])->first();
		
		if(count($CheckBooking) == 1){
		  
		  $UpdateImage = Bookings::Select('id','bookingId','bill_image')->Where(['id'=>$bookingId])->update(['bill_image'=>$image]);
 		  
		  $response['error']="false";
		  $response['error_message']="Bill uploaded successfully";
			
		 }else{
			
			$response['error']="true";
            $response['error_message']="Invalid Booking Id";
		}
		 }else{
			
			$response['error']="true";
            $response['error_message']="Invalid BookingId";
		}
		
		
		echo json_encode($response);
		
	}
	
	//ContentPages
	public function ContentPages(Request $Request){

			$terms  =  "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.";
			
			$privacy  =  "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
			
			
			 $about  =  "Ironbox provides steam ironing service via mobile bookings. Our service catalogue covers credible ironing service for every outfit, be it different in style or material. We have begun this company with a vision to continuously equip and create employment opportunities by building a business model that encompasses on-boarding trainees, service providers, managing quality control, and business analyst while at the same time providing standard service, experience and price to the customers.\n \n Ironbox brings quality ironing service to the customers. We have created a technology platform, a website and a mobile app which makes it convenient for the customers. We assure on time delivery and promising service. \n \n Our features \n - Pickup & Delivery\n- Expert professionals on board\n- Affordable\n- Timely delivery\n- Quality check control";
         	
		 
		    $response['error']='false';
			$response['Terms']=$terms;
			$response['Privacy']=$privacy;
			$response['About']=$about;

	     	echo json_encode($response);
			
	}
	
	//Vendor suppot
	
	public function VendorSupport(Request $Request){
		$UserId = Auth::guard('IroningVendorapi')->user()->id;
		
		if($Request->Comments){
		$Support = DB::table('VendorSupport')->insert([
		               'vendorId' => $UserId,
					   'Comments' => $Request->Comments
					]);
					
         $response['error']="false";
         $response['error_message']="Customer support added successfully";	
		 
		}else{

        $response['error']="true";
        $response['error_message']="Mandatory parameters are missing";

		}		 

        echo json_encode($response);

	}
	
	
	//logout
	public function logout(Request $Request){
		
		$UserId = Auth::guard('IroningVendorapi')->user()->id;
		
		$update=IroningVendor::where('id',$UserId)->update(['deviceToken'=>" "]);
    
		if($update)
		{
			$response['error']='false';
			$response['error_message']='Logout Successfully.';
		}else{
			$response['error']='true';
			$response['error_message']='not logged out';
		}
		echo json_encode($response);
		
	}
    //Viwe Bookings
   /* public function ViewBookingOrder(Request $Request){

        $UserId = Auth::guard('IroningVendorapi')->user()->id;
		
		//echo $UserId;die;
		
		$bookingId = $Request->bookingId;
		
		if($bookingId){
			
		$GetBookingId = BookingItems::Where('bookingId',$bookingId)->get();

        if(count($GetBookingId) > 0 ){  		
		
		$GetItems = DB::table('Booking_Items') 
		                          ->select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Categories.name')
		                          ->Where('bookingId',$bookingId)
		                          ->join('Categories','Categories.id','=','Booking_Items.categoryId')
		                          ->get();
		
		
		    $response['error']="false";
            $response['response']=$GetItems;
		}else{
			$response['error']="true";
            $response['error_message']="Booking Id Not Avaliable";
		}
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
       echo json_encode($response);
	}*/

    	
	
	
}
