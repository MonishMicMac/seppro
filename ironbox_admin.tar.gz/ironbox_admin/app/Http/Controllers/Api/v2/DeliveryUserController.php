<?php

namespace App\Http\Controllers\Api\v2;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\User;
use App\pickupdeliveryuser;
use App\WalletTransaction;
use App\IroningVendor;
use App\Admin;
use App\ServiceAreas;
use App\UserAddresses;
use App\TimeSlots;
use App\Categories;
use App\CategoryList;
use App\Bookings;
use App\Promocode;
use App\UserPromocode;
use App\Packages;
use App\PackageTransaction;
use App\BookingItems;
use App\PushNotifications;
use App\CommonFunctions;
use App\Warehouses;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Session;
use GuzzleHttp\Exception\BadResponseException;
use Guzzle\Http\Exception\ServerErrorResponseException;
use Mail;
use Auth;
use Validator;
use DateTime;
use QrCode;
use DB;

class DeliveryUserController extends Controller
{
	//Login
    public function DeliveryUserLogin(Request $Request){
		
		$mobile = $Request->mobile;
		$deviceToken = $Request->deviceToken;
		
		$validator = Validator::make($Request->all(), [
				   'mobile' => 'required|digits:10|numeric',
				]);
				

				if ($validator->fails()) {

				   $response['error']="true";
				   $response['error_message']="Please enter valid number";
				   echo json_encode($response);
				   die;
				}
				
		if($mobile && $deviceToken){
		
			  $User=pickupdeliveryuser::Where(['mobile'=>$mobile])->count();
			  //echo $User;die;
			  $CommonFunction = new CommonFunctions();
			  if($User > 0){
				  
				   $otp = mt_rand(1000, 9999);
				   $message = "your verification code for Ironbox login is:".$otp;
				   $newresponse = $CommonFunction->SentOtp($mobile,$message);
				   $UserInfo =pickupdeliveryuser::where('mobile',$mobile)
				                   ->update(['otp' => $otp]);
								   
                    
				   $response['error']="false";
                   $response['error_message']="Otp Sent Successfully";
				   $response['Otp']=$otp;
                    								   
				  
			  }else{
				  
				  $otp = mt_rand(1000, 9999);
				  $message = "your verification code for Ironbox login is:".$otp;
				  $newresponse = $CommonFunction->SentOtp($mobile,$message);
				  pickupdeliveryuser::insert([
                  'mobile'=>$mobile,
                  'otp'=>$otp,
				  'deviceToken'=>$deviceToken

                  ]);
				  
				   $response['error']="false";
				   $response['Otp']=$otp;
                   $response['error_message']="Otp Sent Successfully";
			  }
			    
		}else{
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
			
		}
		echo json_encode($response);
	}
	

	
	 //Check Otp
	public function DeliveryUserCheckOpt(Request $Request){
	
		$mobile = $Request->mobile;
		$otp = $Request->otp;
		
		$validator = Validator::make($Request->all(), [
				   'mobile' => 'required|digits:10|numeric',
				]);
				

				if ($validator->fails()) {
					
					//print_r($validator->fails());

				   $response['error']="Not mobile";
				   $response['error_message']="Please enter valid number";
				   echo json_encode($response);
				   die;
					
				}
		
		
		if($mobile && $otp){
			
		 $User=pickupdeliveryuser::Where(['mobile'=>$mobile, 'otp'=> $otp])->count();	
		 if($User > 0){
			 
			   $GetUser=pickupdeliveryuser::Where(['mobile'=>$mobile])->first();
  
	               if($GetUser->email == ''){

                   $token = $GetUser->createToken('Token Name')->accessToken;
                   $response['error']="false";
                   $response['error_message']="Login Successfully";
                   
                   
                   $response['access_token']=$token;
				   $response['id']=$GetUser->id;
				   $response['type']="NotRegister";
				   $response['mobile']=$GetUser->mobile;
					
				   }else{

                   $token = $GetUser->createToken('Token Name')->accessToken;
                   $response['error']="false";
                   $response['error_message']="Login Successfully";
                   
                   
                   $response['access_token']=$token;
				   $response['id']=$GetUser->id;
				   $response['name']=$GetUser->name;
				   $response['type']="Register";
				   $response['mobile']=$GetUser->mobile;
				   $response['email']=$GetUser->email;
				   $response['alternate_number']=$GetUser->alternate_number;
				   $response['gender']=$GetUser->gender;
				   $response['dob']=$GetUser->dob;
				   $response['image']=$GetUser->image;
				   $response['address']=$GetUser->address;
				   }				   
			      
		 }else{
			 
			$response['error']="true";
            $response['error_message']="Invalid Otp";
			 
		 }
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
		echo json_encode($response);
	}
	
	
	//Edit User Profile
	public function EditProfile(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		
			$validator = Validator::make($Request->all(), [
				   'alternate_number' => 'nullable|digits:10|numeric',
				]);
				
				if ($validator->fails()) {

				   $response['error']="true";
				   $response['error_message']="Please enter valid number";
				   echo json_encode($response);
				   die;
				}
				
		$CheckMobile = pickupdeliveryuser::Select('id','mobile','alternate_number')
					   ->Where('mobile', '=',  $Request->alternate_number)
		               ->count();
					 
		if($CheckMobile == '1'){

		   $response['error']="true";
		   $response['error_message']="Alternate number and your mobile number are same";
		   echo json_encode($response);
		   die;
		}		

		if($Request->keyvalue == '1'){
		//With E-mail
		$GetUserCount = pickupdeliveryuser::Select('mobile')->Where('id',$UserId)->count();
		if($GetUserCount > 0){
		
		      $validator = Validator::make($Request->all(), [
				   'email' => 'required|email',
				]);
				

				if ($validator->fails()) {
					

				   $response['error']="true";
				   $response['error_message']="Please enter valid email";
				   echo json_encode($response);
				   die;
					
				}
	
		$name = $Request->name;
		$dob  = $Request->dob;
		$gender = $Request->gender;
		$email =  $Request->email;
		$alternate_number =  $Request->alternate_number;
		$address =  $Request->address;
		$image =  $Request->image;
		
		if($name && $dob && $gender && $email && $address && $image){
			
			try{
			
			$GetUser = pickupdeliveryuser::Where('id',$UserId)->Update([
			        'name' => $name,
					'dob'  => $dob,
					'gender' => $gender,
					'email' => $email,
					'alternate_number' => $alternate_number,
					'address' => $address,
					'image' => $image
			]);
			}catch (\Illuminate\Database\QueryException  $ex) {
                 $response['error']='true';
				 $response['error_message']='Email Already Exists';
				 echo json_encode($response); 
				 die;
             }
			 
			 $UserDetails = pickupdeliveryuser::Select('id','name','mobile','email','image','alternate_number','gender','dob','address','image')
			                      ->Where('id',$UserId)->first();
			
			$response['error']="false";
			$response['error_message']="Profile Update Successfully";
			$response['UserDetails']=$UserDetails;
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
		}else{
			
			$response['error']="true";
            $response['error_message']="Invalid Id";
		}
		
		
     	}else{
			
		//WithOut E-mail
		
		$GetUserCount = pickupdeliveryuser::Select('mobile')->Where('id',$UserId)->count();
		if($GetUserCount > 0){ 

		$name = $Request->name;
		$dob  = $Request->dob;
		$gender = $Request->gender;
		$alternate_number =  $Request->alternate_number;
		$address =  $Request->address;
		$image =  $Request->image;
		
		if($name && $dob && $gender && $image){ 

			$GetUser = pickupdeliveryuser::Where('id',$UserId)->Update([
					'name' => $name,
					'image'=>$image,
					'dob'  => $dob,
					'gender' => $gender,
					'alternate_number' => $alternate_number
			]);
			
			 
			 $UserDetails = pickupdeliveryuser::Select('id','name','mobile','email','image','alternate_number','gender','dob','address','image')
			                      ->Where('id',$UserId)->first();
			
			$response['error']="false";
			$response['error_message']="Profile Update Successfully";
			$response['UserDetails']=$UserDetails;
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
		}else{
			
			$response['error']="true";
            $response['error_message']="Invalid Id";
		}
			
		}
		echo json_encode($response);
			
	}
	
	//Categories
	public function Categories(Request $Request){
		
		$GetMens = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','image','CategoryList.Qty')
		                     ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                     ->Where(['groupName'=>'Mens'])
							 ->get();
		foreach($GetMens as $Mens){
           $Mens->image = "http://139.59.37.241/Ironman/public/images/Icons/".$Mens->image;
		}		
		$GetWomens = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','image','CategoryList.Qty')
		                     ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                     ->Where(['groupName'=>'Womens'])
							 ->get();	
        foreach($GetWomens as $Womens){
           $Womens->image = "http://139.59.37.241/Ironman/public/images/Icons/".$Womens->image;
		}
        $GetUsuals = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','image','CategoryList.Qty')
		                     ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                     ->Where(['groupName'=>'General Clothes'])
							 ->get();							 
		foreach($GetUsuals as $Usuals){
           $Usuals->image = "http://139.59.37.241/Ironman/public/images/Icons/".$Usuals->image;
		}
		$GetExclusive = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','image','CategoryList.Qty')
		                     ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                     ->Where(['groupName'=>'Exclusive'])
							 ->get();
		foreach($GetExclusive as $Exclusive){
           $Exclusive->image = "http://139.59.37.241/Ironman/public/images/Icons/".$Exclusive->image;
		}
		$response= [];
		$MensValue=array("name"=>"Mens Clothes","Category"=>$GetMens);
		$WomensValue=array("name"=>"Womens Clothes","Category"=>$GetWomens);
		$UsualsValue=array("name"=>"General Clothes","Category"=>$GetUsuals);
		$ExclusiveValue=array("name"=>"Exclusive","Category"=>$GetExclusive);
		
	      array_push($response, $MensValue);
	      array_push($response, $WomensValue);
	      array_push($response, $UsualsValue);
	      array_push($response, $ExclusiveValue);
		  echo  json_encode(array("error"=>"false","response"=>$response));
		
	}
	
	//Order List
	public function OrderList(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		
		///echo $UserId;die; 
		
		$CheckPrint = Bookings::Select('Bookings.id','Bookings.BookingId','Bookings.pickupDeliveryUserId','PickupSuccess','Bookings.bookingDate','Bookings.Is_print','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','Bookings.totalPayment','Bookings.paymentType')
		                        ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
		                        ->Where(['pickupDeliveryUserId'=>$UserId,'PickupSuccess'=>1,'Is_print'=>0])
								->first();
		
		if(count($CheckPrint) > 0){
			
		 	$CheckPrint->TimeSlot = $CheckPrint->fromSlots. " - ". $CheckPrint->toSlots;
			$CheckPrint->totalPayment ="Rs.".$CheckPrint->totalPayment;
			$Is_print = 1;
		  }else{
			
			$CheckPrint = (object) array();
			$Is_print = "0";
		}
		
		//login status
		$check_login = pickupdeliveryuser::Select('id','status')->Where(['id'=>$UserId,'Is_active'=>1])->count();
		
		if($check_login == 1){
			
			$Is_admin = 1;
		}else{
			
			$Is_admin = 1;
			// make it 0
		}
		
		$page_number = $Request->page_number;
		$latitude = $Request->latitude;
		$longitude = $Request->longitude;
		
		if($page_number == ''){
			
			$response['error']="true";
            $response['error_message']="Mandatory parameters are missing";
	
		   echo json_encode($response);
		   die;
		}
		
		if($page_number == '0')
         {
         $page_number = '0';
             
         }else{
             $page_number = $page_number - 1;
         
         }
		  $page_offset=($page_number * 5);
		  $current_date = date("d-m-Y");
		  
		  
		  $pending_order = DB::Select("select Bookings.id,Bookings.userId,Bookings.bookingId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status,Bookings.paidStatus,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.paymentType from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$UserId."' AND OrderAssign ='1' AND bookingDate < '".$current_date."' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$UserId."' AND delivery_date < '".$current_date."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL )");
		  
		  // $pending_order  = DB::Select("Select bookingId,bookingDate from Bookings Where bookingDate < '".$current_date."' ");
		  
		  //echo json_encode($pending_order);die;  
		  
		
		  
		  $yester_day = date('d-m-Y', strtotime($current_date. ' - 1 day'));
		  
		  
		  foreach($pending_order as $List){
				
				$List ->TimeSlot = $List->fromSlots. " - " . $List->toSlots;
				
				if($List->OrderAssign == 1){
					$List->Status = "PICKUP";
				}else if($List->OrderAssign == 2){
					$List->Status = "DELIVERY";
				}
				
				 if($List->quantity == null){
					
					 $List->quantity = "";
				}
				
				if($yester_day == $List->bookingDate){
					
					$List->pending_status = 1;
				}else{
					
					$List->pending_status = 2;
				}
				
				$GetUser  = User::Select('id','name','mobile')->Where('id',$List->userId)->first();
				$GetUser->mobile ="+91".$GetUser->mobile;
				$GetAddress = UserAddresses::Select('id','title','flatNo','landmark','address','latitude','longitude')
				                            ->Where('id',$List->addressId)
											->first();

				$List -> UserDetails =$GetUser;
				$List -> Address =$GetAddress;
				
			}
		  // $ord_2 = DB::Select("Select bookingId,bookingDate from Bookings Where bookingDate = '".$current_date."'");
		  
		  // $newarr = array_merge($ord_1,$ord_2);
		  
		  // echo json_encode($pending_order);die;  
		  
		  $Orders = DB::select("select Bookings.id,Bookings.userId,Bookings.bookingId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status,Bookings.paidStatus,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.paymentType from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$UserId."' AND OrderAssign ='1' AND bookingDate='".$current_date."' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$UserId."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ORDER BY Bookings.id DESC LIMIT $page_offset,5 ");
		  
		  // $Orders = DB::select("select Bookings.id,Bookings.userId,Bookings.bookingId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status,Bookings.paidStatus,Bookings.paymentType,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$UserId."' AND OrderAssign ='1' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$UserId."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ORDER BY Bookings.id DESC LIMIT $page_offset,5 ");
		  
		  
           
		   if(count($Orders) > 0){
		   
            foreach($Orders as $List){
				
				$List ->TimeSlot = $List->fromSlots. " - " . $List->toSlots;
				$List ->pending_status = 0;
				
				if($List->OrderAssign == 1){
					$List->Status = "PICKUP";
				}else if($List->OrderAssign == 2){
					$List->Status = "DELIVERY";
				}
				
				 if($List->quantity == null){
					
					 $List->quantity = "";
				}
				
				$GetUser  = User::Select('id','name','mobile')->Where('id',$List->userId)->first();
				$GetUser->mobile ="+91".$GetUser->mobile;
				$GetAddress = UserAddresses::Select('id','title','flatNo','landmark','address','latitude','longitude')
				                            ->Where('id',$List->addressId)
											->first();

				$List -> UserDetails =$GetUser;
				$List -> Address =$GetAddress;
				
			}
			
			$OrdersCount = DB::select("select Bookings.id,Bookings.userId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$UserId."' AND OrderAssign ='1' UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$UserId."' AND OrderAssign ='2' )");
			
			  $merge_arr  = array_merge($pending_order,$Orders);
			
			 $total = count($merge_arr)/5;  
             $NumOfPage = ceil($total);	
			
			$response['error']="false";
			$response['Pages']=$NumOfPage;
			$response['Is_admin']=$Is_admin;
			$response['Is_print']=$Is_print;
			$response['print']=$CheckPrint;
            $response['response']=$merge_arr;	
			
		   }else{
			   
				$response['error']="true";
				$response['Is_admin']=$Is_admin;
				$response['Is_print']=$Is_print;
		     	$response['print']=$CheckPrint;
				$response['error_message']="No Service Avaliable";	
			}
				
			echo json_encode($response);
		   //select bookingDate from Bookings where id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= userid UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = dropid);
		   
		   //$res = DB::select("select Bookings.id,Bookings.userId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.bookingTimeSlot from Bookings where id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '6' AND OrderAssign ='1' UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '6' AND OrderAssign ='2' )");
		   
		//echo json_encode($Orders);
		
	}
	
	//map view
	public function MapView(Request $Request){
		
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		  $current_date = date("d-m-Y");
		  // $Orders = DB::select("select Bookings.id,Bookings.bookingId,Bookings.userId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$UserId."' AND OrderAssign ='1' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$UserId."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ORDER BY Bookings.updated_at DESC ");
		  
		  $Orders = DB::select("select Bookings.id,Bookings.userId,Bookings.bookingId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status,Bookings.paidStatus,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$UserId."' AND OrderAssign ='1' AND bookingDate='".$current_date."' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$UserId."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ORDER BY Bookings.id DESC ");
           
		   if(count($Orders) > 0){
		   
            foreach($Orders as $List){
				
				$List ->TimeSlot = $List->fromSlots. " - " . $List->toSlots;
				
				if($List->OrderAssign == 1){
					$List->Status = "PICKUP";
				}else if($List->OrderAssign == 2){
					$List->Status = "DELIVERY";
				}
				
				 if($List->quantity == null){
					
					 $List->quantity = "";
				}
				
				$GetUser  = User::Select('id','name','mobile')->Where('id',$List->userId)->first();
				
				$GetAddress = UserAddresses::Select('id','title','flatNo','landmark','address','latitude','longitude')
				                            ->Where('id',$List->addressId)
											->first();

				$List -> UserDetails =$GetUser;
				$List -> Address =$GetAddress;
				
			}

			$response['error']="false";
            $response['response']=$Orders;	
			
		   }else{
			   
				$response['error']="true";
				$response['error_message']="No Service Avaliable";	
			}
				
			echo json_encode($response);
	}
	
	public function UserDetails(Request $Request){
		
		$bookingId = $Request->bookingId;

		if($bookingId){
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','users.mobile','Bookings.addressId','flatNo','landmark','UserAddresses.address','UserAddresses.latitude','UserAddresses.longitude','UserAddresses.serviceAreaId','Bookings.bookingDate','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','Bookings.paymentType','Bookings.totalPayment','Bookings.discount_amount','promocode.promocode as offer_code','Bookings.paidStatus','Bookings.paymentType','Bookings.taxamount','ConfirmOrder','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
		                      ->Where(['Bookings.id'=>$bookingId])
		                      ->first();
            //echo $Bookings;die;
		if($Bookings->offer_code == null){
           $Bookings->offer_code = "";
		}		
		if(count($Bookings) == 0){
			
			$response['error']="true";
		    $response['error_message']="Invalid bookingId";
			echo json_encode($response);
			die;
			
		}
         if($Bookings->WaytoPickup == 1){
			 
            $Bookings->PickupStart = "yes";
		  }else{
            $Bookings->PickupStart = "No";
		 }
		 
         if($Bookings->WaytoDelivery == 1){
			 
            $Bookings->DeliveryStart = "yes"; 
		  }else{
            $Bookings->DeliveryStart = "No";  
		 }		 
		 
		 $grand = $Bookings->totalPayment + $Bookings->discount_amount;
		 $Bookings->totalPayment = "Rs.".$Bookings->totalPayment;
		 $Bookings->grand_total = "Rs.".$grand; 
		 //echo $grand;die;
		 $Bookings->mobile="+91-".$Bookings->mobile;	
		 $Bookings->TimeSlot=$Bookings->fromSlots. " - ". $Bookings->toSlots;	
         //$Bookings->totalPayment = "Rs.".$grand;  		
          		
         $Bookings->taxamount = "Rs.".$Bookings->taxamount;	

		 
         // $GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','categoryId','name','price')
		                          // ->join('CategoryList','CategoryList.id', '=', 'Booking_Items.categoryId')
		                          // ->Where(['Booking_Items.bookingId' => $bookingId])
								  // ->get();
								  
		// foreach($GetOrder as $Amt){
                 
               // $priceamt = $Amt->price;
               // $Amt -> amount = "Rs.".$priceamt * $Amt->quantity; 
			   // $Amt -> price = "Rs.".$priceamt;
			// }	

			// $GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','CategoryList.Price','NewCategories.image','NewCategories.groupName')
											  // ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
											  // ->join('CategoryList','CategoryList.id', '=', 'Booking_Items.categoryId')
											  // ->Where(['Booking_Items.bookingId' => $bookingId])
											  // ->get();
											  
			$GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.Price','NewCategories.groupName','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => $bookingId])
								  ->get();								  
							
			foreach($GetOrder as $Amt){
                 
               $priceamt = $Amt->Price;
               $Amt -> amount = "Rs.".$priceamt * $Amt->quantity; 
			   $Amt -> Price = "Rs.".$priceamt;
			}			
			if(count($Bookings) > 0){
				
				$response['error']="false";
                $response['response']=$Bookings;
                $response['BookingItems']=$GetOrder;
			}else{
				
				$response['error']="true";
                $response['error_message']="Invalid bookingId";
			}
			
		}else{
			
			$response['error']="true";
            $response['error_message']="BookingId Missing";
		}
		
		echo json_encode($response);
		
	}
	
	
	//Add booking items
	public function BookingItems(Request $Request){

     $UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
	 
	 // echo  $UserId;die;
	 
	 $CheckBook = Bookings::Where(['id'=>$Request->bookingId,'pickupDeliveryUserId'=>$UserId,'ConfirmOrder'=> 1,'PickupSuccess'=> 1])->count();
	 // echo $CheckBook;die;
	 if($CheckBook == 1){
		 
		 $response['error']="true";
        $response['error_message']="Clothes already collected";
	
		echo json_encode($response);
		die;
	 }
	 
	 $CheckItems = Bookings::Where(['id'=>$Request->bookingId,'pickupDeliveryUserId'=>$UserId,'ConfirmOrder'=> 1])->first();
	 
	 // echo $CheckItems;die;
	 
	 if(count($CheckItems) == 1){
	 
	 if($Request->bookingItems && $Request->bookingId){
		 
		 
		$bookingItems = $Request->bookingItems;
	 
	 // $bookingItems=' [{
           // "categoryId": "1",
		   // "quantity": "2"
         // }, {
           // "categoryId": "2",
		   // "quantity": "5"
         // }, {
           // "categoryId": "3",
		   // "quantity": "5"  
         // }]
       // ';
		
		 $php_array=json_decode($bookingItems,true); 


            //print_r($php_array);die;		 

           // $array=$php_array["result"];
		
		//print_r($array);
		
        $sum = 0;
		
		for($i=0;$i<count($php_array);$i++){

             $categoryId=$php_array[$i]["categoryId"];
             $quantity=$php_array[$i]["quantity"];
			 
			//echo $categoryId;die;
			  
			  $GetAmt = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','CategoryList.Qty')
		                     ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
							 //->join('CategoryList','CategoryList.id','=','packages.categoryId')
							 ->Where(['NewCategories.id'=>$categoryId])
							 ->get();
			  $sum+= $quantity;			 
              foreach($GetAmt as $Amount){
				 
				 $amountValue [] = $Amount->price * $quantity;
				  
				// echo $Amount->CategoryId;
				
				$packages = Packages::Select('id','categoryId','price')->Where('categoryId',$Amount->CategoryId)->first();
				
				if($packages){
				echo $packages->price * $quantity."<br>";
				}
			  }
			  
			  //echo  json_encode($GetAmt);

			 // BookingItems::insert([
                  // 'bookingId'=>$Request->bookingId,
                  // 'quantity'=>$quantity,
				  // 'categoryId'=>$categoryId

                  // ]);
			 
		} 
		// echo $sum;die;
		
	    die;
		$GetBookItems = BookingItems::Select('id')->Where(['bookingId' => $Request->bookingId])->first();
		
		$totalPayment = array_sum($amountValue);
		

		$servicetax = 18;
		
		//$taxamt = $totalPayment * ($servicetax/100);
        //$taxamount = round($taxamt, 2);
		//$grandtotal = $totalPayment + $taxamount;
		$grandtotal = $totalPayment;
		$GetOffer = Bookings::Select('id','promode_code')->Where(['id'=>$Request->bookingId])->first();
		$discount = 0;
	        if(!$GetOffer->promode_code == 0){
				
				//echo $GetOffer->promode_code;
				$get_promo = Promocode::Select('id','discount','maximum_amount')->Where(['id'=>$GetOffer->promode_code])->first();
				//echo $get_promo;
				//$totalPayment = 180;
				$grandtotal = $totalPayment - ($totalPayment * ($get_promo->discount/100));
				
				$discount = $totalPayment - $grandtotal;
				
				//echo $discount;
			}
			//echo $grandtotal;
			//echo $GetOffer->promode_code;
		//die;
		//$grandtotal = $totalPayment - ($totalPayment * ($discount_percent/100));
		
	//echo $grandtotal;die;
		
		$rand = mt_rand(1000, 9999);
		
		$file = $rand.'.png';
		
		date_default_timezone_set('Asia/Kolkata');
		$succesdate =  date("Y-m-d H:i:s", time());
		
		$dis = round($discount);
		$grand = round($grandtotal);
		
		$UpdatePyament = Bookings::Where('id',$Request->bookingId)
		                          ->update(['quantity'=>$sum,'OrderAssign'=>0,'PickupSuccess'=>1,'PickupSuccessDate'=>$succesdate,'totalPayment'=>$grand,'taxamount'=>0,'discount_amount'=>$dis,'QrCode'=>$file,'Is_print'=>1]);
		
		  QrCode::size(5000)->format('png')->generate($GetBookItems, '../public/images/Qrcode/'.$file.'');
		// print_r($amount);
		 //die;
		 $GetQrcode = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.bookingId','Bookings.userId','users.name as username','users.mobile','users.email','users.deviceToken','users.os','Bookings.addressId','UserAddresses.address','Bookings.quantity','Bookings.bookingDate','Bookings.bookingTimeSlot','Bookings.taxamount','Bookings.PickupSuccessDate','Bookings.totalPayment','Bookings.discount_amount','Qrcode','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.paymentType')
		                        ->join('TimeSlots','TimeSlots.id','=','Bookings.bookingTimeSlot')
								->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
								->join('users','users.id', '=', 'Bookings.userId')
		                        ->Where('Bookings.id',$Request->bookingId)
								->first();
		 
		$fcm = new PushNotifications();	
		$username = $GetQrcode->username;
		$email = $GetQrcode->email;
		$mobile = $GetQrcode->mobile;
		$title = 'Pickup confirmation';
		$pickuptime  = explode(" ",$GetQrcode->PickupSuccessDate);
		$ptime = $pickuptime[1];
		$pdate = $pickuptime[0];
		
		$token = $GetQrcode->deviceToken;
		$os = $GetQrcode->os;
		
		$message ='Your booking ID '.$GetQrcode->bookingId.' has been picked up! Total amount paid/ to be paid is Rs.'.$GetQrcode->totalPayment.'. Your clothes will be delivered at the earliest.';
		$CommonFunction = new CommonFunctions();			
		$newresponse = $CommonFunction->SentOtp($mobile,$message);
		
		//ech$token;die;
		//$token = 'cANMOcu8GOc:APA91bGrwv7EQfonF221GWNgGVDAJXCwtGeDTjrj2E1f0P_o1QJLjYovpjqS5MIR0cSD_WaKKsQaSb6Au4bPsUWXA4Kbpwy01g8Mb6scfv5-T-CMnVfPUmMPWWSrq-s5a5R0aTEPAZoy';
		$body ='Your booking ID '.$GetQrcode->bookingId.' has been picked up! Total amount paid/ to be paid is Rs.'.$GetQrcode->totalPayment.'. Your clothes will be delivered at the earliest.';
		$arraydata = array("BookingId"=>$GetQrcode->id,"message"=>$body,"deliverystatus"=>"");
		$newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata); 
		
		$Items = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.Price','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => $GetQrcode->id])
								  ->get();
		 
		// print_r(array_sum($amountValue));
		
		 $bookingDate =  $GetQrcode->bookingDate;
		 $TimeSlot =  $GetQrcode->fromSlots. " - " .$GetQrcode->toSlots;
		 $bookingId = $GetQrcode->bookingId;
		 $quantity = $GetQrcode->quantity;
		 $address = $GetQrcode->address;
		 $taxamount = $GetQrcode->taxamount;
		 $totalPayment = $GetQrcode->totalPayment;
		 $discount_amt = $GetQrcode->discount_amount;
		 
		 $grand = $GetQrcode->totalPayment+$GetQrcode->discount_amount;
		
		Mail::send([], [], function($message) use ($email,$Items,$TimeSlot,$bookingDate,$bookingId,$quantity,$address,$taxamount,$totalPayment,$username,$mobile,$ptime,$pdate,$discount_amt,$grand) {
            $message->from('mohamedabbas289@gmail.com');
            $message->to($email);
            $message->subject('Your Booking Orders');
			
			$mail = "<html lang='en'>
			  <head>
				  <style>
					 .block{width: 250px;margin: 0 auto;padding: 12px;border:1px solid #000;}
					 .left{float:left;}
					 .top_head{display: inline-block;width:100%;}
					 .top_table{width:100%;}
					 .right{float:left;position:relative;left:100px}
					 .logo{float: left;}
					 .logo img{width:54px;height:50px;}
					 .addr{width:200px;}
					  p{padding:0; margin:0;}
					  h5,h3{padding:0; margin:0;}
					  .mr15{margin-top:15px;}
					  .border{border: 1px dashed #000; margin-top:15px;}
					  .pickup {text-align:center;}
					  tr.line td {border-top:1pt solid black;}
					 .head_title p{text-align:center;font-weight:bold;}
					 .tcenter{text-align:center;}
					 .top{padding-top: 27px;}
				  </style>
			  </head>
			  <body>
				<div class='block'>
				<div class='top_head'>
				 <div class='head_title'>
				   <p>Tax Invoice</p>
				 </div>
					 <div class='logo'>
						<img src='http://139.59.37.241/Ironman/public/images/ironbox.png'>
					 </div>
					 <div class='top_table'>
					   <table style='margin-left: 15%;'>
						  <tr>
							<td><strong>Ironbox</strong></td>
						  </tr>
						   <tr>
							<td>Unit of Zero degree south</td>
						  </tr>
						</table>
						</div>
					</div>
					<div class='mr15'>
					  
					   <p class='addr'>New No.7, Arvamuthu Graden Street, Egmore, Chennai 600008</p>
					   <p><strong>GST : </strong>33AACFZ0540L1Z8</p>
					</div>
					<hr class='border'>
					<div class='userdetails mr15'>
					      <p><strong>Name : ".$username."</strong></p>
						   <p><strong>Address :</strong></p>
						   <p class='addr'>".$address."</p>
						   <p><strong>Mob : </strong>".$mobile."</p>
					</div>
					
					<hr class='border'>
					
					<div class='pickup'>
					  <p><strong>Booking Id</strong> : ".$bookingId."</p>
					  <p><strong>Pickup Date</strong> : ".$pdate."</p>
					  <p><strong>Pickup Time</strong> : ".$ptime."</p>
					  <p><strong>Total clothes</strong> : ".$quantity."</p>
					</div>
					
					<hr class='border'>
					
					<div class='clothes'>

					  <table style='width:100%'> ";
					   $mail .="
						<tr>
						  <td><strong>Items</strong></td>
						  <td><strong>Qty</strong></td>
						  <td><strong>Total</strong></td>
						</tr>
					   ";
						foreach($Items as $item){
							$priceamt = $item->Price;
								$mail .= "<tr>
									<td>".$item->name."</td>
									<td>".$item->quantity."</td>
									<td>"."Rs.".$priceamt * $item->quantity."</td>
									</tr>
									";
						}
				 
					  $mail .="
						  <tr>
						  <td style='border-top:dotted 1px #000;' colspan='1'></td>
						  <td style='border-top:dotted 1px #000;'>Total</td>
						  <td style='border-top:dotted 1px #000;'>".$grand."</td>
						  </tr>
						  <tr>
						  <td style='border-top:dotted 1px #000;' colspan='1'></td>
						  <td style='border-top:dotted 1px #000;'>Discount</td>
						  <td style='border-top:dotted 1px #000;'>".$discount_amt."</td>
						  </tr>
						  <tr>
						  <td style='border-top:dotted 1px #000;' colspan='1'></td>
						  <td style='border-top:dotted 1px #000;'>Grand total</td>
						  <td style='border-top:dotted 1px #000;'>".$totalPayment."</td>
						  </tr>
					</table>
					
					 <p class='tcenter top'>Terms & Conditions applied and price inclusive of all GST taxes</p>
					</div>
				</div>
			  </body>
			</html>";
            $message->setBody(
			
			$mail
			   
			,'text/html');
        });
		
		
		$response['error']="false";
		$response['error_message']="Order pickup successfully";  
		$response['id']=$GetQrcode->id;  
		$response['bookingId']=$GetQrcode->bookingId;  
		$response['Time']=$ptime;  
		//$response['pickup_time']=$ptime;  
		$response['bookingDate']=$GetQrcode->bookingDate;  
		$response['Quantity']=$GetQrcode->quantity;  
		$response['total_amount']=$GetQrcode->totalPayment;  
		$response['paymentType']=$GetQrcode->paymentType;  
		$response['QrCode']="http://139.59.37.241/Ironman/public/images/Qrcode/".$GetQrcode->Qrcode;
		
	  }else{
		
		
	        $response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
	}else{
		
		$response['error']="true";
        $response['error_message']="Invalid bookingId";
		
	}
		
		
		echo json_encode($response);
	}
	
	
	//Print View
	
	public function PrintView(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		
		$bookingId = $Request->bookingId;
		if($bookingId){
		
		$CheckUser = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.mobile','UserAddresses.address','Bookings.quantity','Bookings.bookingDate','PickupSuccessDate','Bookings.taxamount','Bookings.totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode as offer_code','Qrcode','TimeSlots.fromSlots','TimeSlots.toSlots')
		                        ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                        ->join('TimeSlots','TimeSlots.id','=','Bookings.bookingTimeSlot')
								->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
								->join('users','users.id', '=', 'Bookings.userId')
								->Where(['Bookings.id'=>$bookingId,'Bookings.pickupDeliveryUserId'=>$UserId])
								->first();
			if($CheckUser->offer_code ==  null){
               $CheckUser->offer_code="";
			}			
			
			$grand = $CheckUser->totalPayment+$CheckUser->discount_amount;
			//grand_total
			   $CheckUser->grand_total="Rs.".$grand;
			   $CheckUser->discount_amount="Rs.".$CheckUser->discount_amount;
			   $CheckUser->totalPayment="Rs.".$CheckUser->totalPayment;
			   
			   if($CheckUser->discount_amount == 0){
				   $discount = "";
			   }else{
				   $discount = "Rs.".$CheckUser->discount_amount;
			   }
		if(count($CheckUser) == 0){

             $response['error']="true";
             $response['error_message']="Invalid user";
			 echo json_encode($response);
			 die;
		}		
			$pickuptime  = explode(" ",$CheckUser->PickupSuccessDate);					
		    $CheckUser->pickuptime =$pickuptime[1];
		    $CheckUser->taxamount ="Rs.".$CheckUser->taxamount;
			
		    //$CheckUser->totalPayment ="Rs.".$grand;
			
		    $CheckUser->TimeSlot =$CheckUser->fromSlots. " - " .$CheckUser->toSlots;
			$CheckUser->Qrcode ="http://139.59.37.241/Ironman/public/images/Qrcode/".$CheckUser->Qrcode;
			
								  
		$GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','CategoryList.Price','NewCategories.groupName','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => $bookingId])
								  ->get();								  
							
			foreach($GetOrder as $Amt){
                 
               $priceamt = $Amt->Price;
               $Amt -> amount = "Rs.".$priceamt * $Amt->quantity; 
			   $Amt -> Price = "Rs.".$priceamt;
			}
		
		$CheckUser->Booking_Items = $GetOrder;
		  if(count($CheckUser) > 0){
			 
			 $response['error']="false";
             $response['Booking_info']=$CheckUser;
		  }else{
			 
			 $response['error']="true";
             $response['error_message']="Invalid user";
		  }
		
		}else{
		
		$response['error']="true";
        $response['error_message']="BookingId missing";
	  }
		echo json_encode($response);
	}
	
	//Pickup Delivery Start
	public function PickupDeliveryStart(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;

		$bookingId = $Request->bookingId;
		$latitude = $Request->latitude;
		$longitude = $Request->longitude;
		
		if($bookingId && $latitude && $longitude){
			
		$ConfirmBook = 	Bookings::Select('id','pickupDeliveryUserId','PickupSuccess')
		                ->Where(['id'=>$bookingId,'PickupSuccess' =>0])
						->count();
		//echo $ConfirmBook;die;
		
		
		if($ConfirmBook > 0){
		
		
		//ON THE WAY TO PICKUP
		$CheckBook = Bookings::Select('Bookings.id','Bookings.userId','users.name','users.deviceToken','users.os','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.paymentType','Bookings.paidStatus')
		             ->join('users','users.id', '=', 'Bookings.userId')
		             ->Where(['Bookings.id'=>$bookingId, 'Bookings.pickupDeliveryUserId'=>$UserId])
					 ->first();
		
		if(count($CheckBook) == 1){

			
			$GetAddress = UserAddresses::Select('id','latitude','longitude')->Where(['id'=>$CheckBook->addressId])->first();
			//echo $CheckBook->deviceToken;die;
			date_default_timezone_set('Asia/Kolkata');
		    $pickupdate =  date("Y-m-d H:i:s", time());
			
			$UpdateStatus = Bookings::Select('id','WaytoPickup','WaytoPickupDate')->Where(['id'=>$bookingId])->update([
										
										'WaytoPickup' => 1,
										'WaytoPickupDate' =>$pickupdate 
									 ]);
									 
			$api = file_get_contents('https://maps.googleapis.com/maps/api/distancematrix/json?origins='.$latitude.','.$longitude.'&destinations='.$GetAddress->latitude.','.$GetAddress->longitude.'&mode=driving&language=en-EN&sensor=false&key=AIzaSyACGUvhcqr81pE1B0LQehgJs1oyh_XoJKc');
            $data = json_decode($api);		

            $ETA=$data->rows[0]->elements[0]->duration->text;			
            // echo $ETA;	die;		
			
			$fcm = new PushNotifications();	
//			$body = "On the way to pickup will reach $ETA. Please keep your clothes ready.";
			$username = $UserId = Auth::guard('pickupdeliveryuserapi')->user()->name;
			$token = $CheckBook->deviceToken;
			$os = $CheckBook->os;
			//$token = 'cANMOcu8GOc:APA91bGrwv7EQfonF221GWNgGVDAJXCwtGeDTjrj2E1f0P_o1QJLjYovpjqS5MIR0cSD_WaKKsQaSb6Au4bPsUWXA4Kbpwy01g8Mb6scfv5-T-CMnVfPUmMPWWSrq-s5a5R0aTEPAZoy';
            $title ="$username Start to Pickup";
            $body = "$username is on the way to pick your clothes will reach there in $ETA. Please keep your clothes ready.";
			$arraydata = array("BookingId"=>$CheckBook->id,"message"=>$body,"deliverystatus"=>"");
			$newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);
            
			$response['error']="false";
			//$response['push']=$newresponse;
            $response['error_message']="Start pickup successfully";
            $response['paymentType']=$CheckBook->paymentType;
            $response['paidStatus']=$CheckBook->paidStatus;
			
		   }else{
			
			$response['error']="true";
            $response['error_message']="Invalid BookingIdd";
			
		}
			
		}else{
			
			
		  //ON THE T WAY TO DELIVERY	
			$CheckBook = Bookings::Select('Bookings.id','Bookings.userId','users.name','users.deviceToken','users.os','Bookings.addressId','Bookings.paymentType','Bookings.paidStatus')
						 ->join('users','users.id', '=', 'Bookings.userId')
						 ->Where(['Bookings.id'=>$bookingId, 'DeliveryUserId'=>$UserId])
						 ->first();
					 
					

            if(count($CheckBook) > 0){

			 date_default_timezone_set('Asia/Kolkata');
		     $deliverydate =  date("Y-m-d H:i:s", time()); 
			 
			 $GetAddress = UserAddresses::Select('id','latitude','longitude')->Where(['id'=>$CheckBook->addressId])->first();
			 
			 
			 $api = file_get_contents('https://maps.googleapis.com/maps/api/distancematrix/json?origins='.$latitude.','.$longitude.'&destinations='.$GetAddress->latitude.','.$GetAddress->longitude.'&mode=driving&language=en-EN&sensor=false&key=AIzaSyACGUvhcqr81pE1B0LQehgJs1oyh_XoJKc');
             $data = json_decode($api);		

             $ETA=$data->rows[0]->elements[0]->duration->text;
			 
			// echo $ETA;die;
			 
			 $UpdateStatus = Bookings::Select('id','WaytoDelivery','DeliveryDate')->Where(['id'=>$bookingId])->update([
										'WaytoDelivery' => 1,
										'DeliveryDate' =>$deliverydate 
									 ]);
			 
              $fcm = new PushNotifications();	
			 $body = "On the way to delivery will reach $ETA";
			 $username = $UserId = Auth::guard('pickupdeliveryuserapi')->user()->name;
			 //echo $username;die;
			 $token = $CheckBook->deviceToken;
			 $os = $CheckBook->os;
			//$token = 'cANMOcu8GOc:APA91bGrwv7EQfonF221GWNgGVDAJXCwtGeDTjrj2E1f0P_o1QJLjYovpjqS5MIR0cSD_WaKKsQaSb6Au4bPsUWXA4Kbpwy01g8Mb6scfv5-T-CMnVfPUmMPWWSrq-s5a5R0aTEPAZoy';
			 $title ="$username Start to delivery";
			 $arraydata = array("BookingId"=>$CheckBook->id,"message"=>$body,"deliverystatus"=>"");
			 $newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);
			 // echo $newresponse;die;
			 $response['error']="false";
			// $response['rr']=$newresponse;
             $response['error_message']="Start delivery successfully"; 
			 $response['paymentType']=$CheckBook->paymentType;
             $response['paidStatus']=$CheckBook->paidStatus;
			 }else{
				 
              $response['error']="true";
              $response['error_message']="Invalid BookingId";
			
			}			
			//die;
		}
			
		}else{
			
			$response['error']="true";
            $response['error_message']="BookingId missing";
			
		}
		echo json_encode($response);	
		
	}
	
	
	//PrintOrder
	
	public function PrintOrder(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		
		$bookingId = $Request->bookingId;
		if($bookingId){
			
			$CheckBooking  = Bookings::Select('id','bookingId','pickupDeliveryUserId','WaytoPickup')
			                           ->Where(['id'=>$bookingId])
									   ->first();
			if(count($CheckBooking) == 1){

			   $UpdateStatus = Bookings::Select('id')->Where(['id'=>$bookingId])->update(['Is_print'=>1]);
			   
			   $response['error']="false";
               $response['error_message']="Print Taken";

			}else{
 
             $response['error']="true";
             $response['error_message']="BookingId missing";
			}			
			
		  }else{
			
			$response['error']="true";
            $response['error_message']="BookingId missing";
		}
		echo json_encode($response);
	}
	
	
	function PackageAmount($user,$bookingId,$current_date,$user_package){
		
		// echo json_encode($user_package);die; 
		
		$GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.id as pack_category','CategoryList.Price','NewCategories.groupName','Booking_Items.quantity')
							  ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
							  ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
							  ->Where(['Booking_Items.bookingId' => $bookingId])
							  ->get();
			// echo json_encode($GetOrder);die;
					$arr = [];		  
					$arr_1 = [];	
                    $newarr = [];					
                    $newarr_1 = [];					
            foreach($GetOrder as $order){
				
				$check_user_package  = DB::table('user_packages')
			                      ->Select('user_packages.id','user_packages.userId','user_packages.packageId','packages.categoryId','packages.id as pack_id','packages.price','user_packages.balance_amount')
								  ->join('packages','packages.id','=','user_packages.packageId')
								  ->where('balance_amount', '!=' , 0)
								  ->where('user_packages.end_date','>=',$current_date)
								  ->Where(['user_packages.userId'=>$user,'packages.categoryId'=>$order->pack_category])
								  ->first();
						// echo json_encode($check_user_package);

						
							  
				if($check_user_package){
				
					
					
					
					    // $Get_categoty = DB::table('CategoryList')->Select('id')->get();
							
							$key_first = "";
							$key_1 = "";
							
							if($check_user_package->categoryId == 1){
								
								
								if($order->pack_category == 1){
						        
								       $stdarr = (object) array();
									   $stdarr->bookingId= $bookingId;
									   $stdarr->maincategotyId= $order->pack_category;
									   $stdarr->categoryId= $order->categoryId;
									   array_push($newarr,$stdarr);
						             // echo $order->categoryId."<br>";
									 
									 // $items = DB::table('package_items')->insert([
								                   // 'bookingId'=>$bookingId,
												   // 'maincategotyId'=>$order->pack_category,
												   // 'categoryId'=>$order->categoryId
								              // ]);
						
					              }
								
								// echo "pack 1"."<br>";
								
								// echo $order->quantity;
								 
								 $arr [] = $check_user_package->price * $order->quantity;
								 
								 $arr_qty [] = $order->quantity;
								 
					$get_pack = DB::table('user_packages')->Select('id','userId','balance_amount','total_clothes')
					     ->Where(['userId'=>$user,'packageId'=>$check_user_package->pack_id])
						 ->first();	
						
								 
					 	 $key_first = 1;
						 
						 $category_1 = $check_user_package->categoryId;
								 
							}
							
							
							if($check_user_package->categoryId == 2){
								
								// echo "pack 2"."<br>";
								
								
								
								if($order->pack_category == 2){
						
						
						               $stdarr_1 = (object) array();
									   $stdarr_1->bookingId= $bookingId;
									   $stdarr_1->maincategotyId= $order->pack_category;
									   $stdarr_1->categoryId= $order->categoryId;
									   array_push($newarr_1,$stdarr_1);
									   
						             // echo $order->categoryId."<br>";
									 
									 // $items = DB::table('package_items')->insert([
								                   // 'bookingId'=>$bookingId,
												   // 'maincategotyId'=>$order->pack_category,
												   // 'categoryId'=>$order->categoryId
								              // ]);
						
					              }
								
								
								$arr_1 [] = $check_user_package->price * $order->quantity;
								$get_pack_1 = DB::table('user_packages')->Select('id','userId','balance_amount')
					                    ->Where(['userId'=>$user,'packageId'=>$check_user_package->pack_id])->first();
								
								
								
								$key_1 = 1; 
								
							}
													
							
						   
						
					
					
				
				
			}
				
				// $order -> newarr = $check_user_package;
			
			} 
			    // echo json_encode($arr_1);
				// die;	
			// echo $tot;
			// echo array_sum($arr_1);
			// echo count($arr_1); 
			// die;
            
			if(count($arr_1) > 0){
			
			$tot_1 = array_sum($arr_1);	
			$pay_1 = $get_pack_1->balance_amount - $tot_1;	

			
			// echo json_encode($newarr_1);
			
            // $update_amount_1 = DB::table('user_packages')->Select('id','userId')
					     // ->Where(['userId'=>$user,'id'=>$get_pack_1->id])
					     // ->update(['balance_amount'=>$pay_1]);	
              // echo "key 1";						 
			
			}else{
				
				echo "No pack 2";      
			}
			  
			  
			  
			  $txId = $this->GenerateTxID();
					date_default_timezone_set('Asia/Kolkata');
			          $payment_date =  date("Y-m-d H:i:s", time());
					  $orderId = 'ORD'.mt_rand(100000000, 999999999);
		
			  
			if(count($arr) > 0){ 
			
			$tot = array_sum($arr);
			
			$tot_qty = array_sum($arr_qty);
			
			// echo $tot_qty;
			// die;
			
			//echo 'ajii';
			
			
			
			if($tot > $get_pack->balance_amount){
			

             $new_amount =  $tot - $get_pack->balance_amount; 
			
			
			
			// $update_amount = DB::table('user_packages')->Select('id','userId')
					     // ->Where(['userId'=>$user,'id'=>$get_pack->id])
					     // ->update(['balance_amount'=>$new_amount]);
			//die;
			
			$get_balance = DB::table('user_packages')->select('id','balance_amount')->Where(['id',$get_pack->id])->first();
			
			 // echo $new;			
				
			   // echo $category_1;
			   // echo $get_pack->balance_amount;
			   
			  
			   
			   $balance_check = DB::table('user_packages')
			                      ->Select('user_packages.id','user_packages.userId','user_packages.packageId','packages.categoryId','packages.id as pack_id','packages.price','user_packages.balance_amount')
								  ->join('packages','packages.id','=','user_packages.packageId')
								  ->where('balance_amount', '!=' , 0)
								  ->where('balance_amount', '>' , $get_balance->balance_amount)
								  ->where('user_packages.end_date','>=',$current_date)
								  ->Where(['user_packages.userId'=>$user,'packages.categoryId'=>$category_1])
								  ->first(); 
								   // echo json_encode($balance_check);
               if(count($balance_check) > 0){
				   
				   //echo 'abbas';
				   
				   $amt = $balance_check->balance_amount - $tot;
				   
				   // echo json_encode($balance_check);
				   
				   // $update_amount = DB::table('user_packages')->Select('id','userId')
					     // ->Where(['userId'=>$user,'id'=>$balance_check->id])
					     // ->update(['balance_amount'=>$amt]);
						 
						 
						 
						  // $Transaction = PackageTransaction::insert([
				                       // 'bookingId'=>$bookingId,
			                           // 'userId'=>$user,									   
									   // 'orderId'=>$orderId,
									   // 'transactionId'=>$txId,
									   // 'amount'=>$tot,
									   // 'transation_status'=>'TXN_SUCCESS',
									   // 'type'=>'Debit',
									   // 'payment_date'=>$payment_date
									   

								// ]);	
				   
			    }else{
				   
				   echo 'No balance';
			   }
								  
				
			}else{
				
				//echo	'yes';
				$pay = $get_pack->balance_amount - $tot;
				$qty = $get_pack->total_clothes - $tot_qty;
				
				// echo $qty;
				 
					 // $update_amount = DB::table('user_packages')->Select('id','userId')
					     // ->Where(['userId'=>$user,'id'=>$get_pack->id])
					     // ->update(['balance_amount'=>$pay]);

             // echo "hi";
                

                 // $Transaction = PackageTransaction::insert([
				                       // 'bookingId'=>$bookingId,
									   // 'packageId'=>$get_pack->id,
			                           // 'userId'=>$user,									   
									   // 'orderId'=>$orderId,
									   // 'transactionId'=>$txId,
									   // 'amount'=>$tot,
									   // 'transation_status'=>'TXN_SUCCESS',
									   // 'type'=>'Debit',
									   // 'payment_date'=>$payment_date
									   

								// ]);	

		       $category_1 = $this->Category_1($newarr);						 
                // echo json_encode($newarr);								
			}
			
								 
						 
			}else{
				
				echo "No pack 1";
			}
			
		die;
	}
	
	
	function category_1($newarr){
		
		
		foreach($newarr as $arr){
			
			// echo $arr->bookingId;
			
			$items = DB::table('package_items')->insert([
								                   'bookingId'=>$arr->bookingId,
												   'maincategotyId'=>$arr->maincategotyId,
												   'categoryId'=>$arr->categoryId
								              ]);
			
		}
		// return 0;
	}
	
	//Delivery Success
	public function DeliverySuccess(Request $Request){
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		$bookingId = $Request->bookingId;
		
		// echo $UserId;die;
		$current_date =  date("Y-m-d");
		if($bookingId && $UserId){
			
			$CheckUser = Bookings::Select('Bookings.id','Bookings.UserId','Bookings.bookingId','DeliveryUserId','userId','users.name','users.mobile','users.wallet_amount','deviceToken','users.os','Bookings.bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.bookingDate','Bookings.quantity','Bookings.totalPayment','Bookings.paymentType')
			                       ->join('users','users.id', '=', 'Bookings.userId')
								   ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
			                       ->Where(['Bookings.id'=>$bookingId,'DeliveryUserId'=>$UserId])
								   ->first();
			
			$user = $CheckUser->UserId;
			
			
            $user_package = DB::table('user_packages')
			                      ->Select('user_packages.id','user_packages.userId','user_packages.packageId','packages.categoryId','balance_amount')
								  ->join('packages','packages.id','=','user_packages.packageId')
								  ->where('balance_amount', '!=' , 0)
								  ->where('user_packages.end_date','>=',$current_date)
								  ->Where(['user_packages.userId'=>$CheckUser->userId])
								  ->get();
             // echo json_encode($user_package);die; 
			  
			if(count($user_package) > 0 ){
				
				
			  $package =$this->PackageAmount($user,$bookingId,$current_date,$user_package);
				
			}else{
				
				echo "No";
			}die;
			
			
			
			
			
			
			
				$GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.id as pack_category','CategoryList.Price','NewCategories.groupName','Booking_Items.quantity')
							  ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
							  ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
							  ->Where(['Booking_Items.bookingId' => $bookingId])
							  ->get();  
			
			
			// $arr=[];
			
			// foreach($GetOrder as $orderitems){
				// $mainid=$orderitems->pack_category;
			     // $user_package = DB::table('user_packages')
			                      // ->Select('user_packages.id','user_packages.userId','user_packages.packageId','packages.categoryId','user_packages.end_date','packages.price')
								  // ->join('packages','packages.id','=','user_packages.packageId')
								  // ->where('user_packages.end_date','>=',$current_date)
								  // ->where('packages.categoryId','=',$mainid)
								  // ->Where(['user_packages.userId'=>$CheckUser->userId])
								  // ->first();
								  
			 		// array_push($arr,$user_package);			  
			// }
			// echo json_encode($arr); die;
			
			
			
			// foreach($user_package as $pack){
				
				// $GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.id as pack_category','CategoryList.Price','NewCategories.groupName','Booking_Items.quantity')
							  // ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
							  // ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
							  // ->Where(['Booking_Items.bookingId' => $bookingId,'CategoryList.id'=>$pack->categoryId])
							  // ->get();
							  
				// foreach($GetOrder as $order){

                   // $packages = Packages::Select('id','categoryId','price')
				                     // ->Where(['categoryId'=>$order->pack_category,'id'=>$pack->packageId])
									 // ->first();
				
						// if($packages){

								// echo  $packages->price * $order->quantity."<br>";

				         // }				
				
			// }
			// }
			
			// echo json_encode($new);
			
			// die;
			
			//foreach($check_user_package as $user_packages){
			
			$GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.id as pack_category','CategoryList.Price','NewCategories.groupName','Booking_Items.quantity')
							  ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
							  ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
							  ->Where(['Booking_Items.bookingId' => $bookingId])
							  ->get();
			// echo json_encode($GetOrder);die;
							  
            foreach($GetOrder as $order){
				
				$check_user_package = DB::table('user_packages')
			                      ->Select('user_packages.id','user_packages.userId','user_packages.packageId','packages.categoryId','packages.price','packages.id as pack_id')
								  ->join('packages','packages.id','=','user_packages.packageId')
								  ->where('user_packages.end_date','>=',$current_date)
								  ->Where(['user_packages.userId'=>$CheckUser->userId,'packages.categoryId'=>$order->pack_category])
								  ->first();
								  
							// echo json_encode($check_user_package);	  
				if($check_user_package){  
					
					echo $check_user_package->price * $order->quantity."pack".$check_user_package->pack_id."<br>";
				   
					
					
				
				
			}
				
				// $order -> newarr = $check_user_package;
			}  
           			
			//}					
			// echo $GetOrder;
			die;
			$current_date =  date("Y-m-d");
			$check_pack  = DB::table('user_packages')->Select('user_packages.id','user_packages.userId','user_packages.packageId','packages.categoryId')
			                   ->join('packages','packages.id','=','user_packages.packageId')
							   ->where('user_packages.end_date','>=',$current_date)
			                   ->Where(['user_packages.userId'=>$CheckUser->UserId])
							   ->get();

				
				$check_pack  = DB::table('user_packages')->Select('user_packages.id','user_packages.userId','user_packages.packageId','packages.categoryId','packages.price')
			                   ->join('packages','packages.id','=','user_packages.packageId')
							   ->join('CategoryList','CategoryList.id','=','packages.categoryId')
							   ->where('user_packages.end_date','>=',$current_date)
			                   ->Where(['user_packages.userId'=>$CheckUser->UserId])
							   ->get();
			
			
			echo json_encode($check_pack);die;
			
			if(count($CheckUser) > 0){
				
			 //echo count($CheckUser);die;
				
			 date_default_timezone_set('Asia/Kolkata');
		     $deliverydate =  date("Y-m-d H:i:s", time());
			
			 if($CheckUser->paymentType == 'Wallet'){
				 
				$pay = '150';
				$wall = '200';
				
				//if($pay > $wall){
				if($CheckUser->totalPayment > $CheckUser->wallet_amount){
					 
					 
					 $err_msg = 0;
					 $update_status = Bookings::Select('id','pending_payment')->Where('id',$bookingId)->update(['pending_payment'=>1]);
					//echo "hi";die;
					$dtime="";
				  }else{
					
					$total =$CheckUser->totalPayment;
					$wallet = $CheckUser->wallet_amount;
					$sumval =  $wallet - $total;
					
					//echo $sumval;
					$update_wallet = User::Select('id','wallet_amount')->Where('id',$CheckUser->UserId)->update(['wallet_amount'=>$sumval]);
					$update_booking = Bookings::Select('id','paidStatus')->Where('id',$bookingId)->update(['paidStatus'=>1]);
					
					$txId = $this->GenerateTxID();
					date_default_timezone_set('Asia/Kolkata');
			          $payment_date =  date("Y-m-d H:i:s", time());
                  $orderId_1 = 'ORD'.mt_rand(100000000, 999999999);
					$FromTransaction = WalletTransaction::insert([
					                   'bookingId'=>$bookingId,
			                           'userId'=>$CheckUser->UserId,									   
									   'orderId'=>$orderId_1,
									   'transactionId'=>$txId,
									   'amount'=>$total,
									   'transation_status'=>'TXN_SUCCESS',
									   'type'=>'Debit',
									   'payment_date'=>$payment_date
									   

								]);	
					
					$err_msg=1;
					
					$UpdateStatus = Bookings::Select('id','DeliveryUserId','Status','DeliverySuccess','DeliverySuccessDate')->Where(['id'=>$bookingId])->update(['Status'=>'COMPLETED',"DeliverySuccess"=>1,"DeliverySuccessDate"=>$deliverydate,"pending_payment"=>0,"OrderAssign"=>0]);
					 $get_bookings = Bookings::Select('id','DeliverySuccessDate')->Where('id',$bookingId)->first();
					 $deliverytime  = explode(" ",$get_bookings->DeliverySuccessDate);
					 $dtime = $deliverytime[1];
					 
					 $fcm = new PushNotifications();	
					 $body = 'Your booking ID '.$CheckUser->bookingId.' has been delivered! Thank you for using Ironbox.';
					 $message = 'Your booking ID '.$CheckUser->bookingId.' has been delivered! Thank you for using Ironbox.';
					 $username = $UserId = Auth::guard('pickupdeliveryuserapi')->user()->name;
					 $token = $CheckUser->deviceToken;
					 $os = $CheckUser->os;
					 $mobile = $CheckUser->mobile;
					 $CommonFunction = new CommonFunctions();			
					 $newresponse = $CommonFunction->SentOtp($mobile,$message);
					 
					 $title ="Delivery Successful";
					 $arraydata = array("BookingId"=>$CheckUser->id,"message"=>$body,"deliverystatus"=>"Yes");
					 $newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);
				}
				
			  }
			  
			  if($CheckUser->paymentType == 'Card' || $CheckUser->paymentType == 'Cash'){
				  
				  $err_msg=1;
				  $UpdateStatus = Bookings::Select('id','DeliveryUserId','Status','DeliverySuccess','DeliverySuccessDate')->Where(['id'=>$bookingId])->update(['Status'=>'COMPLETED',"DeliverySuccess"=>1,"DeliverySuccessDate"=>$deliverydate,"OrderAssign"=>0]);
				 //echo "gg";
				 
				 $get_bookings = Bookings::Select('id','DeliverySuccessDate')->Where('id',$bookingId)->first();
				 $deliverytime  = explode(" ",$get_bookings->DeliverySuccessDate);
				 $dtime = $deliverytime[1];
				 
				  $fcm = new PushNotifications();	
				 $body = 'Your booking ID '.$CheckUser->bookingId.' has been delivered! Thank you for using Ironbox.';
				 $message = 'Your booking ID '.$CheckUser->bookingId.' has been delivered! Thank you for using Ironbox.';
				 $username = $UserId = Auth::guard('pickupdeliveryuserapi')->user()->name;
				 $token = $CheckUser->deviceToken;
				 $os = $CheckUser->os;
				 $mobile = $CheckUser->mobile;
				 $CommonFunction = new CommonFunctions();			
				 $newresponse = $CommonFunction->SentOtp($mobile,$message);
				 
				 $title ="Delivery Successful";
				 $arraydata = array("BookingId"=>$CheckUser->id,"message"=>$body,"deliverystatus"=>"Yes");
				 $newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);
			  }
			  //die;
			
		 
			       
           
                   
			
			 
			 
			 
			 $response['error']="false";
			 $response['id']=$CheckUser->id;
			 $response['bookingId']=$CheckUser->bookingId;
			 $response['bookingDate']=$CheckUser->bookingDate;
			 $response['TimeSlot']=$CheckUser->fromSlots." - ".$CheckUser->toSlots;
			 $response['quantity']=$CheckUser->quantity;
			 $response['delivery_time']=$dtime;
			 $response['payment_status']=$err_msg;
			 $response['total_amount']="Rs.".$CheckUser->totalPayment;
			 $response['paymentType']=$CheckUser->paymentType;
             $response['error_message']="Order delivery successfully";
			 
		 }else{
			 
			 $response['error']="true";
            $response['error_message']="Invalid bookingId";
		 }
			 
		  }else{
			
			$response['error']="true";
            $response['error_message']="BookingId missing";
		}
		
		echo json_encode($response);
	}
	
	
	
	
	
	
	//Paybywallet
	public function PayByWallet(Request $Request){
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		
		$bookingId = $Request->bookingId;
		$amount = $Request->amount;
		
		if($bookingId){
			
		  $get_order = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.wallet_amount','Bookings.totalPayment','Bookings.discount_amount')
		                         ->join('users','users.id','=','Bookings.userId')
		                         ->Where(['Bookings.id'=>$bookingId])
                                 ->first();
								 
			$amount = $get_order->totalPayment + $get_order->discount_amount;					 
           								 
		  if(count($get_order) == 1){
             
			 // echo $get_order->wallet_amount;die;
			 
			 if($amount < $get_order->wallet_amount){

				 $pay_amount = $get_order->wallet_amount - $amount;
				 
				 $update_wallet = User::Select('id','wallet_amount')->Where('id',$get_order->userId)
				                       ->update(['wallet_amount'=>$pay_amount]);
									   
				  date_default_timezone_set('Asia/Kolkata');
		        $deliverydate =  date("Y-m-d H:i:s", time());
				 
				 $UpdateStatus = Bookings::Select('id','DeliveryUserId','Status','DeliverySuccess','DeliverySuccessDate')
				                        ->Where(['id'=>$bookingId])
										->update(['Status'=>'COMPLETED',"DeliverySuccess"=>1,"DeliverySuccessDate"=>$deliverydate,"OrderAssign"=>0,'pending_payment'=>0]);
				 
				 // $update_booking = Bookings::Select('id','Status','paidStatus')->Where('id',$bookingId)->update(['Status'=>'COMPLETED','paidStatus'=>1]);
				 
				 
				 $CheckUser = Bookings::Select('Bookings.id','Bookings.UserId','Bookings.bookingId','DeliveryUserId','userId','users.name','users.mobile','users.wallet_amount','deviceToken','users.os','Bookings.bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.bookingDate','Bookings.quantity','Bookings.totalPayment','Bookings.paymentType')
			                       ->join('users','users.id', '=', 'Bookings.userId')
								   ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
			                       ->Where(['Bookings.id'=>$bookingId])
								   ->first();
								   
				 $fcm = new PushNotifications();	
				 $body = 'Your booking ID '.$CheckUser->bookingId.' has been delivered! Thank you for using Ironbox.';
				 $message = 'Your booking ID '.$CheckUser->bookingId.' has been delivered! Thank you for using Ironbox.';
				 $username = $UserId = Auth::guard('pickupdeliveryuserapi')->user()->name;
				 $token = $CheckUser->deviceToken;
				 $os = $CheckUser->os;
				 $mobile = $CheckUser->mobile;
				 $CommonFunction = new CommonFunctions();			
				 $newresponse = $CommonFunction->SentOtp($mobile,$message);
				 
				 $title ="Delivery Successful";
				 $arraydata = array("BookingId"=>$CheckUser->id,"message"=>$body,"deliverystatus"=>"Yes");
				 $newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);				   
				 
				 $response['error_message']="payment done successfully";
				 $response['error']="false";
				 
			  }else{
				$response['error']="true";
				$response['error_message']="Insufficient balance";
			 }
			 
		   	

		  }else{

			$response['error']="true";
            $response['error_message']="Invalid bookingId";
		  }		  

		}else{
			
			$response['error']="true";
            $response['error_message']="BookingId missing";
		}
		echo json_encode($response);
	}
	
	
	// Generate transactionId
	public function GenerateTxID(){
	 $code = "";
     $chars = "0987654321";
     $chars.= "0123456789";

    for ($i=0; $i < 25; $i++) {
        $code .= $chars[random_int(0, strlen($chars)-1)];
    }
	return $code;

	}
	//CashCashCollected
	public function CashCollect(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		$bookingId = $Request->bookingId;
		$type = $Request->type;
		
		if($bookingId && $UserId && $type){
			
			if($type == 'Cash'){
			
			$CheckUser = Bookings::Select('Bookings.id','DeliveryUserId','userId','users.name','deviceToken')
			                       ->join('users','users.id', '=', 'Bookings.userId')
			                       ->Where(['Bookings.id'=>$bookingId,'DeliveryUserId'=>$UserId,'WaytoDelivery'=>1])
								   ->first();
			
			if(count($CheckUser) > 0){
				
				date_default_timezone_set('Asia/Kolkata');
		        $deliverydate =  date("Y-m-d H:i:s", time());
				 
				
				
				$UpdateStatus = Bookings::Select('id','DeliveryUserId','Status','DeliverySuccess','	paidStatus')
				                ->Where(['id'=>$bookingId])
								->update(['paidStatus'=>1]);
				
			 $response['error']="false";
             $response['error_message']="Cash Collected";
			}else{
				
				$response['error']="true";
				$response['error_message']="Invalid bookingId";
			}
			
		}elseif($type == 'Wallet'){
			
			
			$CheckUser = Bookings::Select('Bookings.id','DeliveryUserId','userId','users.name','deviceToken')
			                       ->join('users','users.id', '=', 'Bookings.userId')
			                       ->Where(['Bookings.id'=>$bookingId,'DeliveryUserId'=>$UserId,'WaytoDelivery'=>1])
								   ->first();
			
			if(count($CheckUser) > 0){
				
				date_default_timezone_set('Asia/Kolkata');
		        $deliverydate =  date("Y-m-d H:i:s", time());
				 
				 $UpdateStatus = Bookings::Select('id','DeliveryUserId','Status','DeliverySuccess','DeliverySuccessDate')
				                        ->Where(['id'=>$bookingId])
										->update(['Status'=>'COMPLETED',"DeliverySuccess"=>1,"DeliverySuccessDate"=>$deliverydate,"OrderAssign"=>0,'paymentType'=>'Cash','pending_payment'=>0]);
				
			$CheckUser_1 = Bookings::Select('Bookings.id','Bookings.UserId','Bookings.bookingId','DeliveryUserId','userId','users.name','users.mobile','users.wallet_amount','deviceToken','users.os','Bookings.bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.bookingDate','Bookings.quantity','Bookings.totalPayment','Bookings.paymentType')
			                       ->join('users','users.id', '=', 'Bookings.userId')
								   ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
			                       ->Where(['Bookings.id'=>$bookingId])
								   ->first();	
				
				
			 $fcm = new PushNotifications();	
			 $body = 'Your booking ID '.$CheckUser_1->bookingId.' has been delivered! Thank you for using Ironbox.';
			 $message = 'Your booking ID '.$CheckUser_1->bookingId.' has been delivered! Thank you for using Ironbox.';
			 $username = $UserId = Auth::guard('pickupdeliveryuserapi')->user()->name;
			 $token = $CheckUser_1->deviceToken;
			 $os = $CheckUser_1->os;
			 $mobile = $CheckUser_1->mobile;
			 $CommonFunction = new CommonFunctions();			
		     $newresponse = $CommonFunction->SentOtp($mobile,$message);
			 
			 $title ="Delivery Successful";
			 $arraydata = array("BookingId"=>$CheckUser_1->id,"message"=>$body,"deliverystatus"=>"Yes");
			 $newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);
				
			 $response['error']="false";
             $response['error_message']="Cash Collected";
			}else{
				
				$response['error']="true";
				$response['error_message']="Invalid bookingId";
			}
			
		}else{
			
			$response['error']="true";
				$response['error_message']="Invalid type";
		}
			
			
			
			
		}else{
			$response['error']="true";
            $response['error_message']="BookingId missing";
		}
		echo json_encode($response);
	}
	
	//Wallet Cash
	public function WalletCash(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		$bookingId = $Request->bookingId;
		
		if($bookingId && $UserId){
			
			$CheckUser = Bookings::Select('Bookings.id','DeliveryUserId','userId','users.name','deviceToken')
			                       ->join('users','users.id', '=', 'Bookings.userId')
			                       ->Where(['Bookings.id'=>$bookingId,'DeliveryUserId'=>$UserId,'WaytoDelivery'=>1])
								   ->first();
			
			if(count($CheckUser) > 0){
				
				$UpdateStatus = Bookings::Select('id','DeliveryUserId','Status','DeliverySuccess','	paidStatus','pending_payment')
				                ->Where(['id'=>$bookingId])
								->update(['paidStatus'=>1,'pending_payment'=>0]);
				
			 $response['error']="false";
             $response['error_message']="Cash Collected";
			}else{
				
				$response['error']="true";
				$response['error_message']="Invalid bookingId";
			}
			
		}else{
			$response['error']="true";
            $response['error_message']="BookingId missing";
		}
		echo json_encode($response);
	}
	
	//GetOrders
	public function GetOrders(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		
		$bookingId = $Request->bookingId;
		//echo $bookingId;die;    
		
		if($bookingId){
			
		$GetUser = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','users.mobile','fromSlots','toSlots','Bookings.bookingTimeSlot','Bookings.quantity','promode_code','promocode.promocode as offer_code','Bookings.discount_amount','Bookings.totalPayment','Bookings.taxamount','Bookings.paymentType','Bookings.PickupSuccessDate','Bookings.DeliverySuccessDate')
		                     ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
                             ->join('users','users.id', '=', 'Bookings.userId')
                             ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							 ->Where(['Bookings.id'=>$bookingId])
                             ->first();
           $grand = $GetUser->totalPayment+$GetUser->discount_amount;
			   
			   if($GetUser->offer_code == null){
				   
				   $GetUser->offer_code = '';
			   }
			   
			   if($GetUser->discount_amount == 0){
				   $GetUser->discount = "";
			   }else{
				    $GetUser->discount = "Rs.".$GetUser->discount_amount;
			   }
			   
			   //grand_total
		  $GetUser->totalPayment  ="Rs.".$GetUser->totalPayment;			 
		  $GetUser->taxamount  ="Rs.".round($GetUser->taxamount);
		  //$GetUser->totalPayment  ="Rs.".number_format((float)$grand, 2, '.', '');;
		  $GetUser->grand_total  ="Rs.".round($grand);
		  
		  // $deliverytime  = explode(" ",$GetUser->DeliverySuccessDate);
		  // $pickuptime  = explode(" ",$GetUser->PickupSuccessDate);
		  // $GetUser->deliverytime = $deliverytime[1];
		  // $GetUser->pickuptime = $pickuptime[1];
		  if(!$GetUser->DeliverySuccessDate == 0){
		    $deliverytime  = explode(" ",$GetUser->DeliverySuccessDate);
		    $GetUser->deliverytime = $deliverytime[1];
		  }else{
			   $GetUser->deliverytime = "";
		  }
		  
		  if(!$GetUser->PickupSuccessDate == 0){
		  $pickuptime  = explode(" ",$GetUser->PickupSuccessDate);
		  $GetUser->pickuptime = $pickuptime[1];
		  }else{
			  $GetUser->pickuptime = "";
		  }
		  
       // foreach($GetUser as $User){

        //$User->TimeSlot = $User->fromSlots. " - " .$User->toSlots; 		 
 		 
		$GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','CategoryList.Price','NewCategories.groupName','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => $bookingId])
								  ->get();     
		
       
				
		foreach($GetOrder as $Amt){
                 
               $priceamt = $Amt->Price;
               $Amt -> amount = "Rs.".$priceamt * $Amt->quantity; 
			   $Amt -> Price = "Rs.".$priceamt;  
			}						  
         //$User->BookingItems = $GetOrder;
		//}		

		if(count($GetOrder) > 0){

			 $response['error']="false";
			 $response['UserInfo']=$GetUser;
             $response['BookingItems']=$GetOrder;

		}else{

              $response['error']="true";
              $response['error_message']="No Items Available";
		}			
		
		 }else{
			
			$response['error']="true";
            $response['error_message']="BookingId missing";
			
		}
		echo json_encode($response);
		
	}
	
	
	//Oder Histoty
	public function OrderHistory(Request $Request){ 
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		 
		 $page_number = $Request->page_number;
		 $type = $Request->type;
		
		if($page_number == ''){
			
			$response['error']="true";
            $response['error_message']="Mandatory parameters are missing";
	
			echo json_encode($response);
			die;
		}
		
		if($page_number == '0')
         {
         $page_number = '0';
             
         }else{
             $page_number = $page_number - 1;
         
         }
		  $page_offset=($page_number * 5);
  
		 if($type == 'Pickup'){
			 
			 $PickupOrder = Bookings::Select('Bookings.id','Bookings.bookingId','users.name','pickupDeliveryUserId','Bookings.bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.bookingDate','Bookings.quantity','Bookings.PickupSuccess','Bookings.paidStatus','Bookings.paymentType')
			                          ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
									  ->join('users','users.id','=','Bookings.userId')
									  ->Where(['Bookings.pickupDeliveryUserId'=>$UserId,'PickupSuccess'=>1])
									  //->orderBy('Bookings.updated_at', 'DESC') 
									  ->orderBy('Bookings.id', 'DESC') 
								      ->offset($page_offset)
								      ->limit(5)
			                          ->get();
			foreach($PickupOrder as $Order){

                $Order->TimeSlot = $Order->fromSlots. " - ". $Order->toSlots;
				
                if($Order->PickupSuccess == 1 && $Order->pickupDeliveryUserId == $UserId){
				  
				  $Order->Status= "PICKUP";
			  }
			 }			
			  
			  
			  $PickupOrderCount = Bookings::Select('Bookings.id','Bookings.bookingId','pickupDeliveryUserId','Bookings.bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.PickupSuccess')
			                          ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
									  ->Where(['Bookings.pickupDeliveryUserId'=>$UserId,'PickupSuccess'=>1])
			                          ->get();
			  
			  $total = count($PickupOrderCount)/5;  
              $NumOfPage = ceil($total);
			  
			  if(count($PickupOrder) > 0){
			  
                 $response['error']="false";		
				 $response['pages']=$NumOfPage;				 
			     $response['PickupOrder']=$PickupOrder; 
			  
			  }else{

			     $response['error']="false";			  
			     $response['error_message']="No pickup history available";
			  }			  
			 
		    }else if($type == 'Delivery'){
			    
				$DeliveryOrder = Bookings::Select('Bookings.id','Bookings.bookingId','DeliveryUserId','users.name','Bookings.bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.bookingDate','Bookings.quantity','Bookings.DeliverySuccess','Bookings.paidStatus','Bookings.paymentType')
			                          ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
									  ->join('users','users.id','=','Bookings.userId')
									  ->Where(['Bookings.DeliveryUserId'=>$UserId,'DeliverySuccess'=>1])
									  ->orderBy('Bookings.id', 'DESC') 
									  //->orderBy('Bookings.bookingDate', 'DESC')
								      ->offset($page_offset)
								      ->limit(5)
			                          ->get();
				
				foreach($DeliveryOrder as $Order){

                $Order->TimeSlot = $Order->fromSlots. " - ". $Order->toSlots;
				
                if($Order->DeliverySuccess == 1 && $Order->DeliveryUserId == $UserId){
				  
				  $Order->Status= "DELIVERY";
			    }
			 }	
				
				$DeliveryOrderCount = Bookings::Select('Bookings.id','Bookings.bookingId','DeliveryUserId','Bookings.bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.DeliverySuccess')
			                          ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
									  ->Where(['Bookings.DeliveryUserId'=>$UserId,'DeliverySuccess'=>1])
									  ->orderBy('Bookings.updated_at', 'DESC') 
			                          ->get();
				
				$total = count($DeliveryOrderCount)/5;  
                $NumOfPage = ceil($total);
				
				if(count($DeliveryOrder) > 0){
				
				 $response['error']="false";		
				 $response['pages']=$NumOfPage;
			     $response['DeliveryOrder']=$DeliveryOrder;
				
				}else{
					$response['error']="false";			  
			        $response['error_message']="No delivery history available";
				}
				
				
		    }else{
				
				$response['error']="true";
				$response['error_message']="Invalid type";
			}
		   
		  
		  echo json_encode($response);
	}
	
	
	//ContentPages
	public function ContentPages(Request $Request){
		
		$terms  =  "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.";
			
			$privacy  =  "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
			
			
			 $about  =  "Ironbox provides steam ironing service via mobile bookings. Our service catalogue covers credible ironing service for every outfit, be it different in style or material. We have begun this company with a vision to continuously equip and create employment opportunities by building a business model that encompasses on-boarding trainees, service providers, managing quality control, and business analyst while at the same time providing standard service, experience and price to the customers.\n \n Ironbox brings quality ironing service to the customers. We have created a technology platform, a website and a mobile app which makes it convenient for the customers. We assure on time delivery and promising service. \n \n Our features \n - Pickup & Delivery\n- Expert professionals on board\n- Affordable\n- Timely delivery\n- Quality check control";
         	
		 
		    $response['error']='false';
			$response['Terms']=$terms;
			$response['Privacy']=$privacy;
			$response['About']=$about;
		 
		 
			
		echo json_encode($response);
	}
	
	
	//Delivery user Rating
	public function Rating(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		
		$Comments = $Request->Comments;
		$Rate = $Request->Rate;
		$bookingId = $Request->bookingId;
		
		if($UserId && $bookingId && $Rate){
			
			$Rating = DB::table('DeliveryUserRating')->insert([
						   'bookingId' => $bookingId,
						   'DeliveryUserId' => $UserId,
						   'rating' => $Rate,
						   'comments' => $Comments
			                ]);
			$response['error']="false";
			$response['error_message']="Rating successfully";				
		}else{
			
			$response['error']="true";
			$response['error_message']="Mandatory parameters are missing";
		}
		echo json_encode($response);
	}
	
	//Delivery User CustomerSupport
	public function CustomerSupport(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		
		if($Request->Comments){
		$Support = DB::table('DeliveryUserSupport')->insert([
		               'DeliveryUserId' => $UserId,
					   'Comments' => $Request->Comments
					]);
					
         $response['error']="false";
         $response['error_message']="Customer support added successfully";	
		 
		}else{

        $response['error']="true";
            $response['error_message']="Mandatory parameters are missing";

		}		 

        echo json_encode($response);
		
	}
	
	//logout
	public function logout(Request $Request){
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
		// echo $UserId;
		$update=pickupdeliveryuser::where('id',$UserId)->update(['deviceToken'=>" "]);
    
		if($update)
		{
			$response['error']='false';
			$response['error_message']='Logout Successfully.';
		}else{
			$response['error']='true';
			$response['error_message']='not logged out';
		}
		echo json_encode($response);
		
	}
	
	
	public function PushNotifications(Request $Request){
		     
			 if($Request->mobile){
			 $CheckUser = User::Select('id','mobile','deviceToken')->Where('mobile',$Request->mobile)->first();
		     $fcm = new PushNotifications();	
			 $body = "Order Delivery";
			 $token = $CheckUser->deviceToken;
			 $title ="Delivery Success";
			 $arraydata = array("BookingId"=>"11","message"=>$body,"deliverystatus"=>"Yes");  
			 $newresponse = $fcm->SentPush($title,$body,$token,$arraydata);
			 
			 //echo json_encode($newresponse);
			 echo $newresponse;
			 
			 }else{
				 
				 echo "Not mobile number";
			 }
	}
	
	
	public function PushNote(Request $Request){
		
		//echo "hii";die;
		
		$fcm = new PushNotifications();
		
		$id = '1';
		
		$new  = $fcm->TestSent($id);
		
		echo $new;
	}
		
		
	public function Qrcode(Request $Request){
		
		$GetBookItems = BookingItems::Select('id')->Where(['bookingId' => 9])->get();
		$newarray = array("GetBookItems"=>$GetBookItems);
		
		$arr = json_encode($newarray);
		
		$rand = mt_rand(1000, 9999);
		
		$file = $rand.'.png';
		
		QrCode::size(9000)->format('png')->generate($arr, '../public/images/Qrcode/'.$file.'');
		echo $file;
	}
	
	
	
	//assign order
	public function AssignOrder(Request $Request){
		
	  $GetBooking = Bookings::Select('Bookings.id','bookingId','addressId','Bookings.bookingTimeSlot','UserAddresses.serviceAreaId')
	                          ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
	                          ->where(['Bookings.DeliveryUserId'=>null,'Bookings.Status'=>'CONFIRMED'])
							  ->get();
							  
		foreach($GetBooking as $data){
             
			 // $Delivery = DB::Select("Select productId , Count(*) as value from pickupdeliveryusers Where customization=0 GROUP BY productId Order by value DESC");
			 
			 $Delivery = DB::Select("Select id,name,latitude,longitude from pickupdeliveryusers where serviceAreaId='".$data->serviceAreaId."' ");
			 
			 foreach($Delivery as $DeliveryUser){
			 
			 $UserOrdersCount = DB::select("select Bookings.id,Bookings.userId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status from Bookings where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$DeliveryUser->id."' AND OrderAssign ='1' UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$DeliveryUser->id."' AND OrderAssign ='2' )");
			 
			 $Ordercount  = count($UserOrdersCount);
			 
			 $DeliveryUser->OrdersCount = $Ordercount;
			 
			 
			 }
			 
             //$UserOrdersCount = Bookings::Select('id','') 
											
			$data->Delivery = $Delivery;							
			  
		}		
							  
	  echo $GetBooking;						  
		
		
	}
	
	
	
	
	//Order List
	public function OrderListDistance(Request $Request){
		
		$UserId = Auth::guard('pickupdeliveryuserapi')->user()->id;
	
		$page_number = $Request->page_number;
		$latitude = $Request->latitude;
		$longitude = $Request->longitude;
		
		if($page_number == ''){
			
			$response['error']="true";
            $response['error_message']="Mandatory parameters are missing";
	
		   echo json_encode($response);
		   die;
		}
		
		if($page_number == '0')
         {
         $page_number = '0';
             
         }else{
             $page_number = $page_number - 1;
         
         }
		  $page_offset=($page_number * 5);
		  $current_date = date("Y-m-d");
		  $pick_date = date("d-m-Y");
		 
		  
		  $GetOutLet = Warehouses::Select('Warehouses.id','Warehouses.latitude','Warehouses.longitude','pickupdeliveryusers.name')
		                           ->join('pickupdeliveryusers','pickupdeliveryusers.warehouseId','=','Warehouses.id')
								   ->Where(['pickupdeliveryusers.id'=>$UserId])
		                           ->first();
		  $GetOutLet->location_id='1';
		  
		  // echo $GetOutLet;die;
		  // echo $GetOutLet;die;
		  
		  $Orders = DB::select("select Bookings.id,Bookings.userId,Bookings.pickupDeliveryUserId,Bookings.DeliveryUserId,Bookings.bookingId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status,Bookings.paidStatus,TimeSlots.fromSlots,TimeSlots.toSlots,latitude,longitude from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id inner join UserAddresses on UserAddresses.id=Bookings.addressId where Bookings.id in (SELECT Bookings.id as booking_id from Bookings  where pickupDeliveryUserId= '".$UserId."' AND OrderAssign ='1' AND bookingDate='".$pick_date."' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$UserId."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ORDER BY Bookings.id DESC LIMIT $page_offset,5 ");
		  
		  echo json_encode($Orders);die;
		  
           $location_array=[];
		   if(count($Orders) > 0){
		   array_push($Orders,$GetOutLet);
		   
		  //echo json_encode($Orders);die;
		   
		   $neworderlist=$Orders;
		   $i = '2';
            foreach($Orders as $List){
				
			   if(!isset($List->location_id)){
			     $List->location_id= $i;
				array_push($location_array,$List);
					
				 
				$i++;
				
			   }
			   
				
			}
			
			$newarray=[];
		   foreach($location_array as $array_data){
			   
		   $new = array_filter($Orders, function ($var) use ($array_data) {
				return ($var->location_id != $array_data->location_id);
				});
			//echo json_encode($array_data); 	die;
			//echo $array_data->longitude; 
            // die;			
			//array_push($newarray,$new);
              
            //echo  json_encode($new);die;

             foreach($new as $newlist){
				 
				$lat[] = array($newlist->latitude,$newlist->longitude);
				
				
				 
				 
				 
				 //echo $newlist->pickupDeliveryUserId;
				 //echo $newlist->latitude."<br>";
				 
				 $api = file_get_contents('https://maps.googleapis.com/maps/api/distancematrix/json?origins='.$array_data->latitude.','.$array_data->longitude.'&destinations='.$newlist->latitude.','.$newlist->longitude.'&mode=driving&language=en-EN&sensor=false&key=AIzaSyACGUvhcqr81pE1B0LQehgJs1oyh_XoJKc');
                  $data  = json_decode($api);
				   $wk=((int)$data->rows[0]->elements[0]->distance->value / 1000);
					$new_distance = round($wk);

					 
					
					$insert = DB::table('order_distance')->insert([
					                    'bookingId'=>$newlist->id,
										'from_latitude'=>$array_data->latitude,
										'from_longitude'=>$array_data->longitude,
										'to_latitude'=>$newlist->latitude,
										'to_longitude'=>$newlist->longitude,
										'userId'=>$newlist->pickupDeliveryUserId,
										'distance'=>$new_distance,
										'curr_date'=>$current_date
					               ]);
				 
				 
				 

                // echo $array_data->longitude;
				 
			 }			 
			}
			
			$nn = json_encode($lat);
			
			$string = str_replace(array('[[',']]'),'',$nn);
			
			//echo $string;
			
			$response['error']="false";
			die;
				
			//echo json_encode($newarray); die;
			$response['error']="false";
            //$response['response']=$Orders;	
			
		   }else{
			   
				$response['error']="true";
				
				$response['error_message']="No Service Avaliable";	
			}
				
			echo json_encode($response);
		
	}
	
	
	public function SortDistance(Request $Request){
		
		$pick_date = date("d-m-Y");
		//$pick_date = '12-06-2018';
		//echo $pick_date;die;
	
		
		$newarrdata = DB::table('order_delivery')->Select('id','userId','service_date','type')->Where(['service_date'=>$pick_date])->get();
		//echo json_encode($newarrdata);die;
		foreach($newarrdata as $ord){
		
		$GetOutLet = Warehouses::Select('Warehouses.id','Warehouses.latitude','Warehouses.longitude','pickupdeliveryusers.name')
		                           ->join('pickupdeliveryusers','pickupdeliveryusers.warehouseId','=','Warehouses.id')
								   ->Where(['pickupdeliveryusers.id'=>$ord->userId])
		                           ->first();
		
		  $lat = $GetOutLet->latitude;
		  $lng = $GetOutLet->longitude;
		
		  $order = DB::select("select Bookings.id,Bookings.userId,Bookings.pickupDeliveryUserId,Bookings.DeliveryUserId,Bookings.bookingId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.warehouseId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status,Bookings.paidStatus,TimeSlots.fromSlots,TimeSlots.toSlots,UserAddresses.latitude,UserAddresses.longitude,Warehouses.latitude as war_lat,Warehouses.longitude as war_lng from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id inner join UserAddresses on UserAddresses.id=Bookings.addressId inner join Warehouses on Warehouses.id=Bookings.warehouseId where Bookings.id in (SELECT Bookings.id as booking_id from Bookings  where pickupDeliveryUserId= '".$ord->userId."' AND OrderAssign ='1' AND bookingDate='".$pick_date."' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$ord->userId."' AND delivery_date='".$pick_date."' AND  OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ");
		 
		 $ord->lis=$order;
		 
		 foreach($order as $newlist){
		 
		 $api = file_get_contents('https://maps.googleapis.com/maps/api/distancematrix/json?origins='.$lat.','.$lng.'&destinations='.$newlist->latitude.','.$newlist->longitude.'&mode=driving&language=en-EN&sensor=false&key=AIzaSyCtiRlaFEsLNCi50ddn1gDhWDgsLEU32qw');
            $data  = json_decode($api);
		    $wk=((int)$data->rows[0]->elements[0]->distance->value / 1000);

            $newlist->wk = $wk;
			
			
		 }
		 
		}  
		
		if(count($newarrdata) == 0){
			
			$response['error']='true';
			echo json_encode($response);
			die;
		}
		//echo json_encode($newarrdata);die;
		
		foreach( $newarrdata as $billdate => $ns) { 
		
              $js[]  = $ns->lis;  
			  
         }  
		
		   $newlist  = json_encode($js);
		    $test = json_decode($newlist);
		 $count = count($test);
		for($i=0;$i<$count;$i++){
			$test1 = $test[$i];
			usort($test1,array("App\Http\Controllers\Api\DeliveryUserController", "cmp"));
			
			
		$newdata [] = $test1;
			
		}
		
		
		
		foreach($newdata as $arr){
			
			
			//echo json_encode($arr);
			
			
			$index =0;
		 
		   $test =$arr;
		 
		  $sorted_dis=[];
		  
		  $newone = $test[0];
			$index=0;
			$pr='0';	
			
			   $i=0;
			
		   foreach($test as $newtest){
			 $lat=$newtest->latitude;
             $lng=$newtest->longitude;
			$bookingId=$newtest->bookingId;
			 
		
			 $order =$test;
			 
			  //echo json_encode($order);die;
			  $count =count($order);
			  
			 // echo $count;die;
			  for($i=0;$i<$count;$i++){
			//$order1 = $order[$i];
		   // echo json_encode($order);
			 $cal_distance_1 = $this->calculatedistance_1($lat,$lng,$order);
			 
			  }
			 // echo json_encode($cal_distance_1);die;
			// print_r($i);
			
			 //echo json_encode($cal_distance_1);
			 //die;
			 
			if(count($cal_distance_1) > 0)
			{
			$stdarr = (object) array();
			$stdarr->pickup_user=$cal_distance_1[0]->pickupDeliveryUserId;
			$stdarr->delivery_user=$cal_distance_1[0]->DeliveryUserId;
			$stdarr->first_lat=$lat;
			$stdarr->first_lon=$lng;
			$stdarr->second_lat=$cal_distance_1[0]->latitude;
			$stdarr->second_lon=$cal_distance_1[0]->longitude;
			$stdarr->bookingId=$cal_distance_1[0]->bookingId;
			$stdarr->wk=$cal_distance_1[0]->wk;
			$stdarr->priority=$pr++;
			array_push($sorted_dis,$stdarr);	
			
			
			$update = Bookings::Select('id','bookingId','sort_order')->Where('bookingId',$bookingId)->update(['sort_order'=>$pr]);
			
			}				
		unset($test[$index]);
			$index++;
			
			}
			$i++;
		}//echo json_encode($sorted_dis); 
		die;
	

	}
	
	
	function calculatedistance_1($lat,$lng,$order) {
		
	    $con_lat = (float)$lat;
	    $con_lng = (float)$lng;
		
		
		//echo json_encode($order);die;
		
		 foreach($order as $list){
			 
			 $dis_lng = (float)$list->longitude;
			 $dis_lat = (float)$list->latitude;
			 
			 $latu[] = array($dis_lat,$dis_lng);
			 
		 $api = file_get_contents('https://maps.googleapis.com/maps/api/distancematrix/json?origins='.$con_lat.','.$con_lng.'&destinations='.$dis_lat.','.$dis_lng.'&mode=driving&language=en-EN&sensor=false&key=AIzaSyCtiRlaFEsLNCi50ddn1gDhWDgsLEU32qw');
		 if($api){
			$data = json_decode($api); 
				$wk=((int)$data->rows[0]->elements[0]->distance->value / 1000);

            $list->wk = $wk;
		 }else{
			 $data=[];
		 }
		 
		 }
		 

		 
          $sorted_array = $order;
		  
		 
		  usort($sorted_array,array("App\Http\Controllers\Api\DeliveryUserController", "cmp"));

		  return $sorted_array;
	}
	
	
	
	public function SortRoute(Request $Request){
		
		
		//$UserId = $Request->id;
		$UserId = 1;
		$pick_date = date("d-m-Y");
		
		
		$GetOutLet = Warehouses::Select('Warehouses.id','Warehouses.latitude','Warehouses.longitude','pickupdeliveryusers.name')
		                           ->join('pickupdeliveryusers','pickupdeliveryusers.warehouseId','=','Warehouses.id')
								   ->Where(['pickupdeliveryusers.id'=>$UserId])
		                           ->first();
		
		  $lat = $GetOutLet->latitude;
		  $lng = $GetOutLet->longitude;
		
		  $order = DB::select("select Bookings.id,Bookings.userId,Bookings.pickupDeliveryUserId,Bookings.DeliveryUserId,Bookings.bookingId,Bookings.bookingDate,Bookings.bookingTimeSlot,Bookings.addressId,Bookings.warehouseId,Bookings.bookingTimeSlot ,quantity,OrderAssign,Bookings.Status,Bookings.paidStatus,TimeSlots.fromSlots,TimeSlots.toSlots,UserAddresses.latitude,UserAddresses.longitude,Warehouses.latitude as war_lat,Warehouses.longitude as war_lng from Bookings INNER JOIN TimeSlots ON Bookings.bookingTimeSlot = TimeSlots.id inner join UserAddresses on UserAddresses.id=Bookings.addressId inner join Warehouses on Warehouses.id=Bookings.warehouseId where Bookings.id in (SELECT Bookings.id as booking_id from Bookings  where pickupDeliveryUserId= '".$UserId."' AND OrderAssign ='1' AND bookingDate='".$pick_date."' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$UserId."' AND delivery_date='".$pick_date."' AND  OrderAssign ='2' AND Bookings.cancelReason IS NULL ) LIMIT 6");
		 
		
		 
		 foreach($order as $newlist){
		 
		 $api = file_get_contents('https://maps.googleapis.com/maps/api/distancematrix/json?origins='.$lat.','.$lng.'&destinations='.$newlist->latitude.','.$newlist->longitude.'&mode=driving&language=en-EN&sensor=false&key=AIzaSyCtiRlaFEsLNCi50ddn1gDhWDgsLEU32qw');
            $data  = json_decode($api);
		    $wk=((int)$data->rows[0]->elements[0]->distance->value / 1000);

            $newlist->wk = $wk;
			
			
		 }
		 


			usort($order,array("App\Http\Controllers\Api\DeliveryUserController", "cmp"));
			
			//echo json_encode($order);
			$index=0;
			
			$sorted_dis = [];
			$pr = 1;
			foreach($order as $newtest){
				
			 $lat=$newtest->latitude;
             $lng=$newtest->longitude;
			 $bookingId=$newtest->bookingId;
			
			
			  $cal_distance_1 = $this->calculatedistance_1($lat,$lng,$order);
			
			if(count($cal_distance_1) > 0)
			{
			$stdarr = (object) array();
			$stdarr->pickup_user=$cal_distance_1[0]->pickupDeliveryUserId;
			$stdarr->first_lat=$lat;
			$stdarr->first_lon=$lng;
			$stdarr->second_lat=$cal_distance_1[0]->latitude;
			$stdarr->second_lon=$cal_distance_1[0]->longitude;
			$stdarr->bookingId=$cal_distance_1[0]->bookingId;
			$stdarr->wk=$cal_distance_1[0]->wk;
			$stdarr->priority=$pr++;
			array_push($sorted_dis,$stdarr);	
			
			
			//$update = Bookings::Select('id','bookingId','sort_order')->Where('bookingId',$bookingId)->update(['sort_order'=>$pr]);
			
			}
			
			
			unset($order[$index]);
			$index++;
			}
			
			echo json_encode($sorted_dis);
		
		
	}
	
	
	function calculatedistance($lat,$lng,$order) {
		
		echo json_encode($order);die;
		
	    $con_lat = (float)$lat;
	    $con_lng = (float)$lng;
		
		
		//return $con_lng;die;
		
		 foreach($order as $list){
			 
			 $dis_lng = (float)$list->longitude;
			 $dis_lat = (float)$list->latitude;
			 
			 $latu[] = array($dis_lat,$dis_lng);
			 
		 $api = file_get_contents('https://maps.googleapis.com/maps/api/distancematrix/json?origins='.$con_lat.','.$con_lng.'&destinations='.$dis_lat.','.$dis_lng.'&mode=driving&language=en-EN&sensor=false&key=AIzaSyCtiRlaFEsLNCi50ddn1gDhWDgsLEU32qw');
            $data = json_decode($api);
			
			$wk=((int)$data->rows[0]->elements[0]->distance->value / 1000);

            $list->wk = $wk;		
			
		 }
		 
		 
      // echo json_encode($data);die;
       //return $order;die;
		 
		  $newlist  = json_encode($order);

          $test = json_decode($newlist);
		 
		  usort($test,array("App\Http\Controllers\Api\DeliveryUserController", "cmp"));
		  
		  //echo json_encode($order);die;
		  
		  $getresult = $this->sortmethod($test);
		  
		  return $getresult;
	}
	
	
		
	
	
	public function cmp($a, $b){

        return $a->wk - $b->wk;
      }
	
		
	public function cmp1($a, $b){

        return $b->wk - $a->wk;
      }
	
	
	
	function sortmethod($test){
		
		// echo json_encode($test);die;
		
		  $index =0;
		 
		$distance_arr=$test;
		 
		  $sorted_dis=[];
		  
		  $newone = $test[0];
			$index=0;
			$pr='1';	
		   foreach($test as $newtest){
			 $lat=$newtest->latitude;
             $lng=$newtest->longitude;
			$bookingId=$newtest->bookingId;
			
		 
			 $order=$test;
			 $cal_distance_1 = $this->calculatedistance_1($lat,$lng,$order);
			if(count($cal_distance_1) > 0)
			{
			$stdarr = (object) array();
			$stdarr->pickup_user=$cal_distance_1[0]->pickupDeliveryUserId;
			$stdarr->delivery_user=$cal_distance_1[0]->DeliveryUserId;
			$stdarr->first_lat=$lat;
			$stdarr->first_lon=$lng;
			$stdarr->second_lat=$cal_distance_1[0]->latitude;
			$stdarr->second_lon=$cal_distance_1[0]->longitude;
			$stdarr->bookingId=$cal_distance_1[0]->bookingId;
			$stdarr->wk=$cal_distance_1[0]->wk;
			$stdarr->priority=$pr++;
			array_push($sorted_dis,$stdarr);	
			
			$update = Bookings::Select('id','bookingId','sort_order')->Where('bookingId',$bookingId)->update(['sort_order'=>$pr++]);
			
			}				
		unset($test[$index]);
			$index++;
			// Filter Location without the current Booking id	
				
			   // $order = array_filter($distance_arr, function ($var) use ($newtest) {
				// return ($var->bookingId != $newtest->bookingId);
				// });
				
				 // $cal_distance_1 = $this->calculatedistance_1($lat,$lng,$order);
				 // usort($cal_distance_1,array("App\Http\Controllers\Api\DeliveryUserController", "cmp"));
				 // array_push($sorted_dis,$cal_distance_1);
			}
			echo json_encode($sorted_dis); die;
		//echo $index;die;
		  //echo json_encode($selectedorder);die;
			  //$newone = $test[0];
		  //echo json_encode($newone);die;
		  
		  //$finalorder = array();
		  
		  
		  $finalorder  = $selectedorder;
		  
		  //echo  json_encode($test);die;
		  
		   unset($test[$index]);
		   
		   $test = array_values($test);
		   
		    $order = $test;
			 //echo  json_encode($order);die;
		   
		    if(count($order) > 0){
		   
		      $lat  = $selectedorder->latitude;
		      $lng  = $selectedorder->longitude;
		   
		      $cal_distance = $this->calculatedistance($lat,$lng,$order);
		   
	         }
		   
		  echo  json_encode($finalorder);
		   
		   
	}
	
	   
	
	
	
	
	
	
	
	
	
	
}
