<?php

namespace App\Http\Controllers\Api\v2;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\pickupdeliveryuser;
use App\Admin;
use App\ServiceAreas;
use App\Pincode;
use App\UserAddresses;
use App\TimeSlots;
use App\Categories;
use App\CategoryList;
use App\CommonFunctions;
use App\PushNotifications;
use App\Warehouses;
use App\Bookings;
use App\Transaction;
use App\Promocode;
use App\UserPromocode;
use App\BookingItems;
use App\CustomerSupport;
use App\WalletTransaction;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Session;
use GuzzleHttp\Exception\BadResponseException;
use Guzzle\Http\Exception\ServerErrorResponseException;
use Mail;
use Auth;
use DateTime;
use Validator;
use DB;

class UserLoginController extends Controller
{
  
	
	/*************************START***************************/
	
	
	
	public function UserLogin(Request $Request){
		
		$mobile = $Request->mobile;
		$deviceToken = $Request->deviceToken; 	
		$os = $Request->os; 	
		
		 $validator = Validator::make($Request->all(), [
				   'mobile' => 'required|digits:10|numeric',
				]);
				

				if ($validator->fails()) {

				   $response['error']="true";
				   $response['error_message']="Please enter valid number";
				   echo json_encode($response);
				   die;
				}
		
		
		if($mobile && $deviceToken && $os){
		
			  $User=User::Where(['mobile'=>$mobile])->count();
			  
			  $CommonFunction = new CommonFunctions();

			  if($User > 0){
				   
				   $otp = mt_rand(1000, 9999);
				   $message = "your verification code for Ironbox login is:".$otp;
				   
				   
				   $newresponse = $CommonFunction->SentOtp($mobile,$message);
				   
				   $UserInfo =User::where('mobile',$mobile)
				                   ->update(['otp' => $otp, 'deviceToken'=>$deviceToken,'os'=>$os]);
								   
                    
				   $response['error']="false";
                   $response['error_message']="Otp Sent Successfully";
				   $response['Otp']=$otp;
                    								   
				  
			  }else{
				  
				  $ReferralCode = $this->GetReferralToken();
				  
				  $otp = mt_rand(1000, 9999);
				  $message = "your verification code for Ironbox login is:".$otp;

				  
				  User::insert([
                  'mobile'=>$mobile,
                  'otp'=>$otp,
				  'referral_code'=>$ReferralCode,
				  'deviceToken'=>$deviceToken,
				  'os'=>$os

                  ]);
				  
				  $newresponse = $CommonFunction->SentOtp($mobile,$message);
				  
				   $response['error']="false";
				   $response['Otp']=$otp;
                   $response['error_message']="Otp Sent Successfully";
			  }
			    
		}else{
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
			
		}
		echo json_encode($response);
	}
	
	
	//User Referral Code
	public function GetReferralToken(){
	
	
	 $code = "";
     $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
     $chars.= "abcdefghijklmnopqrstuvwxyz";
     $chars.= "0123456789";

    for ($i=0; $i < 6; $i++) {
        $code .= $chars[random_int(0, strlen($chars)-1)];
    }
	return $code;
	// $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	// $chars.="0123456789";
	// $chars.="abcdefghijklmnopqrstuvwxyz";
		// $refer = "";
		// for ($i = 0; $i < 5; $i++) {
			// $refer .= $chars[mt_rand(0, strlen($chars)-1)];
		// }
	  // return $refer;
	}
	
	
	
	//Check Otp
	public function UserCheckOpt(Request $Request){
		
		$mobile = $Request->mobile;

		$otp = $Request->otp;
		
		$validator = Validator::make($Request->all(), [
				   'mobile' => 'required|digits:10|numeric',
				]);
				

				if ($validator->fails()) {
					
					//print_r($validator->fails());

				   $response['error']="Not mobile";
				   $response['error_message']="Please enter valid number";
				   echo json_encode($response);
				   die;
					
				}
		
		
		if($mobile && $otp){
		
        //Check AddAddress
        $CheckMobile = User::Select('id','mobile')->Where('mobile',$mobile)->first();
        $CheckAddress = UserAddresses::Select('id','userId','status')
		                                ->Where(['userId'=>$CheckMobile->id,'status'=>0])
                                        ->get();
        if(count($CheckAddress) > 0) {

		  $Address = "Yes";
		 }else{
          $Address = "No";
		}		
			
		 $User=User::Where(['mobile'=>$mobile, 'otp'=> $otp])->count();	
		 if($User > 0){
			 
			   $GetUser=User::Where(['mobile'=>$mobile])->first();
  
	               if($GetUser->email == ''){
					   
                    $GetPin = Pincode::Select('id','code')->Where(['code'=>$GetUser->CheckPin])->count();
			
					if($GetPin == 1){
						$PinValue = "Yes";
					}else{
						$PinValue = "No";
					}	
                   $token = $GetUser->createToken('Token Name')->accessToken;
                   $response['error']="false";
                   $response['error_message']="Login Successfully";
                   
                   
                   $response['access_token']=$token;
				   $response['id']=$GetUser->id;
				   $response['name']=$GetUser->name;
				   $response['image']="";
				   $response['referral_code']=$GetUser->referral_code; 
				   $response['type']="NotRegister";
				   $response['CheckPin']=$PinValue;
				   $response['CheckAddress']=$Address;
				   $response['mobile']=$GetUser->mobile;
					
				   }else{
                   
				   $GetPin = Pincode::Select('id','code')->Where(['code'=>$GetUser->CheckPin])->count();
			       //echo $GetPin;die;
					if($GetPin == 1){
						$PinValue = "Yes";
					}else{
						$PinValue = "No";
					}	
				   
                   $token = $GetUser->createToken('Token Name')->accessToken;
                   $response['error']="false";
                   $response['error_message']="Login Successfully";
                   
                   
                   $response['access_token']=$token;
				   $response['id']=$GetUser->id;
				   $response['name']=$GetUser->name;
				   $response['type']="Register";
				   $response['CheckPin']=$PinValue;
				   $response['CheckAddress']=$Address;
				   $response['mobile']=$GetUser->mobile;
				   $response['email']=$GetUser->email;
				   $response['image']=$GetUser->image;
				   $response['referral_code']=$GetUser->referral_code;
				   $response['alternate_number']=$GetUser->alternate_number;
				   $response['gender']=$GetUser->gender;
				   $response['dob']=$GetUser->dob;
				   }				   
			      
		 }else{
			 
			$response['error']="true";
            $response['error_message']="Invalid Otp";
			 
		 }
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
		echo json_encode($response);
	}
	
	
	
	//Edit User Profile
	public function EditUserProfile(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		$mobile = Auth::guard('api')->user()->mobile;
		
		//echo $mobile;
		
		$validator = Validator::make($Request->all(), [
				   'alternate_number' => 'nullable|digits:10|numeric',
				]);
				

				if ($validator->fails()) {

				   $response['error']="true";
				   $response['error_message']="Please enter valid number";
				   echo json_encode($response);
				   die;
				}
				
		$CheckMobile = User::Select('id','mobile','alternate_number')
					   ->Where('mobile', '=',  $Request->alternate_number)
		               ->count();
					 
		if($CheckMobile == '1'){

		   $response['error']="true";
		   $response['error_message']="Alternate mobile number already in use";
		   echo json_encode($response);
		   die;
		}		
		
		$CheckSameMobile = User::Select('id','mobile','alternate_number')
					   ->Where('mobile', '=',  $Request->alternate_number)
					   ->Where('id',$UserId)
		               ->count();
        if($CheckSameMobile == '1'){

		   $response['error']="true";
		   $response['error_message']="Alternate number and your mobile \n number are same";
		   echo json_encode($response);
		   die;
		}
		
		if($Request->keyvalue == '1'){
		//With E-mail
		$GetUserCount = User::Select('mobile')->Where('id',$UserId)->count();
		if($GetUserCount > 0){
		
		      $validator = Validator::make($Request->all(), [
				   'email' => 'required|email',
				]);
				

				if ($validator->fails()) {
					

				   $response['error']="true";
				   $response['error_message']="Please enter valid email";
				   echo json_encode($response);
				   die;
					
				}
				
				
				
				
		$name = $Request->name;
		$dob  = $Request->dob;
		$gender = $Request->gender;
		$email =  $Request->email;
		$image =  $Request->image;
		$alternate_number =  $Request->alternate_number;
		$referral_code = $Request->referral_code;
		
		if($name && $dob && $gender && $email){
			
			
			 $UserDetailspin = User::Select('id','name','mobile','email','image','alternate_number','gender','dob','CheckPin','referral_code')
			                      ->Where('id',$UserId)->first();
			 
					
            $GetPin = Pincode::Select('id','code')->Where(['code'=>$UserDetailspin->CheckPin])->count();
			
			if($GetPin == 1){
						$PinValue = "Yes";
					}else{
						$PinValue = "No";
					}					  
			
			
			if($referral_code == ''){
				
				try{
			
			$GetUser = User::Where('id',$UserId)->Update([
			'name' => $name,
			'dob'  => $dob,
			'gender' => $gender,
			'email' => $email,
			'image' => $image,
			'alternate_number' => $alternate_number
			]);
			}catch (\Illuminate\Database\QueryException  $ex) {
                 $response['error']='true';
				 $response['error_message']='Email Already Exists';
				 echo json_encode($response); 
				 die;
             }
			 
			
			$UserDetails = User::Select('id','name','mobile','email','image','alternate_number','gender','dob','CheckPin','referral_code')
			                      ->Where('id',$UserId)->first();
			$mobile	= $UserDetails->mobile;				  
			$message='Thank you for registering with Ironbox. For customer support, contact us at 9090903456. You may visit our website www.ironbo.co.in for further information on Ironbox.';					  
		    
            $CommonFunction = new CommonFunctions();			
			$newresponse = $CommonFunction->SentOtp($mobile,$message);					  
			
			$response['error']="false";
			$response['error_message']="Profile Update Successfully";
			$response['CheckPin']=$PinValue;
			$response['UserDetails']=$UserDetails;
			}else{
				
				$CheckCode = User::Select('id','referral_code')->Where(['referral_code'=>$referral_code])->first();
         if(count($CheckCode) == 1){
			 
			 $same_code = User::Select('id','referral_code')->Where(['id'=>$UserId,'referral_code'=>$referral_code])->first();
		  
		  if(count($same_code) == 1){
			     $response['error']='true';
				 $response['error_message']='Invalid referral codes';
				 echo json_encode($response); 
				 die;
		  }
		  
		  $referral_from = $CheckCode->id;
		  $referral_to = $UserId;
		  
		  $check_refer = DB::table('user_referral')->Where(['fromId'=>$referral_from,'toId'=>$referral_to,'referral_id'=>$referral_code])->count();
		  //echo $check_refer;die;
		  if($check_refer == 1){
			     $response['error']='true';
				 $response['error_message']='Already used this codes';
				 echo json_encode($response); 
				 die;
		  }
			 
			 try{
			
			$GetUser = User::Where('id',$UserId)->Update([
			'name' => $name,
			'dob'  => $dob,
			'gender' => $gender,
			'email' => $email,
			'image' => $image,
			'alternate_number' => $alternate_number
			]);
			}catch (\Illuminate\Database\QueryException  $ex) {
                 $response['error']='true';
				 $response['error_message']='Email Already Exists';
				 echo json_encode($response); 
				 die;
             }
		
		  
		  
		  
		
		  $SelectFrom = User::Select('id','wallet_amount')->Where('id',$referral_from)->first();
		  $FromWallet_amount = $SelectFrom->wallet_amount;
		  
		  $SelectTo = User::Select('id','wallet_amount')->Where('id',$referral_to)->first();
		  $ToWallet_amount = $SelectTo->wallet_amount;
		  
		  $SumFrom_wallet = $FromWallet_amount+50;
		  $SumTo_wallet = $ToWallet_amount+50;
		  
		  $UpdateFrom = User::Select('id','wallet_amount')->Where('id',$referral_from)->update(['wallet_amount'=>$SumFrom_wallet]);
		  $UpdateTo = User::Select('id','wallet_amount')->Where('id',$referral_to)->update(['wallet_amount'=>$SumTo_wallet]);
		  
		  $verify = DB::table('user_referral')->insert([
		                            'fromId'=>$referral_from,
									'toId'=>$referral_to,
									'referral_id'=>$referral_code
		                     ]);
							 
			// from user credit
			$txId = $this->GenerateTxID();
			date_default_timezone_set('Asia/Kolkata');
              $payment_date =  date("Y-m-d H:i:s", time());
			  $orderId = 'ORD'.mt_rand(100000000, 999999999);
             $FromTransaction = WalletTransaction::insert([
			                           'userId'=>$referral_from,									   
									   'orderId'=>$orderId,
									   'transactionId'=>$txId,
									   'amount'=>'50',
									   'transation_status'=>'TXN_SUCCESS',
									   'type'=>'Credit',
									   'payment_date'=>$payment_date
									   

								]);		

               //To user credit	
                    $txId = $this->GenerateTxID();
                  $orderId_1 = 'ORD'.mt_rand(100000000, 999999999);
                $FromTransaction = WalletTransaction::insert([
			                           'userId'=>$referral_to,									   
									   'orderId'=>$orderId_1,
									   'transactionId'=>$txId,
									   'amount'=>'50',
									   'transation_status'=>'TXN_SUCCESS',
									   'type'=>'Credit',
									   'payment_date'=>$payment_date
									   

								]);			   
		  
		  $UserDetails = User::Select('id','name','mobile','email','image','alternate_number','gender','dob','CheckPin','referral_code')
			                      ->Where('id',$UserId)->first();
								  
		     $response['error']="false";
			$response['error_message']="Profile Update Successfully";
			$response['CheckPin']=$PinValue;
			$response['UserDetails']=$UserDetails;
		  
		 }else{
			 
			 $response['error']="true";
		     $response['error_message']="Invalid referral code";	 
		 }
				
			}
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
		}else{
			
			$response['error']="true";
            $response['error_message']="Invalid Id";
		}
		
		
     	}else{
			
		//WithOut E-mail
		
		$GetUserCount = User::Select('mobile')->Where('id',$UserId)->count();
		if($GetUserCount > 0){ 

		$name = $Request->name;
		$dob  = $Request->dob;
		$gender = $Request->gender;
		$image = $Request->image;
		

		$alternate_number =  $Request->alternate_number;
		
		if($name && $dob && $gender){

			$GetUser = User::Where('id',$UserId)->Update([
			'name' => $name,
			'image' => $image,
			'dob'  => $dob,
			'gender' => $gender,
			'alternate_number' => $alternate_number
			]);
			
			 
			 $UserDetails = User::Select('id','name','mobile','email','image','alternate_number','gender','dob','CheckPin','referral_code')
			                      ->Where('id',$UserId)->first();
			
			if($UserDetails->CheckPin == 1){
				$PinValue = "Yes";
			}else{
				$PinValue = "No";
			}
			
			
			
			$response['error']="false";
			$response['error_message']="Profile Update Successfully";
			$response['CheckPin']=$PinValue;
			$response['UserDetails']=$UserDetails;
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
		}else{
			
			$response['error']="true";
            $response['error_message']="Invalid Id";
		}
			
		}
		echo json_encode($response);
	}
	
	//Check ReferralCode
	public function CheckReferral(Request $Request){
	  $UserId = Auth::guard('api')->user()->id;
	  $referral_code = $Request->referral_code;

      if($referral_code){
		 
        $CheckCode = User::Select('id','referral_code')->Where(['referral_code'=>$referral_code])->first();
         if(count($CheckCode) == 1){
		
		  $referral_from = $CheckCode->id;
		  $referral_to = $UserId;
		
		  $SelectFrom = User::Select('id','wallet_amount')->Where('id',$referral_from)->first();
		  $FromWallet_amount = $SelectFrom->wallet_amount;
		  
		  $SelectTo = User::Select('id','wallet_amount')->Where('id',$referral_to)->first();
		  $ToWallet_amount = $SelectTo->wallet_amount;
		  
		  $SumFrom_wallet = $FromWallet_amount+50;
		  $SumTo_wallet = $ToWallet_amount+50;
		  
		  $UpdateFrom = User::Select('id','wallet_amount')->Where('id',$referral_from)->update(['wallet_amount'=>$SumFrom_wallet]);
		  $UpdateTo = User::Select('id','wallet_amount')->Where('id',$referral_to)->update(['wallet_amount'=>$SumTo_wallet]);
		  
		     $response['error']="false";
		     $response['error_message']="Successfully";
		  
		 }else{
			 
			 $response['error']="true";
		     $response['error_message']="Invalid referral code";	 
		 }
	   }else{
		  
		$response['error']="true";
		$response['error_message']="Referral code missing";
		  
	  } 
	  echo json_encode($response);
	
	}
	
	
	//Time Slots
	public function GetTimeSlots(Request $Request){
		
		$GetSlot = TimeSlots::Select('id','fromSlots','toSlots')->get();
		if(count($GetSlot) > 0){
			
			$response['error']="false";
            $response['TimeSlot']=$GetSlot;
			
		}else{
			
		    $response['error']="true";
            $response['error_message']="No Slots Avaliable";	
		}
		echo json_encode($response);
	}
	
	//HomeGallery
	public function Home(Request $Request){

		$UserId = Auth::guard('api')->user()->id;
		$app_version = $Request->version;
		//echo $UserId;die;
		
		$Username = Auth::guard('api')->user()->name;
		$GetUser = User::Where('id',$UserId)->first();
		
		$rate = DB::table('UserRating')->Select('Bookings.id as userBookId','UserRating.id','UserRating.userId','Bookings.bookingId as BookId','Bookings.bookingTimeSlot','UserRating.bookingId','Bookings.quantity','Bookings.totalPayment','Bookings.DeliverySuccessDate','Bookings.paymentType','Bookings.pending_payment as wallet_status','TimeSlots.fromSlots','TimeSlots.toSlots')
		                               ->rightjoin('Bookings','Bookings.id','=','UserRating.bookingId')
									   ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
									   ->Where(['Bookings.userId'=>$UserId,'UserRating.bookingId'=>null,'Bookings.Status'=>'COMPLETED'])
									   ->first();  
									   
				

		// echo json_encode($rate);         
		// die;							   
		
		if(count($rate) > 0){
			
			// $wallet_payment = Bookings::Select('id','userId','pending_payment')
		                           // ->Where(['userId'=>$UserId,'Status'=>'COMPLETED','pending_payment'=>1])
			                       // ->count();
								   
			// if($wallet_payment > 0){
			
			// $wallet_status = 1;
			// $payment_type= 'Wallet';
			// }else{
				// $wallet_status = 0;
				// $payment_type= '';
			// }					   
			
			$rating = "1";
			// $rate->wallet_status = $wallet_status;
			// $rate->payment_type= $payment_type;
			$rate->TimeSlot = $rate->fromSlots. " - ". $rate->toSlots;
			$deliverydate   =  explode(" ",$rate->DeliverySuccessDate);
			$rate ->deliverydate = date("d-m-y",strtotime($deliverydate[0]));
			
			
			
		}else{
			
			$rate = (object) array();
			$rating = "0";
		}
		
		$Gallery = DB::table('HomeGallery')->select('id','images')->get();
		$ongoing_service = Bookings::Select('id','userId','Status')->Where(['userId'=>$UserId,'Status'=>'CONFIRMED'])->count();
		// $wallet_payment = Bookings::Select('id','userId','pending_payment')
		                           // ->Where(['userId'=>$UserId,'Status'=>'COMPLETED','pending_payment'=>1])
								   // ->count();
		// if($wallet_payment > 0){
			
			// $wallet_status = 1;
			// $payment_type= 'Wallet';
		// }else{
			// $wallet_status = 0;
			// $payment_type= '';
		// }

		
		//Check app version
		
		$check_version = DB::table('app_setting')->Select('id','version')->first();
	    //echo $check_version->version;die;
		// $app_version = '2.0';
		
		if($check_version->version > $app_version){
		
          $version  = '1';		
			
		}else{
			
			$version  = '0';	
		}    
		 
		if(count($Gallery) > 0){
			
			$response['error']="false";
			$response['error_message']="Home gallery images";
			$response['version']=$version;
			$response['service_count']=$ongoing_service;
            $response['rating']=$rating;
            $response['Username']=$Username;
            $response['wallet_amount']=$GetUser->wallet_amount;
			// $response['wallet_status']=$wallet_status;
			// $response['payment_type']=$payment_type;
            $response['Booking']=$rate;
            $response['response']=$Gallery;
			
		 }else{
			
			$response['error']="true";
            $response['error_message']="No gallery image available";
			$response['service_count']=$ongoing_service;
            $response['rating']=$rating;
            $response['Username']=$Username;
            $response['wallet_amount']=$GetUser->wallet_amount;
			$response['payment_type']=$payment_type;
			$response['wallet_status']=$wallet_status;
            $response['Booking']=$rate;
            $response['response']=$Gallery;
		}
		
		echo json_encode($response);
	}
	
	
	//User Details
	public function UserDetails(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		$GetDetails = User::Select('id','name','mobile','email','image','dob','gender','alternate_number')->Where('id',$UserId)->first();
		
		if(count($GetDetails) == 1){
			
			if($GetDetails->alternate_number == null){
				
				$alternate_number = "";
			}else{
				$alternate_number = $GetDetails->alternate_number;
			}
			
			$response['error']="false";
            $response['id']=$GetDetails->id;
            $response['name']=$GetDetails->name;
            $response['mobile']=$GetDetails->mobile;
            $response['email']=$GetDetails->email;
            $response['image']=$GetDetails->image;
            $response['dob']=$GetDetails->dob;
            $response['gender']=$GetDetails->gender;
            $response['alternate_number']=$alternate_number; 
		}else{
			
			$response['error']="true";
            $response['error_message']="No user details";
		}
		echo json_encode($response);
	}
	
	//Check Avaliable pincode
	public function CheckPincode(Request $Request){
		$UserId = Auth::guard('api')->user()->id;
		
		if($Request->pincode){
			
			$CheckPin = Pincode::Where('code',$Request->pincode)->count();
			
			$validator = Validator::make($Request->all(), [
				   'pincode' => 'required|digits:6|numeric',
				]);
				
			if ($validator->fails()) {

				   $response['error']="true";
				   $response['error_message']="Please enter valid pincode";
				   echo json_encode($response);
				   die;
				}	
			
			if($CheckPin > 0){
				
				$UpdatePin  = User::Select('id','CheckPin')->Where(['id'=>$UserId])->update(['CheckPin' => $Request->pincode]);
				
				$response['error']="false";
				$response['error_message']="sorry!! we would be coming soon to your area";
				
			  }else{
				
				$CheckUser = DB::table('SearchPincode')->Where(['userId'=>$UserId, 'pincode'=>$Request->pincode])->count();
				
				//echo $CheckUser;die;

				if($CheckUser > 0){
				
				$UpdatePin  = User::Select('id','CheckPin')->Where(['id'=>$UserId])->update(['CheckPin' => $Request->pincode]);
				
				$ReqService = DB::table('SearchPincode')->Where('userId',$UserId)->Update(['pincode'=>$Request->pincode]);
									  
				$response['error']="true";
				$response['error_message']="sorry!! we would be coming soon to your area";
				
			  }else{
				  
				  $ReqService = DB::table('SearchPincode')->insert([
				                          'userId'=> $UserId,
										  'pincode'=>$Request->pincode
				                      ]);
				$UpdatePin  = User::Select('id','CheckPin')->Where(['id'=>$UserId])->update(['CheckPin' => $Request->pincode]);					  
				$response['error']="true";
				$response['error_message']="sorry!! we would be coming soon to your area";
			  }
				
			}
			
		  }else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
		echo json_encode($response);
		
	}
	
	//Pincode 
	public function Pincode(Request $Request){
		
		$GetPincode = Pincode::Select('id','area','code')->Where('status',1)->get();
		
		
		if(count($GetPincode) > 0){

			//$GetPincode = array("Other"=>"Others");
			$response['error']="false";
			$response['response']=$GetPincode;
			
		}else{
			
			$response['error']="true";
            $response['error_message']="No pincode available";
		}
		echo json_encode($response);
	}
	
	//Add Address
       public function AddAddresses(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		$pincode = $Request->pincode;
		$title = $Request->title;
		$flatNo = $Request->flatNo;
		$landmark = $Request->landmark;
		$address = $Request->address;
		$latitude = $Request->latitude;
		$longitude = $Request->longitude;
		
		
		if($pincode && $title && $flatNo && $address && $latitude && $longitude){
			
		$GetArea = Pincode::Where('code',$pincode)->first();
		
		//echo $GetArea;die;
		
        if(count($GetArea) == '1'){
            
		 $AreaId =  $GetArea->id;
		 
		if($title == 'Home'){
		
          $CheckHomeAddress = UserAddresses::Where(['UserId'=> $UserId, 'title'=>'Home','status'=>0])->count();

         if($CheckHomeAddress == '0'){

            $Address = UserAddresses::insert([
                      'userId'=>$UserId,
                      'serviceAreaId'=>$AreaId,
                      'title'=>$title,
                      'flatNo'=>$flatNo,
                      'landmark'=>$landmark,
                      'address'=>$address,
                      'latitude'=>$latitude,
                      'longitude'=>$longitude
                    ]);
		
		   $response['error']="false";
           $response['error_message']="Home address added Successfully";
		 }else{


           $response['error']="true";
           $response['error_message']="Home Address Exists";
		 }		 
			
			
		}else if($title == 'Work'){
		
         $CheckWorkAddress = UserAddresses::Where(['UserId'=> $UserId, 'title'=>'Work','status'=>0])->count();  
         if($CheckWorkAddress == '0'){

		 
		  $Address = UserAddresses::insert([
                      'userId'=>$UserId,
                      'serviceAreaId'=>$AreaId,
                      'title'=>$title,
                      'flatNo'=>$flatNo,
                      'landmark'=>$landmark,
                      'address'=>$address,
                      'latitude'=>$latitude,
                      'longitude'=>$longitude
                    ]);
		
		   $response['error']="false";
           $response['error_message']="Work address added successfully";

         }else{

           $response['error']="true";
           $response['error_message']="Work address exists";
		 }		 
			
			
			
		}else{
			
			$Address = UserAddresses::insert([
                      'userId'=>$UserId,
                      'serviceAreaId'=>$AreaId,
                      'title'=>$title,
                      'flatNo'=>$flatNo,
                      'landmark'=>$landmark,
                      'address'=>$address,
                      'latitude'=>$latitude,
                      'longitude'=>$longitude
                    ]);
		
		   $response['error']="false";
           $response['error_message']="Others address added successfully";
			
		}
		
		 
        }else{
			
		    $response['error']="true";
            $response['error_message']="Service not available in this area";
		}
		
		}else{
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		echo json_encode($response);
	}
	
	//Edit Address
	public function EditAddress(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		//echo $UserId;die;
		
		$AddressId = $Request->AddressId;
		$pincode = $Request->pincode;
		$title = $Request->title;
		$flatNo = $Request->flatNo;
		$landmark = $Request->landmark;
		$address = $Request->address;
		$latitude = $Request->latitude;
		$longitude = $Request->longitude;
		
		//echo $landmark;die;
		
		
		if($pincode && $title && $flatNo && $address && $latitude && $longitude && $AddressId){
		
		$CheckAddressId = UserAddresses::Where(['id'=> $AddressId])->count();
		
		if($CheckAddressId){
			
			$GetArea = Pincode::Where('code',$pincode)->first();
			
			//echo $GetArea;die;
		
				if(count($GetArea) > 0){
					
				 $AreaId =  $GetArea->id;
				 
				 if($title == 'Home'){
		
				  $CheckHomeAddress = UserAddresses::Where(['UserId'=> $UserId, 'title'=>'Home'])
				                                      ->Where('id', '!=' , $AddressId)
													  ->Where(['status'=>0])
				                                      ->count();
                  
				  //echo $CheckHomeAddress;die;
				  
				  
				 if($CheckHomeAddress == '0'){

					$Address = UserAddresses::where(['id' => $AddressId])->update([
							  'serviceAreaId'=>$AreaId,
							  'title'=>$title,
							  'flatNo'=>$flatNo,
							  'landmark'=>$landmark,
							  'address'=>$address,
							  'latitude'=>$latitude,
							  'longitude'=>$longitude
							]);
				
				   $response['error']="false";
				   $response['error_message']="Home address updated successfully";
				   
				 }else{


				   $response['error']="true";
				   $response['error_message']="Home Address Exists";
				 }		 
					
					
				}else if($title == 'Work'){
		
				 $CheckWorkAddress = UserAddresses::Where(['UserId'=> $UserId, 'title'=>'Work'])
				                                    ->Where('id', '!=' , $AddressId)
													->Where(['status'=>0])
				                                    ->count();
				 
				 
				 if($CheckWorkAddress == '0'){

				
				  $Address = UserAddresses::Where(['id' => $AddressId])->update([
							  'serviceAreaId'=>$AreaId,
							  'title'=>$title,
							  'flatNo'=>$flatNo,
							  'landmark'=>$landmark,
							  'address'=>$address,
							  'latitude'=>$latitude,
							  'longitude'=>$longitude
							]);
				
				   $response['error']="false";
				   $response['error_message']="Work address updated successfully";

				 }else{

				   $response['error']="true";
				   $response['error_message']="Work Address Exists";
				 }		 
					
					
					
				}else{
			
					$Address = UserAddresses::Where(['id' => $AddressId])->update([
							  'serviceAreaId'=>$AreaId,
							  'title'=>$title,
							  'flatNo'=>$flatNo,
							  'landmark'=>$landmark,
							  'address'=>$address,
							  'latitude'=>$latitude,
							  'longitude'=>$longitude
							]);
				
				   $response['error']="false";
				   $response['error_message']="Other address updated successfully";
					
				}

				}else{
					
					 $response['error']="true";
					 $response['error_message']="No service area avaliable";
				}

		}else{
			
			$response['error']="true";
            $response['error_message']="Invalid address";
		}
		
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory parameters are missing";
		}
		
		
		echo json_encode($response);
	}
	
	//GetAddress
	public function GetAddress(Request $Request){
		$UserId = Auth::guard('api')->user()->id;
         // echo $UserId;
		
		$GetHomeAddress = UserAddresses::Where(['UserId'=> $UserId])
		              ->Select('UserAddresses.id','userId','serviceAreaId','code as pincode','title','flatNo','landmark','address','latitude','longitude')
					   ->join('Pincode','Pincode.id', '=' , 'UserAddresses.serviceAreaId')
		              //->whereIn('title', ['Home'])
					   ->Where(['title'=>'Home','UserAddresses.status'=>'0'])
		              ->get();
					  
		$GetWorkAddress = UserAddresses::Where(['UserId'=> $UserId])
		              ->Select('UserAddresses.id','userId','serviceAreaId','code as pincode','title','flatNo','landmark','address','latitude','longitude')
					  ->join('Pincode','Pincode.id', '=' , 'UserAddresses.serviceAreaId')
		              //->whereIn('title', ['Work'])
					  ->Where(['title'=>'Work','UserAddresses.status'=>'0'])
		              ->get();
					
		$OtherAddress = UserAddresses::Where(['UserId'=> $UserId])
		              ->Select('UserAddresses.id','userId','serviceAreaId','code as pincode','title','flatNo','landmark','address','latitude','longitude')
					   ->join('Pincode','Pincode.id', '=' , 'UserAddresses.serviceAreaId')
		              //->whereIn('title', ['Other'])
					   ->Where(['title'=>'Other','UserAddresses.status'=>'0'])
		              ->get();
   
        $GetSlot = TimeSlots::Select('id','fromSlots','toSlots')->Where('status',1)->get();
		
		foreach($GetSlot as $Slots){
			
			//$fromtime  =  explode(" ",$Slots->fromSlots);
			
			$Slots->TimeSlot = $Slots->fromSlots." "."-"." ".$Slots->toSlots;
		}
		
		
		  $date_from =  date("Y-m-d"); 
		  
		  $date_to = date('Y-m-d', strtotime($date_from. ' + 17 day'));
		  
		
		// $date_from = "2018-06-22";   
		$date_from = strtotime($date_from); 
		// $date_to = "2018-06-30";  
		$date_to = strtotime($date_to);  

		$mainarr = [];
		$j = 1;
		 
		for ($i=$date_from; $i<=$date_to; $i+=86400) {  


			
			$thisDate = date( 'd-m-Y', $i );

			$getDate = date('l', strtotime($thisDate));
		   
			 $day_name = substr($getDate, 0, 3);
			 
			 if($day_name != 'Sun' && $day_name != 'Sat'){
				 
				 $stdarr = (object) array();
				 
				 $stdarr->id=$j++;
				 $stdarr->dates=$thisDate;
				 
				 array_push($mainarr,$stdarr);

			 }
			 
			
		} 

		// echo json_encode($mainarr);

		// die;
		
		$current_date =  date("Y-m-d"); 
		$user_package = DB::table('user_packages')->Select('id','end_date','balance_amount','balance_clothes')
		                                 ->where('balance_clothes', '!=' , 0)
										 ->where('balance_amount', '!=' , 0)
		                                 ->Where(['user_packages.userId'=>$UserId])
										 ->where('user_packages.end_date','>=',$current_date)
										 ->get();
	   if(count($user_package) > 0){

         $Is_package = 1;
	    
	   }else{

          $Is_package = 0;
	   }	   
        		
		// echo json_encode($user_package);die;
				
       if(count($GetHomeAddress) == '0' && count($OtherAddress) == '0' && count($GetWorkAddress) == '0'){
  
          $array = [];
          $response['error']="false";
          $response['Is_package']=$Is_package;
          $response['Home']=$array;
          $response['Work']=$array;
          $response['Other']=$array;
          $response['Slots']=$GetSlot;
          $response['order_date']=$mainarr;
		  echo json_encode($response);
		  
	   }else{	   

		echo  json_encode(array("error"=>"false","Is_package"=>$Is_package,"Home"=>$GetHomeAddress,"Work"=>$GetWorkAddress,"Other"=>$OtherAddress,"Slots"=>$GetSlot,'order_date'=>$mainarr));
	   }
	}
	
	
	//Delete Address
	public function DeleteAddress(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		
		if($Request->addressId){
			
			$AddressId = UserAddresses::Where(['id' => $Request->addressId,'userId' => $UserId])->count();
			if($AddressId == '1'){
			
			$DeleteAddress = UserAddresses::Where(['id' => $Request->addressId,'userId' => $UserId])->update(['status'=>1]);
			$response['error']="false";
			$response['id']=$Request->addressId;
            $response['error_message']="Address deleted";
				
			}else{
				
			$response['error']="true";
            $response['error_message']="Invalid address id";	
			}
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory parameters are missing";
		}
		echo json_encode($response);
	}
	
	//RateCard
	public function RateCard(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		
		$GetMens = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','CategoryList.Qty')
		                     ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                     ->Where(['groupName'=>'Mens'])
							 ->get();
		foreach($GetMens as $Mens){
          
		   $MensPrice = $Mens->price;
		   $MensQty = $Mens->Qty;
		}		
		$GetWomens = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','CategoryList.Qty')
		                     ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                     ->Where(['groupName'=>'Womens'])
							 ->get();
							 
        foreach($GetWomens as $Womens){
          
		   $WomensPrice = $Womens->price;
		   $WomensQty = $Womens->Qty;
		}							 
							 
		 $GetUsuals = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','CategoryList.Qty')
		                     ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                     ->Where(['groupName'=>'General Clothes'])
							 ->get();	
							 
         foreach($GetUsuals as $Usuals){
          
		   $UsualsPrice = $Usuals->price;
		   $UsualsQty = $Usuals->Qty;
		   
		   $Usuals->SubCategoryName = $Usuals->name;
		   
		 }	   
		
		 $GetExclusive = DB::table('NewCategories')->Select('NewCategories.id','NewCategories.name','CategoryList.id as CategoryId','CategoryList.price','CategoryList.Qty')
		                     ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                     ->Where(['groupName'=>'Exclusive'])
							 ->get();
							 
	    foreach($GetExclusive as $Exclusive){
          
		   $ExclusivePrice = $Exclusive->price;
		   $ExclusiveQty = $Exclusive->Qty;
		   
		   $Exclusive->SubCategoryName = $Exclusive->name;
		   
		 }	
  		
		   $response= [];
		   
		
		$RegularValue = array(
		        "CategoryName"=>"Daily Wear"
				,"price"=>"Rs.".$MensPrice,"quantity"=>$MensQty,
				"Category"=>array(array("SubCategoryName"=>"Men","arrSubCategory"=>$GetMens),
				array("SubCategoryName"=>"Women","arrSubCategory"=>$GetWomens))
			);
		
		   $UsualsValue=array("CategoryName"=>"General Clothes","price"=>"Rs.".$UsualsPrice,"quantity"=>$UsualsQty,"Category"=>$GetUsuals);
		   $ExclusiveValue=array("CategoryName"=>"Exclusive","price"=>"Rs.".$ExclusivePrice,"quantity"=>$ExclusiveQty,"Category"=>$GetExclusive);
		   
		   array_push($response, $RegularValue);
		   array_push($response, $UsualsValue);
		   array_push($response, $ExclusiveValue);
		   echo  json_encode(array("error"=>"false","tax"=> "Above prices are inclusive of 18% tax","response"=>$response));

	}
	
	
	//Booking Request
	public function UserBooking(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		// echo $UserId;die;
		date_default_timezone_set('Asia/Kolkata');
		$current_date =  date("Y-m-d");
		$time = date("H:i:s");
		$time_1 = date("H:i");
		
		
		
		$book_date = date('Y-m-d', strtotime($Request->bookingDate));

		$bookDateBegin = $current_date;
		$bookDateEnd = date('Y-m-d', strtotime($current_date. ' + 17 day'));

		$from_time = '09:00:00';
		$to_time = '17:00:00';
		
	    $get_slot = TimeSlots::Select('id','fromSlots','toSlots')->Where('id',$Request->TimeSlotId)->first();

		// if (($book_date >= $bookDateBegin) && ($book_date <= $bookDateEnd)) {
			
		  // if (($time >= $from_time) && ($time <= $to_time)) {
				
				// if($current_date == $book_date){
					
					// if($get_slot->toSlots > $time_1){
						
						// echo "boo";
						
					// }else{
						
						// echo "no";
					// }
					
				 // }else{
					
					// echo "noo";
					
				// }
				
				
			// }else{
				
				
				// echo 'expriy';
			// }
			
		// }else{
			
			// echo "not";
		// }die;
		
		
		$addressId = $Request->addressId;
		$bookingDate = $Request->bookingDate;
        $TimeSlotId = $Request->TimeSlotId;
        $Quantity = $Request->quantity;
        $payment_type = $Request->payment_type;
		$promode_code = $Request->promode_code;
		$Status = "CONFIRMED";
		
		$given_date = '11-06-2018';
		
		$book_date_1 = date("Y-m-d", strtotime($bookingDate));
		
		
		if($book_date_1 < $current_date){
			
			$response['error']="true";
            $response['error_message']="Invalid date";
            echo json_encode($response);			
			die; 
		}
		
		
		$confirmdate =  date("Y-m-d H:i:s", time());

		
        $Addresses = UserAddresses::Where(['id'=> $addressId, 'userId' => $UserId])->first();
		// echo $Addresses;die;
		if(count($Addresses) == 0){
			 
			$response['error']="true";
            $response['error_message']="Invalid addressId";
            echo json_encode($response);			
			die;
		 }
		$GetArea = Pincode::Where('id',$Addresses->serviceAreaId)->Where('status',1)->first();
		// echo $GetArea;die;
		if(count($GetArea) == '0'){
			$response['error']="true";
            $response['error_message']="service area currently not available";
            echo json_encode($response);			
			die;  
		 }
		
		$Pickup = pickupdeliveryuser::Select('id','Is_active')
		                             ->Where(['serviceAreaId'=>$Addresses->serviceAreaId,'Is_active'=>1])->get();
		$serviceId = $Addresses->serviceAreaId;							 
		if(count($Pickup) == 0){
			
			$response['error']="true";
            $response['error_message']="Pickup user not available";
            echo json_encode($response);			
			die;
		}
		// $assign_pickup = $this->AssignPickup($serviceId);
		// echo $assign_pickup;die;
		
	     // echo $Pickup; die;
		 
		 // $SelectPickupMan = $Pickup[rand(0, count($Pickup) - 1)];
	   
	     // echo $SelectPickupMan->id;die;
		 
		 // if(count($SelectPickupMan) == '0'){
			// $response['error']="true";
            // $response['error_message']="Pickup guy not avaliable";
            // echo json_encode($response);			
			// die; 
			 
		 // }
		 
		 //Check Promo code
		 
		 if($promode_code){
			 
		 $get_promode =Promocode::Select('id','promocode','status')
		                         ->Where(['promocode'=>$promode_code,'status'=>1])->first();	 
		 
	    if(count($get_promode) == 1){
		
		 
		 $check_promocode = UserPromocode::Select('id','userId')
		                        ->Where(['userId'=>$UserId,'promocodeId'=>$get_promode->id])->count();
		
		 
		 if($check_promocode == 1){ 
			 
			$response['error']="true";
            $response['error_message']="Already used that promocode";
            echo json_encode($response);			
			die;
		 }
		 
		}else{
			
			$response['error']="true";
            $response['error_message']="Invalid offer code";
            echo json_encode($response);			
			die;
			
		}
		 
		 
		 }
		 
		 
		
		if($addressId && $bookingDate && $TimeSlotId && $payment_type){
			
		if($Quantity >= 10 || $Quantity == '')	{
			
		if(count($Addresses) > 0){
			

      	
		if (($book_date >= $bookDateBegin) && ($book_date <= $bookDateEnd)) {
		
	     //if (($time >= $from_time) && ($time <= $to_time)) {
		   //Booking Current date time validation
		   if($current_date == $book_date){
			   
			   if($get_slot->toSlots > $time_1){
				   
				   
				   //Get Promo code
		 $promo_id = 0;
		 
		 if($promode_code){
		 
		 $get_promode =DB::table('promocode')->Select('id','promocode')->Where(['promocode'=>$promode_code])->first();
		 
		 if(count($get_promode) == 0){
			 
			$response['error']="true";
            $response['error_message']="Invalid promocode";
            echo json_encode($response);			
			die; 
			 
		  }else{
			  $promo_id = json_encode($get_promode->id);
			  $add_promo_code = DB::table('user_promocode')->insert(['userId'=>$UserId,'promocodeId'=>$promo_id]);
		  }
			 
		 
		 }
		 
		 if($promo_id == ''){
			 
			 $promo_id = 0;
		  }
				   
				   
				   $bookingId="IB".mt_rand(1000, 9999);	 
			
				$Booking = Bookings::insert([
							  'userId'=>$UserId,
							  'bookingId'=>$bookingId,
							  'pickupDeliveryUserId'=>1,
							  'addressId'=>$addressId,
							  'service_area'=>$Addresses->serviceAreaId,
							  'bookingDate'=>$bookingDate,
							  'bookingTimeSlot'=>$TimeSlotId,
							  'quantity'=>$Quantity,
							  'warehouseId'=>$GetArea->warehouseId,
							  'Status'=> $Status,
							  'OrderAssign'=>1,
							  'ConfirmOrder'=> 1,
							  'OrderConfirmDate'=> $confirmdate,
							  'paymentType'=>$payment_type,
							  'promode_code'=>$promo_id
							]);
					
		//pickup orders
         $pickup = DB::table('order_delivery')->Select('id','userId','service_date','type')
		                                      ->Where(['userId'=>1,'service_date'=>$bookingDate,'type'=>'pickup'])->count();
          if($pickup == 0){

               $data =DB::table('order_delivery')->insert([
			                         'userId'=>1,
									 'service_date'=>$bookingDate,
									 'type'=>'pickup'
			                     ]);
		  }		  
					
		 $GetId = Bookings::select('Bookings.id','Bookings.bookingId','Bookings.bookingDate','Bookings.quantity','Bookings.bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','OrderConfirmDate','Bookings.paymentType')
		                    ->join('TimeSlots','TimeSlots.id','=','Bookings.bookingTimeSlot')
		                    ->orderBy('id', 'DESC')
							->take(1)
							->first();
		 
		 if($GetId->quantity == null){
			 
			 $qty = "";
			 
		 }else{
			 $qty = $GetId->quantity;
		 }
		 
		  $con_date_1  = explode(" ",$GetId->OrderConfirmDate);
		   
		   $con_date = date("Y-m-d", strtotime($GetId->bookingDate));
		   
		  $book_date =  date("j-M-Y", strtotime($con_date));
		  $booking_id = $GetId->bookingId;
		 
		 $fcm = new PushNotifications();
		 $GetDetails = User::Select('id','name','mobile','deviceToken','os')->where('id',$UserId)->first();
		 $title = "Service confirmation";
		 $body ='Dear '.$GetDetails->name.', your bookingID '.$booking_id.' is confirmed! Your scheduled pick up is on '.$book_date.' between '.$GetId->fromSlots .' TO '. $GetId->toSlots.'. Track your order status on Ironbox app';
		 $token = $GetDetails->deviceToken;
		 $mobile = $GetDetails->mobile;
		 $os = $GetDetails->os;
		 $message ='Dear '.$GetDetails->name.', your bookingID '.$booking_id.' is confirmed! Your scheduled pick up is on '.$book_date.' between '.$GetId->fromSlots .' TO '. $GetId->toSlots.'. Track your order status on Ironbox app';
		 
		 $CommonFunction = new CommonFunctions();			
		$newresponse = $CommonFunction->SentOtp($mobile,$message);
		 
		 
		 $arraydata = array("BookingId"=>"","message"=>$body,"deliverystatus"=>"");
	     $newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);
		 
					
		  $response['error']="false";
          $response['error_message']="Booking Success";
          $response['bookingId']=$GetId->id;
          $response['bookId']=$GetId->bookingId;
          $response['bookingDate']=$GetId->bookingDate;
          $response['paymentType']=$GetId->paymentType;
          $response['TimeSlots']=$GetId->fromSlots ." - ". $GetId->toSlots;
          $response['quantity']=$qty;
				   
				echo json_encode($response);			
					die;   
				   
			   }else{
				   
				   $response['error']="true";
					$response['error_message']="Time slot expriy";
					echo json_encode($response);			
					die; 
				   
			   }
			   
			   
			   
			   
			   
		   }else{
        //Booking others days


         //Get Promo code
		 $promo_id = 0;
		 
		 if($promode_code){
		 
		 $get_promode =DB::table('promocode')->Select('id','promocode')->Where(['promocode'=>$promode_code])->first();
		 
		 if(count($get_promode) == 0){
			 
			$response['error']="true";
            $response['error_message']="Invalid promocode";
            echo json_encode($response);			
			die; 
			 
		  }else{
			  $promo_id = json_encode($get_promode->id);
			  $add_promo_code = DB::table('user_promocode')->insert(['userId'=>$UserId,'promocodeId'=>$promo_id]);
		  }
			 
		 
		 }
		 
		 if($promo_id == ''){
			 
			 $promo_id = 0;
		  }		
        $bookingId="IB".mt_rand(1000, 9999);	 
			
		$Booking = Bookings::insert([
                      'userId'=>$UserId,
					  'bookingId'=>$bookingId,
					  'pickupDeliveryUserId'=>1,
                      'addressId'=>$addressId,
					  'service_area'=>$Addresses->serviceAreaId,
                      'bookingDate'=>$bookingDate,
                      'bookingTimeSlot'=>$TimeSlotId,
					  'quantity'=>$Quantity,
					  'warehouseId'=>$GetArea->warehouseId,
					  'Status'=> $Status,
					  'OrderAssign'=>1,
					  'ConfirmOrder'=> 1,
					  'OrderConfirmDate'=> $confirmdate,
					  'paymentType'=>$payment_type,
					  'promode_code'=>$promo_id
                    ]);
					
		//pickup orders
         $pickup = DB::table('order_delivery')->Select('id','userId','service_date','type')
		                                      ->Where(['userId'=>1,'service_date'=>$bookingDate,'type'=>'pickup'])->count();
          if($pickup == 0){

               $data =DB::table('order_delivery')->insert([
			                         'userId'=>1,
									 'service_date'=>$bookingDate,
									 'type'=>'pickup'
			                     ]);
		  }		  
					
		 $GetId = Bookings::select('Bookings.id','Bookings.bookingId','Bookings.bookingDate','Bookings.quantity','Bookings.bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','OrderConfirmDate','Bookings.paymentType')
		                    ->join('TimeSlots','TimeSlots.id','=','Bookings.bookingTimeSlot')
		                    ->orderBy('id', 'DESC')
							->take(1)
							->first();
		 
		 if($GetId->quantity == null){
			 
			 $qty = "";
			 
		 }else{
			 $qty = $GetId->quantity;
		 }
		 
		  $con_date_1  = explode(" ",$GetId->OrderConfirmDate);
		   
		   $con_date = date("Y-m-d", strtotime($GetId->bookingDate));
		   
		  $book_date =  date("j-M-Y", strtotime($con_date));
		  $booking_id = $GetId->bookingId;
		 
		 $fcm = new PushNotifications();
		 $GetDetails = User::Select('id','name','mobile','deviceToken','os')->where('id',$UserId)->first();
		 $title = "Service confirmation";
		 $body ='Dear '.$GetDetails->name.', your bookingID '.$booking_id.' is confirmed! Your scheduled picked up is on '.$book_date.' between '.$GetId->fromSlots .' TO '. $GetId->toSlots.'. Track your order status on Ironbox app';
		 $token = $GetDetails->deviceToken;
		 $mobile = $GetDetails->mobile;
		 $os = $GetDetails->os;
		 $message ='Dear '.$GetDetails->name.', your bookingID '.$booking_id.' is confirmed! Your scheduled picked up is on '.$book_date.' between '.$GetId->fromSlots .' TO '. $GetId->toSlots.'. Track your order status on Ironbox app';
		 
		 $CommonFunction = new CommonFunctions();			
		 $newresponse = $CommonFunction->SentOtp($mobile,$message);
		 
		 
		 $arraydata = array("BookingId"=>"","message"=>$body,"deliverystatus"=>"");
	     $newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);
		 
					
		  $response['error']="false";
          $response['error_message']="Booking Success";
          $response['bookingId']=$GetId->id;
          $response['bookId']=$GetId->bookingId;
          $response['bookingDate']=$GetId->bookingDate;
          $response['TimeSlots']=$GetId->fromSlots ." - ". $GetId->toSlots;
          $response['paymentType']=$GetId->paymentType;
          $response['quantity']=$qty;
		 }
		  
		// }else{
			
			// $response['error']="true";
            // $response['error_message']="Invalid time";
		// }
		  
		}else{
			
			$response['error']="true";
            $response['error_message']="Invalid date";
			
		}
		  
		}else{
			
			$response['error']="true";
            $response['error_message']="AddressId Is Missing";
		}
		  
		}else{
			
			$response['error']="true";
            $response['error_message']="Max 10 Items";
		}
		}else{

            $response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";

		}		
		echo json_encode($response);
	}
	
	
	
	function AssignPickup($serviceId){
		
		$GetDeliveryUser = pickupdeliveryuser::Select('id','serviceAreaId')
		                                      ->Where(['serviceAreaId'=>$serviceId,'Is_active'=>1])
											  ->get();
		foreach($GetDeliveryUser as $Delivery){
			
			   //$Orders = DB::select("select count(*) as orders from Bookings where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$Delivery->id."' AND OrderAssign ='1' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$Delivery->id."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ");
			   
		       $Orders = DB::select("select Bookings.id,OrderAssign from Bookings where Bookings.id in (SELECT Bookings.id as booking_id from Bookings where pickupDeliveryUserId= '".$Delivery->id."' AND OrderAssign ='1' AND Bookings.cancelReason IS NULL UNION ALL  Select Bookings.id as booking_id from Bookings where DeliveryUserId = '".$Delivery->id."' AND OrderAssign ='2' AND Bookings.cancelReason IS NULL ) ");

             $Delivery->orderWeight = count($Orders);			   
             //$Delivery->orderWeight = $Orders;			   
			
		}
		
		return $GetDeliveryUser;
	}
	
	//Order List
	
	public function UserOrderList(Request $Request){
		
		
		$UserId = Auth::guard('api')->user()->id;
		$page_number = $Request->page_number;
		
		if($page_number == ''){
			
			$response['error']="true";
        $response['error_message']="Mandatory parameters are missing";
	
		echo json_encode($response);
		die;
		}
		
		if($page_number == '0')
         {
         $page_number = '0';
             
         }else{
             $page_number = $page_number - 1;
         
         }
		  $page_offset=($page_number * 10);
		 
		
		$checkStatus = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','pickupDeliveryUserId','addressId','bookingDate','quantity','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','ConfirmOrder','WaytoPickup','OrderConfirmDate','WaytoPickupDate','PickupSuccess','PickupSuccessDate','WaytoDelivery','DeliveryDate','DeliverySuccess','DeliverySuccessDate','StartJob','totalPayment','paidStatus','paymentType')
		                         ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
			                     ->whereIn('Bookings.Status', ['CONFIRMED'])
								 ->Where('userId',$UserId)
								 ->orderBy('Bookings.id', 'DESC')
								 ->offset($page_offset)
								 ->limit(10)
								 ->get();
								 				 
		foreach($checkStatus as $BoookingStatus){
			$BoookingStatus -> description = "Your clothes will be picked up shortly";
			if($BoookingStatus->WaytoPickup == 1){
				$BoookingStatus -> description = "On the way to pickup your clothes";
				$BoookingStatus->Status='ON THE WAY';
			}
			
			if($BoookingStatus->PickupSuccess == 1){
				
				$BoookingStatus->Status='PICKUP SUCCESS';
				$BoookingStatus -> description = "Will get back earliest, once steam clothes are done";
			}
			
			if($BoookingStatus->WaytoDelivery == 1){
				$BoookingStatus -> description = "On the way to delivery your clothes";
				$BoookingStatus->Status='ON THE WAY';
			}
			
			if($BoookingStatus->Status == 'COMPLETED'){
				
				$BoookingStatus->Status='COMPLETED';
			}
			
			if($BoookingStatus->quantity == null){
				$BoookingStatus->quantity = "";
			}
			
			
			
			if($BoookingStatus->StartJob == 1 || $BoookingStatus->StartJob == 2){
				
				$BoookingStatus->CanCancel = 'No';
			}else{
				
				$BoookingStatus->CanCancel = 'Yes';
			}
			
			$BoookingStatus->TimeSlot=$BoookingStatus->fromSlots. " - ". $BoookingStatus->toSlots;
			
			$DeliveryUser = pickupdeliveryuser::Select('id','name','mobile','image')
                           ->Where(['id' => $BoookingStatus->pickupDeliveryUserId])
                           ->first();
			$DeliveryUser->mobile="+91".$DeliveryUser->mobile;			   
			if($DeliveryUser->image == null){
				
				$DeliveryUser->image = "";
			}
						   
			$BoookingStatus -> DeliveryUser = $DeliveryUser;			   
			
		   	 
			
           $GetStatus = DB::table('OrderStatus')->Select('id','name')->get();
		   
		   
		   foreach($GetStatus as $Check){

          	  // if($BoookingStatus->CancelStatus == 'Cancel'){

                 // $GetStatus[1]->CancelStatus = "yes";
			  // }			  
		   
		   if($BoookingStatus->ConfirmOrder == 1){

				 $GetStatus[0]->Status = 'Yes';
			     $GetStatus[0]->statusdate = $BoookingStatus->OrderConfirmDate;

		   }

		   if($BoookingStatus->WaytoPickup == 1){

				   $GetStatus[1]->Status = 'Yes';
				   $GetStatus[1]->statusdate = $BoookingStatus->WaytoPickupDate;
			   
		   }
		   
		   
		   
		   if($BoookingStatus->PickupSuccess == 1){

			   $GetStatus[2]->Status = 'Yes';
			   $GetStatus[2]->statusdate = $BoookingStatus->PickupSuccessDate;
			 
		   }
		   
		   
		   if($BoookingStatus->WaytoDelivery == 1){
			   
			   $GetStatus[3]->Status = 'Yes';
			   $GetStatus[3]->statusdate = $BoookingStatus->DeliveryDate;
		   }
		
		   
		   if($BoookingStatus->DeliverySuccess == 1){
			   
			   $GetStatus[4]->Status = 'Yes';
			   $GetStatus[4]->statusdate = $BoookingStatus->DeliverySuccessDate;
		   }

		   
		   }
		   $BoookingStatus->OrderStatus =$GetStatus;
		   $BoookingStatus->paidStatus =1;
		}

		//page Count
        $checkStatusCount = Bookings::Select('Bookings.id','Bookings.userId','pickupDeliveryUserId','addressId','bookingDate','quantity','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','ConfirmOrder','WaytoPickup','OrderConfirmDate','WaytoPickupDate','PickupSuccess','PickupSuccessDate','WaytoDelivery','DeliveryDate','DeliverySuccess','DeliverySuccessDate','StartJob')
		                         ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
			                     ->whereIn('Bookings.Status', ['CONFIRMED'])
								 ->Where('userId',$UserId)
								 ->orderBy('Bookings.id', 'DESC')
								 ->get();

         $total = count($checkStatusCount)/10;  
         $NumOfPage = ceil($total);		
		
			//die;							 
	    if(count($checkStatus) > 0 ){
			
			$response['error']="false";
			$response['Pages']=$NumOfPage;
            $response['BookingList']=$checkStatus;
			
	      }else{
		
		    $response['error']="true";
            $response['error_message']="No Booking Order Avaliable";
	    }
		echo json_encode($response);
		
	}
	
	//Booking History
	public function BookingHistory(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		$page_number = $Request->page_number;
		
		if($page_number == ''){
			
			$response['error']="true";
            $response['error_message']="Mandatory parameters are missing";
	
			echo json_encode($response);
			die;
		}
		
		if($page_number == '0')
         {
         $page_number = '0';
             
         }else{
             $page_number = $page_number - 1;
         
         }
		  $page_offset=($page_number * 10);
		
		$checkStatus = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','pickupDeliveryUserId','addressId','bookingDate','quantity','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','ConfirmOrder','WaytoPickup','OrderConfirmDate','WaytoPickupDate','PickupSuccess','PickupSuccessDate','WaytoDelivery','DeliveryDate','DeliverySuccess','DeliverySuccessDate','CancelDate','StartJob','paidStatus','paymentType')
		                         ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
			                     //->where('Status','Cancelled')
								 ->whereIn('Bookings.Status', ['CANCELLED','COMPLETED'])
								 ->Where('userId',$UserId)
								 ->orderBy('Bookings.updated_at', 'DESC') 
								 ->offset($page_offset)
								 ->limit(10)
								 ->get();
		foreach($checkStatus as $BoookingStatus){
			
			//echo $BoookingStatus->Status;
			
			
			if($BoookingStatus->StartJob == 1){
				
				$BoookingStatus->CanCancel = 'No';
			}else{
				
				$BoookingStatus->CanCancel = 'Yes';
			}

			if($BoookingStatus->WaytoPickup == 1){
				
				$BoookingStatus->Status='ON THE WAY';
			}
			
			if($BoookingStatus->PickupSuccess == 1){
				
				$BoookingStatus->Status='PICKUP SUCCESS';
			}
			
			if($BoookingStatus->WaytoDelivery == 1){
				
				$BoookingStatus->Status='ON THE WAY';
			}
			
			if($BoookingStatus->Status== 'ON THE WAY'){
				
				$BoookingStatus->Status='COMPLETED';
				$BoookingStatus->description = "Thank you! we are here to help again";
				
			}
			
			
			if(!empty($BoookingStatus->CancelDate)){
				
				$BoookingStatus->Status='CANCELLED';
			}
			
			if($BoookingStatus->Status== 'CANCELLED'){
				 $BoookingStatus->description = "Thank you! we are here to help again";
			}
			
			if($BoookingStatus->quantity == null){
				$BoookingStatus->quantity = "";
			}
			
		   $BoookingStatus->TimeSlot=$BoookingStatus->fromSlots. " - ". $BoookingStatus->toSlots;	 
		   

           $GetStatus = DB::table('OrderStatus')->Select('id','name')->get();
		   
		   
		   foreach($GetStatus as $Check){

            	   
		   
		   if($BoookingStatus->ConfirmOrder == 1){  
			   
			   $GetStatus[0]->Status = 'Yes';
			   
			   $GetStatus[0]->statusdate = $BoookingStatus->OrderConfirmDate;
		   }
		   
		   if($BoookingStatus->WaytoPickup == 1){
			   
			   $GetStatus[1]->Status = 'Yes';
			   $GetStatus[1]->statusdate = $BoookingStatus->WaytoPickupDate;
		   }
		   if($BoookingStatus->PickupSuccess == 1){
			   
			   $GetStatus[2]->Status = 'Yes';
			   $GetStatus[2]->statusdate = $BoookingStatus->PickupSuccessDate;
		   }
		   if($BoookingStatus->WaytoDelivery == 1){
			   
			   $GetStatus[3]->Status = 'Yes';
			   $GetStatus[3]->statusdate = $BoookingStatus->DeliveryDate;
		   }
		
		   
		   if($BoookingStatus->DeliverySuccess == 1){
			   
			   $GetStatus[4]->Status = 'Yes';
			   $GetStatus[4]->statusdate = $BoookingStatus->DeliverySuccessDate;
		   }
		   
		   //PickupSuccess
		   
		   }
		   $BoookingStatus->OrderStatus =$GetStatus;
		}		
			//die;	

        $checkStatusCount = Bookings::Select('Bookings.id','Bookings.userId','pickupDeliveryUserId','addressId','bookingDate','quantity','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','ConfirmOrder','WaytoPickup','OrderConfirmDate','WaytoPickupDate','PickupSuccess','PickupSuccessDate','WaytoDelivery','DeliveryDate','DeliverySuccess','DeliverySuccessDate','CancelDate','StartJob')
		                         ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
			                     //->where('Status','Cancelled')
								 ->whereIn('Bookings.Status', ['CANCELLED','COMPLETED'])
								 ->Where('userId',$UserId)
								 ->orderBy('Bookings.id', 'DESC')
								 ->get();
		$total = count($checkStatusCount)/10;  
         $NumOfPage = ceil($total);						 
			
	    if(count($checkStatus) > 0 ){
			
			$response['error']="false";
			$response['pages']=$NumOfPage;
            $response['BookingList']=$checkStatus;
			
	      }else{
		
		    $response['error']="true";
            $response['error_message']="No Booking Order Avaliable";
	    }
		echo json_encode($response);
	}
	
	//View Order List
	public function ViewItems(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		$bookingId = $Request->bookingId;
		
		
		if($bookingId){
			
	   	$CheckBook = Bookings::Select('id')->Where('id',$bookingId)->count();
		
		if($CheckBook > 0){
			
		  // $current_date =  date("Y-m-d"); 
		  // $user_package = DB::table('user_packages')->Select('user_packages.id','end_date','balance_amount','balance_clothes','packages.categoryId')
		                                 // ->join('packages','packages.id','=','user_packages.packageId')
		                                 // ->where('balance_clothes', '!=' , 0)
										 // ->where('balance_amount', '!=' , 0)
		                                 // ->Where(['user_packages.userId'=>$UserId])
										 // ->where('user_packages.end_date','>=',$current_date)
										 // ->get();
										 
		// echo json_encode($user_package);die;							 
		
          $GetPackage = DB::table('package_items')->Select('package_items.id','package_items.bookingId','package_items.quantity','maincategotyId','categoryId','CategoryList.price')
		                         ->join('CategoryList','CategoryList.id','=','package_items.maincategotyId')
		                         ->Where(['bookingId'=>$bookingId])
		                         ->get(); 
           // echo json_encode($GetPackage);die;
		   
		   $cate_1 [] = 0;
		   $cate_2 [] = 0;
		   if(count($GetPackage) > 0){
			   
			  $Is_package = 1; 
		   
           foreach($GetPackage as $pack){

               if($pack->maincategotyId == 1){
				   
				   $cate_1 [] = $pack->quantity * $pack->price;
			   }
			   
			   if($pack->maincategotyId == 2){
				   
				   $cate_2 [] = $pack->quantity * $pack->price;
			   }
		   }	

		     $sum = array_sum($cate_1) + array_sum($cate_2);
		   }else{

		      $Is_package = 0;
			  $sum = 0;

		   }		   
		  
		  
		  
		  // echo json_encode($sum);die;
		
			
		$GetUser = Bookings::Select('Bookings.id','Bookings.userId','Bookings.bookingTimeSlot','Bookings.quantity','totalPayment','taxamount','promode_code','promocode.promocode','discount_amount')
                             ->leftjoin('promocode','promocode.id', '=', 'Bookings.promode_code')
                             //->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							 ->Where(['Bookings.id'=>$bookingId])
                             ->first();							 		 
 		 if($GetUser->promocode == null){
			 $GetUser->promocode = "";
		 }
		$GetOrder = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.Price','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
								  // ->where('CategoryList.id', '!=', $cate)
		                          ->Where(['Booking_Items.bookingId' => $bookingId])
								  ->get();
				
      // echo json_encode($GetOrder);die;    				
			foreach($GetOrder as $Amt){
                 
               $priceamt = $Amt->Price;
               $Amt -> amount = "Rs.".$priceamt * $Amt->quantity; 
			   $Amt -> Price = "Rs.".$priceamt;
			   
			   $sum_amt [] = $priceamt * $Amt->quantity;
			}

			 // echo array_sum($sum_amt);
             // echo json_encode($sum_amt);
			 // die;

			 

			if(count($GetOrder) > 0){
			
            if(count($GetUser) > 0){

			   $grand = $GetUser->totalPayment+$GetUser->discount_amount;
			   
			   if($GetUser->discount_amount == 0){
				   $discount = "";
			   }else{
				   $discount = "Rs.".$GetUser->discount_amount;
			   }
			   
			   $final_total = $grand - $sum;
			   
			  $response['error']="false";
			  $response['id']=$GetUser->id;
			  $response['userId']=$GetUser->userId;
			  $response['bookingTimeSlot']=$GetUser->bookingTimeSlot;
			  $response['quantity']=$GetUser->quantity;
			  $response['promode_code']=$GetUser->promode_code;
			  $response['promocode']=$GetUser->promocode;
			  $response['Is_package']=$Is_package;
			  $response['grand_total']="Rs.".$GetUser->totalPayment;
			  $response['packages_total']="Rs.".$sum;
			  $response['discount_amount']=$discount;
			  $response['totalPayment']="Rs.".$grand;
			  $response['final_total']="Rs.".$final_total;
			  $response['taxamount']="Rs.".round($GetUser->taxamount, 2);
              $response['BookingItems']=$GetOrder;
                 

			 }else{

              $response['error']="true";
              $response['error_message']="Invalid bookingId";
			}	
			}else{

               $response['error']="true";
              $response['error_message']="No Items Available";
			}			
		
		}else{
			
			$response['error']="true";
              $response['error_message']="Invalid bookingId";
		}
		 }else{
			
			$response['error']="true";
            $response['error_message']="BookingId missing";
			
		}
		echo json_encode($response);
		
	}
	
	//Order Cancel
	public  function OrderCancel(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		$bookingId = $Request->bookingId;
		$reasonId = $Request->reasonId;
		
		if($bookingId && $reasonId){
			
			$checkId = Bookings::Where('id',$bookingId)->count();
			
			if($checkId > 0){
				
				date_default_timezone_set('Asia/Kolkata');
		        $canceldate =  date("Y-m-d H:i:s", time());
				
				$checkStatus = Bookings::Where('id',$bookingId)
			                             ->whereIn('Status', ['CONFIRMED'])->first();
				if(count($checkStatus) > 0){
				
				$cancel = "CANCELLED";

                $updateStatus  = Bookings::Where('id',$bookingId)->update(['Status' => $cancel,'CancelDate'=>$canceldate, 'cancelReason' =>$reasonId]);
				
				$user_data = User::Select('id','mobile','deviceToken','os')->Where('id',$UserId)->first();
				
				$title = 'Cancellation';
				$body = 'As per your request, booking ID '.$checkStatus->bookingId.' has been cancelled. For any future support, contact us on 9090903456 or visit our website www.ironbo.co.in.';
				
				$message = 'As per your request, booking ID '.$checkStatus->bookingId.' has been cancelled. For any future support, contact us on 9090903456 or visit our website www.ironbo.co.in.';
				$mobile = $user_data->mobile;
				$CommonFunction = new CommonFunctions();			
		        $newresponse = $CommonFunction->SentOtp($mobile,$message);
				$token = $user_data->deviceToken;
				$os = $user_data->os;
				 $fcm = new PushNotifications();
				 $arraydata = array("BookingId"=>"","message"=>$body,"deliverystatus"=>"");
	             $newresponse = $fcm->SentPush($title,$body,$token,$os,$arraydata);
 
                $response['error']="false";
                $response['error_message']="Order Cancelled Successfully"; 
					
				}else{
					$response['error']="true";
                    $response['error_message']="Order could not be cancel";
				}
				
			}else{
				
				$response['error']="true";
                $response['error_message']="Invalid BookingId";	
			}
			
		}else{
			$response['error']="true";
            $response['error_message']="Mandatory parameters are missing";	
		}
		echo json_encode($response);
	}
	
	
	
	
	//CustomerSupport
	public function CustomerSupport(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		if($Request->Comments){
		$Support = CustomerSupport::insert([
		               'UserId' => $UserId,
					   'Comments' => $Request->Comments
					]);
					
         $response['error']="false";
         $response['error_message']="Customer support added successfully";	
		 
		}else{

        $response['error']="true";
            $response['error_message']="Mandatory parameters are missing";

		}		 

        echo json_encode($response);		 
	}
	
	//Cancel reason
	public function CancelReason(Request $Request){
		$UserId = Auth::guard('api')->user()->id;
		
		$Reason =  DB::table('CancelReason')->get();
		
		$response['error']="false";
		$response['response']=$Reason;
		echo json_encode($response);
	}
	
	//User Rating
	public function Rating(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
	
		
		$PickupRate = $Request->PickupRate;
		$ServiceRate = $Request->ServiceRate;
		$DeliveryRate = $Request->DeliveryRate;
		$Comments = $Request->Comments;
		$bookingId = $Request->bookingId;
		
		if($PickupRate && $ServiceRate && $DeliveryRate && $UserId && $bookingId){
			
			$Rating = DB::table('UserRating')->insert([
						   'userId' => $UserId,
						   'bookingId' => $bookingId,
						   'forPickup' => $PickupRate,
						   'forService' => $ServiceRate,
						   'forDelivery' => $DeliveryRate,
						   'comments' => $Comments,
			                ]);
			
			$response['error']="false";
			$response['error_message']="Rating successfully";
			
		  }else{
			
			$response['error']="true";
			$response['error_message']="Mandatory parameters are missing";	
			
		}
		
		echo json_encode($response);
	}
	
	
	
	
	//Get Wallet amount
	public function WalletAmount(Request $Request){
		$UserId = Auth::guard('api')->user()->id;

		
		$UserDetails = User::Select('id','name','wallet_amount')->where('id',$UserId)->first();
		
		$response['error']="false";
	    $response['wallet_amount']=$UserDetails->wallet_amount;
		echo json_encode($response);
	}
	
	//Wallet transactionId
	public function WalletTransaction(Request $Request){ 
		
		$UserId = Auth::guard('api')->user()->id;
		
		$type = $Request->type;
		
		if($type){
			
			if($type == 'All'){
				
			$GetAll = WalletTransaction::Select('wallet_transaction.id','wallet_transaction.bookingId','Bookings.bookingId as book_id','wallet_transaction.orderId','transactionId','bank_name','wallet_transaction.amount','transation_status','type','createdAt') 
			                             ->leftjoin('Bookings','Bookings.id','=','wallet_transaction.bookingId')
			                             ->Where('wallet_transaction.userId',$UserId)
										 ->orderBy('wallet_transaction.id', 'DESC')
										 ->get();
			 
			 foreach($GetAll as $Pay){
				 
				 $Pay->amount = number_format((float)$Pay->amount, 2, '.', '');;
				 if($Pay->book_id == null){
					 $Pay->book_id="";
				 }
			 }
			 
			 if(count($GetAll) > 0){
				$response['error']="false";
				$response['response']=$GetAll;
			 }else{
				 
				 $response['error']="true";
			     $response['error_message']="No transation available";
			 }
			
			}else if($type == 'Credit'){
				
				$GetCredit = WalletTransaction::Select('id','orderId','bank_name','transactionId','amount','transation_status','type','createdAt')
				                                ->Where(['userId'=>$UserId,'type'=>'Credit'])
												->orderBy('id', 'DESC')
												->get();
				if(count($GetCredit) > 0){
				$response['error']="false";
				$response['response']=$GetCredit;
			 }else{
				 
				 $response['error']="true";
			     $response['error_message']="No transation available";
			 }
			}else if($type == 'Debit'){
				
				$GetDebit = WalletTransaction::Select('wallet_transaction.id','wallet_transaction.bookingId','Bookings.bookingId as book_id','wallet_transaction.orderId','bank_name','transactionId','wallet_transaction.amount','transation_status','type','createdAt')  
				                                ->leftjoin('Bookings','Bookings.id','=','wallet_transaction.bookingId')
				                                ->Where(['wallet_transaction.userId'=>$UserId,'wallet_transaction.type'=>'Debit'])
												->orderBy('wallet_transaction.id', 'DESC')
												->get();
												
		         foreach($GetDebit as $Card){
              
                   $Card->amount = number_format((float)$Card->amount, 2, '.', '');;
				 }				 
				if(count($GetDebit) > 0){
				$response['error']="false";
				$response['response']=$GetDebit;
				}else{
				 
				 $response['error']="true";
			     $response['error_message']="No transation available";
			 }
				
			}else{
				
				$response['error']="true";
			     $response['error_message']="Invalid type";
			}
			
		}else{
			
			$response['error']="true";
			$response['error_message']="Mandatory parameters are missing";
		}
		echo json_encode($response);
	}
	
	
	
    //Card payment
	public function CardPayment(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		$orderId = $Request->orderId;
		$transactionId = $Request->transactionId;
		$tnx_date = $Request->tnx_date;
		$amount = $Request->txn_amount;
		$tnx_status = $Request->tnx_status;
		$check_sum = $Request->check_sum;
		$payment_mode = $Request->payment_mode;
		$bank_name = $Request->bank_name;
		$bank_tnx_id = $Request->bank_tnx_id;
		$status_code =$Request->status_code;
		$bookingId =$Request->bookingId;


		if($transactionId && $orderId && $amount && $tnx_status && $check_sum && $payment_mode && $status_code){ 
		
		   $CheckUser = Bookings::Select('id','userId')->Where(['id'=>$bookingId,'userId'=>$UserId])->count();
		   
		   if($CheckUser == 1){
			   
			   $Check_booking = Transaction::Select('id','userId','bookingId')
			                               ->Where(['userId'=>$UserId,'bookingId'=>$bookingId])
										   ->count();
			   if($Check_booking == 0){
			   
			   $update = Bookings::Select('id','paidStatus')->Where('id',$bookingId)->update(['paidStatus'=>1]);
			   date_default_timezone_set('Asia/Kolkata');
			   $payment_date =  date("Y-m-d H:i:s", time());
			   
			   $Transaction = Transaction::insert([
			                           'userId'=>$UserId,
									   'bookingId'=>$bookingId,
									   'orderId'=>$orderId,
									   'transactionId'=>$transactionId,
									   'transation_status'=>$tnx_status,
									   'amount'=>$amount,
									   'check_sum'=>$check_sum,
									   'payment_mode'=>$payment_mode,
									   'bank_name'=>$bank_name,
									   'bank_tnx_id'=>$bank_tnx_id,
									   'status_code'=>$status_code,
									   'payment_date'=>$payment_date
			                       ]);
			   
			    $get_bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.quantity','totalPayment','payment_transaction.payment_date')
				                             ->join('payment_transaction','payment_transaction.bookingId','=','Bookings.id')
				                             ->Where(['Bookings.id'=>$bookingId])
											 ->orderBy('payment_transaction.id', 'DESC')
											 ->first();							 
			   $response['error']="false";
			   $response['error_message']="Payment done successfully";
			   $response['bookings']=$get_bookings;
		     }else{
			   
			   $response['error']="true";
			$response['error_message']="Already Paid";
		     }
			   
		    }else{
			$response['error']="true";
			$response['error_message']="Invalid Id";
		   }
		  
		   
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
		}
		
		
		echo json_encode($response);
	}
	
	//Add Wallet amount
	public function AddWallet(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		$orderId = $Request->orderId;
		$transactionId = $Request->transactionId;
		$tnx_date = $Request->tnx_date;
		$wall_amount = $Request->txn_amount;
		$tnx_status = $Request->tnx_status;
		$check_sum = $Request->check_sum;
		$payment_mode = $Request->payment_mode;
		$bank_name = $Request->bank_name;
		$bank_tnx_id = $Request->bank_tnx_id;
		$status_code =$Request->status_code;
		$offer_code =$Request->offer_code;
		
		// $jsondecode =  json_decode($transactionId, TRUE);
		   
		// $decode  = json_decode($jsondecode);

		if($transactionId && $orderId && $wall_amount && $tnx_status && $check_sum && $payment_mode && $status_code){ 
		
		
		
			
		if($tnx_status == 'TXN_SUCCESS'){
			
		$CheckUser = User::Select('id','wallet_amount')->Where('id',$UserId)->first();
		
		date_default_timezone_set('Asia/Kolkata');
	    $payment_date =  date("Y-m-d H:i:s", time());
		
		if($offer_code  == ''){
			
			$OldAmount = $CheckUser->wallet_amount;
			$UpdateAmount = $OldAmount+round($wall_amount, 2);
			
			$Addwallet  = WalletTransaction::insert([
			                           'userId'=>$UserId,
									   'orderId'=>$orderId,
									   'transactionId'=>$transactionId,
									   'transation_status'=>$tnx_status,
									   'amount'=>round($wall_amount, 2),
									   'check_sum'=>$check_sum,
									   'payment_mode'=>$payment_mode,
									   'bank_name'=>$bank_name,
									   'bank_tnx_id'=>$bank_tnx_id,
									   'status_code'=>$status_code,
									   'type'=>'credit',
									   'payment_date'=>$payment_date
			                       ]);
			$UpdateWallet =User::Select('id','wallet_amount')->Where(['id'=>$UserId])->update(['wallet_amount'=>$UpdateAmount]);
			
			$response['error']="false";				   
			$response['error_message']="Wallet amount Added";
			
		}else{
			
		//check promocode already used or not
		$get_promode =Promocode::Select('id','promocode','discount','offer_type')
		                         ->Where(['promocode'=>$offer_code,'offer_type'=>'Wallet'])
								 ->first();	 
		 
	    if(count($get_promode) == 1){
		
		 
		 $check_promocode = UserPromocode::Select('id','userId')
		                        ->Where(['userId'=>$UserId,'promocodeId'=>$get_promode->id])->first();
		
		 
		 if(count($check_promocode) == 1){ 
			 
			$response['error']="true";
            $response['error_message']="Already used that promocode";
            echo json_encode($response);			
			die;
		 }
		 
		}else{
			
			$response['error']="true";
            $response['error_message']="Invalid offer code";
            echo json_encode($response);			
			die;
			
		}	
		// Add wallet and promotional offers
		
		//echo $get_promode->discount;
		
		$amount = $wall_amount * ($get_promode->discount/100);
		
		$percent_amt = $amount+$wall_amount;
		
		$OldAmount = $CheckUser->wallet_amount;
		
		$UpdateAmount = $OldAmount+round($percent_amt, 2);

		$UpdateWallet =User::Select('id','wallet_amount')->Where(['id'=>$UserId])->update(['wallet_amount'=>$UpdateAmount]);
		
		
	
			
			$Addwallet  = WalletTransaction::insert([
			                           'userId'=>$UserId,
									   'orderId'=>$orderId,
									   'transactionId'=>$transactionId,
									   'transation_status'=>$tnx_status,
									   'amount'=>round($wall_amount, 2),
									   'check_sum'=>$check_sum,
									   'payment_mode'=>$payment_mode,
									   'bank_name'=>$bank_name,
									   'bank_tnx_id'=>$bank_tnx_id,
									   'status_code'=>$status_code,
									   'type'=>'credit',
									   'payment_date'=>$payment_date
			                       ]);
								   
		   $txId = $this->GenerateTxID();
           $orderId_1 = 'ORD'.mt_rand(100000000, 999999999);								
		   $FromTransaction = WalletTransaction::insert([
			                           'userId'=>$UserId,									   
									   'orderId'=>$orderId_1,
									   'transactionId'=>$txId,
									   'amount'=>round($amount, 2),
									   'transation_status'=>'TXN_SUCCESS',
									   'bank_name'=>'Promotional offers',
									   'offer_code'=>$get_promode->id,
									   'type'=>'credit',
									   'payment_date'=>$payment_date
								]);						   
			$add_promo_code = DB::table('user_promocode')->insert(['userId'=>$UserId,'promocodeId'=>$get_promode->id]);					   
			$response['error']="false";				   
			$response['error_message']="Wallet amount Added";
		}

		}else{

            $response['error']="true";				   
			$response['error_message']="Transaction failed";
		}		
			
		 }else{
			
			$response['error']="true";
			$response['error_message']="Mandatory parameters are missing";
		}
		
		echo json_encode($response);
	}
	
	//Wallet payment
	public function WalletPayment(Request $Request){
		
		
		$UserId = Auth::guard('api')->user()->id;
		
		$wallet_amount = Auth::guard('api')->user()->wallet_amount;
		//echo $wallet_amount;die;
		$bookingId = $Request->bookingId;
		$pay = $Request->amount;
		
		if($bookingId && $pay){
			
			if($wallet_amount == 0){
				
				$response['error']="true";
				$response['error_message']="Insufficient balance";
				
				echo json_encode($response);
				die;
			}
			
			$CheckUser = Bookings::Select('id','userId')->Where(['id'=>$bookingId,'userId'=>$UserId])->count();
			
			if($CheckUser == 1){
				
				$wtam = 200;
				
				//if($wallet_amount >= 150){  
				//if($wallet_amount == 0){  
					
					//$pay  = 150;
					$txId = $this->GenerateTxID();
					date_default_timezone_set('Asia/Kolkata');
			          $payment_date =  date("Y-m-d H:i:s", time());
					  $orderId = 'ORD'.mt_rand(100000000, 999999999);
					$check_transaction = Bookings::Where(['id'=>$bookingId,'paidStatus'=>1])->count();
					if($check_transaction == 0){
					
					if($wallet_amount >= $pay){
                      
					  //echo "hii";die;
						$sum1 = $wallet_amount - $pay;
				
                      
			   
                      $Transaction = WalletTransaction::insert([
				                       'bookingId'=>$bookingId,
			                           'userId'=>$UserId,									   
									   'orderId'=>$orderId,
									   'transactionId'=>$txId,
									   'amount'=>$pay,
									   'transation_status'=>'TXN_SUCCESS',
									   'type'=>'Debit',
									   'payment_date'=>$payment_date
									   

								]);									   
						//echo $sum1;
						
					  $update_booking = Bookings::Select('id','paidStatus')->Where(['id'=>$bookingId])
					                              ->update(['paidStatus'=>1,'balance_amt'=>0]);
					  $update_wallet = User::Select('id','wallet_amount')->Where('id',$UserId)->update(['wallet_amount'=>$sum1]);
					  
					  $get_bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.quantity','totalPayment','wallet_transaction.payment_date')
				                             ->join('wallet_transaction','wallet_transaction.bookingId','=','Bookings.id')
				                             ->Where(['Bookings.id'=>$bookingId])
											 ->orderBy('wallet_transaction.id', 'DESC')
											 ->first();
					  
					  $response['error']="false";
					  $response['error_message']="Payment done successfully";
					  $response['bookings']=$get_bookings;
					  
						
					 }else{
						 
						 //echo "bye";die;
						
						$sum2 = $wallet_amount - $pay;
						
						$balance = abs($sum2);
						
						$paid = $pay - $balance;
						
						//echo $wallet_amount;die;
						
						$Transaction = WalletTransaction::insert([
				                       'bookingId'=>$bookingId,
			                           'userId'=>$UserId,									   
									   'orderId'=>$orderId,
									   'transactionId'=>$txId,
									   'amount'=>$paid,
									   'transation_status'=>'TXN_SUCCESS',
									   'type'=>'Debit',
									   'payment_date'=>$payment_date
									   

								]);
						
						
						$update_wallet = User::Select('id','wallet_amount')->Where('id',$UserId)->update(['wallet_amount'=>0]);
						
						$update_booking = Bookings::Select('id','paidStatus')->Where(['id'=>$bookingId])
					                              ->update(['paidStatus'=>0,'balance_amt'=>$balance]);
												  
						$get_bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.quantity','totalPayment','wallet_transaction.payment_date')
				                             ->join('wallet_transaction','wallet_transaction.bookingId','=','Bookings.id')
				                             ->Where(['Bookings.id'=>$bookingId])
											 ->orderBy('wallet_transaction.id', 'DESC')
											 ->first();
						
						//echo $sum2;
						$response['error']="false";
						$response['error_message']="Payment done successfully";
						$response['bookings']=$get_bookings;
					}
					
				}else{
					
					$response['error']="true";
					$response['error_message']="already paid";
				}
					
					// $sum = $wta - $pay;
					
					// echo abs($sum);
					
				// }else{
					
					// $response['error']="true";
					// $response['error_message']="Insufficient balance";
				// }
				
				
			 }else{
				
			   $response['error']="true";
			   $response['error_message']="Invalid Id";
			}
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Mandatory Parameters are Missing";
			
		}
		echo json_encode($response);
		
	}
	
	// Generate transactionId
	public function GenerateTxID(){
	 $code = "";
     $chars = "0987654321";
     $chars.= "0123456789";

    for ($i=0; $i < 25; $i++) {
        $code .= $chars[random_int(0, strlen($chars)-1)];
    }
	return $code;

	}
	
	//payment
    public function Payment(Request $Request){  
		$UserId = Auth::guard('api')->user()->id;
		
		
		date_default_timezone_set('Asia/Kolkata');
	    $current_date =  date("Y-m-d");
		
		//server date
	$paymentDate = '2018-06-11';
	
	$give_date = '2018-06-11';

    $bookDateBegin = '2018-06-11';
    $bookDateEnd = '2018-06-19';

	//server time
	$time  = '09:00:00';
	
	$time_1 = '10:00';//cur
	$time_2 = '09:00';
	
	$from_time = '09:00:00';
	$to_time = '17:00:00';
	
	 $get_slot = TimeSlots::Select('id','fromSlots')->Where('id',1)->first();
	 
    //if (($bookDateBegin >= $paymentDate) && ($bookDateEnd <= $paymentDate)) {
    if (($paymentDate >= $bookDateBegin) && ($paymentDate <= $bookDateEnd)) {
		
		if (($time >= $from_time) && ($time <= $to_time)) {
			
			if($current_date  ==  $give_date){
				
				if($time_1 < $time_2){
					
					echo "book";
				}else{
					
					echo "no";
				}
				
			 }else{
				
				echo "No";
			}
			
			//echo 'booking';
			
		}else{
			
			
			echo 'expriy';
		}
		
		
      //echo "is between";
	  
	  //echo $time = date("H:i:s");
    }
    else
    {
      echo "NO GO!";  
    }die;
		
		$exp_date = date('Y-m-d', strtotime($current_date. ' + 16 day'));
		
		if($exp_date > $current_date){
			
			echo 'hii';
		}
		
		die;
		
		$given_date = '2018-06-11';
		
		$book_date = date("Y-m-d", strtotime($given_date));
		
		
		if($book_date < $current_date){
			
			echo "hii";
		}
		
		// echo $exp_to;
		die;
		
		
		// $date = new DateTime();
// $match_date = new DateTime($timestamp);
// $interval = $date->diff($match_date);

// if($interval->days == 0) {

   // echo "hii";

// }die;
		
	    $payment_date =  date("Y-m-d");
		
		 $time = date("H:i:s");
		
		
		$from_time = "11:25:00";
		
		$to_time = "17:00:00";
		
		if($payment_date == $payment_date){
			
			
			if($to_time > $from_time){
				
				echo "not valid";
			}
			
		}die;
		
		// $date = date("d.m.Y H:i");
		// $timestamp = "2014.09.02T13:34";
        // $match_date = date('d.m.Y H:i', strtotime($timestamp));
		
		// if($date == $match_date) { 

			// echo "hii";

		// }
		die;
		
		$cate_list = DB::table('CategoryList')->Select('id','name','Price','Qty')->get();
		
		foreach($cate_list  as $list){
			
			$get_sub = DB::table('SubCategory')->Select('id','categoryId','name as SubCategoryName')->Where(['categoryId'=>$list->id])->get();
			
			$list->Category=$get_sub;
			
			 foreach($get_sub as $newcate){
				
				 $new = DB::table('NewCategories')->Select('name','image','groupName')
				                   ->Where(['groupName'=>$newcate->SubCategoryName])
								   ->get();
                  $newcate->arrSubCategory= $new;								   
			 }
			
		}


        echo $cate_list;
        die;		
		
		
		
		//echo $UserId;
		
		//date_default_timezone_set('Asia/Kolkata');
		        // $canceldate =  date("Y/m/d H:i:s", time());
				
				// echo $canceldate;
				
				// $test = 'Fri, 15 Jan 2016 15:14:10 +0800';
// $t = date('Y-m-d H:i:s',strtotime($test));
// echo $t;

              date_default_timezone_set('Asia/Kolkata');
		    //$time = date("H:i:s", strtotime("+15 minutes"));
		    $time = date("Y/m/d H:i:s");
			
			echo $time;
		
	}
	
	//Valid promocode
	
	public function ValidPromocode(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		$offer_code  = $Request->offer_code;
		
		if($offer_code){
			
			$check_promo = Promocode::Select('id','promocode')->Where('promocode',$offer_code)->first();
			
			//echo json_encode($check_promo);die;
			if(count($check_promo) == 1){
				
				$used_promocode = UserPromocode::Select('id','userId')
		                        ->Where(['userId'=>$UserId,'promocodeId'=>$check_promo->id])->first();
		
		 //echo json_encode($used_promocode);die;
				 if(count($used_promocode) == 1){ 
					 
					$response['error']="true";
					$response['error_message']="Already used that promocode";
					// echo json_encode($response);			
					// die;
				 }else{
					 
					 $response['error']="false";
					$response['error_message']="Promocode apply successful";
				 }
				
				
			}else{
				
				$response['error']="true";
                $response['error_message']="Invalid promocode";
			}
			
		}else{
			
			$response['error']="true";
            $response['error_message']="Promocode missing";
		}
		echo json_encode($response);
	}
	
	//User Promocode
	public function UserPromocode(Request $Request){
		$UserId = Auth::guard('api')->user()->id;
		
		
		//echo $UserId;die;
		
		$payment_type = $Request->payment_type;
		$offet_type = $Request->offet_type;
		
		if($offet_type == 'All'){
		
		$CheckPromocode = UserPromocode::Select('id','promocodeId','userId')->Where(['userId'=>$UserId])->get();
		//echo json_encode($CheckPromocode);die;
		if(count($CheckPromocode) == 0){
		$newcode = 0;
		}
		//$dt = Carbon::now();
	     $current_date =  date("Y-m-d"); 				 
		
		foreach($CheckPromocode as $Promocode){  
			
			$newcode [] = $Promocode->promocodeId;
		}
		
		// echo json_encode($newcode);die;
		
		$AllPromocode = Promocode::Select('promocode.id','promocode.promocode','expiry_from','expiry_to','promocode.offer_type','images','description')
		                           ->where('expiry_from','<=',$current_date)
								   ->where('expiry_to','>=',$current_date)
		                           ->where('promocode.id', '!=', $newcode)
		                           // ->whereNotIn('promocode.id', $newcode)
								   //->whereIn('payment_type',['All','0',$payment_type])
								   //->orWhere('payment_type',$payment_type)
								   //->orWhere('payment_type','All')
								   ->orWhere('no_expiry','Yes')
								   ->Where('promocode.status',1)
								   ->get();
								   
		foreach($AllPromocode as $Promo){
         
         if($Promo->expiry_from == null){		 
         $Promo->expiry_from = "";
		 }
 
         if($Promo->expiry_to == null){		 
         $Promo->expiry_to = "";
		 }
		 
		 $exp_from = date("d-m-Y", strtotime($Promo->expiry_from));
		 $exp_to = date("d-m-Y", strtotime($Promo->expiry_to));
		 $Promo->expiry_from =$exp_from;
		 $Promo->expiry_to =$exp_to;
		  
		  
		}		
			
		if(count($AllPromocode) > 0){
			
			$response['error']="false";
			$response['prmocode']=$AllPromocode;
		}else{
			
			$response['error']="true";
			$response['error_message']="No promocode available";
		}
		
	//offer type
	
	}elseif($offet_type == 'Wallet'){
		
		//echo "hii";
		$CheckPromocode = UserPromocode::Select('id','promocodeId','userId')->Where(['userId'=>$UserId])->get();
		// echo json_encode($CheckPromocode);die;
		if(count($CheckPromocode) == 0){
		$newcode = 0;
		}
	     $current_date =  date("Y-m-d"); 
				 
		
		foreach($CheckPromocode as $Promocode){  
			
			$newcode [] = $Promocode->promocodeId;
		}
		
		// echo json_encode($CheckPromocode);die;

		$AllPromocode = Promocode::Select('promocode.id','promocode.promocode','expiry_from','expiry_to','promocode.offer_type','images','description')
		                           ->where('expiry_from','<=',$current_date)
								   ->where('expiry_to','>=',$current_date)
								   // ->whereNotIn('promocode.id', $newcode)
		                           ->where('promocode.id', '!=', $newcode)
								   //->whereIn('payment_type',['All','0',$payment_type])
								   //->orWhere('payment_type',$payment_type)
								   //->orWhere('payment_type','All')
								   ->Where(['promocode.status'=>1,'offer_type'=>'Wallet'])
								   ->orWhere('no_expiry','Yes')
								   ->get();
								   //'promocode.status',1
		foreach($AllPromocode as $Promo){
         
         if($Promo->expiry_from == null){		 
         $Promo->expiry_from = "";
		 }
 
         if($Promo->expiry_to == null){		 
         $Promo->expiry_to = "";
		 }
		 
		 $exp_from = date("d-m-Y", strtotime($Promo->expiry_from));
		 $exp_to = date("d-m-Y", strtotime($Promo->expiry_to));
		 $Promo->expiry_from =$exp_from;
		 $Promo->expiry_to =$exp_to;
		  
		  
		}		
								   	
		if(count($AllPromocode) > 0){
			
			$response['error']="false";
			$response['prmocode']=$AllPromocode;
		}else{
			
			$response['error']="true";
			$response['error_message']="No promocode available";
		}
		//for booking promocode 
	}elseif($offet_type == 'Booking'){
		
		$CheckPromocode = UserPromocode::Select('id','promocodeId','userId')->Where(['userId'=>$UserId])->get();
		// echo json_encode($CheckPromocode);die;
		
		if(count($CheckPromocode) == 0){
		$newcode = 0;
		}
	     $current_date =  date("Y-m-d"); 
				 
		
		foreach($CheckPromocode as $Promocode){  
			
			$newcode [] = $Promocode->promocodeId;
		}

		$AllPromocode = Promocode::Select('promocode.id','promocode.promocode','offer_type','expiry_from','expiry_to','images','description')
		                           ->where('expiry_from','<=',$current_date)
								   ->where('expiry_to','>=',$current_date)
								   // ->whereNotIn('promocode.id', $newcode)
		                           ->where('promocode.id', '!=', $newcode)
								   //->whereIn('payment_type',['All','0',$payment_type])
								   //->orWhere('payment_type',$payment_type)
								   //->orWhere('payment_type','All')
								   ->Where(['promocode.status'=>1,'offer_type'=>'Booking'])
								   //->orWhere('no_expiry','Yes')
								   ->get();
								   //'promocode.status',1
		foreach($AllPromocode as $Promo){
         
         if($Promo->expiry_from == null){		 
         $Promo->expiry_from = "";
		 }
 
         if($Promo->expiry_to == null){		 
         $Promo->expiry_to = "";
		 }
		 
		 $exp_from = date("d-m-Y", strtotime($Promo->expiry_from));
		 $exp_to = date("d-m-Y", strtotime($Promo->expiry_to));
		 $Promo->expiry_from =$exp_from;
		 $Promo->expiry_to =$exp_to;
		  
		  
		}		
								   	
		if(count($AllPromocode) > 0){
			
			$response['error']="false";
			$response['prmocode']=$AllPromocode;
		}else{
			
			$response['error']="true";
			$response['error_message']="No promocode available";
		}
		
	}
		
		echo json_encode($response);
	}
	

	
	//ContentPages
	public function ContentPages(Request $Request){
			
			$terms  =  "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.";
			
			$privacy  =  "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
			
			
			 $about  =  "Ironbox provides steam ironing service via mobile bookings. Our service catalogue covers credible ironing service for every outfit, be it different in style or material. We have begun this company with a vision to continuously equip and create employment opportunities by building a business model that encompasses on-boarding trainees, service providers, managing quality control, and business analyst while at the same time providing standard service, experience and price to the customers.\n \n Ironbox brings quality ironing service to the customers. We have created a technology platform, a website and a mobile app which makes it convenient for the customers. We assure on time delivery and promising service. \n \n Our features \n - Pickup & Delivery\n- Expert professionals on board\n- Affordable\n- Timely delivery\n- Quality check control";
	
         	
		     
		    $response['error']='false';
			$response['Terms']=$terms;
			$response['Privacy']=$privacy;
			$response['About']=$about;  
			//$response['Our features']=$arrayList;  
		 
		 
			
		echo json_encode($response);
				
	}
	
	
	//Get OrderId
	public function GetOrderId(Request $Request){
		
		$orderId = 'ORD'.mt_rand(100000000, 999999999);
		
		$response['error']='false';
	    $response['orderId']=$orderId;
		echo json_encode($response);
		
		
	}
	
	//GenerateCheckSum
	public function GenerateCheckSum(Request $Request){
		
		$MID = $Request->MID;
		$ORDER_ID = $Request->ORDER_ID;
		$CUST_ID = $Request->CUST_ID;
		$INDUSTRY_TYPE_ID = $Request->INDUSTRY_TYPE_ID;
		$CHANNEL_ID = $Request->CHANNEL_ID;
		$WEBSITE = $Request->WEBSITE;
		$TXN_AMOUNT = $Request->TXN_AMOUNT;
		$CALLBACK_URL = $Request->CALLBACK_URL;
		
		
         if($MID && $ORDER_ID && $CUST_ID && $INDUSTRY_TYPE_ID && $CHANNEL_ID && $WEBSITE && $TXN_AMOUNT && $CALLBACK_URL){
		
		 try{
               $client = new \GuzzleHttp\Client();
               $res = $client->request('POST', 'http://139.59.37.241/paytm/generateChecksum.php', [
            'form_params' => [
                'MID' => $MID,
                'ORDER_ID' => $ORDER_ID,
                'CUST_ID' => $CUST_ID,
                'INDUSTRY_TYPE_ID' => $INDUSTRY_TYPE_ID,
                'CHANNEL_ID' =>$CHANNEL_ID,
                'TXN_AMOUNT' => $TXN_AMOUNT,
                'WEBSITE'=>$WEBSITE,
                'CALLBACK_URL'=>$CALLBACK_URL
            ]
        ]);

	} catch (\GuzzleHttp\Exception\BadResponseException $e) {
	$jsonresp=$e->getMessage();
	$response['error']='true';
	$response['message']='invalid';
	  echo json_encode($jsonresp); die;
			
			
		}
		
		$check_sum = json_decode((string) $res->getBody(), true)['CHECKSUMHASH'];
		
		 
		
		    $response['error']='false';
			$response['check_sum']=$check_sum;
			//$response['orderId']=$orderId;
			
		 }else{
			 
			 $response['error']='true';
			$response['error_message']='Invalid';
		 }
			
			echo json_encode($response);
		
	}
	
	//verify checksun
	public function VerifyChecksum(Request $Request){
		
		
		
		$MID = $Request->MID;
		$ORDER_ID = $Request->ORDER_ID;
		$CUST_ID = $Request->CUST_ID;
		$INDUSTRY_TYPE_ID = $Request->INDUSTRY_TYPE_ID;
		$CHANNEL_ID = $Request->CHANNEL_ID;
		$WEBSITE = $Request->WEBSITE;
		$TXN_AMOUNT = $Request->TXN_AMOUNT;
		$CALLBACK_URL = $Request->CALLBACK_URL;
		$CHECKSUMHASH = $Request->CHECKSUMHASH;
		
         if($MID && $ORDER_ID && $CUST_ID && $INDUSTRY_TYPE_ID && $CHANNEL_ID && $WEBSITE && $TXN_AMOUNT && $CALLBACK_URL && $CHECKSUMHASH){
		
		try{
               $client_mew = new \GuzzleHttp\Client();
               $res = $client_mew->request('POST', 'http://139.59.37.241/paytm/verifyChecksum.php', [
            'form_params' => [
			
			    'MID' => $MID,
                'ORDER_ID' => $ORDER_ID,
                'CUST_ID' => $CUST_ID,
                'INDUSTRY_TYPE_ID' => $INDUSTRY_TYPE_ID,
                'CHANNEL_ID' =>$CHANNEL_ID,
                'TXN_AMOUNT' =>$TXN_AMOUNT,
                'WEBSITE'=>$WEBSITE,
				'CHECKSUMHASH'=>$CHECKSUMHASH,
                'CALLBACK_URL'=>$CALLBACK_URL
            ]
        ]);

		} catch (\GuzzleHttp\Exception\BadResponseException $e) {
		$jsonresp=$e->getMessage();
		$response['error']='true';
		$response['message']='User Credentials are incorrect.';
		echo json_encode($jsonresp); die;
		}
		$checkvalue =  json_decode((string) $res->getBody(), true)['isValidChecksum'];
		
		    $response['error']='false';
			$response['error_message']=$checkvalue;
		 }else{
			 
			  $response['error']='true';
			$response['error_message']='Invalid';
		 }
		 
		echo json_encode($response);
		

	}
	
	
		//logout
	public function logout(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		
		$update=User::where('id',$UserId)->update(['deviceToken'=>" "]);
    
		if($update)
		{
			$response['error']='false';
			$response['error_message']='Logout Successfully.';
		}else{
			$response['error']='true';
			$response['error_message']='not logged out';
		}
		echo json_encode($response);
		
	}
	
/*******************************************************************/	
	
	public function CheckPush(Request $Request){
		
		$url = 'https://fcm.googleapis.com/fcm/send';
		
        $serverKey = "AAAANyqGCjU:APA91bGe1AVnwpkCnIZTgyDECSfv0bAOcQP1SPctw0fzfxutBHvJzfrVs963XkZ01AkNEbyH2fw7MFsM-ZSmJmj4G2U3dCCyUDQzSi4SRRh9OCfhiXKAc9G9NNmtHNX7c4scX10744wu";
		
		
		$headers = array(
            'Authorization: key=' . $serverKey,
            'Content-Type: application/json'
        );
		
		
		//$message = array("Message"=>"first push");
		
		$tokens = 'fhchDgaUYhw:APA91bH5XifmIIGsbvZL0EcDY7j3DO8_iax65cEXHMTpBCg60fNQM9CEDfJzNRov-Jgrh2Eyc6WLMuObsiXDjxS9My4BQV_4Ee4nJjfReP8EQzs6G-sHrkANhVqrFy052T-57qQJooUu';
		
		$messagedata = array(
	             "BookingId"=>'122',
				 "message"=>'push',
				 "DeliveryStatus"=>'0'
				 );
		//return $messagedata;die;
		
		// $msg['title'] = 'First push';
        // $msg['body'] = 'test';
        // $msg['icon'] = 'ic_launcher.png';

		
		
		$fields = array(
			 'to' => $tokens,
			 'message'=>'dijdi',
			 'data' => $messagedata,
			 'title'=>'First push',
			 'body'=>'test',
			 //'notification'=>$msg,
			 'content_available'=>true,
			 'icon'=>'ic_launcher.png',
			 'badge' => 1,
             'sound' => 'default'
			);
		
	   $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, $url);
       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);  
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
       $result = curl_exec($ch);           
       if ($result === FALSE) {
           die('Curl failed: ' . curl_error($ch));
       }
       curl_close($ch);
       return $result;	
	   
	}
	
	
	public function TestOpt(Request $Request){
		
		$UserId = Auth::guard('api')->user()->id;
		//echo $UserId;
		//die;
		


		
				$data     = array(
				'User' => 'rupeshkumar',
				'Password' => '12345'
			);
			// Send the POST request with cURL
			//$ch       = curl_init('http://websmsapp.in/api/mt/GetBalance?User=rupeshkumar&Password=12345');
			
			$mes2 = 'hii how are youuuu';
			
			$message  = rawurlencode($mes2);
			
			$ch       = curl_init('http://websmsapp.in/api/mt/SendSMS?User=Ironbox&Password=12345&senderid=IRONBX&channel=Trans&DCS=0&flashsms=0&number=919677965573&text='.$message.'&route=9');
			//curl_setopt($ch, CURLOPT_POST, true);
			//curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$response = curl_exec($ch);
			curl_close($ch);
			// Process your response here
            $new =  json_encode($response);
			
			echo json_decode($new);


		
		
		// {
    // "ErrorCode": "000",
    // "ErrorMessage": "Done",
    // "JobId": "1294823",
    // "MessageData": [
        // {
            // "Number": "919677965573",
            // "MessageId": "HC7MQZSSNUyUREAj1Z6eqA"
        // }
    // ]
// }
		
		
	}
	
	
	public function EmailCheck(Request $Request){
		
		
		// $array = array(
    // array("name"=>"abbas"),
    // array("name"=>"abbafgs"),
   
		
		
		$Email = "mohamedabbas289@gmail.com";
		$otp= "4444";
		
		//$data = array("Category"=>array(array('email'=>$Email,'otp'=>$otp))); echo json_encode($data['Category']->email);die;
		$data = array('email'=>$Email,'otp'=>$otp);
		
		//"Category"=>array(array("SubCategoryName"=>"Mens","arrSubCategory"=>$GetMens))
		
		
		//$a =  json_encode($data);
		
		// echo $a['Category'];
		// die;
		
		
		
		// $Items = DB::table('Bookings')->Select('id','quantity','PickupSuccessDate')->Where('id',1)->first();
		// $Items->PickupSuccessDate;
		// $time  = explode(" ",$Items->PickupSuccessDate);
		// print_r($time[1]);
		// die;
		// echo json_encode($Items);die;
		
		$Items = BookingItems::Select('Booking_Items.id','Booking_Items.bookingId','Booking_Items.quantity','Booking_Items.categoryId','NewCategories.name','NewCategories.image','CategoryList.Price','NewCategories.groupName')
		                          ->join('NewCategories','NewCategories.id', '=', 'Booking_Items.categoryId')
		                          ->join('CategoryList','CategoryList.id', '=', 'NewCategories.categoryId')
		                          ->Where(['Booking_Items.bookingId' => 1])
								  ->get();
	  // echo $Items;die;
		Mail::send([], [], function($message) use ($Email,$Items) {
            $message->from('mohamedabbas289@gmail.com');
            $message->to($Email);
            $message->subject('Your email and password');
			
			$mail = "<html lang='en'>
  <head>
	  <style>
		 .block{width: 230px;margin: 0 auto;padding: 12px;border:1px solid #000;}
		 .left{float:left;}
		 .top_head{display: inline-block;width:100%;}
		 .top_table{width:100%;}
		 .right{float:left;position:relative;left:100px}
		 .logo{float: left;}
		 .logo img{width:54px;height:50px;}
		 .addr{width:200px;}
		  p{padding:0; margin:0;}
		  h5,h3{padding:0; margin:0;}
		  .mr15{margin-top:15px;}
		  .border{border: 1px dashed #000; margin-top:15px;}
		  .pickup {text-align:center;}
		  tr.line td {border-top:1pt solid black;}
         .head_title p{text-align:center;font-weight:bold;}
	  </style>
  </head>
  <body>
	<div class='block'>
	<div class='top_head'>
	 <div class='head_title'>
	   <p>Invoice</p>
	 </div>
		 <div class='logo'>
			<img src='http://139.59.37.241/Ironman/public/images/ironbox.png'>
		 </div>
		 <div class='top_table'>
		   <table style='margin-left: 15%;'>
			  <tr>
				<td><strong>Ironbox</strong></td>
			  </tr>
			   <tr>
				<td>Unit of Zero degree south</td>
			  </tr>
			</table>
			</div>
		</div>
		<div class='mr15'>
		   <p><strong>Address :</strong></p>
		   <p class='addr'>40/156, Tirumurthy Nagar, Nungambakkam, Chennai, Tamil Nadu 600034, India</p>
		   <p><strong>GST : </strong>123456</p>
		</div>
		<hr class='border'>
		<div class='userdetails mr15'>
		 <p><strong>Name : Mohamed Abbas</strong></p>
		   <p><strong>Address :</strong></p>
		   <p class='addr'>40/156, Tirumurthy Nagar, Nungambakkam, Chennai, Tamil Nadu 600034, India</p>
		   <p><strong>Mob : </strong>9677965573</p>
		</div>
		
		<hr class='border'>
		
		<div class='pickup'>
		  <p><strong>Booking Id</strong> : 12:00</p>
		  <p><strong>Pickup Date</strong> : 12-09-2018</p>
		  <p><strong>Pickup Time</strong> : 12:00</p>
		  <p><strong>Total clothes</strong> : 1034</p>
		</div>
		
		<hr class='border'>
		<div class='uaddress'>
		   <h3>Address :</h3>
		   <p>40/156, Tirumurthy Nagar, Nungambakkam, Chennai</p>
		</div>
		<hr class='border'>
		
		<div class='clothes'>

		  <table style='width:100%'> ";
		   $mail .="
		    <tr>
			  <td><strong>Items</strong></td>
			  <td><strong>Qty</strong></td>
			  <td><strong>Total</strong></td>
			</tr>
		   ";
			foreach($Items as $item){
				$priceamt = $item->Price;
					$mail .= "<tr>
						<td>".$item->name."</td>
						<td>".$item->quantity."</td>
						<td>"."Rs.".$priceamt * $item->quantity."</td>
						</tr>
						";
			}
	 
		  $mail .="
			  <tr>
			  <td class='line' colspan='1'></td>
			  <td>Total</td>
			  <td>345</td>
			  </tr>
		</table>
		
		 <p class='tcenter'>Terms & Conditions applied and price inclusive of all GST taxes</p>
		</div>
	</div>
  </body>
</html>";
            $message->setBody(
			
			$mail
			   
			,'text/html');
        });
		
                     // Mail::send('mail', $data, function($message) use ($data){
                        // $message->to($data['email'], 'name')->subject
                           // ('Your email and password');
                        // $message->from('mohamedabbas289@gmail.com','');
                     // });
					 
					 echo"successfully";
					 //djfh
	}
	
	
	public function AdminFunction(Request $Request){
		
		//Highest Order Placed
		
		$Highest_order = DB::Select("Select service_area , Count(*) as value from Bookings Where Status='COMPLETED' GROUP BY service_area Order by value DESC");
		
		echo json_encode($Highest_order);
		
	}
	
	
	
	
	
	

}	