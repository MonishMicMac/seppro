<?php

namespace App\Http\Controllers\Api\v2;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\pickupdeliveryuser;
use App\Admin;
use App\ServiceAreas;
use App\Pincode;
use App\UserAddresses;
use App\TimeSlots;
use App\Categories;
use App\CategoryList;
use App\CommonFunctions;
use App\Bookings;
use App\Transaction;
use App\Promocode;
use App\UserPromocode;
use App\BookingItems;
use App\CustomerSupport;
use App\WalletTransaction;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Session;
use GuzzleHttp\Exception\BadResponseException;
use Guzzle\Http\Exception\ServerErrorResponseException;
use Mail;
use Auth;
use DateTime;
use Validator;
use DB;

class UserLoginController_1 extends Controller
{
	
	
	
	
	public function testapi(Request $Request){
		
		echo "hii";
		
	}
	
}


?>