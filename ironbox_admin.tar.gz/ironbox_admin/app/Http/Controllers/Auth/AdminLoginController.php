<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

class AdminLoginController extends Controller
{
  public function __construct(){
   $this->middleware('guest:admin')->except('logout');
  }

  public function showLoginForm(){
    return view('auth.admin-login');
  }

public function login(Request $request){
  $email = $request->input('email');
  $password = $request->input('password');

  if(Auth::guard('admin')->attempt(array('email' => $email, 'password' => $password))){

    return redirect()->intended(route('admin.dashboard'));
     }else{
        return redirect()->intended(route('admin.login'));
     }

    //return redirect()->back()->withInput($request->only('email','remember'));

  }
  
  
  public function logout(){
	  
	Auth::guard('admin')->logout();

      return redirect('/admin');  
  }
  
}
