<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

class ManagerLoginController extends Controller
{
  public function __construct(){
   $this->middleware('guest:manager')->except('logout');
  }

  public function showLoginForm(){
    return view('auth.manager-login');
  }

public function login(Request $request){
  $email = $request->input('email');
  $password = $request->input('password');

  if(Auth::guard('manager')->attempt(array('email' => $email, 'password' => $password))){

    return redirect()->intended(route('manager.dashboard'));
     }else{
        return redirect()->intended(route('manager.login'));
     }

    //return redirect()->back()->withInput($request->only('email','remember'));

  }
  
  
  public function logout(){
	  
	 Auth::guard('manager')->logout();

      return redirect('/manager'); 
	  
  }
  
}
