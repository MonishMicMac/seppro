<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

class WarehousesLoginController extends Controller
{
  public function __construct(){
   $this->middleware('guest:warehouse')->except('logout');
  }

  public function showLoginForm(){
    return view('auth.outlet-login');
  }

public function login(Request $request){
  $email = $request->input('email');
  $password = $request->input('password');

  if(Auth::guard('warehouse')->attempt(array('email' => $email, 'password' => $password))){

    return redirect()->intended(route('outlet.dashboard'));
	
	// echo 'hii';
	
     }else{
        return redirect()->intended(route('outlet.login'));
     }

    //return redirect()->back()->withInput($request->only('email','remember'));

  }
  
  
  public function logout(){
	  
	 Auth::guard('warehouse')->logout();

      return redirect()->intended(route('outlet.login'));
	  
  }
  
}
