<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\User;
use App\pickupdeliveryuser;
use App\IroningVendor;
use App\Admin;
use App\ServiceAreas;
use App\UserAddresses;
use App\TimeSlots;
use App\Pincode;
use App\Promocode;
use App\Categories;
use App\CategoryList;
use App\Bookings;
use App\BookingItems;
use App\Warehouses;
use App\CustomerSupport;
use App\CommonFunctions;
use App\OutletFunctions;
use Auth;
use Mail;
use DateTime;
use Excel;
use Validator;
use DB;
use PDF;
use Carbon\Carbon;

class OutletController extends Controller
{
	
	public function __construct()
    {
        $this->middleware('auth:admin');
    }
	
	/*************************OutletControl***********************************************************************************************/
	
	public function OutletDashboard(Request $Request){
		
		$id = $Request['id'];
		$Users = User::Select('id')->whereNotNull('email')->count();
		$PickupUser = pickupdeliveryuser::Select('id','warehouseId')->where('warehouseId',$id)->count();
		$Ironing = IroningVendor::Select('id')->count();
		$total_booking = Bookings::Select('id')->Where(['warehouseId'=>$id])->count();
		$Bookings = Bookings::Select('id')->Where(['Bookings.Status'=>'COMPLETED','warehouseId'=>$id])->count();
		$pending = Bookings::Select('id')->Where(['Bookings.Status'=>'CONFIRMED','warehouseId'=>$id])->count();
		$cancelled = Bookings::Select('id')->Where(['Bookings.Status'=>'CANCELLED','warehouseId'=>$id])->count();
		
		
		return view('outlet.dashboard',['id'=>$id,'Users'=>$Users,'PickupUser'=>$PickupUser,'Ironing'=>$Ironing,'Bookings'=>$Bookings,'total_booking'=>$total_booking,'pending'=>$pending,'cancelled'=>$cancelled]);  
		
	}
	
	public function OutletPickUser(Request $Request,$id){
		$OutletFunction = new OutletFunctions();
		$PickupUsers = $OutletFunction->war_pickup_list($id);
		
		return view('outlet.PickupUserList',['id'=>$id,'User' => $PickupUsers]); 
		
	}
	
	public function OutletPickUserReports(Request $Request){
		
		$id = $Request->id;
		$pickupId = $Request->pickupId;

		$userId = $pickupId; 
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->out_pickup_reports($userId);

		$TodayReport  =$response['TodayOrder'];
		$WeekReport  =$response['WeekOrder'];
		$MonthReport  =$response['MonthOrder'];
		$MonthReport  =$response['MonthOrder'];
		$YearReport  =$response['YearOrder'];
		$Days  =$response['Days'];
		$Months  =$response['Months'];
		$Months  =$response['Months'];
		$Years  =$response['Years'];
		$Weeks  =$response['Weeks'];

		 
		return view('outlet.PickupUser',['id'=>$id,'userId'=>$userId,'TodayOrder'=>$TodayReport,'WeekOrder'=>$WeekReport,'MonthOrder'=>$MonthReport,'YearOrder'=>$YearReport,'Days'=>$Days,'Months'=>$Months,'Years'=>$Years,'Weeks'=>$Weeks]);
		
	}
	
	
	public function OutletVendors(Request $Request,$id){
		
		$UserList = IroningVendor::Select('id','name','mobile','email','dob','Is_active')
		                           ->Where('name','!=',null)
		                           ->orderBy('name','ASC')
								   ->get();
		
		return view('outlet.IroningVendorList',['id'=>$id,'User' => $UserList]);
		
	}
	
	
	public function OutletVendorDetails(Request $Request){
		
		$id = $Request->id;
		$vendorId = $Request->vendorId;
		
		$CommonFunction = new CommonFunctions();
		$response = $CommonFunction->out_vendor_report($vendorId);
		
		$Today = $response['Day'];
		$Week = $response['Week'];
		$Month = $response['Month'];
		$Year = $response['Year'];
		$today_rep = $response['today_rep'];
		$week_rep = $response['week_rep'];
		$month_rep = $response['month_rep'];
		$year_rep = $response['year_rep'];
		
		

		 $userId = $vendorId;

		 $category = DB::table('CategoryList')->select('id','name')->get();
		 
		 $cate_first = DB::table('CategoryList')->select('id','name')->first();
		 
		 
		 return view('outlet.VendorReport',['id'=>$id,'userId'=>$userId,'Day'=>$Today,'Week'=>$Week,'Month'=>$Month,'Year'=>$Year,'category'=>$category,'cate_first'=>$cate_first,'today_rep'=>$today_rep,'week_rep'=>$week_rep,'month_rep'=>$month_rep,'year_rep'=>$year_rep]);
		
	}
	
	public function OutletService(Request $Request,$id){
	
	    $Pincode = Pincode::Select('Pincode.id','area','warehouseId','warehouses.name','code')
		                           ->join('warehouses','warehouses.id','=','Pincode.warehouseId')
		                           ->Where('Pincode.warehouseId',$id)
								   ->get();
		
		return view('outlet.service',['id'=>$id,'code'=>$Pincode]); 
		
	}
	
	public function OutletOrders(Request $Request,$id){
		
		$OutletFunction = new OutletFunctions();
		$BookingsList = $OutletFunction->outlet_bookings($id);
	    return view('outlet.orders',['id'=>$id,'Bookings' => $BookingsList]);
		
	}
	
	
	public function OutletBookings(Request $Request,$id){
		
		$id  = $Request->id;
		
		$CommonFunction = new CommonFunctions();
		
		$BookingsDetails = $CommonFunction->ViewBook($id);
		
		$Bookings = $BookingsDetails['Bookings'];
		$DeliveyuserDetails = $BookingsDetails['Deliveyuser'];
		$BookingItems = $BookingsDetails['GetOrder'];
		$IroningVendor = $BookingsDetails['Ironing'];
		$Rating = $BookingsDetails['Rating'];
		
        $id =$BookingsDetails['Bookings'][0]->warehouseId;
	
       return view('outlet.bookings',['id'=>$id,'Bookings' => $Bookings,'Deliveyuser'=>$DeliveyuserDetails,"GetOrders"=>$BookingItems,"Ironing"=>$IroningVendor,'Rating'=>$Rating]);
		
	} 


    public function OutletSales(Request $Request){
     
	    $id = $Request->id;
	   	$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->TodaySales($id);
	 
	    return json_encode($Order);
	 
	}

    public function OutletPayment (Request $Request){
	
		$id = $Request->id;
	   	$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->OutletPayType($id);
	 
	    return json_encode($Order);
		
	}
	
	public function OutletMostOrder(Request $Request){
		
		
		$id = $Request->id;
	   	$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->OutletUserOrder($id);
		
		return json_encode($Order);
		
	}
	
	public function OutletPieChart(Request $Request){
		
		$id = $Request->id;
		
		$Clothes = DB::select("select NewCategories.name as label,groupName,SUM(Booking_Items.quantity) as value from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where Bookings.DeliverySuccess='1' AND Bookings.warehouseId='".$id."'  Group by Booking_Items.categoryId");  
		
		
		foreach($Clothes as $Report){
			
			$Report->label  = $Report->groupName. " / " . $Report->label;
			$Report->value  = (int)$Report->value;
			unset($Report->groupName);
			
		}
		
		return $Clothes; 
		
	}
	
	//Reports
	
	public function OutletReports(Request $Request,$id){
		
		return view('outlet.reports',['id'=>$id]);
	}
	
	public function OutletHighOrders(Request $Request,$id){
		
		
		$id = $Request->id;
	   	$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->OutletPincode($id);
		
		$OrderDay = $Order['Day'];
		$OrderWeek = $Order['Week'];
		$OrderMonth = $Order['Month'];
		$OrderYear = $Order['Year'];
		
		$repDay = $Order['Dayrep'];
		$repWeek = $Order['Weekrep'];
		$repMonth = $Order['Monthrep'];
		$repYear = $Order['Yearrep'];
		$summary = $Order['summary'];
		$pincode = $Order['pincode'];
		
		// echo json_encode($repYear);die;
		

			
		return view('outlet.HighOrder',['id'=>$id,'Day'=>$OrderDay,'Week'=>$OrderWeek,'Month'=>$OrderMonth,'Year'=>$OrderYear,'Dayrep'=>$repDay,'Weekrep'=>$repWeek,'Monthrep'=>$repMonth,'Yearrep'=>$repYear,'summary'=>$summary,'pincode'=>$pincode]);
	}
	
	

	
	public function OutletPincodeGraph(Request $Request){
		
		$id = $Request->id;
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->OutletPinGraph($id);
		
		return json_encode($response);  
		
	}
	
	public function SearchOutletPin(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pinId =$Request->pinId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_search_pin($fromdate,$todate,$pinId,$outletId);
		
		return $response;
		
		
		
	}
	
	public function custom_outlet_pingraph(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pinId =$Request->pinId;
		$outletId =$Request->outletId;

        $OutletFunction = new OutletFunctions();
		$response = $OutletFunction->OutletCustomPin($fromdate,$todate,$pinId,$outletId);		
		
		return $response;
		
	}

	
	public function OutletPinReport(Request $Request){
		
		$id = $Request->id;
		$outletId = $Request->outletId;
		$type = $Request->type;
		
		// return $type;die;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->OutletPinDownload($id,$outletId,$type);
		
		return $response;
		
		die;
	
		
		$data= json_decode( json_encode($Order), true);
		
		Excel::create('area-month-report', function($excel) use($data) {
			$excel->sheet('Sheet 1', function($sheet) use($data) {
				$sheet->fromArray($data);
			});
		})->export('xls');
		
		
	}
	
	
	public function OutletPaymentType(Request $Request,$id){
		
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_PayType($id);
		
		$PaymentTypeDay = $Order['Day'];
		$PaymentTypeWeek = $Order['Week'];
		$PaymentTypeMonth = $Order['Month'];
		$PaymentTypeYear = $Order['Year'];
		
		
		$DayRep = $Order['DayRep'];
		$WeekRep = $Order['WeekRep'];
		$MonthRep = $Order['MonthRep'];
		$YearRep = $Order['YearRep'];
		$summary = $Order['summary'];
		
		// echo json_encode($YearRep);die;

		
		return view('outlet.ReportPaymentType',['id'=>$id,'Day'=>$PaymentTypeDay,'Month'=>$PaymentTypeMonth,'Week'=>$PaymentTypeWeek,'Year'=>$PaymentTypeYear,'DayRep'=>$DayRep,'WeekRep'=>$WeekRep,'MonthRep'=>$MonthRep,'YearRep'=>$YearRep,'summary'=>$summary]);
		
	}
	
	public function OutletPaymentGraph(Request $Request){
		
		 $id = $Request->id;
		 
		 $OutletFunction = new OutletFunctions();
		 $Order = $OutletFunction->Outlet_PayType_graph($id);
		 
		 return json_encode($Order);
		
	}
	
	public function OutletPayDownload(Request $Request){
		
		
		$id = $Request->id;
		$outletId = $Request->outletId;
		$type = $Request->type;

		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_PayType_Download($id,$outletId,$type);
		
		return $response;

	}
	
	public function outlet_paymentgraph(Request $Request){
		
		$fromdate =$Request->paymentfrom;
		$todate =$Request->paymentto;
		$paytypeId =$Request->paytypeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_payment_graph($fromdate,$todate,$paytypeId,$outletId);
		
		return $response;
		
	}
	
	public function SearchOutletPayment(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$paytypeId =$Request->paytypeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->search_outlet_payment($fromdate,$todate,$paytypeId,$outletId);
		
		return $response;
		
		
	}
	
	public function OutletRevenue(Request $Request,$id){
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Revenue($id);
		
		$TodayRep = $Order['Day'];
		$WeekRep = $Order['Week'];
		$MonthRep = $Order['Month'];
		$YearRep = $Order['Year'];
		
		
		$Days = $Order['Days'];
		$Weekly = $Order['Weekly'];
		$Monthly = $Order['Monthly'];
		$Yearly = $Order['Yearly'];
		$summary = $Order['summary'];
		
		// echo json_encode($summary);die;
		
		return view('outlet.revenue',['id'=>$id,'Day'=>$TodayRep,'Week'=>$WeekRep,'Month'=>$MonthRep,'Year'=>$YearRep,'Days'=>$Days,'Weekly'=>$Weekly,'Monthly'=>$Monthly,'Yearly'=>$Yearly,'summary'=>$summary]);
		
		// return view('outlet.revenue',['id'=>$id,'Day'=>$TodayRep,'Week'=>$WeekRep,'Month'=>$MonthRep,'Year'=>$YearRep]);
		
	}
	
	public function OutletRevenueGraph(Request $Request){
		
		$id = $Request->id;
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Revenue_Graph($id);
		
		return json_encode($Order);
		
	}

    public function OutletRevenueExcel(Request $Request){
		
		$id = $Request->id;
		$type = $Request->type;
		$outletId = $Request->outletId;
		
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_Revenue_Download($id,$type,$outletId);
		
		
		return $response;
		die;
		
		
		Excel::create('revenue-month-report', function($excel) use($Order) {
			$excel->sheet('Sheet 1', function($sheet) use($Order) {
				$sheet->fromArray($Order);
			});
		})->export('xls');
	}
	
	
	public function OutletClothGraph(Request $Request){
		
		$id = $Request->id;
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Cloth_Graph($id);
		
		 return json_encode($Order);
		
	}
	
	public function OutletClothes(Request $Request,$id){
		
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Cloth($id);
		
		$TodayRev = $Order['Day'];
		$WeekRev = $Order['Week'];
		$MonthRev = $Order['Month'];
		$YearRev = $Order['Year'];
		
		$category = $Order['category'];
		$summary = $Order['summary'];
		
		return view('outlet.clothes',['id'=>$id,'Day'=>$TodayRev,'Week'=>$WeekRev,'Month'=>$MonthRev,'Year'=>$YearRev,'category'=>$category,'summary'=>$summary]);
		
	}
	
	public function OutletMonthClothSales(Request $Request){
		
		$id = $Request->id;
		
		// $id= 1;
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Qty_Month($id);
	
		return json_encode($Order); 
	}
	
	public function OutletMonthClothRev(Request $Request){
		
		$id = $Request->id;
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Rev_Month($id);
	
		return json_encode($Order); 
		
	}
	
	public function OutletClotheReport(Request $Request){
		
		$id = $Request->id;
		$type= $Request->type;
		$outletId = $Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_Clothe_Report($id,$type,$outletId); 

        return $response;die;		
		
		
	}



     public function OutletTimeSlots(Request $Request,$id){
		 
		 
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_time_slots($id); 
		
		$time_slot = DB::table('TimeSlots')->select('id','fromSlots','toSlots','status')->Where('status',1)->get();
		
		$TodayReport = $response['Day'];
		$WeekReport = $response['Week'];
		$MonthReport = $response['Month'];
		$YearReport = $response['Year'];
		
		$Dayrep = $response['Dayrep'];
		$Weekrep = $response['Weekrep'];
		$Monthrep = $response['Monthrep'];
		$Yearrep = $response['Yearrep'];
		$summary = $response['summary'];
		
		return view('outlet.time-slots',['id'=>$id,'Day'=>$TodayReport,'Week'=>$WeekReport,'Month'=>$MonthReport,'Year'=>$YearReport,'Dayrep'=>$Dayrep,'Weekrep'=>$Weekrep,'Monthrep'=>$Monthrep,'Yearrep'=>$Yearrep,'Slot'=>$time_slot,'summary'=>$summary]);

	 }
	 
	 public function OutletTimeSlotReport(Request $Request){
		 
		 
		 $id = $Request->id;
		 $type = $Request->type;
		 $outletId = $Request->outletId;
		 
		 $OutletFunction = new OutletFunctions();
		  $response = $OutletFunction->Outlet_timeslots_report($id,$type,$outletId);
		  
		  return $response;
		 
	 }
	 
	 public function OutletSlotGraph(Request $Request){
		 
		 $outletId = $Request->id;

		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_slot_graph($outletId);
		 
		 return $response;
		 
	 }
	 
	 public function OutletSearchTime(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$timeId =$Request->timeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_search_timeslots($fromdate,$todate,$timeId,$outletId);
		
		return $response;
		 
		 
	 }
	 
	 
	 public function custom_outlet_graph_slot(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$timeId =$Request->timeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->custom_slot_graph($fromdate,$todate,$timeId,$outletId);
		
		return $response;
		 
	 }
	 
	 
	  public function OutletSlotReport(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$timeId =$Request->timeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->slot_rep_download($fromdate,$todate,$timeId,$outletId); 
		 
		 
	 }
	 
	 
	 public function SearchOutletRevenue(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->search_outlet_revenue($fromdate,$todate,$outletId);
		
		return $response;
 
	 }

	 
	 public function custom_outlet_revenue(Request $Request){
		 
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_rev_graph($fromdate,$todate,$outletId);
		
		return $response;
		 
	 }

	 
	 public function OutletRevReport(Request $Request){
		 
		 $fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_rev_report($fromdate,$todate,$outletId);
		 
	 }
	 
	 public function OutletPaymentReport(Request $Request){
		  
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$paytypeId =$Request->paytypeId;
		$outletId =$Request->outletId;
		
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_pay_report($fromdate,$todate,$outletId,$paytypeId);
		 
	 }
	 
	 public function SearchClothesOutlet(Request $Request){
		 
		 $fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$cateId =$Request->cateId;
		$outletId =$Request->outletId;
		
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->search_out_clothes($fromdate,$todate,$outletId,$cateId);
		
		return $response;
 
	 }
	 
	 public function OutletClothesDown(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$cateId =$Request->cateId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_clothes_down($fromdate,$todate,$outletId,$cateId);

		 
	 }
	 
	 public function custom_outlet_category(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$cateId =$Request->cateId;
		$outletId =$Request->outletId;
	
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_clothes_category($fromdate,$todate,$cateId,$outletId);
		
		return $response;
		 
	 }
	 
	 
	 public function OutletClothesCate(Request $Request,$id){
		 
		 
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_clothes_cate($id);
		 
		 $cateId = $response['cateId'];
		 $category = $response['category'];
		 $Today = $response['Day'];
		 $Week = $response['Week'];
		 $Month = $response['Month'];
		 $Year = $response['Year'];

		 return view('outlet.category-clothes',['id'=>$id,'cateId'=>$cateId,'category'=>$category,'Day'=>$Today,'Week'=>$Week,'Month'=>$Month,'Year'=>$Year]);

		 
	 }
	 
	 
	 public function category_clothes_outlet(Request $Request){
		 
		 $outletId = $Request->outletId;
		 $id = $Request->id;
		 $type = $Request->type;
		 
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->out_let_clothes($outletId,$id,$type);
		 
		 return $response;
	 }
	 
	 
	 public function Outlet_Category_Clothes(Request $Request){
		 
		 $id = $Request->id;
		 
		 $outletId = $Request->outletId;
		 
		
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->out_let_cate_clothes($outletId,$id);
		
	}
	
	
	public function OutletPromocode($id){
		
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->out_let_promo($id);
		 
		 $PromoDay = $response['Day'];
		 $PromoWeek = $response['Week'];
		 $PromoMonth = $response['Month'];
		 $PromoYear = $response['Year'];
		 $PromoYear = $response['Year'];
		 $Days = $response['Days'];
		 $Weekly = $response['Weekly'];
		 $Monthly = $response['Monthly'];
		 $Yearly = $response['Yearly'];
		 $promo_list = $response['Promo'];
		 $summary = $response['summary'];
		 
		 
		 
		  return view('outlet.PromocodeView',['id'=>$id,'Day'=>$PromoDay,'Week'=>$PromoWeek,'Month'=>$PromoMonth,'Year'=>$PromoYear,'Days'=>$Days,'Weekly'=>$Weekly,'Monthly'=>$Monthly,'Yearly'=>$Yearly,'Promo'=>$promo_list,'summary'=>$summary]); 
		
	}
	
	
	public function OutletSearchPromo(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$promoId =$Request->promoId;
		$outletId =$Request->outletId;

		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_promo_search($fromdate,$todate,$promoId,$outletId);
		 
		 return $response;

	}
	
	
	public function OutletPromoDown(Request $Request){
		
		
		$id = $Request->id;
		$type = $Request->type;
		$outletId = $Request->outletId;
		
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_promo_down($id,$type,$outletId);
		 
		 return $response;
		
	}

	
	public function custom_graph_outpromo(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$promoId =$Request->promoId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_custom_graph($fromdate,$todate,$promoId,$outletId);
		 return $response;
		
	}
	
	public function OutletPromoDayGraph(Request $Request){
		
		 $outletId = $Request->id;
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_promo_graph($outletId);
		 return $response;
		
	}
	
	
	
	public function out_search_promo(Request $Request){
		
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$promoId =$Request->promoId;
		$outletId =$Request->outletId;
		
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->promo_search_down($fromdate,$todate,$promoId,$outletId);

	}
	
	public function OutletStatus(Request $Request,$id){
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_status($id);
		
		$complete_day = $response['Day'];
		$complete_week = $response['Week'];
		$complete_month = $response['Month'];
		$complete_year = $response['Year'];
		$DayRep = $response['DayRep'];
		$WeekRe = $response['WeekRe'];
		$MonthRep = $response['MonthRep'];
		$YearRep = $response['YearRep'];
		$summary = $response['summary'];
		
		return view('outlet.OrderSuccess',['id'=>$id,'Day'=>$complete_day,'Week'=>$complete_week,'Month'=>$complete_month,'Year'=>$complete_year,'DayRep'=>$DayRep,'WeekRe'=>$WeekRe,'MonthRep'=>$MonthRep,'YearRep'=>$YearRep,'summary'=>$summary]);
		
	}
	
	
	public function OutletStatusReport(Request $Request){
		
		 $outletId = $Request->outletId;
		 $id = $Request->id;
		 $type = $Request->type;
		 
		 // return $id;die;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_status_report($id,$type,$outletId);
		
		return $response;
	}
	
	public function OutStatusDayGraph(Request $Request){
		
		$id = $Request->id;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_status_graph_day($id);
		return $response;
		
	}
	
	public function OutletSearchSat(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$typeId =$Request->typeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_search_status($fromdate,$todate,$typeId,$outletId);
		
		return $response;
		
	}
	
	
	public function OutletStatusDown(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$typeId =$Request->typeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_down_status($fromdate,$todate,$typeId,$outletId);
		
	}
	
	
	public function OutletAvg(Request $Request,$id){
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_avg_cost($id);
		
		$stdday = $response['Today'];
		$stdweek = $response['Week'];
		$stdmonth = $response['Month'];
		$stdyear = $response['Year'];
		
		
		return view('outlet.AvgCost',['id'=>$id,'Today'=>$stdday,'Week'=>$stdweek,'Month'=>$stdmonth,'Year'=>$stdyear]);
	}
	
	
	public function SearchOutAvg(Request $Request){
		
		$outletId = $Request->outletId;
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_avg_search($outletId,$fromdate,$todate);
		
		return $response;
	}
	
	
}