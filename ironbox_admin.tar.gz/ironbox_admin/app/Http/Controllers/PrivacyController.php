<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PrivacyController extends Controller
{


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function UserPrivacy(Request $Request)
    {
        return view('pages.userprivacy');
    }
	
	public function UserTerms(Request $Request)
    {
        return view('pages.userterms');
    }
	
	public function Refunds(Request $Request)
    {
        return view('pages.refunds');
    }
	
	public function Disclaimer(Request $Request)
    {
        return view('pages.Disclaimer');
    }
}