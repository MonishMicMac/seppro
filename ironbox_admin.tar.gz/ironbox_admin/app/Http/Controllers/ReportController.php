<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\User;
use App\pickupdeliveryuser;
use App\IroningVendor;
use App\Admin;
use App\ServiceAreas;
use App\UserAddresses;
use App\TimeSlots;
use App\Pincode;
use App\Promocode;
use App\Categories;
use App\CategoryList;
use App\Bookings;
use App\BookingItems;
use App\Warehouses;
use App\CustomerSupport;
use App\CommonFunctions;
use Auth;
use Mail;
use DateTime;
use Excel;
use Validator;
use DB;
use PDF;
use Carbon\Carbon;

class ReportController extends Controller
{
	
	public function __construct()
    {
        $this->middleware('auth:admin');
    }
	
	public function DownloadAreaReport(Request $Request){
		
		$id = $Request->id;
		$type = $Request->type;
		
		if($type == 'graph'){
			
			switch ($id) {
          case "1":
	        
			 $OrderDay = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");
			  if(count($OrderDay) == 0){
				  
				  $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
			  }
			 return json_encode($OrderDay);
			
			break;
		  case "2":
	        
			$Order = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND  YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW())   GROUP by Bookings.service_area");
		   
		    if(count($Order) == 0){
				  
				  $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
			  }
		   return json_encode($Order);
		   
		   break;
		case "3":
	
	    $OrderMonth = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");
		     if(count($OrderMonth) == 0){
				  
				  $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
			  }
		return json_encode($OrderMonth);
	
		 break;
		case "4":
	
	    $Order = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");
		
		if(count($Order) == 0){
				  
				  $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
			  }
		
	    return json_encode($Order);
		 break;
		 case "5":
		 $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
		  break;
		default:
			
				  
				  return 'No record';
			  
			}
			
		}else{
		//Report download
		switch ($id) {
    case "1":

	   $description = "Pincode Today reports (".date('d-m-Y').")";
	   

		$CommonFunction = new CommonFunctions();
		$query_fnc  = $CommonFunction->get_function_day();
		$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

	   
        break;
    case "2":
        
		
		    
		$description = "Pincode week reports (".date('d-m-Y').")";
	   
		$CommonFunction = new CommonFunctions();
		$query_fnc  = $CommonFunction->get_function_day();
		$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

        break;
    case "3":

	   
	    $description = "Pincode month reports (".date('d-m-Y').")";
		$CommonFunction = new CommonFunctions();
		$query_fnc  = $CommonFunction->get_function_month();
		$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

        break;
		
	case "4":

	    $description = "Pincode year reports (".date('d-m-Y').")";

		$CommonFunction = new CommonFunctions();
		$query_fnc  = $CommonFunction->get_function_year();
		$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

		
	   

	   
        break;
    default:
        echo "No record";
   }
   
	}
		
		 die;
		
		
		$data = User::get()->toArray();
        return Excel::create('laravelcode', function($excel) use ($data) {
            $excel->sheet('mySheet', function($sheet) use ($data)
            {   
			    $sheet->row(1, ["TITLE 1"]);
			    $sheet->row(2, ["TITLE 1"]);
				
                $sheet->mergeCells('A1:D1');
                $sheet->mergeCells('A2:D2');
				
				$sheet->getStyle('A1:D1')->applyFromArray(array(
                     'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  20,
					'bold'      =>  true,
					'color'      => array('rgb' => 'FF0000')
				)
				));
				
				// $sheet->setStyle(array(
				// 'font' => array(
					// 'name'      =>  'Calibri',
					// 'size'      =>  12,
					// 'bold'      =>  true
				// )
			// )); 
		
				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);

			$sheet->getStyle('A2:D2')->getAlignment()->applyFromArray(
				array('horizontal' => 'center')
			);
                $sheet->cell('A4', function($cell) {$cell->setValue('First Name');   });
                $sheet->cell('B4', function($cell) {$cell->setValue('Last Name');   });
                $sheet->cell('C4', function($cell) {$cell->setValue('Email');   });
                if (!empty($data)) {
                    foreach ($data as $key => $value) {
                        $i= $key+5;
                        $sheet->cell('A'.$i, $value['name']); 
                        $sheet->cell('B'.$i, $value['email']); 
                        $sheet->cell('C'.$i, $value['mobile']); 
                    }
                }
            });
        })->export('xls');die;
		
		
	}
	
	
	public function custom_area_graph(Request $Request){
		
		$fromdate =$Request->areafrom;
		$todate =$Request->areato;
		$pinId =$Request->pinId;
		
		// SELECT Pincode.code as pincode,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '2018-08-01' AND '2018-08-09'  GROUP by Bookings.service_area
		
		if(empty($pinId)){
			
			$Pincode = DB::select("SELECT Pincode.code as code,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  GROUP by Bookings.service_area");
			
			return json_encode($Pincode);
			
		}else if(empty($fromdate) && empty($todate)){
			
			$Pincode = DB::select("SELECT Pincode.code as code,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Pincode.id='".$pinId."' GROUP by Bookings.service_area");
		
		    return json_encode($Pincode);
		}else if($fromdate && $todate && $pinId){
			
			
			$Pincode = DB::select("SELECT Pincode.code as code,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Pincode.id='".$pinId."'  GROUP by Bookings.service_area");
			
			return json_encode($Pincode);
			
		}
		
	}
	
	
  public function get_excel_pincode_2($Bookings,$description){
		
		Excel::create("".$description."", function($excel) use ($Bookings,$description) {
            $excel->sheet('mySheet', function($sheet) use ($Bookings,$description)
            {   
			    $sheet->row(1, ["".$description.""]);
			    // $sheet->row(2, ["Name : 'fdfdf'"]);
			    // $sheet->row(3, ["Mobile : 'dfjnh'"]);
				
                $sheet->mergeCells('A1:F1');
                // $sheet->mergeCells('A2:D2');
                // $sheet->mergeCells('A3:D3');
				
				$sheet->getStyle('A1:F1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A5', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B5', function($cell) {$cell->setValue('BookindId');   });
                $sheet->cell('C5', function($cell) {$cell->setValue('Name');   });
                $sheet->cell('D5', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('E5', function($cell) {$cell->setValue('Email');   });
                $sheet->cell('F5', function($cell) {$cell->setValue('Booking date');   });
                $sheet->cell('G5', function($cell) {$cell->setValue('Delivery date');   });
                $sheet->cell('H5', function($cell) {$cell->setValue('Time Slots');   });
                $sheet->cell('I5', function($cell) {$cell->setValue('Pincode');   });
                $sheet->cell('J5', function($cell) {$cell->setValue('address');   });
                $sheet->cell('K5', function($cell) {$cell->setValue('quantity');   });
                $sheet->cell('L5', function($cell) {$cell->setValue('Status');   });
                $sheet->cell('M5', function($cell) {$cell->setValue('paymentType');   });
                $sheet->cell('N5', function($cell) {$cell->setValue('totalPayment');   });
                $sheet->cell('O5', function($cell) {$cell->setValue('discount_amount');   });
                $sheet->cell('P5', function($cell) {$cell->setValue('promocode');   });
                $sheet->cell('Q5', function($cell) {$cell->setValue('Cancel reasons');   });
                $sheet->cell('R5', function($cell) {$cell->setValue('Order date');   });
                $sheet->cell('S5', function($cell) {$cell->setValue('Order time');   });
                $sheet->cell('T5', function($cell) {$cell->setValue('Way to pickup date');   });
                $sheet->cell('U5', function($cell) {$cell->setValue('Way to pickup time');   });
                $sheet->cell('V5', function($cell) {$cell->setValue('Pickup success date');   });
                $sheet->cell('W5', function($cell) {$cell->setValue('Pickup success time');   });
                $sheet->cell('X5', function($cell) {$cell->setValue('Way to delivery date');   });
                $sheet->cell('Y5', function($cell) {$cell->setValue('Way to delivery time');   });
                $sheet->cell('Z5', function($cell) {$cell->setValue('delivery date');   });
                $sheet->cell('AA5', function($cell) {$cell->setValue('delivery time');   });
                if (!empty($Bookings)) {
                    foreach ($Bookings as $key => $value) {
						
						if($value['reasons'] == null){
							
							$value['reasons'] = "";
						 }

                        $i= $key+6;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['bookingId']); 
                        $sheet->cell('C'.$i, $value['username']); 
                        $sheet->cell('D'.$i, $value['usermobile']); 
                        $sheet->cell('E'.$i, $value['useremail']); 
                        $sheet->cell('F'.$i, $value['bookingDate']); 
                        $sheet->cell('G'.$i, $value['delivery_date']); 
                        $sheet->cell('H'.$i, $value['fromSlots'].'-'.$value['toSlots']); 
                        $sheet->cell('I'.$i, $value['code']); 
                        $sheet->cell('J'.$i, $value['address']); 
                        $sheet->cell('K'.$i, $value['quantity']); 
                        $sheet->cell('L'.$i, $value['Status']); 
                        $sheet->cell('M'.$i, $value['paymentType']); 
                        $sheet->cell('N'.$i, $value['totalPayment']); 
                        $sheet->cell('O'.$i, $value['discount_amount']); 
                        $sheet->cell('P'.$i, $value['promocode']); 
                        $sheet->cell('Q'.$i, $value['reasons']); 
                        $sheet->cell('R'.$i, $value['confirm_date']); 
                        $sheet->cell('S'.$i, $value['confirm_time']); 
                        $sheet->cell('T'.$i, $value['waypick_date']); 
                        $sheet->cell('U'.$i, $value['waypick_time']); 
                        $sheet->cell('V'.$i, $value['pickup_date']); 
                        $sheet->cell('W'.$i, $value['pickup_time']); 
                        $sheet->cell('X'.$i, $value['waydeli_date']); 
                        $sheet->cell('Y'.$i, $value['waydeli_time']); 
                        $sheet->cell('Z'.$i, $value['deli_date']); 
                        $sheet->cell('AA'.$i, $value['delivery_time']); 
                    }
                }
            });
        })->export('xls');
		
	}
	
	
	public function DownloadPaymentType(Request $Request){
		
		$id = $Request->id;
		$type = $Request->type;
		
		
		
		if($type == 'graph'){
		
		$paytype = array(array('orders'=>'','paymentType'=>'Cash'),array('orders'=>'','paymentType'=>'Card'),array('orders'=>'','paymentType'=>'Wallet'));		
		
		switch ($id) {
			case "1":
				
		$PaymentReport = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");
		
		
		if(count($PaymentReport)  == 0){
			
			return json_encode($paytype);die;
		}
		
		return json_encode($PaymentReport);
	
				
				break;
			case "2":
				
				$PaymentReport = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");
				
				if(count($PaymentReport)  == 0){
			
					return json_encode($paytype);die;
				}
		
		   return json_encode($PaymentReport);
		
				
				break;
			case "3":
				
				
		$PaymentReport = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");
		
		if(count($PaymentReport)  == 0){
			
			return json_encode($paytype);die;
		}
		
		return json_encode($PaymentReport);
		
		
		
				break;
			case "4":
				
				$PaymentReport = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");
				
				if(count($PaymentReport)  == 0){
			
			return json_encode($paytype);die;
		}
				
		return json_encode($PaymentReport);
		
				
				break;
			default:
				$paytype = array(array('orders'=>'','paymentType'=>'Cash'),array('orders'=>'','paymentType'=>'Card'),array('orders'=>'','paymentType'=>'Wallet'));	
				return json_encode($paytype);die;
		  }
		
    	}else{
			
			switch ($id) {
			case "1":
			
			$description = "Payment type today reports (".date('d-m-Y').")";
	   
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_function_day();
			$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
			
			break;
			
			case "2":
			
			$description = "Payment type weekly reports (".date('d-m-Y').")";
	   
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_function_week();
			$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
			
			break;
			
			case "3":
			
			$description = "Payment type monthly reports (".date('d-m-Y').")";
	   
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_function_month();
			$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
			
			break;
			
			
			case "4":
			
			$description = "Payment type yearly reports (".date('d-m-Y').")";
	   
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_function_Year();
			$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
			
			break;
			
			default;
			   echo 'No data';
			break;
			
			}
			
			
		}

	}
	
	public function custom_paymenttype_graph(Request $Request){
		
		$fromdate =$Request->paymentfrom;
		$todate =$Request->paymentto;
		$paytypeId =$Request->paytypeId;
		
		// return $paytypeId;die;
		
		if(empty($paytypeId)){
			
			$paytype = DB::select("SELECT Bookings.paymentType,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  GROUP by Bookings.paymentType order by Bookings.id desc");
			
			return json_encode($paytype);
			
		}else if(empty($fromdate) && empty($todate)){
			
			$paytype = DB::select("SELECT Bookings.paymentType,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.paymentType='".$paytypeId."' GROUP by Bookings.paymentType order by Bookings.id desc");
		
		    return json_encode($paytype);
		}else if($fromdate && $todate && $paytypeId){
			
			
			$paytype = DB::select("SELECT Bookings.paymentType,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Bookings.paymentType='".$paytypeId."'  GROUP by Bookings.paymentType order by Bookings.id desc");
			
			return json_encode($paytype);
			
		}
		
	}
	
	public function DownloadPromocode(Request $Request){
		
		
		$id = $Request->id;
		$type = $Request->type;
		
		
		if($type == 'graph'){
			
			switch ($id) {
			case "1":
			
			$promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) GROUP by Bookings.promode_code");
			
			return json_encode($promocode);
			
			break; 

            case "2":
			
			$promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) GROUP by Bookings.promode_code");
		
		    return json_encode($promocode);
			
			break; 

            case "3":
			
			$promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) GROUP by Bookings.promode_code");
		
		    return json_encode($promocode);
			
			break; 

            case "4":
			
			$promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) GROUP by Bookings.promode_code");
		
		    return json_encode($promocode);
			
			break;
			default:
				echo "Invalid data";die;
			
			}
			
			
		  }else{
		
		switch ($id) {
			case "1":
              
			  $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->where('Bookings.promode_code', '!=' , 0)
							  ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
							  
			 $description = "Promocode today reports (".date('d-m-Y').")";
			 $CommonFunction = new CommonFunctions();
			 $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);


           case "2":
              
			  $now = Carbon::now();
	   
	   $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->where('Bookings.promode_code', '!=' , 0)
							  ->whereBetween('DeliverySuccessDate', [Carbon::now()->startOfWeek(),Carbon::now()->endOfWeek()])
		                      ->get()
							  ->toArray();
			  
			 $description = "Promocode week reports (".date('d-m-Y').")";
			 $CommonFunction = new CommonFunctions();
			 $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			  
            break;

           case "3":
              
			   $now = Carbon::now();
			   $month = date('m');
	   
	  $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->where('Bookings.promode_code', '!=' , 0)
							  ->whereMonth('DeliverySuccessDate', $month)
		                      ->get()
							  ->toArray();
			  
			   $description = "Promocode month reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
            break;


            case "4":
                
				 $year = date('Y');
		 $now = Carbon::now();
		 $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->where('Bookings.promode_code', '!=' , 0)
							  ->whereYear('DeliverySuccessDate', $year)
		                      ->get()
							  ->toArray();
				
				$description = "Promocode year reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
				
            break;          	
			
			break;
			default:
				echo "Invalid data";die;
		}
		
		
		
		
		
		$data= json_decode( json_encode($Promo_report), true);
		Excel::create('promocode-report', function($excel) use($data) {
			$excel->sheet('Sheet 1', function($sheet) use($data) {
				$sheet->fromArray($data);
			});
		})->export('xls');
		
		
	  }
	
	}
	
	
	public function custom_graph_promocode(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$promoId =$Request->promoId;
		
		// return $todate;die;
		
		if(empty($promoId)){
			
			$promo = DB::select("select promocode.promocode as code ,COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' GROUP by Bookings.promode_code");
			
			return json_encode($promo);
			
			// return 5;
			
		}else if(empty($fromdate) && empty($todate)){
			
			$promo = DB::select("select promocode.promocode as code ,COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND promocode.id='".$promoId."' GROUP by Bookings.promode_code");
			
			return json_encode($promo);
			
			
		}else if($fromdate && $todate && $promoId){
			
			
			$promo = DB::select("select promocode.promocode as code ,COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND promocode.id='".$promoId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' GROUP by Bookings.promode_code");
			
			return json_encode($promo);
			
		}
		
		
		
	}
	
	public function DownloadCancel(Request $Request){
		
		
		$id = $Request->id;
		$type = $Request->type;
		
		if($type == 'graph'){
			
			
			switch ($id) {
			case "1":
			
			
			$report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED'  AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW())"); 	


						foreach($report as $list){
							 
							 if($list->Status == null){  
								 
								 $list->Status = "";
							 }
						 }

               						 
				return 	json_encode($report);
			
			break;
			
			
			case "2":
			
			$report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND  YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED'  AND  YEARWEEK(CancelDate) = YEARWEEK(NOW())"); 	


						foreach($report as $list){
							 
							 if($list->Status == null){  
								 
								 $list->Status = "";
							 }
						 }

               						 
				return 	json_encode($report);
			
			break;
			
			case "3":
			
			$report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED'  AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW())"); 	


						foreach($report as $list){
							 
							 if($list->Status == null){  
								 
								 $list->Status = "";
							 }
						 } 
				return 	json_encode($report);	 
			
			break;
			
			case "4":
			
			
			$report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED' AND YEAR(CancelDate) = YEAR(NOW())"); 	


						foreach($report as $list){
							 
							 if($list->Status == null){  
								 
								 $list->Status = "";
							 }
						 } 
				return 	json_encode($report);	
			
			break;
			
			default:
				
				$data = array(array('orders'=>0,'Status'=>'COMPLETED'),array('orders'=>0,'Status'=>'CANCELLED'));
				
				return json_encode($data);
			
			}
			
			
		}else{
		
		
		switch ($id) {
			case "1":
				
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
							  ->orwhereDate('CancelDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
              $description = "Success - cancelled totday reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
               							 
				
				break;
			case "2":
				
				$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->whereBetween('DeliverySuccessDate', [Carbon::now()->startOfWeek(),Carbon::now()->endOfWeek()])
							  ->orwhereBetween('CancelDate', [Carbon::now()->startOfWeek(),Carbon::now()->endOfWeek()])
		                      ->get()
							  ->toArray();
              $description = "Success - cancelled week reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
				
				
				break;
			case "3":
				
				$month = date('m');
	   
	            $now = Carbon::now();
                   $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->whereRaw('MONTH(DeliverySuccessDate) = ?',[$month])
							  ->orwhereRaw('MONTH(CancelDate) = ?',[$month])
		                      ->get()
							  ->toArray();
              $description = "Success - cancelled month reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			  
				break;
			case "4":
				
				
				$year = date('Y');
	   
	            $now = Carbon::now();
                   $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->whereRaw('YEAR(DeliverySuccessDate) = ?',[$year])
							  ->orwhereRaw('YEAR(CancelDate) = ?',[$year])
		                      ->get()
							  ->toArray();
              $description = "Success - cancelled year reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
				
				break;
			default:
				echo "No data";
		}
		
	}
		
	}
	
	
	public function custom_orders_graph(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$typeId =$Request->typeId;
		
		
		if(empty($typeId)){
		
		$Report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED' AND DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."' ");
		
		foreach($Report as $list){
							 
			 if($list->Status == null){  
				 
				 $list->Status = "";
			 }
		 } 
		
		return json_encode($Report);		
		}else if(empty($fromdate) && empty($todate)){
			
			$Report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='".$typeId."'  ");
			
			foreach($Report as $list){
							 
			 if($list->Status == null){  
				 
				 $list->Status = "";
			 }
		 }
		
		return json_encode($Report);
			
		  
		}else if($fromdate && $todate && $typeId){
			
			if($typeId == 'COMPLETED'){
				
				$Report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='".$typeId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' ");
				
				return json_encode($Report);
				
			}else if($typeId == 'CANCELLED'){
				
				$Report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='".$typeId."' AND DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."' ");
				
				return json_encode($Report);
			}
			
			
		}
		
	}
	
	
	public function WalletView(Request $Request){
		
		 $month = date('m');
		 $year = date('Y');
		 
		$transaction = DB::table('wallet_transaction')->select('wallet_transaction.id','wallet_transaction.userId','users.name','users.mobile','wallet_transaction.orderId','amount','transation_status','wallet_transaction.createdAt',DB::raw('DATE_FORMAT(createdAt, "%d-%m-%Y") as trans_date'))
		                        ->join('users','users.id','=','wallet_transaction.userId')
		                        ->get();
		
		
		
		//Day
		/* $WalletDay = DB::select("SELECT SUM(amount)as amount,DAY(createdAt) as ord_date,MONTH(createdAt) as ord_month,Year(createdAt) as ord_year FROM wallet_transaction Where DAY(createdAt) = DAY(NOW()) AND MONTH(createdAt) = MONTH(CURRENT_DATE()) AND YEAR(createdAt) = YEAR(CURRENT_DATE()) GROUP BY MONTH(createdAt), DAY(createdAt), YEAR(createdAt) ORDER BY ord_date desc, ord_month desc");
		foreach($WalletDay as $Data){
			 
			 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
		 }
		 

		
		//Month
		$WalletMonth = DB::select("SELECT SUM(amount)as amount,DAY(createdAt) as ord_date,MONTH(createdAt) as ord_month,Year(createdAt) as ord_year FROM wallet_transaction Where MONTH(createdAt) = MONTH(CURRENT_DATE()) AND YEAR(createdAt) = YEAR(CURRENT_DATE()) GROUP BY MONTH(createdAt), DAY(createdAt), YEAR(createdAt) ORDER BY ord_date desc, ord_month desc");
		foreach($WalletMonth as $Data){
			 
			 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
		 }
		 
		
		 
		 //Week
		 $WalletWeek = DB::select("SELECT SUM(amount)as amount,DAY(createdAt) as ord_date,MONTH(createdAt) as ord_month,Year(createdAt) as ord_year FROM wallet_transaction Where YEARWEEK(createdAt) = YEARWEEK(NOW()) GROUP BY MONTH(createdAt), DAY(createdAt), YEAR(createdAt) ORDER BY ord_date desc, ord_month desc");
		foreach($WalletWeek as $Data){
			 
			 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
		 }
		 
		 //Year
		$WalletYear = DB::select("SELECT SUM(amount)as amount,DAY(createdAt) as ord_date,MONTH(createdAt) as ord_month,Year(createdAt) as ord_year FROM wallet_transaction Where YEAR(createdAt) = YEAR(CURRENT_DATE()) GROUP BY MONTH(createdAt), DAY(createdAt), YEAR(createdAt) ORDER BY ord_date desc, ord_month desc");
		foreach($WalletYear as $Data){
			 
			  $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
		 }  */
		 
		 
		
		$day_rep = DB::Select("select wallet_transaction.id,wallet_transaction.userId, users.name,users.mobile,Bookings.bookingId,orderId,transactionId,amount,transation_status,type,DATE_FORMAT(payment_date, '%d-%m-%Y') as payment_date,TIME(payment_date) as pay_time  from wallet_transaction inner join users on wallet_transaction.userId = users.id  left join Bookings on wallet_transaction.bookingId = Bookings.id Where DAY(payment_date) = DAY(NOW()) AND MONTH(payment_date) = MONTH(CURRENT_DATE()) AND YEAR(payment_date) = YEAR(CURRENT_DATE())");
		
		$week_rep = DB::Select("select wallet_transaction.id,wallet_transaction.userId, users.name,users.mobile,Bookings.bookingId,orderId,transactionId,amount,transation_status,type,DATE_FORMAT(payment_date, '%d-%m-%Y') as payment_date,TIME(payment_date) as pay_time  from wallet_transaction inner join users on wallet_transaction.userId = users.id  left join Bookings on wallet_transaction.bookingId = Bookings.id Where  YEARWEEK(payment_date) = YEARWEEK(NOW())");
		
		$month_rep = DB::Select("select wallet_transaction.id,wallet_transaction.userId, users.name,users.mobile,Bookings.bookingId,orderId,transactionId,amount,transation_status,type,DATE_FORMAT(payment_date, '%d-%m-%Y') as payment_date,TIME(payment_date) as pay_time  from wallet_transaction inner join users on wallet_transaction.userId = users.id  left join Bookings on wallet_transaction.bookingId = Bookings.id Where MONTH(payment_date) = MONTH(CURRENT_DATE()) AND YEAR(payment_date) = YEAR(CURRENT_DATE())");
		
		$year_rep = DB::Select("select wallet_transaction.id,wallet_transaction.userId, users.name,users.mobile,Bookings.bookingId,orderId,transactionId,amount,transation_status,type,DATE_FORMAT(payment_date, '%d-%m-%Y') as payment_date,TIME(payment_date) as pay_time  from wallet_transaction inner join users on wallet_transaction.userId = users.id  left join Bookings on wallet_transaction.bookingId = Bookings.id Where  YEAR(payment_date) = YEAR(CURRENT_DATE())");


         // echo json_encode($year_rep);die;

        $Days = DB::Select("Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Debit' AND DAY(payment_date) = DAY(NOW()) AND MONTH(payment_date) = MONTH(CURRENT_DATE()) AND YEAR(payment_date) = YEAR(CURRENT_DATE()) GROUP BY type UNION ALL Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Credit' AND DAY(payment_date) = DAY(NOW()) AND MONTH(payment_date) = MONTH(CURRENT_DATE()) AND YEAR(payment_date) = YEAR(CURRENT_DATE()) GROUP BY type");
		
		$Week = DB::Select("Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Debit' AND YEARWEEK(payment_date) = YEARWEEK(NOW()) GROUP BY type UNION ALL Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Credit' AND YEARWEEK(payment_date) = YEARWEEK(NOW()) GROUP BY type");
		
		$Month = DB::Select("Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Debit' AND  MONTH(payment_date) = MONTH(CURRENT_DATE()) AND YEAR(payment_date) = YEAR(CURRENT_DATE()) GROUP BY type UNION ALL Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Credit' AND  MONTH(payment_date) = MONTH(CURRENT_DATE()) AND YEAR(payment_date) = YEAR(CURRENT_DATE()) GROUP BY type");
		
		
		$Year = DB::Select("Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Debit' AND YEAR(payment_date) = YEAR(CURRENT_DATE()) GROUP BY type  UNION ALL Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Credit' AND YEAR(payment_date) = YEAR(CURRENT_DATE()) GROUP BY type");

       // echo json_encode($Days);die;

        $summary = DB::Select("Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Debit' GROUP BY type  UNION ALL Select COUNT(*) as orders,SUM(amount) as amount,type from wallet_transaction Where type='Credit' AND transation_status='TXN_SUCCESS' GROUP BY type");
	   
		// echo json_encode($summary);die;	   
		
		return view('report.wallet-report',['transaction'=>$transaction,'day_rep'=>$day_rep,'week_rep'=>$week_rep,'month_rep'=>$month_rep,'year_rep'=>$year_rep,'Days'=>$Days,'Week'=>$Week,'Month'=>$Month,'Year'=>$Year,'summary'=>$summary]);
	}
	
	
	public function WalletReportGraph(Request $Request){
    
        $wallet = DB::select("SELECT SUM(amount)as orders,DAY(createdAt) as ord_date,MONTH(createdAt) as ord_month,Year(createdAt) as ord_year FROM wallet_transaction Where DAY(createdAt) = DAY(NOW()) AND MONTH(createdAt) = MONTH(CURRENT_DATE()) AND YEAR(createdAt) = YEAR(CURRENT_DATE()) AND transation_status='TXN_SUCCESS' GROUP BY MONTH(createdAt), DAY(createdAt), YEAR(createdAt) ORDER BY ord_date desc, ord_month desc");
			foreach($wallet as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($wallet);

	}
	
	public function WalletReport(Request $Request){
		
		$id = $Request->id;
		$type = $Request->type;
		
		if($type == 'graph'){
			
			switch ($id) {
			case "1":
			
			 $wallet = DB::select("SELECT SUM(amount)as orders,DAY(createdAt) as ord_date,MONTH(createdAt) as ord_month,Year(createdAt) as ord_year FROM wallet_transaction Where DAY(createdAt) = DAY(NOW()) AND MONTH(createdAt) = MONTH(CURRENT_DATE()) AND YEAR(createdAt) = YEAR(CURRENT_DATE()) AND transation_status='TXN_SUCCESS' GROUP BY MONTH(createdAt), DAY(createdAt), YEAR(createdAt) ORDER BY ord_date desc, ord_month desc");
			foreach($wallet as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($wallet);
			
			break;
			
			case "2":
			
			$wallet = DB::select("SELECT SUM(amount)as orders,DAY(createdAt) as ord_date,MONTH(createdAt) as ord_month,Year(createdAt) as ord_year FROM wallet_transaction Where YEARWEEK(createdAt) = YEARWEEK(NOW()) AND transation_status='TXN_SUCCESS' GROUP BY MONTH(createdAt), DAY(createdAt), YEAR(createdAt) ORDER BY ord_date desc, ord_month desc");
		foreach($wallet as $Data){
			 
			 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
		 }
			
			return json_encode($wallet);
			
			break;
			
			case "3":
			
			$wallet = DB::select("SELECT SUM(amount)as orders,DAY(createdAt) as ord_date,MONTH(createdAt) as ord_month,Year(createdAt) as ord_year FROM wallet_transaction Where MONTH(createdAt) = MONTH(CURRENT_DATE()) AND YEAR(createdAt) = YEAR(CURRENT_DATE()) AND transation_status='TXN_SUCCESS' GROUP BY MONTH(createdAt), DAY(createdAt), YEAR(createdAt) ORDER BY ord_date desc, ord_month desc");
			foreach($wallet as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($wallet);
			
			break;
			
			case "4":
			
			$wallet = DB::select("SELECT SUM(amount)as orders,DAY(createdAt) as ord_date,MONTH(createdAt) as ord_month,Year(createdAt) as ord_year FROM wallet_transaction Where  YEAR(createdAt) = YEAR(CURRENT_DATE()) AND transation_status='TXN_SUCCESS' GROUP BY MONTH(createdAt), DAY(createdAt), YEAR(createdAt) ORDER BY ord_date desc, ord_month desc");
			foreach($wallet as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($wallet);
			
			break;
			default:
				echo "No data";

			}
		}else{
			
			
		
		switch ($id) {
			case "1":
			
			 $transaction = DB::select("select wallet_transaction.id,users.name,users.mobile,orderId,transactionId,amount,type,transation_status,payment_mode,bank_name,payment_date,Bookings.bookingId from wallet_transaction inner join users on wallet_transaction.userId = users.id LEFT JOIN Bookings ON wallet_transaction.bookingId=Bookings.id Where DAY(payment_date) = DAY(NOW()) AND  MONTH(payment_date) = MONTH(CURRENT_DATE()) AND YEAR(payment_date) = YEAR(NOW())");
			
			break;
			
			case "2":
			
			$transaction = DB::select("select wallet_transaction.id,users.name,users.mobile,orderId,transactionId,amount,type,transation_status,payment_mode,bank_name,payment_date,Bookings.bookingId from wallet_transaction inner join users on wallet_transaction.userId = users.id LEFT JOIN Bookings ON wallet_transaction.bookingId=Bookings.id Where YEARWEEK(payment_date) = YEARWEEK(NOW())");
			
			break;
			
			case "3":
			
			 $transaction = DB::select("select wallet_transaction.id,users.name,users.mobile,orderId,transactionId,amount,type,transation_status,payment_mode,bank_name,payment_date,Bookings.bookingId from wallet_transaction inner join users on wallet_transaction.userId = users.id LEFT JOIN Bookings ON wallet_transaction.bookingId=Bookings.id Where MONTH(payment_date) = MONTH(CURRENT_DATE()) AND YEAR(payment_date) = YEAR(NOW())");
		
			
			
			break;
			
			case "4":
			
			 $transaction = DB::select("select wallet_transaction.id,users.name,users.mobile,orderId,transactionId,amount,type,transation_status,payment_mode,bank_name,payment_date,Bookings.bookingId from wallet_transaction inner join users on wallet_transaction.userId = users.id left join Bookings on Bookings.id=wallet_transaction.bookingId Where  YEAR(payment_date) = YEAR(NOW())");
			 
			
			
			break;
			
			break;
			default:
				echo "No data";
		}
		
		
		foreach($transaction as $trans){
				
			 $tr_date  =  explode(" ",$trans->payment_date);

			  $t_date = $tr_date[0];		  
			  $t_time = $tr_date[1];		  
				
			  $trans->payment_date = 	date("d-m-Y", strtotime($t_date));
			  $trans->payment_time = $t_time;
			}
			
			 // echo json_encode($transaction);die;
			
			$description = "Wallet transaction reports (".date('d-m-Y').")";
		
            $CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_wallet_report($transaction,$description);die;
		
		$data= json_decode( json_encode($transaction), true);
		Excel::create('wallet-payment-report', function($excel) use($data) {
			$excel->sheet('Sheet 1', function($sheet) use($data) {
				$sheet->fromArray($data);
			});
		})->export('xls');
		
		}
		
	}
	
	
	public function custom_graph_wallet(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		
		$wallet = DB::select("SELECT SUM(amount)as orders,DAY(payment_date) as ord_date,MONTH(payment_date) as ord_month,Year(payment_date) as ord_year FROM wallet_transaction Where DATE(payment_date) BETWEEN '".$fromdate."' AND '".$todate."'  GROUP BY MONTH(payment_date), DAY(payment_date), YEAR(payment_date) ORDER BY ord_date desc, ord_month desc");
			foreach($wallet as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($wallet);
		
	}
	
	public function RevenueDownload(Request $Request){
	
	    $type = $Request->type;
		$id = $Request->id;
						
        if($type == 'graph'){
			
			
			switch ($id) {
			case "1":
			
			
			$TodayRep = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($TodayRep as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($TodayRep);
			
			break;
			
			case "2":
			
			$WeekRep = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND Status='COMPLETED' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate), YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($WeekRep as $Data){
				 
				$Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 return json_encode($WeekRep);
			
			break;
			
			case "3":
			
			$MonthRep = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($MonthRep as $Data){
				
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($MonthRep);
			
			break;
			
			case "4":
             
			 $YearRep = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where  YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($YearRep as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 return json_encode($YearRep);
			
			break;
           default:
		    echo "No data";die;
			
			
			
			}
			
			
		 }else{
						
        switch ($id) {
			case "1":
			 
			 $description = "Today revenue reports (".date('d-m-Y').")";
	   

			$CommonFunction = new CommonFunctions();
			$Bookings  = $CommonFunction->get_function_day();
			
			$Reports = $CommonFunction->get_excel_revunue($Bookings,$description);
			 
			break;
			
			case "2":
			 
			 $description = "Weekly revenue reports (".date('d-m-Y').")";

			$CommonFunction = new CommonFunctions();
			$Bookings  = $CommonFunction->get_function_week();
			$Reports = $CommonFunction->get_excel_revunue($Bookings,$description);
			
			break;
			
			case "3":
			
			  $description = "Monthly revenue reports (".date('d-m-Y').")";

			$CommonFunction = new CommonFunctions();
			$Bookings  = $CommonFunction->get_function_month();
			$Reports = $CommonFunction->get_excel_revunue($Bookings,$description);
			
			break;
			
			case "4":
			
			$description = "Yearly revenue reports (".date('d-m-Y').")";

			$CommonFunction = new CommonFunctions();
			$Bookings  = $CommonFunction->get_function_year();
			$Reports = $CommonFunction->get_excel_revunue($Bookings,$description);
			
			break;
           
		   break;
           default:
		   echo "No data";die;
		   
		   
		}			

	}
							
	}
	
	
	public function custom_revenue_graph(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		
		$revenue = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
		 foreach($revenue as $Data){
			 
			 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
		 }
		 
		 return json_encode($revenue);
		
	}
	
	public function ClothesReport(Request $Request){
		
		
		$id = $Request->id;
		$type = $Request->type;
		
		
		if($type == 'graph'){
			
			switch ($id) {
			case "1":  
			
			$day_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.Status='COMPLETED'  Group by CategoryList.id");
			
			
			$day_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.Status='COMPLETED'  Group by CategoryList.id");
		    
			return array("amount"=>$day_amount,"quantity"=>$day_qty);
			
			
			break;
			case "2":
			
			$week_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND Bookings.Status='COMPLETED'  Group by CategoryList.id");
			
			$week_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND Bookings.Status='COMPLETED'  Group by CategoryList.id");
			
			return array("amount"=>$week_amount,"quantity"=>$week_qty);
			
			
			break;
			case "3":
			
			
			$month_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.Status='COMPLETED'  Group by CategoryList.id");
			
			
			$month_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.Status='COMPLETED'  Group by CategoryList.id");
		    
			return array("amount"=>$month_amount,"quantity"=>$month_qty);
			
			break;
			case "4":
			
			$year_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.Status='COMPLETED'  Group by CategoryList.id");
			
			
			$year_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where  YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.Status='COMPLETED'  Group by CategoryList.id");
		    
			return array("amount"=>$year_amount,"quantity"=>$year_qty);
			
			break;
			
			default:
				echo "No data";
			}
			
		 }else{
		
		
		switch ($id) {
			case "1":

		    $description = "Cloths day reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_cloth_day();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
		
			case "2":
				
				$description = "Cloths week reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_cloth_week();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
				
				break;
			case "3":
				
			$description = "Cloths month reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_cloth_month();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
				
				break;
			case "4":
				
				$description = "Cloths year reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_cloth_year();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
				
				break;
			default:
				echo "No data";
		}
		
		
	  }
		
		
	}
	
	public function custom_category_graph(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$cateId =$Request->cateId;
		
		if(empty($cateId)){
		
		
		$day_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' Group by CategoryList.id");
			
			
		$day_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' Group by CategoryList.id");
		    
		return array("amount"=>$day_amount,"quantity"=>$day_qty);
		
		
		}else if(empty($fromdate) && empty($todate)){
			
			
		$day_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where CategoryList.id='".$cateId."' Group by CategoryList.id");
			
			
		$day_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where  CategoryList.id='".$cateId."' Group by CategoryList.id");
		    
		return array("amount"=>$day_amount,"quantity"=>$day_qty);
		
		// return $day_qty;
			
			
		}else if($fromdate && $todate && $cateId){
			
		$day_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND CategoryList.id='".$cateId."' Group by CategoryList.id");
			
			
		$day_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND CategoryList.id='".$cateId."' Group by CategoryList.id");
		    
		return array("amount"=>$day_amount,"quantity"=>$day_qty);
			
		}
		
	}
	
	
	
	public function NotUseBooking(Request $Request){
		
		$id = $Request->id;

		if ($id == 30) {
			$User = DB::select("SELECT `name`,`mobile`,`email`,last_booking FROM `users` Where last_booking < NOW() - INTERVAL 30 DAY Group by id ORDER BY `users`.`last_booking`  DESC");

			$description = "UserNotUse-Report for last (".$id." Days)";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_UserNotUse($User,$description);		

		}elseif ($id == 15) {
			$User = DB::select("SELECT `name`,`mobile`,`email`,last_booking FROM `users` Where last_booking < NOW() - INTERVAL 15 DAY Group by id ORDER BY `users`.`last_booking`  DESC");

			$description = "UserNotUse-Report for last (".$id." Days)";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_UserNotUse($User,$description);		
		}
		elseif ($id == 10) {
			$User = DB::select("SELECT `name`,`mobile`,`email`,last_booking FROM `users` Where last_booking < NOW() - INTERVAL 10 DAY Group by id ORDER BY `users`.`last_booking`  DESC");
		
			$description = "UserNotUse-Report for last (".$id." Days)";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_UserNotUse($User,$description);			
		}
		
		
		foreach($User as $data){
			
			$data->last_booking = date("d-m-Y", strtotime($data->last_booking)); 
		}
		
		
	}
	
	
	public function SlotReportDownload(Request $Request){
		
		
		$id = $Request->id;
		$type = $Request->type;
		
		
		if($type == 'graph'){
			
			
			switch ($id) {
			case "1":
			
			$slot = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY Bookings.bookingTimeSlot");
			 
			 return json_encode($slot);
			
			break;
			
			case "2":
			
			$slot = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) GROUP BY Bookings.bookingTimeSlot");
			 
			 return json_encode($slot);
			
			break;
			
			case "3":
			
			 $slot = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY Bookings.bookingTimeSlot");
			 
			 return json_encode($slot);
			
			break;
			
			case "4":
			
			
			 $slot = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY Bookings.bookingTimeSlot");
			 
			 return json_encode($slot);
			
			
			default:
				echo "No data";
			
			}
			
			
		}else{
		
		
		
		 switch ($id) {
    case "1":

	   $description = "TimeSlots Today reports (".date('d-m-Y').")";
	   

		$CommonFunction = new CommonFunctions();
		$query_fnc  = $CommonFunction->get_function_day();
		$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

	   
        break;
    case "2":
        
		
		    
		$description = "TimeSlots week reports (".date('d-m-Y').")";
	   
		$CommonFunction = new CommonFunctions();
		$query_fnc  = $CommonFunction->get_function_day();
		$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

        break;
    case "3":

	   
	    $description = "TimeSlots month reports (".date('d-m-Y').")";
		$CommonFunction = new CommonFunctions();
		$query_fnc  = $CommonFunction->get_function_month();
		$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

        break;
		
	case "4":

	    $description = "TimeSlots year reports (".date('d-m-Y').")";

		$CommonFunction = new CommonFunctions();
		$query_fnc  = $CommonFunction->get_function_year();
		$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

		
	   

	   
        break;
    default:
        echo "No record";
   }
		
		
	  }
		
	}
	
	
	public function custom_graph_timeslot(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$timeId =$Request->timeId;
		
		if(empty($timeId)){


			$slots = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' GROUP BY Bookings.bookingTimeSlot");
			
		    return  json_encode($slots);
			
		}else if(empty($fromdate) && empty($todate)){
			
			
			$slots = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND TimeSlots.id='".$timeId."' GROUP BY Bookings.bookingTimeSlot");
			
		    return  json_encode($slots);
			
		}else if($fromdate && $todate && $timeId){
		
		
		$slots = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND TimeSlots.id='".$timeId."' GROUP BY Bookings.bookingTimeSlot");
			
		   return  json_encode($slots);
		
		}
		
	}
	
	public function UserWalletReport(Request $Request,$id){
		
		
		
		 $CommonFunction = new CommonFunctions();
		 $wallet = $CommonFunction->wallet_trasnaction($id);
		 
		 
		 $data= json_decode( json_encode($wallet), true);
		Excel::create('wallet-transaction', function($excel) use($data) {
			$excel->sheet('Sheet 1', function($sheet) use($data) {
				$sheet->fromArray($data);
			});
		})->export('xls');
		
	}
	
	
	
	
	public function Categoty_Clothes(Request $Request,$id){
		
	
		switch ($id) {
			case "1":
			
			$description = "Cloths day reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_cloth_day();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
				
				
				break;
			case "2":
				
			$description = "Cloths week reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_cloth_week();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
				
				break;
				
			case "3":
				
				$description = "Cloths month reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_cloth_month();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
				
				break;
			case "4":
			
				$description = "Cloths year reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_cloth_year();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
				
				break;
			default:
				echo "Invalid data";
		}
		
	}
	
	
	public function Vendor_Report(Request $Request){
		
		$id = $Request->id;
		$userId = $Request->vendorId;
		$Vendorname = $Request->VendorName;
		
	
		
		switch ($id) {
			case "1":
			
			$day_rep = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y') as start_time,bookingId,quantity,totalPayment from Bookings Where Bookings.VendorUserId='".$userId."'  AND StartJob='2' AND DAY(Bookings.job_completed) = DAY(NOW()) AND MONTH(Bookings.job_completed) = MONTH(Bookings.job_completed) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) ORDER BY start_time"); 
			
			$description = "Cloths today reports (".date('d-m-Y').")";	
			$query_fnc =  json_decode( json_encode($day_rep), true);
			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description,$Vendorname);
			  
			break;
			
			case "2":
			
			$week_rep = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y') as start_time,bookingId,quantity,totalPayment from Bookings Where Bookings.VendorUserId='".$userId."'  AND StartJob='2' AND  YEARWEEK(Bookings.job_completed) = YEARWEEK(NOW()) ORDER BY start_time");

			$monday = strtotime("last sunday");
			$monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;

			$sunday = strtotime(date("d-m-Y",$monday)." +6 days");

			$this_week_sd = date("d-m-Y",$monday);
			$this_week_ed = date("d-m-Y",$sunday);

			 
			$description = "Cloths week reports From - ".$this_week_sd." - To - " .$this_week_ed. "(".date('d-m-Y').")";	
			$query_fnc =  json_decode( json_encode($week_rep), true);
			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description,$Vendorname);
			
			break;
			
			case "3":
			
			$month_rep = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y') as start_time,bookingId,quantity,totalPayment from Bookings Where Bookings.VendorUserId='".$userId."'  AND StartJob='2' AND MONTH(Bookings.job_completed) = MONTH(Bookings.job_completed) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) ORDER BY start_time"); 
			
			$description = "Cloths month reports (".date('d-m-Y').")";	
			$query_fnc =  json_decode( json_encode($month_rep), true);
			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description,$Vendorname);
			
			break;
			
			
			case "4":
			
			$year_rep = DB::select("select DATE_FORMAT(start_time, '%d/%m/%Y') as start_time,bookingId,quantity,totalPayment from Bookings Where Bookings.VendorUserId='".$userId."'  AND StartJob='2' AND  YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) ORDER BY start_time"); 
			
			$description = "Cloths year reports (".date('d-m-Y').")";	
			$query_fnc =  json_decode( json_encode($year_rep), true);
			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description,$Vendorname);
			
			break;
			default:
				echo "Invalid data";
			
			
		}
		
		 
	}
	
	public function Pickup_Report(Request $Request){
		
		$pickupId = $Request->pickupId;

		 $id = $Request->id;
		 $type = $Request->type;
		 
		 $CommonFunction = new CommonFunctions();
		 $response = $CommonFunction->pickuser_graph_rep($id,$type,$pickupId);
		 
		 return $response;
		
	}
	
	
	public function active_users_rep(Request $Request){
		
		$active_users = DB::SELECT("select name,mobile,email,alternate_number,dob,gender,referral_code,wallet_amount,last_booking,created_at from users where last_booking IS NULL AND name IS NOT NULL order by name asc");
		
		
		$description = "Inactive user report (".date('d-m-Y').")";			 
		$Bookings =  json_decode( json_encode($active_users), true);
		$CommonFunction = new CommonFunctions();
		$Reports = $CommonFunction->active_nonactive_rep($Bookings,$description);
	}
	
	
	
	public function download_user(Request $Request){
		
		$current_date = date('d-m-Y');
		
		$Users = User::select('name','mobile','email','image','alternate_number','dob','gender','referral_code','wallet_amount','created_at')->Where('name','!=',null)->orderBy('name','asc')->
		get()->
		toArray();
		
        Excel::create("user-list-".$current_date."", function($excel) use ($Users,$current_date) {
            $excel->sheet('mySheet', function($sheet) use ($Users,$current_date)
            {   
			    $sheet->row(1, ["User List - ".$current_date.""]);
				
                $sheet->mergeCells('A1:D1');
				
				$sheet->getStyle('A1:D1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A4', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B4', function($cell) {$cell->setValue('Name');   });
                $sheet->cell('C4', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('D4', function($cell) {$cell->setValue('image');   });
                $sheet->cell('E4', function($cell) {$cell->setValue('Alternate number');   });
                $sheet->cell('F4', function($cell) {$cell->setValue('DOB');   });
                $sheet->cell('G4', function($cell) {$cell->setValue('Gender');   });
                $sheet->cell('H4', function($cell) {$cell->setValue('Referral code');   });
                $sheet->cell('I4', function($cell) {$cell->setValue('Wallet amount');   });
                $sheet->cell('J4', function($cell) {$cell->setValue('Joining date');   });
                if (!empty($Users)) {
                    foreach ($Users as $key => $value) {
						$datetime = explode(" ",$value['created_at']);
                        $i= $key+5;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['name']); 
                        $sheet->cell('C'.$i, $value['mobile']); 
                        $sheet->cell('D'.$i, $value['image']); 
                        $sheet->cell('E'.$i, $value['alternate_number']); 
                        $sheet->cell('F'.$i, $value['dob']); 
                        $sheet->cell('G'.$i, $value['gender']); 
                        $sheet->cell('H'.$i, $value['referral_code']); 
                        $sheet->cell('I'.$i, $value['wallet_amount']); 
                        $sheet->cell('J'.$i, date("d-m-Y", strtotime($datetime[0]))); 
                    }
                }
            });
        })->export('xls');
		
	}
	
	
	public function UserBookingDown(Request $Request,$id){
		
		// $user_booking  = DB::select("select bookingId,quantity,paymentType,totalPayment,discount_amount,DeliverySuccessDate as payment_date from Bookings inner join users on users.id = Bookings.userId Where Bookings.userId='".$id."'");
		
		$current_date = date('d-m-Y');
		
		//// DB::raw("DATE_FORMAT(created_at, '%d-%m-%Y') as join_date")
		
		// PickupSuccessDate  H:i:s
		
		// $boo = Bookings::select('PickupSuccessDate',DB::raw("TIME(DeliverySuccessDate) as delivery_time"))->get();
		// $boo = Bookings::select('PickupSuccessDate',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as delivery_date"))->get();
		
		// echo json_encode($boo);die; 
		//delivery_date bookingDate
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  //->join('UserAddresses.serviceAreaId' , '=', 'Pincode','Pincode.id' )
		                      ->Where(['Bookings.userId'=>$id])
							  // ->limit(1)
		                      ->get()
							  ->toArray();
		
		$user = $Bookings[0]['username'];
		$mob = $Bookings[0]['usermobile'];
		
		// echo json_encode($Bookings);die;
		
		Excel::create("".$current_date."-bookings", function($excel) use ($Bookings,$current_date,$user,$mob) {
            $excel->sheet('mySheet', function($sheet) use ($Bookings,$current_date,$user,$mob)
            {   
			    $sheet->row(1, ["".$current_date."-Reports"]);
			    $sheet->row(2, ["Name : ".$user.""]);
			    $sheet->row(3, ["Mobile : ".$mob.""]);
				
                $sheet->mergeCells('A1:D1');
                $sheet->mergeCells('A2:D2');
                $sheet->mergeCells('A3:D3');
				
				$sheet->getStyle('A1:D1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A5', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B5', function($cell) {$cell->setValue('BookindId');   });
                $sheet->cell('C5', function($cell) {$cell->setValue('Booking date');   });
                $sheet->cell('D5', function($cell) {$cell->setValue('Delivery date');   });
                $sheet->cell('E5', function($cell) {$cell->setValue('Time Slots');   });
                $sheet->cell('F5', function($cell) {$cell->setValue('address');   });
                $sheet->cell('G5', function($cell) {$cell->setValue('quantity');   });
                $sheet->cell('H5', function($cell) {$cell->setValue('Status');   });
                $sheet->cell('I5', function($cell) {$cell->setValue('paymentType');   });
                $sheet->cell('J5', function($cell) {$cell->setValue('totalPayment');   });
                $sheet->cell('K5', function($cell) {$cell->setValue('discount_amount');   });
                $sheet->cell('L5', function($cell) {$cell->setValue('promocode');   });
                $sheet->cell('M5', function($cell) {$cell->setValue('Cancel reasons');   });
                $sheet->cell('N5', function($cell) {$cell->setValue('Order date');   });
                $sheet->cell('O5', function($cell) {$cell->setValue('Order time');   });
                $sheet->cell('P5', function($cell) {$cell->setValue('Way to pickup date');   });
                $sheet->cell('Q5', function($cell) {$cell->setValue('Way to pickup time');   });
                $sheet->cell('R5', function($cell) {$cell->setValue('Pickup success date');   });
                $sheet->cell('S5', function($cell) {$cell->setValue('Pickup success time');   });
                $sheet->cell('T5', function($cell) {$cell->setValue('Way to delivery date');   });
                $sheet->cell('U5', function($cell) {$cell->setValue('Way to delivery time');   });
                $sheet->cell('V5', function($cell) {$cell->setValue('delivery date');   });
                $sheet->cell('W5', function($cell) {$cell->setValue('delivery time');   });
                if (!empty($Bookings)) {
                    foreach ($Bookings as $key => $value) {
						
						if($value['reasons'] == null){
							
							$value['reasons'] = "";
						 }

                        $i= $key+6;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['bookingId']); 
                        $sheet->cell('C'.$i, $value['bookingDate']); 
                        $sheet->cell('D'.$i, $value['delivery_date']); 
                        $sheet->cell('E'.$i, $value['fromSlots'].'-'.$value['toSlots']); 
                        $sheet->cell('F'.$i, $value['address']); 
                        $sheet->cell('G'.$i, $value['quantity']); 
                        $sheet->cell('H'.$i, $value['Status']); 
                        $sheet->cell('I'.$i, $value['paymentType']); 
                        $sheet->cell('J'.$i, $value['totalPayment']); 
                        $sheet->cell('K'.$i, $value['discount_amount']); 
                        $sheet->cell('L'.$i, $value['promocode']); 
                        $sheet->cell('M'.$i, $value['reasons']); 
                        $sheet->cell('N'.$i, $value['confirm_date']); 
                        $sheet->cell('O'.$i, $value['confirm_time']); 
                        $sheet->cell('P'.$i, $value['waypick_date']); 
                        $sheet->cell('Q'.$i, $value['waypick_time']); 
                        $sheet->cell('R'.$i, $value['pickup_date']); 
                        $sheet->cell('S'.$i, $value['pickup_time']); 
                        $sheet->cell('T'.$i, $value['waydeli_date']); 
                        $sheet->cell('U'.$i, $value['waydeli_time']); 
                        $sheet->cell('V'.$i, $value['deli_date']); 
                        $sheet->cell('W'.$i, $value['delivery_time']); 
                    }
                }
            });
        })->export('xls');
		
	}
	
	
	
	public function download_pickup(Request $Request){
		$current_date = date('d-m-Y');
		$Users = pickupdeliveryuser::select('pickupdeliveryusers.name','pickupdeliveryusers.mobile','pickupdeliveryusers.email','image','dob','gender','pickupdeliveryusers.address','serviceAreaId',DB::raw("DATE_FORMAT(pickupdeliveryusers.created_at, '%d-%m-%Y') as joining_date"))
		                              ->Where('pickupdeliveryusers.name','!=',null)
									  ->Where('Is_active','!=',2)
									  ->orderBy('name','asc')
									  ->get()
									  ->toArray();
		
		
		 Excel::create("pickup-user-".$current_date."", function($excel) use ($Users,$current_date) {
            $excel->sheet('mySheet', function($sheet) use ($Users,$current_date)
            {   
			    $sheet->row(1, ["pickup-user - ".$current_date.""]);
				
                $sheet->mergeCells('A1:D1');
				
				$sheet->getStyle('A1:D1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A4', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B4', function($cell) {$cell->setValue('Name');   });
                $sheet->cell('C4', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('D4', function($cell) {$cell->setValue('Email');   });
                $sheet->cell('E4', function($cell) {$cell->setValue('DOB');   });
                $sheet->cell('F4', function($cell) {$cell->setValue('Gender');   });
                $sheet->cell('G4', function($cell) {$cell->setValue('Address');   });
                $sheet->cell('H4', function($cell) {$cell->setValue('image');   });
                $sheet->cell('I4', function($cell) {$cell->setValue('Joining date');   });
                if (!empty($Users)) {
                    foreach ($Users as $key => $value) {
                        $i= $key+5;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['name']); 
                        $sheet->cell('C'.$i, $value['mobile']); 
                        $sheet->cell('D'.$i, $value['email']); 
                        $sheet->cell('E'.$i, $value['dob']); 
                        $sheet->cell('F'.$i, $value['gender']); 
                        $sheet->cell('G'.$i, $value['address']); 
                        $sheet->cell('H'.$i, $value['image']); 
                        $sheet->cell('I'.$i, $value['joining_date']); 
                    }
                }
            });
        })->export('xls');
		
	}
	
	
	
	public function download_vendor(Request $Request){
		
		$current_date = date('d-m-Y');
		$Users = IroningVendor::select('name','mobile','email','dob','gender','image',DB::raw("DATE_FORMAT(created_at, '%d-%m-%Y') as joining_date"))->Where('name','!=',null)->Where('Is_active','!=',2)->orderBy('name','asc')->get();
		
		 Excel::create("vendor-".$current_date."", function($excel) use ($Users,$current_date) {
            $excel->sheet('mySheet', function($sheet) use ($Users,$current_date)
            {   
			    $sheet->row(1, ["vendor - ".$current_date.""]);
				
                $sheet->mergeCells('A1:D1');
				
				$sheet->getStyle('A1:D1')->applyFromArray(array(
                    'font' => array(
					'name'      =>  'Calibri',
					'size'      =>  15,
					'bold'      =>  true,
					'color'      => array('rgb' => '000')
				)
				));
				

				$sheet->getStyle('A1:D1')->getAlignment()->applyFromArray(
					array('horizontal' => 'center')
				);
                $j=1;
                $sheet->cell('A4', function($cell) {$cell->setValue('S.No');   });
                $sheet->cell('B4', function($cell) {$cell->setValue('Name');   });
                $sheet->cell('C4', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('D4', function($cell) {$cell->setValue('Email');   });
                $sheet->cell('E4', function($cell) {$cell->setValue('DOB');   });
                $sheet->cell('F4', function($cell) {$cell->setValue('Gender');   });
                $sheet->cell('G4', function($cell) {$cell->setValue('image');   });
				$sheet->cell('h4', function($cell) {$cell->setValue('Joining date');   });
                if (!empty($Users)) {
                    foreach ($Users as $key => $value) {
                        $i= $key+5;
                        $sheet->cell('A'.$i, $j++); 
                        $sheet->cell('B'.$i, $value['name']); 
                        $sheet->cell('C'.$i, $value['mobile']); 
                        $sheet->cell('D'.$i, $value['email']); 
                        $sheet->cell('E'.$i, $value['dob']); 
                        $sheet->cell('F'.$i, $value['gender']); 
                        $sheet->cell('G'.$i, $value['image']); 
                        $sheet->cell('H'.$i, $value['joining_date']); 
                    }
                }
            });
        })->export('xls');
		
	}
	
	
	
	
}