<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\User;
use App\pickupdeliveryuser;
use App\IroningVendor;
use App\Admin;
use App\ServiceAreas;
use App\UserAddresses;
use App\TimeSlots;
use App\Pincode;
use App\Promocode;
use App\Categories;
use App\CategoryList;
use App\Bookings;
use App\BookingItems;
use App\Warehouses;
use App\CustomerSupport;
use App\CommonFunctions;
use Auth;
use Mail;
use DateTime;
use Excel;
use Validator;
use DB;
use PDF;

class SearchReportController extends Controller
{
	
	
	public function __construct()
    {
        $this->middleware('auth:admin');
    }
	
	public function SearchTimeSlots(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$timeId =$Request->timeId;
		
		

		
		
		if(empty($timeId)){

			$slots = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  order by Bookings.id desc");
			
		    return $slots;
			
		}else if(empty($fromdate) && empty($todate)){
			
			
			$slots = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND  TimeSlots.id='".$timeId."' order by Bookings.id desc");
			
		    return $slots;
			
		}else if($fromdate && $todate && $timeId){
		
		
		$slots = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND TimeSlots.id='".$timeId."' order by Bookings.id desc");
			
		    return $slots;
		
		}
	
		
	}
	
	
	
	public function search_slot_download(Request $Request){
		
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$timeId =$Request->timeId;
		
		
		$current = date('d-m=Y');
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		
		if(empty($timeId)){

          $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $description = "TimeSlots reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}else if(empty($fromdate) && empty($todate)){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.bookingTimeSlot'=>$timeId])
		                      ->get()
							  ->toArray();
			
			 $get_pin = DB::table('TimeSlots')->Select('id','fromSlots','toSlots')->Where('id',$timeId)->first();
			
			 $description = "Pincode reports - ".$get_pin->fromSlots." - ".$get_pin->toSlots." (".$current.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}else if($fromdate && $todate && $timeId){
		
		     $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.bookingTimeSlot'=>$pinId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
			
			 $description = "TimeSlots reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
		
		
		}
		
		
		
	}
	
	
	public function SearchPincode(Request $Request){
		
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pinId =$Request->pinId;
		// $pindays =$Request->pindays;
		// $report = 1;
		// if($pindays == ''){
			
			// $report = 0;
		// }
		
		if(empty($pinId)){
			
			
			$Pincode = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Pincode.code FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' order by Bookings.id desc");
			
		
		    return $Pincode;
		}else if(empty($fromdate) && empty($todate)){
			
			$Pincode = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Pincode.code FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Pincode.id='".$pinId."' order by Bookings.id desc");
			
		    return $Pincode;
			
		}else if($fromdate && $todate && $pinId){
		
		$Pincode = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Pincode.code FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Pincode.id='".$pinId."' order by Bookings.id desc");
		
		return $Pincode;
		}
		
	}
	
	public function search_pin_download(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pinId =$Request->pinId;
		$current = date('d-m-Y');
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		if(empty($pinId)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $description = "Pincode reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if(empty($fromdate) && empty($todate)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.service_area'=>$pinId])
							  // ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $get_pin = DB::table('Pincode')->Select('id','code')->Where('id',$pinId)->first();
			
			 $description = "Pincode reports - ".$get_pin->code." (".$current.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if($fromdate && $todate && $pinId){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.service_area'=>$pinId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $description = "Pincode reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}else die;
		
		$Pincode = DB::select("SELECT Pincode.code as pincode,COUNT(*) as orders,SUM(quantity) as quantity,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  GROUP by Bookings.service_area");
		
		$data= json_decode( json_encode($Pincode), true);
		Excel::create('pincode-report', function($excel) use($data) {
			$excel->sheet('Sheet 1', function($sheet) use($data) {
				$sheet->fromArray($data);
			});
		})->export('xls');
		
		
	}
	
	
	public function SearchPaymentType(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$paytypeId =$Request->paytypeId;
		
		
		if(empty($paytypeId)){
			
	
			
			$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Bookings.PaymentType FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' order by Bookings.id desc");
			
		
		    return $Result;
		}else if(empty($fromdate) && empty($todate)){
			
			$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Bookings.PaymentType FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.PaymentType='".$paytypeId."' order by Bookings.id desc");
			
           return $Result;
			
		}else if($fromdate && $todate && $paytypeId){
		

		
		$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Bookings.service_area,Bookings.PaymentType FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Bookings.PaymentType='".$paytypeId."' order by Bookings.id desc");
		
		return $Result;
		}
		

		
	}
	
	public function search_payment_download(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$paytypeId =$Request->paytypeId;
		
		$current = date('d-m=Y');
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		if(empty($paytypeId)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			
			 $description = "payment type reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if(empty($fromdate) && empty($todate)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.PaymentType'=>$paytypeId])
							  // ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			
			
			 $description = "Payment type reports - ".$paytypeId." (".$current.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if($fromdate && $todate && $pinId){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.PaymentType'=>$paytypeId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $description = "Pincode reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}
		
		// $PaymentType = DB::select("SELECT Bookings.paymentType,COUNT(id)as orders,SUM(quantity) as quantity,SUM(totalPayment) as total FROM Bookings Where DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");
		
		// $data= json_decode( json_encode($PaymentType), true);
		// Excel::create('payment-type-report', function($excel) use($data) {
			// $excel->sheet('Sheet 1', function($sheet) use($data) {
				// $sheet->fromArray($data);
			// });
		// })->export('xls');
		
		
	}
	
	
	public function SearchOrderStatus(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$typeId =$Request->typeId;
		//CancelDate
		
		
		if(empty($typeId)){
			
	          
			  $Result  =   DB::select("SELECT *
						FROM (
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' )
						UNION
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Status = 'CANCELLED' AND DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."')
						) AS i
						ORDER BY id DESC");
			
		
		    return $Result;
		}else if(empty($fromdate) && empty($todate)){

				
				$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id  Where Bookings.Status='".$typeId."' ORDER BY Bookings.id DESC");

			
           return $Result;
			
		}else if($fromdate && $todate && $typeId){
		
          if($typeId == 'COMPLETED'){
		
		$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id  Where Bookings.Status='".$typeId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  ORDER BY Bookings.id DESC");
		
		  }else if($typeId == 'CANCELLED'){
			  
			  
			  $Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id Where Bookings.Status='".$typeId."' AND DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."'  ORDER BY Bookings.id DESC");
			  
		  }
		  else if($typeId == 'CONFIRMED'){
			  
			  
			  $Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id Where Bookings.Status='".$typeId."' AND DATE(OrderConfirmDate) BETWEEN '".$fromdate."' AND '".$todate."'  ORDER BY Bookings.id DESC");
			  
		  }
		
		
		return $Result;
		}

		
	}

	public function InactiveUser(Request $Request){

		$noofdays =$Request->noofdays;

		if ($noofdays == '10') {
			$User = DB::select("SELECT `name`,`mobile`,`email`,DATE_FORMAT(last_booking, '%d-%m-%Y') as last_booking FROM `users` Where last_booking < NOW() - INTERVAL 10 DAY Group by id ORDER BY `users`.`last_booking`  DESC");
			return $User;
			
		}
		else if($noofdays == '15'){
			$User = DB::select("SELECT `name`,`mobile`,`email`,DATE_FORMAT(last_booking, '%d-%m-%Y') as last_booking FROM `users` Where last_booking < NOW() - INTERVAL 15 DAY Group by id ORDER BY `users`.`last_booking`  DESC");
			return $User;
		}
		else if($noofdays == '30'){
			$User = DB::select("SELECT `name`,`mobile`,`email`,DATE_FORMAT(last_booking, '%d-%m-%Y') as last_booking FROM `users` Where last_booking < NOW() - INTERVAL 30 DAY Group by id ORDER BY `users`.`last_booking`  DESC");
			return $User;
		}
		
	}
	
	public function search_orderstatus_download(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$typeId =$Request->typeId;
		
		     $f_date = date("d-m-Y", strtotime($fromdate));
		     $t_date = date("d-m-Y", strtotime($todate));
			
		
		if(empty($typeId)){
		
		// $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      // ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      // ->join('users','users.id', '=', 'Bookings.userId')
							  // ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  // ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  // ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  // ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  // ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  // ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  // ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->orwhereRaw("DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      // ->get()
							  // ->toArray();
							  
			$report_1 = DB::SELECT("select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where Bookings.Status = 'COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' UNION ALL select Bookings.id,Bookings.bookingId,pickupDeliveryUserId,users.name as username,users.mobile as usermobile,users.email as useremail,bookingDate,Bookings.Status,'Pickup',DATE_FORMAT(delivery_date, '%d-%m-%Y') as delivery_date,TimeSlots.fromSlots,TimeSlots.toSlots,Pincode.code,UserAddresses.address,UserAddresses.flatNo,UserAddresses.landmark,Bookings.quantity,DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date,TIME(OrderConfirmDate) as confirm_time,TIME(WaytoPickupDate) as waypick_time,DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date,DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date ,TIME(PickupSuccessDate) as pickup_time,TIME(DeliveryDate) as waydeli_time,DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date,DeliverySuccess,DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date,TIME(DeliverySuccessDate) as delivery_time,CancelDate,cancelReason,StartJob,taxamount,totalPayment,discount_amount,CancelReason.reasons,Bookings.promode_code,Bookings.paymentType,promocode.promocode from Bookings inner join users on users.id = Bookings.userId inner join TimeSlots on TimeSlots.id = Bookings.bookingTimeSlot inner join UserAddresses on UserAddresses.id = Bookings.addressId left join CancelReason on CancelReason.id = Bookings.CancelReason left join promocode on promocode.id = Bookings.promode_code inner join Pincode on Pincode.id = Bookings.service_area Where Bookings.Status = 'CANCELLED' AND DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."'  order by id desc");
		
            $description = "success - cancelled reports (".$f_date." - ".$t_date.")";
			$query_fnc =  json_decode( json_encode($report_1), true);
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);	
		
            $description = "success - cancelled reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);		
							  
		}else if(empty($fromdate) && empty($todate)){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.Status',$typeId)
		                      ->get()
							  ->toArray();
			
			$current = date('d-m-Y');
			
			
			 $description = "success - cancelled  - ".$typeId." (".$current.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);	
			
		}else if($fromdate && $todate && $typeId){
			
			if($typeId == 'COMPLETED'){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.Status',$typeId)
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
							  
		}else{
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.Status',$typeId)
							  ->whereRaw("DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
			
		}
							  
		    $description = "Orders report - ".$typeId." (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}
							  
		
	}
	
	
	public function SearchRevenue(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		
		 
		 $revenue = DB::select("select id,bookingId,bookingDate,Status from Bookings Where Status='COMPLETED' AND  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' order by id desc");
		 
		 return $revenue;
		 
		  // $revenue = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
		 // foreach($revenue as $Data){
			 
			 // $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
		 // }
		
		// return $revenue;
	}
	
	public function Search_revenue_download(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		 
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
		
            $description = "Revenue reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_revunue($Bookings,$description);
							

	}
	
	public function SearchPromocode(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$promoId =$Request->promoId;
		
		// return $fromdate;die;
		
		if(empty($promoId)){
			
		$Promo_report = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' order by Bookings.id desc");
		
		return $Promo_report;
		
		}else if(empty($fromdate) && empty($todate)){
			
			
			$Promo_report = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED'  AND promocode.id='".$promoId."' order by Bookings.id desc");
		
		return $Promo_report;
			
		}else if($fromdate && $todate && $promoId){
			
			
			$Promo_report = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED'  AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND promocode.id='".$promoId."' order by Bookings.id desc");
		
		return $Promo_report;
			
			
		}
		
	}
	
	public function Search_promo_download(Request $Request){
		

		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$promoId =$Request->promoId;
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		
		if(empty($promoId)){
			
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.promode_code', '!=' , 0)
		                      ->Where(['Bookings.Status'=>'COMPLETED'])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
			  $description = "Promocode reports (".$f_date." - ".$t_date.")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);				  

		
		}else if(empty($fromdate) && empty($todate)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.promode_code', '!=' , 0)
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.promode_code'=>$promoId])
							  // ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
			  $description = "Promocode reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if($fromdate && $todate && $promoId){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%m-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%m-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%m-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%m-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%m-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.promode_code', '!=' , 0)
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.promode_code'=>$promoId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
							  
			  $description = "Promocode reports (".$f_date." - ".$t_date.")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}die;
		
		
		$Promo_report = DB::select("select promocode.promocode,users.name,users.mobile,Bookings.quantity,Bookings.totalPayment,Bookings.discount_amount  FROM Bookings inner join promocode on Bookings.promode_code = promocode.id inner join users on users.id = Bookings.userId Where promode_code !=0 AND Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' ");
		
		$data= json_decode( json_encode($Promo_report), true);					
		 
		 Excel::create('promocode-report', function($excel) use($data) {
			$excel->sheet('Sheet 1', function($sheet) use($data) {
				$sheet->fromArray($data);  
			});
		})->export('xls');
		
	}
	
	public function SearchWalletReport(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		 $month = date('m');
		 $year = date('Y');
		 
		 
		 
		$WalletReport = DB::select("select wallet_transaction.id,Bookings.bookingId,wallet_transaction.userId,users.name,users.mobile,orderId,transactionId,amount,type,transation_status,payment_mode,bank_name,payment_date from wallet_transaction inner join users on wallet_transaction.userId = users.id LEFT JOIN Bookings ON wallet_transaction.bookingId=Bookings.id Where DATE(payment_date) BETWEEN '".$fromdate."' AND '".$todate."' ");
		
		foreach($WalletReport as $trans){
				
			 $tr_date  =  explode(" ",$trans->payment_date);

			  $t_date = $tr_date[0];		  
			  $t_time = $tr_date[1];		  
				
			  $trans->payment_date = 	date("d-m-Y", strtotime($t_date));
			  $trans->payment_time = $t_time;
			}
		 
		 return $WalletReport;
		
	}
	
	public function Search_wallet_download(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		
		$transaction = DB::select("select wallet_transaction.id,Bookings.bookingId,users.name,users.mobile,orderId,transactionId,amount,type,transation_status,payment_mode,bank_name,payment_date from wallet_transaction inner join users on wallet_transaction.userId = users.id LEFT JOIN Bookings ON wallet_transaction.bookingId=Bookings.id Where DATE(payment_date) BETWEEN '".$fromdate."' AND '".$todate."' ");
		
		foreach($transaction as $trans){
				
			 $tr_date  =  explode(" ",$trans->payment_date);

			  $t_date = $tr_date[0];		  
			  $t_time = $tr_date[1];		  
				
			  $trans->payment_date = 	date("d-m-Y", strtotime($t_date));
			  $trans->payment_time = $t_time;
			}
			
			 // echo json_encode($transaction);die;
			
			$description = "Wallet transaction reports (".date('d-m-Y').")";
		
            $CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_wallet_report($transaction,$description);die;
		
		
		
	}
	
	public function SearchClothesReport(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$cateId =$Request->cateId;
		
		if(empty($cateId)){
		
		$data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND  DeliverySuccess='1'   Group by CategoryList.id");
		
		return $data;
		
		}else if(empty($fromdate) && empty($todate)){
			
			
			$data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where CategoryList.id='".$cateId."' AND DeliverySuccess='1'   Group by CategoryList.id");
			return $data;
		}else if($fromdate && $todate && $cateId){
			
			
			$data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND CategoryList.id='".$cateId."' AND DeliverySuccess='1'  Group by CategoryList.id");
		
		return $data;
			
		}
		
	}
	
	public function Search_clothes_download(Request $Request){
		
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		$clothes = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  Group by CategoryList.id");
		
		$data= json_decode( json_encode($clothes), true);					
		 
		 Excel::create('clothes-report', function($excel) use($data) {
			$excel->sheet('Sheet 1', function($sheet) use($data) {
				$sheet->fromArray($data);  
			});
		})->export('xls');
		
	}
	
	
	public function SearchCategoryReports(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		
		
		$Clothes = DB::select("select NewCategories.name,groupName,SUM(Booking_Items.quantity) as quantity,SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  Group by Booking_Items.categoryId");  
		
		
		foreach($Clothes as $Report){
			
			$Report->name  = $Report->groupName. " / " . $Report->name;
			unset($Report->groupName);
			
		}
		
		return $Clothes;
		
	}
	
	public function Category_clothes_download(Request $Request){
		
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$cateId =$Request->cateId;
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		if(empty($cateId)){
		
		
		$description = "Clothes reports (".$f_date." - ".$t_date.")";

		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND DeliverySuccess='1'  Group by Booking_Items.categoryId"); 
		
		$query_fnc = json_decode( json_encode($day_rep), true);

		$CommonFunction = new CommonFunctions();
		$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
		
		}else if(empty($fromdate) && empty($todate)){
			
			$rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where CategoryList.id='".$cateId."' AND DeliverySuccess='1'  Group by Booking_Items.categoryId"); 
			
			$query_fnc = json_decode( json_encode($rep), true);
			
			
			$category = DB::table('CategoryList')->select('id','name')->Where(['status'=>1,'id'=>$cateId])->first();
			
			$description = "Clothes reports - ".$category->name." (".date('d-m-Y').")";

			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
			
		}else if($fromdate && $todate && $cateId){
			

			
			$rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where CategoryList.id='".$cateId."' AND DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  AND DeliverySuccess='1' Group by Booking_Items.categoryId"); 
			
			$query_fnc = json_decode( json_encode($rep), true);
			
			
			$category = DB::table('CategoryList')->select('id','name')->Where(['status'=>1,'id'=>$cateId])->first();
			
			$description = "Clothes reports - ".$category->name." (".$f_date." - ".$t_date.")";

			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_clothes_reports($query_fnc,$description);
			
		}
		

		
	}
	
	public function SearchAvgCost(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;

		$Year = DB::select("SELECT sum(a1.quantity) as quantity,a2.categoryId as maincatid,a3.price as price,a3.name as Categoryname,sum(a1.quantity) * a3.price as payments FROM `Booking_Items` as a1 LEFT OUTER JOIN NewCategories as a2 on a1.categoryId=a2.id  left outer join CategoryList as a3 on a3.id=a2.categoryId WHERE a1.delivery='1' and  DATE(a1.updatedAt) BETWEEN '".$fromdate."' AND '".$todate."' GROUP BY a2.categoryId ");

		 $arr = [];
		 $qu = [];
		
		
		if(count($Year) > 0){
		
			foreach($Year as $rep){
				
				$stdyear = (object) array();

				$stdyear->Categoryname  = $rep->Categoryname;
				$stdyear->payments  = $rep->payments;
				$stdyear->quantity  = $rep->quantity;;
				
				array_push($arr, $stdyear);

				array_push($qu, $rep->quantity);
			}

			$Totalquantity4=array_sum($qu);
			$stdyear=$arr;
		
		}else{
			
			$stdyear = (object) array();
			$stdyear->Categoryname  ="";
			$stdyear->payments  = 0;
			$stdyear->quantity  = 0;
			$stdyear->avg_cost  = 0;
			array_push($arr, $stdyear);
			$Totalquantity4 = 0;
			$stdyear=$arr;
		}
		 //$Year = DB::select("select SUM(totalPayment) as payment ,SUM(quantity) as quantity from Bookings Where DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  AND DeliverySuccess ='1' ");
		
		
		// $arr = [];
		// if(!$Year[0]->payment == null){
		
		// if(count($Year) > 0){
		
		// foreach($Year as $rep){
			
		// 	$stdyear = (object) array();
		// 	$stdyear->payment  = $rep->payment;
		// 	$stdyear->quantity  = $rep->quantity;
			
		// 	$year_sum  = $rep->payment / $rep->quantity;
		
		// 	$year_avg  =  round($year_sum * 100 / 118, 2);
			
		// 	$stdyear->avg_cost  = $year_avg;
			
		// 	array_push($arr,$stdyear);
		// }
		
		// }else{
			
		// 	$stdyear = (object) array();
		// 	$stdyear->payment  = 0;
		// 	$stdyear->quantity  = 0;
		// 	$stdyear->avg_cost  = 0;
		// }
		
		// }else{
			
		// 	$stdyear = (object) array();
		// 	$stdyear->payment  = 0;
		// 	$stdyear->quantity  = 0;
		// 	$stdyear->avg_cost  = 0;
		// }
		
		// $new  = json_encode($stdyear);
		$Result = array($Totalquantity4,$stdyear);
		
		 return $Result;
		
	}
	
	public function SearchVendorReports(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$vendorId =$Request->vendorId;
		
		$CommonFunction = new CommonFunctions();
		$response = $CommonFunction->search_vendor_rep($fromdate,$todate,$vendorId);
		
		return $response;

	}
	
	public function Vendor_clothes_download(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$vendorId =$Request->vendorId;
		$VendorName =$Request->VendorName;
		
		$CommonFunction = new CommonFunctions();
		$response = $CommonFunction->search_vendor_download($fromdate,$todate,$vendorId,$VendorName);
		
		
	}
	
	public function SearchPickupReports(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pickupId =$Request->pickupId;
	
		
		$report = DB::Select("SELECT id,bookingDate,bookingId,Status, 'Pickup'  FROM Bookings WHERE DATE(Bookings.PickupSuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND pickupDeliveryUserId='".$pickupId."' AND PickupSuccess='1'  UNION ALL SELECT id,bookingDate,bookingId,Status, 'Delivery' FROM Bookings WHERE DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND DeliveryUserId='".$pickupId."' AND DeliverySuccess='1'  order by id desc");
		
		
		return $report;
		
	}
	
	public function Pickup_order_dowmload(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pickupId =$Request->pickupId;
		
		
		$CommonFunction = new CommonFunctions();
		$Order = $CommonFunction->search_pickup_down($fromdate,$todate,$pickupId);
		
		
	}
	
	
	/*****************************************New Search *****************************************/
	
	public function slots_search_report(Request $Request){
		
		$id = $Request->id;
		
		switch ($id) {
			case "1":
			
			$Order = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code,Bookings.quantity,Bookings.totalPayment FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DeliverySuccess='1' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) ");
		
		return $Order;
			
			break;
			
			case "2":
			
			$Order = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code,Bookings.quantity,Bookings.totalPayment FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DeliverySuccess='1' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) ");
		
		return $Order;
			
			break;
			
			
			case "3":
			
			$Order = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code,Bookings.quantity,Bookings.totalPayment FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DeliverySuccess='1' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) ");
		
		return $Order;
			
			break;
			
			
			case "4":
			$Order = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code,Bookings.quantity,Bookings.totalPayment FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DeliverySuccess='1' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) ");
		
		return $Order;
			
			break;
			
			default;
			   echo 'No data';
			break;
			
		}
			

		
		
		
	}
	
	
	
}