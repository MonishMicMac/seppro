<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Validator;
use Illuminate\Support\Facades\Input;
use App\Warehouses;
use App\User;
use App\pickupdeliveryuser;
use App\IroningVendor;
use App\Admin;
use App\ServiceAreas;
use App\UserAddresses;
use App\TimeSlots;
use App\Pincode;
use App\Promocode;
use App\Categories;
use App\CategoryList;
use App\Bookings;
use App\BookingItems;
use App\CustomerSupport;
use App\CommonFunctions;
use App\OutletFunctions;
use Auth;
use Mail;
use DateTime;
use DB;

class WarehousesController extends Controller
{
    /**
     * Create a new controller instance.
     *WarehousesController.php
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:warehouse');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		
		$id = Auth::user()->id;
		
		$Users = User::Select('id')->whereNotNull('email')->count();
		$PickupUser = pickupdeliveryuser::Select('id','warehouseId')->where('warehouseId',$id)->count();
		$Ironing = IroningVendor::Select('id')->count();
		$total_booking = Bookings::Select('id')->Where(['warehouseId'=>$id])->count();
		$Bookings = Bookings::Select('id')->Where(['Bookings.Status'=>'COMPLETED','warehouseId'=>$id])->count();
		$pending = Bookings::Select('id')->Where(['Bookings.Status'=>'CONFIRMED','warehouseId'=>$id])->count();
		$cancelled = Bookings::Select('id')->Where(['Bookings.Status'=>'CANCELLED','warehouseId'=>$id])->count();
		
		return view('warehouse.warehouse',['id'=>$id,'Users'=>$Users,'PickupUser'=>$PickupUser,'Ironing'=>$Ironing,'Bookings'=>$Bookings,'total_booking'=>$total_booking,'pending'=>$pending,'cancelled'=>$cancelled]);  
		 	

    }
	
	
	public function OutletUserList(Request $Request){
		
		
		$CommonFunction = new CommonFunctions();
		$List = $CommonFunction->GetUsers();
		
		return view('warehouse.UsersList',['UserList'=>$List]);
		
	}
	
	
	public function OutletUserDetails(Request $Request,$id){
		
		$CommonFunction = new CommonFunctions();
		$Details = $CommonFunction->GetUserDetails($id);
		
		$UserDetails = $Details['User'];
		$BookingsDetails = $Details['Bookings'];
		$UserAddr = $Details['UserAddress'];
		$order = $Details['orders'];
		return view('warehouse.UserDetails',['GetUserDetails'=>$UserDetails,'BookingsList'=>$BookingsDetails,'Address'=>$UserAddr,'order'=>$order]);
	}
	
	public function OutWalletReportTrans(Request $Request){
		
		  $id = $Request->id;
		
	     $CommonFunction = new CommonFunctions();
		 $wallet = $CommonFunction->wallet_trasnaction($id);
		 
		return view('warehouse.wallet-transaction',['id'=>$id,'Transc'=>$wallet]);
		
	}
	
	public function WarPickupUser(Request $Request){
		
		$id = Auth::user()->id;
		$OutletFunction = new OutletFunctions();
		$PickupUsers = $OutletFunction->war_pickup_list($id);
		
		return view('warehouse.PickupUserList',['id'=>$id,'User' => $PickupUsers]);
	}
	
	
	public function WarPickupReport(Request $Request){
		
		$id = $Request->id;
		$pickupId = $Request->pickupId;

		$userId = $pickupId; 
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->out_pickup_reports($userId);

		$TodayReport  =$response['TodayOrder'];
		$WeekReport  =$response['WeekOrder'];
		$MonthReport  =$response['MonthOrder'];
		$MonthReport  =$response['MonthOrder'];
		$YearReport  =$response['YearOrder'];
		$Days  =$response['Days'];
		$Months  =$response['Months'];
		$Months  =$response['Months'];
		$Years  =$response['Years'];
		$Weeks  =$response['Weeks'];

		 
		return view('warehouse.PickupUser',['id'=>$id,'userId'=>$userId,'TodayOrder'=>$TodayReport,'WeekOrder'=>$WeekReport,'MonthOrder'=>$MonthReport,'YearOrder'=>$YearReport,'Days'=>$Days,'Months'=>$Months,'Years'=>$Years,'Weeks'=>$Weeks]);
	}
	
	public function WarPickuserDay(Request $Request){
		
		$id = $Request->id;
		$CommonFunction = new CommonFunctions();
		$response = $CommonFunction->PickupDayGraph($id);
		
		return $response;
	}
	
	public function War_Pickup_Report(Request $Request){
		
		$pickupId = $Request->pickupId;

		 $id = $Request->id;
		 $type = $Request->type;
		 
		 $CommonFunction = new CommonFunctions();
		 $response = $CommonFunction->pickuser_graph_rep($id,$type,$pickupId);
		 
		 return $response;
		
	}
	
	public function SearchOutPickup(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pickupId =$Request->pickupId;
	
		
		$report = DB::Select("SELECT id,bookingDate,bookingId,Status, 'Pickup'  FROM Bookings WHERE DATE(Bookings.PickupSuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND pickupDeliveryUserId='".$pickupId."' AND PickupSuccess='1'  UNION ALL SELECT id,bookingDate,bookingId,Status, 'Delivery' FROM Bookings WHERE DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND DeliveryUserId='".$pickupId."' AND DeliverySuccess='1'  order by id desc");
		
		
		return $report;
		
	}
	
	public function OutPickupRepDownload(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pickupId =$Request->pickupId;
		
		
		$CommonFunction = new CommonFunctions();
		$Order = $CommonFunction->search_pickup_down($fromdate,$todate,$pickupId);
		
	}
	
	
	public function OutletVendor(Request $Request){
		
		$id = Auth::user()->id;
		
		$UserList = IroningVendor::Select('id','name','mobile','email','dob','Is_active')
		                           ->Where('name','!=',null)
		                           ->orderBy('name','ASC')
								   ->get();
		
		return view('warehouse.IroningVendorList',['id'=>$id,'User' => $UserList]);
		
	}
	
	
	public function OutletVendorDetails(Request $Request,$id){
		
		$CommonFunction = new CommonFunctions();
		$response = $CommonFunction->VendorInfo($id);
		
		$VendorDetail = $response['Vendor'];
		$GetBookings = $response['Bookings'];
		$jobs = $response['jobs'];
		
		return view('warehouse.VendorDetails',['VendorInfo'=>$VendorDetail,'Bookings'=>$GetBookings,'jobs'=>$jobs]);
		
	}
	
	public function GetVendorReport(Request $Request){
		
		$id = $Request->id;
		$vendorId = $Request->vendorId;
		
		$CommonFunction = new CommonFunctions();
		$response = $CommonFunction->out_vendor_report($vendorId);
		
		$Today = $response['Day'];
		$Week = $response['Week'];
		$Month = $response['Month'];
		$Year = $response['Year'];
		$today_rep = $response['today_rep'];
		$week_rep = $response['week_rep'];
		$month_rep = $response['month_rep'];
		$year_rep = $response['year_rep'];
		
		

		 $userId = $vendorId;

		 $category = DB::table('CategoryList')->select('id','name')->get();
		 
		 $cate_first = DB::table('CategoryList')->select('id','name')->first();
		 
		 
		 return view('warehouse.VendorReport',['id'=>$id,'userId'=>$userId,'Day'=>$Today,'Week'=>$Week,'Month'=>$Month,'Year'=>$Year,'category'=>$category,'cate_first'=>$cate_first,'today_rep'=>$today_rep,'week_rep'=>$week_rep,'month_rep'=>$month_rep,'year_rep'=>$year_rep]);
	}
	
	
	public function OutletVendorGraph(Request $Request){
		
		$id = $Request->id;
		$cate_id = $Request->cate_id;

		
		$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where Bookings.VendorUserId='".$id."' AND  CategoryList.id='".$cate_id."' AND StartJob='2' AND MONTH(Bookings.job_completed) = MONTH(Bookings.job_completed) AND YEAR(Bookings.job_completed) = YEAR(CURRENT_DATE()) Group by Booking_Items.categoryId");

		return json_encode($report);

	}
	
	public function SearchOutVendorReports(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$vendorId =$Request->vendorId;
		
		$CommonFunction = new CommonFunctions();
		$response = $CommonFunction->search_vendor_rep($fromdate,$todate,$vendorId);
		
		return $response;
	}
	
	public function OutVendorRepDown(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$vendorId =$Request->vendorId;
		
		$CommonFunction = new CommonFunctions();
		$response = $CommonFunction->search_vendor_download($fromdate,$todate,$vendorId);
	}
	
	
	public function outlet_pickup_user($id){
		
		
		$CommonFunction = new CommonFunctions();
		
		$PickupUsers = $CommonFunction->EditPickupUser($id);
		
		$Pincode = $CommonFunction->GetPincode();
		
		
		$warehouse = DB::table('warehouses')->Select('id','name')->Where('status','1')->get();
     
		 $PickupUser = $PickupUsers['GetDetails'];
		 
		 $bookings = $PickupUsers['Bookings'];
		 $SelectAreas = $PickupUsers['SelectAreas'];
		 $DeliveryService = $PickupUsers['Delivery'];
		 $pickup_count = $PickupUsers['pickup_count'];
		 $delivery_count = $PickupUsers['delivery_count'];
		
		return view('warehouse.EditPickupUser',['User' => $PickupUser, 'Code' => $Pincode,'houses'=>$warehouse,'UserBookings'=>$bookings,"Area"=>$SelectAreas,"Delivery"=>$DeliveryService,'pickup_count'=>$pickup_count,'delivery_count'=>$delivery_count]);
		
	}
	
	
	public function WarOutletSales(Request $Request){
     
	    $id = $Request->id;
	   	$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->TodaySales($id);
	 
	    return json_encode($Order);
	 
	}
	
	public function WarOutletPayment (Request $Request){
	
		$id = $Request->id;
	   	$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->OutletPayType($id);
	 
	    return json_encode($Order);
		
	}
	
	public function WarOutletMostOrder(Request $Request){
		
		
		$id = $Request->id;
	   	$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->OutletUserOrder($id);
		
		return json_encode($Order);
		
	}
	
	public function WarOutletClothGraph(Request $Request){
		
		$id = $Request->id;
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Cloth_Graph($id);
		
		 return json_encode($Order);
		
	}
	
	public function WarOutletPieChart(Request $Request){
		
		$id = $Request->id;
		
		$Clothes = DB::select("select NewCategories.name as label,groupName,SUM(Booking_Items.quantity) as value from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where Bookings.DeliverySuccess='1' AND Bookings.warehouseId='".$id."'  Group by Booking_Items.categoryId");  
		
		
		foreach($Clothes as $Report){
			
			$Report->label  = $Report->groupName. " / " . $Report->label;
			$Report->value  = (int)$Report->value;
			unset($Report->groupName);
			
		}
		
		return $Clothes; 
		
	}
	
	
	public function WarOrderList(Request $Request){
		
		$id = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$BookingsList = $OutletFunction->outlet_bookings($id);
		
		return view('warehouse.orders',['id'=>$id,'Bookings' => $BookingsList]);

	}
	
	
	public function WarBookings(Request $Request){
		
		
		$id = $Request->id;
		
		$CommonFunction = new CommonFunctions();
		
		$BookingsDetails = $CommonFunction->ViewBook($id);
		
		$Bookings = $BookingsDetails['Bookings'];
		$DeliveyuserDetails = $BookingsDetails['Deliveyuser'];
		$BookingItems = $BookingsDetails['GetOrder'];
		$IroningVendor = $BookingsDetails['Ironing'];
		$Rating = $BookingsDetails['Rating'];
		
        return view('warehouse.ViewBookings',['Bookings' => $Bookings,'Deliveyuser'=>$DeliveyuserDetails,"GetOrders"=>$BookingItems,"Ironing"=>$IroningVendor,'Rating'=>$Rating]);
		
	}
	
	
	public function WarReports(Request $Request){

		
		return view('warehouse.reports');

	}
	
	
	public function WarHighestArea(Request $Request){
		
		$id = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->OutletPincode($id);
		
		$OrderDay = $Order['Day'];
		$OrderWeek = $Order['Week'];
		$OrderMonth = $Order['Month'];
		$OrderYear = $Order['Year'];
		
		$repDay = $Order['Dayrep'];
		$repWeek = $Order['Weekrep'];
		$repMonth = $Order['Monthrep'];
		$repYear = $Order['Yearrep'];
		$summary = $Order['summary'];
		$pincode = $Order['pincode'];

		return view('warehouse.HighOrder',['id'=>$id,'Day'=>$OrderDay,'Week'=>$OrderWeek,'Month'=>$OrderMonth,'Year'=>$OrderYear,'Dayrep'=>$repDay,'Weekrep'=>$repWeek,'Monthrep'=>$repMonth,'Yearrep'=>$repYear,'summary'=>$summary,'pincode'=>$pincode]);
		
	}
	
	
	public function WarPincodeGraph(Request $Request){
		
		$id = Auth::user()->id;
		
		$id = $Request->id;
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->OutletPinGraph($id);
		
		return json_encode($response);
		
	}
	
	public function WarletPinReport(Request $Request){
		
		
		$id = $Request->id;
		$outletId = $Request->outletId;
		$type = $Request->type;
	
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->OutletPinDownload($id,$outletId,$type);
		
		return $response;
		
	}
	
	
	public function SearchWarPin(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pinId =$Request->pinId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_search_pin($fromdate,$todate,$pinId,$outletId);
		
		return $response;
	
	}
	
	public function custom_war_pingraph(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pinId =$Request->pinId;
		$outletId =$Request->outletId;

        $OutletFunction = new OutletFunctions();
		$response = $OutletFunction->OutletCustomPin($fromdate,$todate,$pinId,$outletId);		
		
		return $response;
		
	}
	
	
	public function WarPincodeDown(Request $Request){
		
		$outletId = Auth::user()->id;
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$pinId =$Request->pinId;

		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_pincode_down($fromdate,$todate,$pinId,$outletId);	
		
	}
	
	
	public function WarPaymentType(Request $Request){
		
		$id = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_PayType($id);
		
		$PaymentTypeDay = $Order['Day'];
		$PaymentTypeWeek = $Order['Week'];
		$PaymentTypeMonth = $Order['Month'];
		$PaymentTypeYear = $Order['Year'];
		
		
		$DayRep = $Order['DayRep'];
		$WeekRep = $Order['WeekRep'];
		$MonthRep = $Order['MonthRep'];
		$YearRep = $Order['YearRep'];
		$summary = $Order['summary'];
		
		return view('warehouse.ReportPaymentType',['id'=>$id,'Day'=>$PaymentTypeDay,'Month'=>$PaymentTypeMonth,'Week'=>$PaymentTypeWeek,'Year'=>$PaymentTypeYear,'DayRep'=>$DayRep,'WeekRep'=>$WeekRep,'MonthRep'=>$MonthRep,'YearRep'=>$YearRep,'summary'=>$summary]);

	}
	
	public function WarPaymentGraph(Request $Request){
		
		$id = Auth::user()->id;
		$OutletFunction = new OutletFunctions();
		 $Order = $OutletFunction->Outlet_PayType_graph($id);
		 
		 return json_encode($Order);
		
	}
	
	
	public function WarPayDownload(Request $Request){
		
		
		$id = $Request->id;
		$outletId = Auth::user()->id;
		$type = $Request->type;

		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_PayType_Download($id,$outletId,$type);
		
		return $response;

	}
	
	public function SearchWarPayment(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$paytypeId =$Request->paytypeId;
		$outletId = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->search_outlet_payment($fromdate,$todate,$paytypeId,$outletId);
		
		return $response;
		
		
	}
	
	
	public function war_paymentgraph(Request $Request){
		
		$fromdate =$Request->paymentfrom;
		$todate =$Request->paymentto;
		$paytypeId =$Request->paytypeId;
		$outletId = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_payment_graph($fromdate,$todate,$paytypeId,$outletId);
		
		return $response;
		
	}
	
	
	public function WarPaymentReport(Request $Request){
		  
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$paytypeId =$Request->paytypeId;
		$outletId = Auth::user()->id;
		
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_pay_report($fromdate,$todate,$outletId,$paytypeId);
		 
	 }
	 
	 
	 
	 public function WarRevenue(Request $Request){
		 
		$id = Auth::user()->id; 
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Revenue($id);
		
		$TodayRep = $Order['Day'];
		$WeekRep = $Order['Week'];
		$MonthRep = $Order['Month'];
		$YearRep = $Order['Year'];
		
		
		$Days = $Order['Days'];
		$Weekly = $Order['Weekly'];
		$Monthly = $Order['Monthly'];
		$Yearly = $Order['Yearly'];
		$summary = $Order['summary'];

		
		return view('warehouse.revenue',['id'=>$id,'Day'=>$TodayRep,'Week'=>$WeekRep,'Month'=>$MonthRep,'Year'=>$YearRep,'Days'=>$Days,'Weekly'=>$Weekly,'Monthly'=>$Monthly,'Yearly'=>$Yearly,'summary'=>$summary]);
		 
	 }
	 
	 
	 public function WarRevenueGraph(Request $Request){
		
		$id = $Request->id;
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Revenue_Graph($id);
		
		return json_encode($Order);
		
	}
	
	
	public function WarRevenueExcel(Request $Request){
		
		$id = $Request->id;
		$type = $Request->type;
		$outletId = $Request->outletId;

		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_Revenue_Download($id,$type,$outletId);

		return $response;
		
	}
	
	
	public function SearchWarRevenue(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$outletId = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->search_outlet_revenue($fromdate,$todate,$outletId);
		
		return $response;
 
	 }
	 
	 public function custom_war_revenue(Request $Request){
		 
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_rev_graph($fromdate,$todate,$outletId);
		
		return $response;
		 
	 }
	 
	 public function WarRevenueDownload(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$outletId = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_rev_down($fromdate,$todate,$outletId);
		 
		 
	 }
	 
	 
	 public function WarTimeslots(Request $Request){
		 
		 $id = Auth::user()->id;
		 
		 $OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_time_slots($id); 
		
		$time_slot = DB::table('TimeSlots')->select('id','fromSlots','toSlots','status')->Where('status',1)->get();
		
		$TodayReport = $response['Day'];
		$WeekReport = $response['Week'];
		$MonthReport = $response['Month'];
		$YearReport = $response['Year'];
		
		$Dayrep = $response['Dayrep'];
		$Weekrep = $response['Weekrep'];
		$Monthrep = $response['Monthrep'];
		$Yearrep = $response['Yearrep'];
		$summary = $response['summary'];
		
		return view('warehouse.time-slots',['id'=>$id,'Day'=>$TodayReport,'Week'=>$WeekReport,'Month'=>$MonthReport,'Year'=>$YearReport,'Dayrep'=>$Dayrep,'Weekrep'=>$Weekrep,'Monthrep'=>$Monthrep,'Yearrep'=>$Yearrep,'Slot'=>$time_slot,'summary'=>$summary]);
		 
	 }
	 
	 
	 public function WarSlotGraph(Request $Request){
		 
		 $outletId = Auth::user()->id;

		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_slot_graph($outletId);
		 
		 return $response;
		 
	 }
	 
	 
	 public function WarTimeSlotReport(Request $Request){
		 
		 
		 $id = $Request->id;
		 $type = $Request->type;
		 $outletId = Auth::user()->id;
		 
		 $OutletFunction = new OutletFunctions();
		  $response = $OutletFunction->Outlet_timeslots_report($id,$type,$outletId);
		  
		  return $response;
		 
	 }
	 
	 
	 public function WarSearchTime(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$timeId =$Request->timeId;
		$outletId = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_search_timeslots($fromdate,$todate,$timeId,$outletId);
		
		return $response; 
		 
	 }
	 
	 
	 public function custom_war_graph_slot(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$timeId =$Request->timeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->custom_slot_graph($fromdate,$todate,$timeId,$outletId);
		
		return $response;
		 
	 }
	 
	 public function WarSlotReport(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$timeId =$Request->timeId;
		$outletId = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->slot_rep_download($fromdate,$todate,$timeId,$outletId); 
		 
		 
	 }
	
	
	public function WarPromocode(Request $Request){
		 $id = Auth::user()->id;
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->out_let_promo($id);

		 $PromoDay = $response['Day'];
		 $PromoWeek = $response['Week'];
		 $PromoMonth = $response['Month'];
		 $PromoYear = $response['Year'];
		 $PromoYear = $response['Year'];
		 $Days = $response['Days'];
		 $Weekly = $response['Weekly'];
		 $Monthly = $response['Monthly'];
		 $Yearly = $response['Yearly'];
		 $promo_list = $response['Promo'];
		 $summary = $response['summary'];

		  return view('warehouse.PromocodeView',['id'=>$id,'Day'=>$PromoDay,'Week'=>$PromoWeek,'Month'=>$PromoMonth,'Year'=>$PromoYear,'Days'=>$Days,'Weekly'=>$Weekly,'Monthly'=>$Monthly,'Yearly'=>$Yearly,'Promo'=>$promo_list,'summary'=>$summary]); 
		
		
	}
	
	
	public function WarPromocodeGraph(Request $Request){
		
		 $outletId = Auth::user()->id;
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_promo_graph($outletId);
		 return $response;
		
	}
	
	public function WarPromoDown(Request $Request){
		
		
		$id = $Request->id;
		$type = $Request->type;
		$outletId = $Request->outletId;
		
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_promo_down($id,$type,$outletId);
		 
		 return $response;
		
	}
	
	public function WarSearchPromo(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$promoId =$Request->promoId;
		$outletId =$Request->outletId;

		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_promo_search($fromdate,$todate,$promoId,$outletId);
		 
		 return $response;

	}
	
	public function war_search_promo_down(Request $Request){
		
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$promoId =$Request->promoId;
		$outletId =$Request->outletId;
		
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->promo_search_down($fromdate,$todate,$promoId,$outletId);

	}
	
	
	public function custom_graph_warpromo(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$promoId =$Request->promoId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_custom_graph($fromdate,$todate,$promoId,$outletId);
		 return $response;
		
	}
	
	
	public function WarOrderStatus(Request $Request){
		
		$id = Auth::user()->id;
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_status($id);
		
		$complete_day = $response['Day'];
		$complete_week = $response['Week'];
		$complete_month = $response['Month'];
		$complete_year = $response['Year'];
		$DayRep = $response['DayRep'];
		$WeekRe = $response['WeekRe'];
		$MonthRep = $response['MonthRep'];
		$YearRep = $response['YearRep'];
		$summary = $response['summary'];
		
		return view('warehouse.OrderSuccess',['id'=>$id,'Day'=>$complete_day,'Week'=>$complete_week,'Month'=>$complete_month,'Year'=>$complete_year,'DayRep'=>$DayRep,'WeekRe'=>$WeekRe,'MonthRep'=>$MonthRep,'YearRep'=>$YearRep,'summary'=>$summary]);
	}
	
	public function WarOrderStatusGraph(Request $Request){
		
		$id = $Request->id;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_status_graph_day($id);
		return $response;
		
	}
	
	
	public function WarStatusReport(Request $Request){
		
		 $outletId = $Request->outletId;
		 $id = $Request->id;
		 $type = $Request->type;
		 
		 // return $id;die;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_status_report($id,$type,$outletId);
		
		return $response;
	}
	
	
	public function WarStatusDown(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$typeId =$Request->typeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_down_status($fromdate,$todate,$typeId,$outletId);
		
	}
	
	public function WarSearchSat(Request $Request){
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$typeId =$Request->typeId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_search_status($fromdate,$todate,$typeId,$outletId);
		
		return $response;
		
	}
	
	
	public function WarCategoryClothes(Request $Request){
		
		 $id = Auth::user()->id;
		
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->outlet_clothes_cate($id);
		 
		 $cateId = $response['cateId'];
		 $category = $response['category'];
		 $Today = $response['Day'];
		 $Week = $response['Week'];
		 $Month = $response['Month'];
		 $Year = $response['Year'];

		 return view('warehouse.category-clothes',['id'=>$id,'cateId'=>$cateId,'category'=>$category,'Day'=>$Today,'Week'=>$Week,'Month'=>$Month,'Year'=>$Year]);
		
	}
	
	
	public function WarDaygraph(Request $Request){
		
		$id = $Request->id;
		$type = $Request->type;
		$outletId = $Request->outletId;
		
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_clothes_graph($id,$type,$outletId);
		return $response;
		
		
	}
	
	public function category_clothes_War(Request $Request){
		 
		 $outletId = $Request->outletId;
		 $id = $Request->id;
		 $type = $Request->type;
		 
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->out_let_clothes($outletId,$id,$type);
		 
		 return $response;
	 }
	 
	 
	  public function warhs_Category_Clothes(Request $Request){
		 
		 $id = $Request->id;
		 
		 $outletId = $Request->outletId;
		 
		
		 $OutletFunction = new OutletFunctions();
		 $response = $OutletFunction->out_let_cate_clothes($outletId,$id);
		
	}
	
	
	public function WarClothesRep(Request $Request){
		
		$id = Auth::user()->id;
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Cloth($id);
		
		$TodayRev = $Order['Day'];
		$WeekRev = $Order['Week'];
		$MonthRev = $Order['Month'];
		$YearRev = $Order['Year'];
		
		$category = $Order['category'];
		$summary = $Order['summary'];
		
		return view('warehouse.clothes',['id'=>$id,'Day'=>$TodayRev,'Week'=>$WeekRev,'Month'=>$MonthRev,'Year'=>$YearRev,'category'=>$category,'summary'=>$summary]);
		
	}
	
	public function WarClothesSales(Request $Request){
		
		$id = $Request->id;
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Qty_Month($id);
	
		return json_encode($Order); 
	}
	
	
	public function WarClothesRev(Request $Request){
		
		$id = $Request->id;
		
		$OutletFunction = new OutletFunctions();
		$Order = $OutletFunction->Outlet_Rev_Month($id);
	
		return json_encode($Order);
	}
	
	public function WarClotheReport(Request $Request){
		
		$id = $Request->id;
		$type= $Request->type;
		$outletId = $Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->Outlet_Clothe_Report($id,$type,$outletId); 

        return $response;		
		
		
	}
	
	 public function SearchClothesWar(Request $Request){
		 
		 $fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$cateId =$Request->cateId;
		$outletId =$Request->outletId;
		
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->search_out_clothes($fromdate,$todate,$outletId,$cateId);
		
		return $response;
 
	 }
	 
	  public function WarClothesDown(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$cateId =$Request->cateId;
		$outletId =$Request->outletId;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_clothes_down($fromdate,$todate,$outletId,$cateId);

	 }
	 
	 
	 public function custom_war_category(Request $Request){
		 
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		$cateId =$Request->cateId;
		$outletId =$Request->outletId;
	
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_clothes_category($fromdate,$todate,$cateId,$outletId);
		
		return $response;
	 }
	 
	 
	 public function WarAvgCost(Request $Request){
		 
		$id = Auth::user()->id;
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_avg_cost($id);
		
		$stdday = $response['Today'];
		$stdweek = $response['Week'];
		$stdmonth = $response['Month'];
		$stdyear = $response['Year'];
		
		
		return view('warehouse.AvgCost',['id'=>$id,'Today'=>$stdday,'Week'=>$stdweek,'Month'=>$stdmonth,'Year'=>$stdyear]);
	 }
	 
	 
	 public function SearchWarAvg(Request $Request){
		
		$outletId = $Request->outletId;
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		$OutletFunction = new OutletFunctions();
		$response = $OutletFunction->outlet_avg_search($outletId,$fromdate,$todate);
		
		return $response;
	}
	 
	 
	
}


?>