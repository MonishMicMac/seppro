<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeaveAssign extends Model
{
    protected $table='LeaveAssign';
}
