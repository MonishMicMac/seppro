<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class Manager extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $table='managers';

    protected $fillable = ['name', 'email', 'password'];
}
