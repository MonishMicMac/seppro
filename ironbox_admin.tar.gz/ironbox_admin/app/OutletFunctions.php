<?php

namespace App;
use Illuminate\Http\Request;
use App\User;
use App\pickupdeliveryuser;
use App\IroningVendor;
use App\Admin;
use App\ServiceAreas;
use App\UserAddresses;
use App\TimeSlots;
use App\Pincode;
use App\Promocode;
use App\Categories;
use App\CategoryList;
use App\Bookings;
use App\BookingItems;
use App\CommonFunctions;
use Auth;
use DateTime;
use Validator;
use DB;
use Carbon\Carbon;

class OutletFunctions{
	
	
	function war_pickup_list($id){
		
		$UserList = pickupdeliveryuser::Select('pickupdeliveryusers.id','pickupdeliveryusers.name','pickupdeliveryusers.mobile','email','serviceAreaId','pickupdeliveryusers.warehouseId','Is_active','Pincode.area','Pincode.code')
		                                ->leftjoin('Pincode','Pincode.id', '=', 'pickupdeliveryusers.serviceAreaId')
										->Where('pickupdeliveryusers.warehouseId', '=' , $id)
										->orderBy('pickupdeliveryusers.name','ASC')
		                                ->get();		
										
		return 	$UserList;
		
	}
	
	
	
	function outlet_bookings($id){
		
		
		$BookingsList=Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name','pickupdeliveryusers.name as deliveryusers','Bookings.pickupDeliveryUserId','Bookings.addressId','Bookings.bookingDate','bookingTimeSlot','fromSlots','toSlots','Bookings.Status','WaytoPickup','PickupSuccess','WaytoDelivery','DeliverySuccess','ConfirmOrder','CancelDate','cancelReason','CancelReason.reasons')
		                    ->join('users','users.id','=','Bookings.userId')
							->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
		                    ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							->Where('Bookings.warehouseId',$id)
							->orderBy('Bookings.id', 'desc')
		                    ->get();
         foreach($BookingsList as $Book){

		       if($Book->ConfirmOrder == 1){
				$Book->Status='BOOKING CONFIRM';
			   }
		 
              if($Book->WaytoPickup == 1){
				$Book->Status='WAY TO PICKUP';
			   }
			   
			   if($Book->PickupSuccess == 1){
				$Book->Status='PICKUPED';
			   }
			   
			   if($Book->WaytoDelivery == 1){
				$Book->Status='WAY TO DELIVERY';
			   }
			   
			   if($Book->DeliverySuccess == 1){
				  $Book->Status='COMPLETED';
			   }


			}
		
			return $BookingsList;
	}
	
	
	function TodaySales($id){
		
		// $data = DB::select("select CategoryList.id,CategoryList.name,COUNT(CategoryList.id) as cate_val,SUM(Booking_Items.quantity) as qty from  Booking_Items inner join NewCategories on Booking_Items.categoryId = NewCategories.id inner join CategoryList on NewCategories.categoryId = CategoryList.id Where MONTH(Booking_Items.createdAt) = MONTH(CURRENT_DATE()) AND YEAR(Booking_Items.createdAt) = YEAR(CURRENT_DATE()) AND Booking_Items.warehouse='".$id."' GROUP BY CategoryList.id" );
		
		$data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$id."'  Group by CategoryList.id");
		
		return $data;
		
	}
	
	
	function OutletPayType($id){
		
		
		$PaymentType = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where  DeliverySuccess ='1' AND Bookings.warehouseId='".$id."' GROUP by Bookings.paymentType");
		
		return $PaymentType;
		
	}
	
	function OutletUserOrder($id){
		
		$User = DB::select("select userId,COUNT(*) as orders,users.name as code FROM Bookings inner join users on Bookings.userId = users.id Where Status='COMPLETED' AND Bookings.warehouseId='".$id."' GROUP by userId order by orders desc limit 10");
		
		return $User;
		
	}
	
	function OutletPincode($id){
		
		
		$OrderDay = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId = '".$id."'  GROUP by Bookings.service_area");
		
		$OrderWeek = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND  YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND Bookings.warehouseId = '".$id."'  GROUP by Bookings.service_area");
		
		$OrderMonth = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId = '".$id."'  GROUP by Bookings.service_area");
		
		$OrderYear = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId = '".$id."'  GROUP by Bookings.service_area");
		
		
		$Dayrep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code,Bookings.Status FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.warehouseId = '".$id."' AND Bookings.Status='COMPLETED' AND  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) ");
		
		$Weekrep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code,Bookings.Status FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.warehouseId = '".$id."' AND Bookings.Status='COMPLETED' AND  YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW()) ");
		
		
		$Monthrep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code,Bookings.Status FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.warehouseId = '".$id."' AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) ");
		
		$Yearrep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code,Bookings.Status FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.warehouseId = '".$id."' AND Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) ");
		
		$pincode = DB::table('Pincode')->select('id','area','code')->Where(['status'=>1,'warehouseId'=>$id])->get(); 
		
		$order_summery = DB::Select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.warehouseId = '".$id."' AND Bookings.Status='COMPLETED' AND Bookings.warehouseId = '".$id."'  GROUP by Bookings.service_area");
		
		return array('Day'=>$OrderDay,'Week'=>$OrderWeek,'Month'=>$OrderMonth,'Year'=>$OrderYear,'Dayrep'=>$Dayrep,'Weekrep'=>$Weekrep,'Monthrep'=>$Monthrep,'Yearrep'=>$Yearrep,'summary'=>$order_summery,'pincode'=>$pincode);
		
	}
	
	function OutletPinGraph($id){
		
		$HighestOrder = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND Bookings.warehouseId = '".$id."'  GROUP by Bookings.service_area");
		
		return $HighestOrder; 
	}
	
	
	public function outlet_search_pin($fromdate,$todate,$pinId,$outletId){
		
		if(empty($pinId)){

			
			$Pincode = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' ");
			
		
		    return $Pincode;
		}else if(empty($fromdate) && empty($todate)){
			
			$Pincode = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' AND Pincode.id='".$pinId."' ");

		    return $Pincode;
			
		}else if($fromdate && $todate && $pinId){
		
		
			$Pincode = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Pincode.code FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Pincode.id='".$pinId."'");
			
			return $Pincode;
		}
		
	}
	
	
	public function OutletCustomPin($fromdate,$todate,$pinId,$outletId){
		

		if(empty($pinId)){
			
			$Pincode = DB::select("SELECT Pincode.code as code,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  GROUP by Bookings.service_area");
			
			return json_encode($Pincode);
			
		}else if(empty($fromdate) && empty($todate)){
			
			$Pincode = DB::select("SELECT Pincode.code as code,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' AND Pincode.id='".$pinId."' GROUP by Bookings.service_area");
		
		    return json_encode($Pincode);
		}else if($fromdate && $todate && $pinId){
			
			
			$Pincode = DB::select("SELECT Pincode.code as code,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Pincode.id='".$pinId."'  GROUP by Bookings.service_area");
			
			return json_encode($Pincode);
			
		}
		
		
	}
	
	
	function OutletPinDownload($id,$outletId,$type){
		
		
		if($type == 'graph'){
			
			switch ($id) {
          case "1":
	        
			 $OrderDay = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.warehouseId='".$outletId."' AND  Bookings.Status='COMPLETED' AND  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");
			  if(count($OrderDay) == 0){
				  
				  $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
			  }
			 return json_encode($OrderDay);
			
			break;
		  case "2":
	        
			$Order = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.warehouseId='".$outletId."' AND  Bookings.Status='COMPLETED' AND  YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW())   GROUP by Bookings.service_area");
		   
		    if(count($Order) == 0){
				  
				  $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
			  }
		   return json_encode($Order);
		   
		   break;
		case "3":
	
	    $OrderMonth = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.warehouseId='".$outletId."' AND  Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");
		     if(count($OrderMonth) == 0){
				  
				  $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
			  }
		return json_encode($OrderMonth);
	
		 break;
		case "4":
	
	    $Order = DB::select("SELECT COUNT(*) as orders,Bookings.service_area,Pincode.code,SUM(totalPayment) as total, SUM(quantity) as qty FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.warehouseId='".$outletId."' AND  Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW())  GROUP by Bookings.service_area");
		
		if(count($Order) == 0){
				  
				  $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
			  }
		
	    return json_encode($Order);
		 break;
		 case "5":
		 $pin = DB::table('Pincode')->select('id','code')->get();
			
					foreach($pin as $code){
						
						$code->orders = "";
					}
					return json_encode($pin);die;
		  break;
		default:
			
				  
				  return 'No record';
			  
			}
			
		}else{
		
		$outlet = DB::table('warehouses')->Where('id',$outletId)->value('name'); 
		
		// echo $outlet;die;
		
		  switch ($id) {
				case "1":

				   $description = "".$outlet." Pincode today reports (".date('d-m-Y').")";
				   

					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_day($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

				   
					break;
				case "2":
					
					
						
					$description = "".$outlet." Pincode week reports (".date('d-m-Y').")";
				   
					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_week($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

					break;
				case "3":

				   
					$description = "".$outlet." Pincode month reports (".date('d-m-Y').")";
					
					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_month($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
					

					break;
					
				case "4":

					$description = "".$outlet." Pincode year reports (".date('d-m-Y').")";
					
					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_year($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

					


					break;
				default:
					echo "No record";
			   }
		
		
		}
		
	}
	
	
	function outlet_pincode_down($fromdate,$todate,$pinId,$outletId){
		
		$current = date('d-m-Y');
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		if(empty($pinId)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $description = "Pincode reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if(empty($fromdate) && empty($todate)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.service_area'=>$pinId,'Bookings.warehouseId'=>$outletId])
							  // ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $get_pin = DB::table('Pincode')->Select('id','code')->Where('id',$pinId)->first();
			
			 $description = "Pincode reports - ".$get_pin->code." (".$current.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if($fromdate && $todate && $pinId){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.service_area'=>$pinId,'Bookings.warehouseId'=>$outletId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $description = "Pincode reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}else die;
		
		$Pincode = DB::select("SELECT Pincode.code as pincode,COUNT(*) as orders,SUM(quantity) as quantity,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  GROUP by Bookings.service_area");
		
		$data= json_decode( json_encode($Pincode), true);
		Excel::create('pincode-report', function($excel) use($data) {
			$excel->sheet('Sheet 1', function($sheet) use($data) {
				$sheet->fromArray($data);
			});
		})->export('xls');
	}
	
	
	function Outlet_PayType($id){
		
		
		$PaymentTypeDay = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' GROUP by Bookings.paymentType");
		
		$PaymentTypeWeek = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW())  AND DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' GROUP by Bookings.paymentType");
		
		$PaymentTypeMonth = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' GROUP by Bookings.paymentType");
		
		$PaymentTypeYear = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' GROUP by Bookings.paymentType");
		
		/*************** view details **************************/
		
		$DayRep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.Status,Bookings.paymentType FROM Bookings Where DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' order by Bookings.id desc");
		
		$WeekRep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.Status,Bookings.paymentType FROM Bookings Where DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' AND YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW())  AND DeliverySuccess ='1' order by Bookings.id desc");
		
		$MonthRep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.Status,Bookings.paymentType FROM Bookings Where DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate)  AND DeliverySuccess ='1' order by Bookings.id desc");
		
		
		$YearRep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.Status,Bookings.paymentType FROM Bookings Where DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' order by Bookings.id desc");
		
		$summary = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where  DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' GROUP by Bookings.paymentType");
		
		return array('Day'=>$PaymentTypeDay,'Month'=>$PaymentTypeMonth,'Week'=>$PaymentTypeWeek,'Year'=>$PaymentTypeYear,'DayRep'=>$DayRep,'WeekRep'=>$WeekRep,'MonthRep'=>$MonthRep,'YearRep'=>$YearRep,'summary'=>$summary);
		
	}
	
	function Outlet_PayType_graph($id){
		
		$PaymentType = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' AND Bookings.warehouseId = '".$id."' GROUP by Bookings.paymentType");
		
		return $PaymentType;
		
	}
	
	function Outlet_PayType_Download($id,$outletId,$type){
		
		
		
		if($type == 'graph'){
			
			$paytype = array(array('orders'=>'','paymentType'=>'Cash'),array('orders'=>'','paymentType'=>'Card'),array('orders'=>'','paymentType'=>'Wallet'));		
		
		switch ($id) {
			case "1":
				
		$PaymentReport = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' GROUP by Bookings.paymentType");
		
		
		if(count($PaymentReport)  == 0){
			
			return json_encode($paytype);die;
		}
		
		return json_encode($PaymentReport);
	
				
				break;
			case "2":
				
				$PaymentReport = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW())  AND DeliverySuccess ='1' AND Bookings.warehouseId = '".$outletId."' GROUP by Bookings.paymentType");
				
				if(count($PaymentReport)  == 0){
			
					return json_encode($paytype);die;
				}
		
		   return json_encode($PaymentReport);
		
				
				break;
			case "3":
				
				
		$PaymentReport = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' AND Bookings.warehouseId = '".$outletId."' GROUP by Bookings.paymentType");
		
		if(count($PaymentReport)  == 0){
			
			return json_encode($paytype);die;
		}
		
		return json_encode($PaymentReport);
		
		
		
				break;
			case "4":
				
				$PaymentReport = DB::select("SELECT COUNT(id)as orders,SUM(totalPayment) as total, SUM(quantity) as qty,Bookings.paymentType FROM Bookings Where YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1' AND Bookings.warehouseId = '".$outletId."' GROUP by Bookings.paymentType");
				
				if(count($PaymentReport)  == 0){
			
			return json_encode($paytype);die;
		}
				
		return json_encode($PaymentReport);
		
				
				break;
			default:
				$paytype = array(array('orders'=>'','paymentType'=>'Cash'),array('orders'=>'','paymentType'=>'Card'),array('orders'=>'','paymentType'=>'Wallet'));	
				return json_encode($paytype);die;
		  }
			
		}else{
		
		    $outlet = DB::table('warehouses')->Where('id',$outletId)->value('name'); 
		
		// echo $outlet;die;
		
		  switch ($id) {
				case "1":

				   $description = "".$outlet." Pincode today reports (".date('d-m-Y').")";
				   

					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_day($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

				   
					break;
				case "2":
					
					
						
					$description = "".$outlet." Pincode week reports (".date('d-m-Y').")";
				   
					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_week($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

					break;
				case "3":

				   
					$description = "".$outlet." Pincode month reports (".date('d-m-Y').")";
					
					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_month($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
					

					break;
					
				case "4":

					$description = "".$outlet." Pincode year reports (".date('d-m-Y').")";
					
					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_year($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

					


					break;
				default:
					echo "No record";
			   }
		
		}
		
	}
	
	
	function outlet_payment_graph($fromdate,$todate,$paytypeId,$outletId){
		
		
		if(empty($paytypeId)){
			
			$paytype = DB::select("SELECT Bookings.paymentType,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Bookings.warehouseId = '".$outletId."'  GROUP by Bookings.paymentType");
			
			return json_encode($paytype);
			
		}else if(empty($fromdate) && empty($todate)){
			
			$paytype = DB::select("SELECT Bookings.paymentType,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.paymentType='".$paytypeId."' AND Bookings.warehouseId = '".$outletId."' GROUP by Bookings.paymentType");
		
		    return json_encode($paytype);
		}else if($fromdate && $todate && $paytypeId){
			
			
			$paytype = DB::select("SELECT Bookings.paymentType,COUNT(*) as orders,SUM(quantity) as qty,SUM(totalPayment) as total FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Bookings.paymentType='".$paytypeId."' AND Bookings.warehouseId = '".$outletId."'  GROUP by Bookings.paymentType");
			
			return json_encode($paytype);
			
		}
		
	}
	
	function search_outlet_payment($fromdate,$todate,$paytypeId,$outletId){
		
		if(empty($paytypeId)){
			
	
			
			$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Bookings.PaymentType FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Bookings.warehouseId = '".$outletId."' order by Bookings.id desc");
			
		
		    return $Result;
		}else if(empty($fromdate) && empty($todate)){
			
			$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Bookings.PaymentType FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND Bookings.PaymentType='".$paytypeId."'  AND Bookings.warehouseId = '".$outletId."' order by Bookings.id desc");
			
           return $Result;
			
		}else if($fromdate && $todate && $paytypeId){
		

		
		$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,Bookings.PaymentType FROM Bookings inner join Pincode on Bookings.service_area = Pincode.id Where Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Bookings.PaymentType='".$paytypeId."' AND Bookings.warehouseId = '".$outletId."' order by Bookings.id desc");
		
		return $Result;
		}
		
	}
	
	function Outlet_Revenue($id){
		
		 $TodayRep = DB::select("select id,bookingId,Status from Bookings Where Status='COMPLETED' AND warehouseId = '".$id."' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE())");
		 
		 $WeekRep = DB::select("select id,bookingId,Status from Bookings Where Status='COMPLETED' AND warehouseId = '".$id."' AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())");
		 
		 $MonthRep = DB::select("select id,bookingId,Status from Bookings Where Status='COMPLETED' AND warehouseId = '".$id."' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE())");
		 
		 $YearRep = DB::select("select id,bookingId,Status from Bookings Where Status='COMPLETED' AND  warehouseId = '".$id."' AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE())");
		 
		 // echo json_encode($YearRep);die;
		 
		 $Days = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty FROM Bookings Where  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' AND warehouseId = '".$id."'  ");
		 
		 $Weekly = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty FROM Bookings Where YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW()) AND Status='COMPLETED' AND warehouseId = '".$id."' ");
		 
		 $Monthly = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty FROM Bookings Where  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' AND warehouseId = '".$id."' ");
		 
		 $Yearly = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty FROM Bookings Where  YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' AND warehouseId = '".$id."' ");
		 
		 
		 $summary = DB::select("select COUNT(*) as booking,SUM(totalPayment) as revenue,SUM(quantity) as quantity from Bookings Where Status='COMPLETED' AND warehouseId = '".$id."' ");
		 
		 
		 return array('Day'=>$TodayRep,'Month'=>$MonthRep,'Week'=>$WeekRep,'Year'=>$YearRep,'Days'=>$Days,'Weekly'=>$Weekly,'Monthly'=>$Monthly,'Yearly'=>$Yearly,'summary'=>$summary);
		 
		 
		
	}
	
	function Outlet_Revenue_Graph($id){

		 
		 $Revenue = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' AND Bookings.warehouseId = '".$id."' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($Revenue as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return $Revenue;
		
	}
	
	function Outlet_Revenue_Download($id,$type,$outletId){
		
		if($type == 'graph'){
			
			switch ($id) {
			case "1":
			
			
			$TodayRep = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($TodayRep as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($TodayRep);
			
			break;
			
			case "2":
			
			$WeekRep = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate), YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($WeekRep as $Data){
				 
				$Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 return json_encode($WeekRep);
			
			break;
			
			case "3":
			
			$MonthRep = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($MonthRep as $Data){
				
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 
			 return json_encode($MonthRep);
			
			break;
			
			case "4":
             
			 $YearRep = DB::select("SELECT SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where  YEAR(DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Status='COMPLETED' AND Bookings.warehouseId = '".$outletId."' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
			 foreach($YearRep as $Data){
				 
				 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
			 }
			 return json_encode($YearRep);
			
			break;
           default:
		    echo "No data";die;
			
			}
			
		}else{
			
			$outlet = DB::table('warehouses')->Where('id',$outletId)->value('name'); 
			switch ($id) {
				case "1":

				   $description = "".$outlet." revenue today reports (".date('d-m-Y').")";
				   

					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_day($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

				   
					break;
				case "2":
					
					
						
					$description = "".$outlet." revenue week reports (".date('d-m-Y').")";
				   
					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_week($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

					break;
				case "3":

				   
					$description = "".$outlet." revenue month reports (".date('d-m-Y').")";
					
					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_month($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);
					

					break;
					
				case "4":

					$description = "".$outlet." revenue year reports (".date('d-m-Y').")";
					
					$CommonFunction = new CommonFunctions();
					$query_fnc  = $CommonFunction->get_function_pin_year($outletId);
					$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

					


					break;
				default:
					echo "No record";
			   }
			
		}
	}
	
	
	
	function Outlet_Cloth_Graph($id){
		
		
		$price = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$id."'  Group by CategoryList.id");
		
		// $price = DB::select("select CategoryList.id,CategoryList.name,CategoryList.Price,SUM(Booking_Items.quantity) as qty from  Booking_Items inner join NewCategories on Booking_Items.categoryId = NewCategories.id inner join CategoryList on NewCategories.categoryId = CategoryList.id Where MONTH(Booking_Items.createdAt) = MONTH(CURRENT_DATE()) AND YEAR(Booking_Items.createdAt) = YEAR(CURRENT_DATE()) AND Booking_Items.warehouse='".$id."' GROUP BY CategoryList.id" );
		 
		
		// foreach($price as $pri){
			
			// $pri->price_amount = $pri->qty * $pri->Price; 
			
		// }
		
		return $price; 
		
	}
	
	
	function Outlet_Cloth($id){
		
		$TodayRev = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$id."' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");
		
		$WeekRev = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$id."' AND YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW())  Group by CategoryList.id");
		
		$MonthRev = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$id."' AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");
		
		$YearRev = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$id."' AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");
		
		$category = DB::table('CategoryList')->select('id','name')->Where('status',1)->get();
		
		$summary = DB::select("select COUNT(Bookings.id) as booking,CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$id."'   Group by CategoryList.id");
		
		return array('Day'=>$TodayRev,'Week'=>$WeekRev,'Month'=>$MonthRev,'Year'=>$YearRev,'category'=>$category,'summary'=>$summary);
		
	}
	
	function Outlet_Qty_Month($id){
		
		
		$data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where  Bookings.warehouseId='".$id."' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW())  Group by CategoryList.id");
		
		
		return $data; 
		
	}
	
	function Outlet_Rev_Month($id){
		
		$price = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$id."' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) Group by CategoryList.id");
		 
		
		return $price; 
	}
	
	function Outlet_Clothe_Report($id,$type,$outletId){
		  
		  
		  if($type == 'graph'){
			
			switch ($id) {
			case "1":  
			
			$day_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$outletId."' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");
			
			
			$day_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$outletId."' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");
		    
			return array("amount"=>$day_amount,"quantity"=>$day_qty);
			
			
			break;
			case "2":
			
			$week_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$outletId."' AND YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW())   Group by CategoryList.id");
			
			$week_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$outletId."' AND YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW())   Group by CategoryList.id");
			
			return array("amount"=>$week_amount,"quantity"=>$week_qty);
			
			
			break;
			case "3":
			
			
			$month_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$outletId."' AND  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");
			
			
			$month_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$outletId."' AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");
		    
			return array("amount"=>$month_amount,"quantity"=>$month_qty);
			
			break;
			case "4":
			
			$year_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$outletId."' AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");
			
			
			$year_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$outletId."' AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE())  Group by CategoryList.id");
		    
			return array("amount"=>$year_amount,"quantity"=>$year_qty);
			
			break;
			
			default:
				echo "No data";
			}
			
		 }else{
			 
			 switch ($id) {
			case "1":
			
			

		    $description = "Cloths day reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_outlet_cloth_day($outletId);
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
		
			case "2":
				
				$description = "Cloths week reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_outlet_cloth_week($outletId);
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
				
				break;
			case "3":
				
			$description = "Cloths month reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_outlet_cloth_month($outletId);
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
				
				break;
			case "4":
				
				$description = "Cloths year reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_outlet_cloth_year($outletId);
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
				
				break;
			default:
				echo "No data";
		}
			 
			 }
		  
		   
	}
	
	
	function Outlet_time_slots($id){
		
		$Dayrep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND  DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' ");
		
		
		$Weekrep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND  YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW()) AND Bookings.warehouseId='".$id."' ");
		
		
		$Monthrep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND   MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' ");
		
		
		$Yearrep = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1'  AND    YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' ");
		

		$TodayReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$id."' GROUP BY Bookings.bookingTimeSlot");
		
		
		$WeekReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND Bookings.warehouseId='".$id."' GROUP BY Bookings.bookingTimeSlot");
		
		$MonthReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND Bookings.warehouseId='".$id."' AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY Bookings.bookingTimeSlot");
		
		
		$YearReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$id."' GROUP BY Bookings.bookingTimeSlot");
		
		
		
		
		$summary = DB::select("select COUNT(Bookings.id) as booking,SUM(Bookings.totalPayment) as revenue,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$id."'  GROUP BY Bookings.bookingTimeSlot");
		
		
		return array('Day'=>$TodayReport,'Week'=>$WeekReport,'Month'=>$MonthReport,'Year'=>$YearReport,'Dayrep'=>$Dayrep,'Weekrep'=>$Weekrep,'Monthrep'=>$Monthrep,'Yearrep'=>$Yearrep,'summary'=>$summary);
		
	}
	
	
	function Outlet_timeslots_report($id,$type,$outletId){
		
		// return $type;die;
		if($type == 'graph'){
			
			
			switch ($id) {
			case "1":
			
			$slot = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$outletId."' GROUP BY Bookings.bookingTimeSlot");
			 
			 return json_encode($slot);
			
			break;
			
			case "2":
			
			$slot = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND Bookings.warehouseId='".$outletId."' GROUP BY Bookings.bookingTimeSlot");
			 
			 return json_encode($slot);
			
			break;
			
			case "3":
			
			 $slot = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$outletId."' GROUP BY Bookings.bookingTimeSlot");
			 
			 return json_encode($slot);
			
			break;
			
			case "4":
			
			
			 $slot = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$outletId."' GROUP BY Bookings.bookingTimeSlot");
			 
			 return json_encode($slot);
			
			
			default:
				echo "No data";
			
			}
			
			
		}else{
		
		
		
		 switch ($id) {
			case "1":

			   $description = "TimeSlots Today reports (".date('d-m-Y').")";
			   

				$CommonFunction = new CommonFunctions();
				$query_fnc  = $CommonFunction->get_function_pin_day($outletId);
				$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

			   
				break;
			case "2":
				
				
					
				$description = "TimeSlots week reports (".date('d-m-Y').")";
			   
				$CommonFunction = new CommonFunctions();
				$query_fnc  = $CommonFunction->get_function_pin_month($outletId);
				$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

				break;
			case "3":

			   
				$description = "TimeSlots month reports (".date('d-m-Y').")";
				$CommonFunction = new CommonFunctions();
				$query_fnc  = $CommonFunction->get_function_pin_month($outletId);
				$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

				break;
				
			case "4":

				$description = "TimeSlots year reports (".date('d-m-Y').")";

				$CommonFunction = new CommonFunctions();
				$query_fnc  = $CommonFunction->get_function_pin_year($outletId);
				$Reports = $CommonFunction->get_excel_pincode($query_fnc,$description);

				
			   

			   
				break;
			default:
				echo "No record";
		   }
				
				
	  }
		
		
	}
	
	
	
	function Outlet_search_timeslots($fromdate,$todate,$timeId,$outletId){
		
		if(empty($timeId)){

			$slots = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1' AND Bookings.warehouseId='".$outletId."'  AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  ");
			
		    return $slots;
			
		}else if(empty($fromdate) && empty($todate)){
			
			
			$slots = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1' AND Bookings.warehouseId='".$outletId."'   AND  TimeSlots.id='".$timeId."' ");
			
		    return $slots;
			
		}else if($fromdate && $todate && $timeId){
		
		
		$slots = DB::select("SELECT Bookings.id,Bookings.bookingId,Bookings.service_area,TimeSlots.fromSlots,TimeSlots.toSlots,Bookings.Status FROM Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id Where Bookings.Status='COMPLETED' AND TimeSlots.status='1' AND Bookings.warehouseId='".$outletId."'   AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND TimeSlots.id='".$timeId."' ");
			
		    return $slots;
		
		}
		
	}
	
	
	function custom_slot_graph($fromdate,$todate,$timeId,$outletId){
		
		
		if(empty($timeId)){


			$slots = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND  Bookings.warehouseId='".$outletId."' AND  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' GROUP BY Bookings.bookingTimeSlot");
			
		    return  json_encode($slots);
			
		}else if(empty($fromdate) && empty($todate)){
			
			
			$slots = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND  Bookings.warehouseId='".$outletId."' AND TimeSlots.id='".$timeId."' GROUP BY Bookings.bookingTimeSlot");
			
		    return  json_encode($slots);
			
		}else if($fromdate && $todate && $timeId){
		
		
		$slots = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND  Bookings.warehouseId='".$outletId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND TimeSlots.id='".$timeId."' GROUP BY Bookings.bookingTimeSlot");
			  
		   return  json_encode($slots);
		
		}

	}
	
	
	function slot_rep_download($fromdate,$todate,$timeId,$outletId){
		
		
		$current = date('d-m=Y');
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		
		if(empty($timeId)){

          $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $description = "TimeSlots reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}else if(empty($fromdate) && empty($todate)){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.bookingTimeSlot'=>$timeId,'Bookings.warehouseId'=>$outletId])
		                      ->get()
							  ->toArray();
			
			 $get_pin = DB::table('TimeSlots')->Select('id','fromSlots','toSlots')->Where('id',$timeId)->first();
			
			 $description = "Pincode reports - ".$get_pin->fromSlots." - ".$get_pin->toSlots." (".$current.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}else if($fromdate && $todate && $timeId){
		
		     $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.bookingTimeSlot'=>$pinId,'Bookings.warehouseId'=>$outletId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
			
			 $description = "TimeSlots reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
		
		
		}
		
	}
	
	
	function search_outlet_revenue($fromdate,$todate,$outletId){
		
		
		$revenue = DB::select("select id,bookingId,Status from Bookings Where Status='COMPLETED' AND warehouseId='".$outletId."' AND  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' order by id desc");
		
		return $revenue;
		
	}
	
	
	function outlet_rev_graph($fromdate,$todate,$outletId){
		
		
		$revenue = DB::select("SELECT COUNT(*) as booking,SUM(totalPayment)as orders,SUM(quantity) as qty,DAY(DeliverySuccessDate) as ord_date,MONTH(DeliverySuccessDate) as ord_month, YEAR(DeliverySuccessDate) as ord_year FROM Bookings Where Bookings.warehouseId='".$outletId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' GROUP BY MONTH(DeliverySuccessDate), DAY(DeliverySuccessDate),  YEAR(DeliverySuccessDate) ORDER BY ord_date desc, ord_month desc");
		 
		 foreach($revenue as $Data){
			 
			 $Data->order_date = sprintf("%02d", $Data->ord_date)."-".sprintf("%02d", $Data->ord_month)."-".$Data->ord_year;
		 }
		 
		 return json_encode($revenue);
		
		
	}
	
	
	function outlet_rev_report($fromdate,$todate,$outletId){
		
		
		$fromdate =$Request->fromdate;
		$todate =$Request->todate;
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		 
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->Where(['Bookings.warehouseId'=>$outletId])
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  ->orderBy('Bookings.id','desc')
		                      ->get()
							  ->toArray();
		
            $description = "Revenue reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
		
		
	}
	
	
	
	function outlet_pay_report($fromdate,$todate,$outletId,$paytypeId){
		
		
		$current = date('d-m=Y');
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		if(empty($paytypeId)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			
			 $description = "payment type reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if(empty($fromdate) && empty($todate)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.PaymentType'=>$paytypeId,'Bookings.warehouseId'=>$outletId])
							  // ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			
			
			 $description = "Payment type reports - ".$paytypeId." (".$current.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if($fromdate && $todate && $pinId){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.PaymentType'=>$paytypeId,'Bookings.warehouseId'=>$outletId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  // ->limit(1)
		                      ->get()
							  ->toArray();
			// echo json_encode($Bookings);
			
			 $description = "Pincode reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}
		
		
		
	}
	
	
	
	function search_out_clothes($fromdate,$todate,$outletId,$cateId){
		
		
		if(empty($cateId)){
		
		$data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$outletId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  Group by CategoryList.id");
		
		return $data;
		
		}else if(empty($fromdate) && empty($todate)){
			
			
			$data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$outletId."' AND CategoryList.id='".$cateId."'  Group by CategoryList.id");
			return $data;
		}else if($fromdate && $todate && $cateId){
			
			
			$data = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$outletId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND CategoryList.id='".$cateId."'  Group by CategoryList.id");
		
		return $data;
			
		}
	}
	
	
	function outlet_clothes_down($fromdate,$todate,$outletId,$cateId){
	
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		
		if(empty($cateId)){
		
		
		$description = "Clothes reports (".$f_date." - ".$t_date.")";

		$day_rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where Bookings.warehouseId='".$outletId."' AND DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  Group by Booking_Items.categoryId"); 
		
		$query_fnc = json_decode( json_encode($day_rep), true);

		$CommonFunction = new CommonFunctions();
		$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
		
		}else if(empty($fromdate) && empty($todate)){
			
			
			$rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where Bookings.warehouseId='".$outletId."' AND CategoryList.id='".$cateId."'  Group by Booking_Items.categoryId"); 
			
			$query_fnc = json_decode( json_encode($rep), true);
			
			
			$category = DB::table('CategoryList')->select('id','name')->Where(['status'=>1,'id'=>$cateId])->first();
			
			$description = "Clothes report- ".$category->name." (".date('d-m-Y').")";

			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
			
		}else if($fromdate && $todate && $cateId){
			

			
			$rep = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.name as categoty_name,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id  Where Bookings.warehouseId='".$outletId."' AND CategoryList.id='".$cateId."' AND DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  Group by Booking_Items.categoryId"); 
			
			$query_fnc = json_decode( json_encode($rep), true);
			
			
			$category = DB::table('CategoryList')->select('id','name')->Where(['status'=>1,'id'=>$cateId])->first();
			
			$description = "Clothes reports - ".$category->name." (".$f_date." - ".$t_date.")";

			$CommonFunction = new CommonFunctions();
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
			
		}
		
	}
	
	
	
	function outlet_rev_down($fromdate,$todate,$outletId){
		
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		 
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->Where(['Bookings.warehouseId'=>$outletId])
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
		
            $description = "Revenue reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
		
	}
	
	
	 function outlet_slot_graph($outletId){
		
		
		
		$MonthReport = DB::select("select COUNT(Bookings.id) as orders,SUM(Bookings.totalPayment) as total,SUM(Bookings.quantity) as quantity,TimeSlots.fromSlots,TimeSlots.toSlots from Bookings inner join TimeSlots on Bookings.bookingTimeSlot = TimeSlots.id where Bookings.Status='COMPLETED' AND DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) GROUP BY Bookings.bookingTimeSlot");
		
		return json_encode($MonthReport);
	}
	
	
	function outlet_clothes_cate($id){
		
		
		$category = DB::table('CategoryList')->select('id','name')->get();
		
		$category_first = DB::table('CategoryList')->select('id')->first();
		
		$cateId = $category_first->id;

		$Today = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$id."'   Group by Booking_Items.categoryId");  
		
		
		$Week = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where  YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND Bookings.warehouseId='".$id."'   Group by Booking_Items.categoryId"); 

		$Month = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where  YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND Bookings.warehouseId='".$id."'   Group by Booking_Items.categoryId"); 
		
		$Month = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$id."'   Group by Booking_Items.categoryId");
		
		$Year = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity) * CategoryList.Price as amount from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND Bookings.warehouseId='".$id."'   Group by Booking_Items.categoryId");
		
		
		return array('cateId'=>$category_first->id,'category'=>$category,'Day'=>$Today,'Week'=>$Week,'Month'=>$Month,'Year'=>$Year);
		
		
	}
	
	
	function out_let_clothes($outletId,$id,$type){
		
		
		switch ($type) {
			case "1":
			
			$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
			
			return json_encode($report);
			
			
			break;
			case "2":
			
			$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where   YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
			
			return json_encode($report);
			
			
			break;
			case "3":
			
			$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
			
			return json_encode($report);
			
			break;
			case "4":
			
			$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where   YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
			
			return json_encode($report);
			
			break;
			
			default:
				$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
				
				return json_encode($report);
			
		}
		
	}
	
	
	
	
	function out_let_cate_clothes($outletId,$id){
		

		switch ($id) {
			case "1":
			
			$description = "Cloths day reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_out_cloth_day($outletId);
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
				
				
				break;
			case "2":
				
			$description = "Cloths week reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_out_cloth_week($outletId);
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
				
				break;
				
			case "3":
				
				$description = "Cloths month reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_out_cloth_month($outletId);

			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
				
				break;
			case "4":
			
				$description = "Cloths year reports (".date('d-m-Y').")";
			$CommonFunction = new CommonFunctions();
			$query_fnc  = $CommonFunction->get_out_cloth_year($outletId);
			$Reports = $CommonFunction->get_excel_clothes($query_fnc,$description);
				
				break;
			default:
				echo "Invalid data";
		}
		
	}
	
	
	function out_let_promo($id){
		
		
		 $Days = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where DAY(DeliverySuccessDate) = DAY(NOW()) AND promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' order by Bookings.id desc");
		 
		 
		 $Weekly = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND promode_code !=0 AND Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$id."'  order by Bookings.id desc");
		 
		 $Monthly = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' order by Bookings.id desc");
		 
		 $Yearly = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' order by Bookings.id desc");

		 $PromoDay = DB::select("select COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where DAY(DeliverySuccessDate) = DAY(NOW()) AND promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' GROUP by Bookings.promode_code");
		 
		 
		 $PromoWeek = DB::select("select COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND promode_code !=0 AND Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$id."' GROUP by Bookings.promode_code");
		 
		 $PromoMonth = DB::select("select COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' GROUP by Bookings.promode_code");
		 
		 
		 $PromoYear = DB::select("select COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' GROUP by Bookings.promode_code");
		 
		 
		 $promo_list = DB::table('promocode')->select('id','promocode','status')->Where('status',1)->get();
		 
         $summary = DB::Select("select COUNT(Bookings.promode_code) as orders,promocode.promocode,SUM(totalPayment) as total, SUM(discount_amount) as discount from Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code != '0' AND Bookings.Status='COMPLETED' AND Bookings.warehouseId='".$id."'  group by Bookings.promode_code");
		 
		  return array('Day'=>$PromoDay,'Week'=>$PromoWeek,'Month'=>$PromoMonth,'Year'=>$PromoYear,'Days'=>$Days,'Weekly'=>$Weekly,'Monthly'=>$Monthly,'Yearly'=>$Yearly,'Promo'=>$promo_list,'summary'=>$summary); 
		
		
	}
	
	
	 function outlet_promo_search($fromdate,$todate,$promoId,$outletId){

		
		if(empty($promoId)){
			
		$Promo_report = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Bookings.warehouseId='".$outletId."' order by Bookings.id desc");
		
		return $Promo_report;
		
		}else if(empty($fromdate) && empty($todate)){
			
			
			$Promo_report = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED'  AND promocode.id='".$promoId."' AND Bookings.warehouseId='".$outletId."' order by Bookings.id desc");
		
		return $Promo_report;
			
		}else if($fromdate && $todate && $promoId){
			
			
			$Promo_report = DB::select("select Bookings.id,bookingId,bookingDate,Bookings.Status,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED'  AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND promocode.id='".$promoId."' AND Bookings.warehouseId='".$outletId."' order by Bookings.id desc");
		
		return $Promo_report;
			
			
		}
		 
		 
	 }
	 
	 
	 
	 function outlet_promo_down($id,$type,$outletId){

		if($type == 'graph'){
			
			switch ($id) {
			case "1":
			
			$promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$outletId."' GROUP by Bookings.promode_code");
			
			return json_encode($promocode);
			
			break; 

            case "2":
			
			$promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) AND Bookings.warehouseId='".$outletId."' GROUP by Bookings.promode_code");
		
		    return json_encode($promocode);
			
			break; 

            case "3":
			
			$promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$outletId."' GROUP by Bookings.promode_code");
		
		    return json_encode($promocode);
			
			break; 

            case "4":
			
			$promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()) AND Bookings.warehouseId='".$outletId."' GROUP by Bookings.promode_code");
		
		    return json_encode($promocode);
			
			break;
			default:
				echo "Invalid data";die;
			
			}
			
			
		  }else{
		
		switch ($id) {
			case "1":
              
			  $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->where('Bookings.promode_code', '!=' , 0)
							  ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
							  
			 $description = "Promocode today reports (".date('d-m-Y').")";
			 $CommonFunction = new CommonFunctions();
			 $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);


           case "2":
              
			  $now = Carbon::now();
	   
	   $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->where('Bookings.promode_code', '!=' , 0)
							  ->whereBetween('DeliverySuccessDate', [Carbon::now()->startOfWeek(),Carbon::now()->endOfWeek()])
		                      ->get()
							  ->toArray();
			  
			 $description = "Promocode week reports (".date('d-m-Y').")";
			 $CommonFunction = new CommonFunctions();
			 $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			  
            break;

           case "3":
              
			   $now = Carbon::now();
			   $month = date('m');
	   
	  $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->where('Bookings.promode_code', '!=' , 0)
							  ->whereMonth('DeliverySuccessDate', $month)
		                      ->get()
							  ->toArray();
			  
			   $description = "Promocode month reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
            break;


            case "4":
                
				 $year = date('Y');
		 $now = Carbon::now();
		 $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->where('Bookings.promode_code', '!=' , 0)
							  ->whereYear('DeliverySuccessDate', $year)
		                      ->get()
							  ->toArray();
				
			  $description = "Promocode year reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
				
            break;          	
			
			break;
			default:
				echo "Invalid data";die;
		}
		
	  }
		 
	 }
	
	
	
	function outlet_custom_graph($fromdate,$todate,$promoId,$outletId){
		
		
		if(empty($promoId)){
			
			$promo = DB::select("select promocode.promocode as code ,COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Bookings.warehouseId='".$outletId."' GROUP by Bookings.promode_code");
			
			return json_encode($promo);
			
			// return 5;
			
		}else if(empty($fromdate) && empty($todate)){
			
			$promo = DB::select("select promocode.promocode as code ,COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND promocode.id='".$promoId."' AND Bookings.warehouseId='".$outletId."' GROUP by Bookings.promode_code");
			
			return json_encode($promo);
			
			
		}else if($fromdate && $todate && $promoId){
			
			
			$promo = DB::select("select promocode.promocode as code ,COUNT(*) as orders,SUM(discount_amount) as total, SUM(quantity) as qty FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where promode_code !=0 AND Bookings.Status='COMPLETED' AND promocode.id='".$promoId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND Bookings.warehouseId='".$outletId."' GROUP by Bookings.promode_code");
			
			return json_encode($promo);
			
		}
		
	}
	
	
	
	
	function promo_search_down($fromdate,$todate,$promoId,$outletId){
		
		
		$f_date = date("d-m-Y", strtotime($fromdate));
		$t_date = date("d-m-Y", strtotime($todate));
		
		
		if(empty($promoId)){
			
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.promode_code', '!=' , 0)
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.warehouseId'=>$outletId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
			  $description = "Promocode reports (".$f_date." - ".$t_date.")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);				  

		
		}else if(empty($fromdate) && empty($todate)){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.promode_code', '!=' , 0)
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.promode_code'=>$promoId,'Bookings.warehouseId'=>$outletId])
							  // ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
			  $description = "Promocode reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
		}else if($fromdate && $todate && $promoId){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.promode_code', '!=' , 0)
		                      ->Where(['Bookings.Status'=>'COMPLETED','Bookings.promode_code'=>$promoId,'Bookings.warehouseId'=>$outletId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
							  
			  $description = "Promocode reports (".$f_date." - ".$t_date.")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}
		
	}
	
	function outlet_status($id){
		
		
		$complete_day  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED'  AND DAY(CancelDate) = DAY(NOW()) AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' ");  
		
		foreach($complete_day as $list){
			 
			 if($list->Status == null){  
				 
				 $list->Status = "";
			 }
		 }
		 
		 $complete_week  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED'  AND YEARWEEK(CancelDate) = YEARWEEK(NOW()) AND Bookings.warehouseId='".$id."' ");
		
		foreach($complete_week as $list){
			 
			 if($list->Status == null){  
				 
				 $list->Status = "";
			 }
		 }
		
		$complete_month  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Status='COMPLETED'  AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED'  AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' ");
		
		foreach($complete_month as $list){
			 
			 if($list->Status == null){  
				 
				 $list->Status = "";
			 }
			 
		 } 
		 
		 $complete_year  =   DB::select("select COUNT(*) as orders,Status FROM Bookings  Where Status='COMPLETED'  AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Status='CANCELLED' AND  YEAR(CancelDate) = YEAR(NOW()) AND Bookings.warehouseId='".$id."' ");
		
		foreach($complete_year as $list){
			 
			 if($list->Status == null){  
				 
				 $list->Status = "";
			 }
		 } 
		
		
		
		 
		
		$DayRep  =   DB::select("SELECT *
						FROM (
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE  Bookings.warehouseId='".$id."' AND Status = 'COMPLETED' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())) 
						UNION
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Bookings.warehouseId='".$id."' AND Status = 'CANCELLED' AND DAY(CancelDate) = DAY(NOW()) AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW()))
						) AS i
						ORDER BY id DESC");
						
	    $WeekRe  =   DB::select("SELECT *
						FROM (
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Bookings.warehouseId='".$id."' AND Status = 'COMPLETED' AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW()))
						UNION
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Bookings.warehouseId='".$id."' AND Status = 'CANCELLED'  AND YEARWEEK(CancelDate) = YEARWEEK(NOW()))
						) AS i
						ORDER BY id DESC");						
						
	  
	  $MonthRep  =   DB::select("SELECT *
						FROM (
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Bookings.warehouseId='".$id."' AND Status = 'COMPLETED' AND   MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()))
						UNION
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Bookings.warehouseId='".$id."' AND Status = 'CANCELLED' AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW()))
						) AS i
						ORDER BY id DESC");
						
	$YearRep  =   DB::select("SELECT *
						FROM (
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Bookings.warehouseId='".$id."' AND Status = 'COMPLETED' AND YEAR(DeliverySuccessDate) = YEAR(NOW()))
						UNION
						(SELECT Bookings.id,Bookings.bookingId,Status,bookingDate,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Bookings.warehouseId='".$id."' AND Status = 'CANCELLED'  AND YEAR(CancelDate) = YEAR(NOW()))
						) AS i
						ORDER BY id DESC");					
		  
		
		
	 $summary = DB::select("select COUNT(*) as orders,Status from Bookings Where Status='COMPLETED' AND Bookings.warehouseId='".$id."' GROUP BY Status UNION ALL select COUNT(*) as orders,Status from Bookings Where Status='CANCELLED' AND Bookings.warehouseId='".$id."' GROUP BY Status");
	 
	 
		

		return array('Day'=>$complete_day,'Week'=>$complete_week,'Month'=>$complete_month,'Year'=>$complete_year,'DayRep'=>$DayRep,'WeekRe'=>$WeekRe,'MonthRep'=>$MonthRep,'YearRep'=>$YearRep,'summary'=>$summary);
		
		
	}
	
	
	
	function outlet_status_report($id,$type,$outletId){

		
		if($type == 'graph'){
			
			
			switch ($id) {
			case "1":
			
			
			$report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Bookings.warehouseId='".$outletId."' AND Status='COMPLETED'  AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where  Bookings.warehouseId='".$outletId."' ANDStatus='CANCELLED'  AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW())"); 	


						foreach($report as $list){
							 
							 if($list->Status == null){  
								 
								 $list->Status = "";
							 }
						 }

               						 
				return 	json_encode($report);
			
			break;
			
			
			case "2":
			
			$report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Bookings.warehouseId='".$outletId."' AND Status='COMPLETED'  AND  YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Bookings.warehouseId='".$outletId."' AND Status='CANCELLED'  AND  YEARWEEK(CancelDate) = YEARWEEK(NOW())"); 	


						foreach($report as $list){
							 
							 if($list->Status == null){  
								 
								 $list->Status = "";
							 }
						 }

               						 
				return 	json_encode($report);
			
			break;
			
			case "3":
			
			$report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Bookings.warehouseId='".$outletId."' AND Status='COMPLETED'  AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Bookings.warehouseId='".$outletId."' AND Status='CANCELLED'  AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW())"); 	


						foreach($report as $list){
							 
							 if($list->Status == null){  
								 
								 $list->Status = "";
							 }
						 } 
				return 	json_encode($report);	 
			
			break;
			
			case "4":
			
			
			$report  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Bookings.warehouseId='".$outletId."' AND Status='COMPLETED'  AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Bookings.warehouseId='".$outletId."' AND Status='CANCELLED' AND YEAR(CancelDate) = YEAR(NOW())"); 	


						foreach($report as $list){
							 
							 if($list->Status == null){  
								 
								 $list->Status = "";
							 }
						 } 
				return 	json_encode($report);	
			
			break;
			
			default:
				
				$data = array(array('orders'=>0,'Status'=>'COMPLETED'),array('orders'=>0,'Status'=>'CANCELLED'));
				
				return json_encode($data);
			
			}
			
			
		}else{
		
		
		switch ($id) {
			case "1":
				
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->Where('Bookings.warehouseId',$outletId)
							  ->whereDate('DeliverySuccessDate', '=', \DB::raw('CURDATE()'))
							  ->orwhereDate('CancelDate', '=', \DB::raw('CURDATE()'))
		                      ->get()
							  ->toArray();
              $description = "Success - cancelled totday reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
               							 
				
				break;
			case "2":
				
				$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->Where('Bookings.warehouseId',$outletId)
							  ->whereBetween('DeliverySuccessDate', [Carbon::now()->startOfWeek(),Carbon::now()->endOfWeek()])
							  ->orwhereBetween('CancelDate', [Carbon::now()->startOfWeek(),Carbon::now()->endOfWeek()])
		                      ->get()
							  ->toArray();
              $description = "Success - cancelled week reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
				
				
				break;
			case "3":
				
				$month = date('m');
	   
	            $now = Carbon::now();
                   $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->Where('Bookings.warehouseId',$outletId)
							  ->whereRaw('MONTH(DeliverySuccessDate) = ?',[$month])
							  ->orwhereRaw('MONTH(CancelDate) = ?',[$month])
		                      ->get()
							  ->toArray();
              $description = "Success - cancelled month reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			  
				break;
			case "4":
				
				
				$year = date('Y');
	   
	            $now = Carbon::now();
                   $Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->whereRaw('YEAR(DeliverySuccessDate) = ?',[$year])
							  ->orwhereRaw('YEAR(CancelDate) = ?',[$year])
		                      ->get()
							  ->toArray();
              $description = "Success - cancelled year reports (".date('d-m-Y').")";
			  $CommonFunction = new CommonFunctions();
			  $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
				
				break;
			default:
				echo "No data";
		}
		
	}
		
	}
	
	
	
	function outlet_search_status($fromdate,$todate,$typeId,$outletId){
		
		
		
		if(empty($typeId)){
			
	          
			  $Result  =   DB::select("SELECT *
						FROM (
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Bookings.warehouseId='".$outletId."' AND Status = 'COMPLETED' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' )
						UNION
						(SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id WHERE Bookings.warehouseId='".$outletId."' AND Status = 'CANCELLED' AND DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."')
						) AS i
						ORDER BY id DESC");
			
		
		    return $Result;
		}else if(empty($fromdate) && empty($todate)){

				
				$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id  Where Bookings.warehouseId='".$outletId."' AND Bookings.Status='".$typeId."' ORDER BY Bookings.id DESC");

			
           return $Result;
			
		}else if($fromdate && $todate && $typeId){
		
          if($typeId == 'COMPLETED'){
		
		$Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id  Where Bookings.warehouseId='".$outletId."' AND Bookings.Status='".$typeId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  ORDER BY Bookings.id DESC");
		
		  }else if($typeId == 'CANCELLED'){
			  
			  
			  $Result = DB::select("SELECT Bookings.id,Bookings.bookingId,bookingDate,Status,COALESCE(reasons, '') AS cancelReason FROM Bookings left join CancelReason on Bookings.CancelReason = CancelReason.id Where Bookings.warehouseId='".$outletId."' AND Bookings.Status='".$typeId."' AND DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."'  ORDER BY Bookings.id DESC");
			  
		  }
		
		
		return $Result;
		}
		
	}
	
	
	
	function outlet_down_status($fromdate,$todate,$typeId,$outletId){
		
		
		 $f_date = date("d-m-Y", strtotime($fromdate));
		     $t_date = date("d-m-Y", strtotime($todate));
			
		
		if(empty($typeId)){
		
		$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->where('Bookings.warehouseId',$outletId)
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  ->orwhereRaw("DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
		
            $description = "success - cancelled reports (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);		
							  
		}else if(empty($fromdate) && empty($todate)){
			
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->Where(['Bookings.warehouseId'=>$outletId,'Bookings.Status'=>$typeId])
							  ->whereIn('Bookings.Status', ['COMPLETED','CANCELLED'])
		                      ->get()
							  ->toArray();
			
			$current = date('d-m-Y');
			
			
			 $description = "success - cancelled  - ".$typeId." (".$current.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);	
			
		}else if($fromdate && $todate && $typeId){
			
			$Bookings = Bookings::Select('Bookings.id','Bookings.bookingId','Bookings.userId','users.name as username','users.email as useremail','users.mobile as usermobile','users.alternate_number as user_al_number','pickupDeliveryUserId','pickupdeliveryusers.name as pickupusers','pickupdeliveryusers.mobile as pick_us_mobile','Bookings.DeliveryUserId','Bookings.addressId','Bookings.warehouseId','flatNo','landmark','Pincode.code','UserAddresses.address','UserAddresses.serviceAreaId','Bookings.bookingDate','delivery_date','bookingTimeSlot','TimeSlots.fromSlots','TimeSlots.toSlots','Bookings.quantity','paymentType','Bookings.Status','ConfirmOrder','WaytoPickup',DB::raw("DATE_FORMAT(OrderConfirmDate, '%d-%l-%Y') as confirm_date"),DB::raw("TIME(OrderConfirmDate) as confirm_time"),DB::raw("TIME(WaytoPickupDate) as waypick_time"),DB::raw("DATE_FORMAT(WaytoPickupDate, '%d-%l-%Y') as waypick_date"),'PickupSuccess',DB::raw("DATE_FORMAT(PickupSuccessDate, '%d-%l-%Y') as pickup_date"),DB::raw("TIME(PickupSuccessDate) as pickup_time"),'WaytoDelivery',DB::raw("TIME(DeliveryDate) as waydeli_time"),DB::raw("DATE_FORMAT(DeliveryDate, '%d-%l-%Y') as waydeli_date"),'DeliverySuccess',DB::raw("DATE_FORMAT(DeliverySuccessDate, '%d-%l-%Y') as deli_date"),DB::raw("TIME(DeliverySuccessDate) as delivery_time"),'CancelDate','cancelReason','CancelReason.reasons','StartJob','taxamount','totalPayment','Bookings.discount_amount','Bookings.promode_code','promocode.promocode')
		                      ->leftjoin('promocode','promocode.id','=','Bookings.promode_code')
		                      ->join('users','users.id', '=', 'Bookings.userId')
							  ->leftjoin('CancelReason','CancelReason.id','=','Bookings.CancelReason')
							  ->join('pickupdeliveryusers','pickupdeliveryusers.id','=','Bookings.pickupDeliveryUserId')
							  ->join('TimeSlots','TimeSlots.id', '=', 'Bookings.bookingTimeSlot')
							  ->join('UserAddresses','UserAddresses.id', '=', 'Bookings.addressId')
							  ->join('Pincode','Pincode.id','=','Bookings.service_area' )
							  ->Where(['Bookings.warehouseId'=>$outletId,'Bookings.Status'=>$typeId])
							  ->whereRaw("DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'")
							  ->orwhereRaw("DATE(CancelDate) BETWEEN '".$fromdate."' AND '".$todate."'")
		                      ->get()
							  ->toArray();
							  
		    $description = "success - cancelled reports - ".$typeId." (".$f_date." - ".$t_date.")";
			
			$CommonFunction = new CommonFunctions();
		    $Reports = $CommonFunction->get_excel_pincode($Bookings,$description);
			
			
		}
		
	}
	
	
	function outlet_promo_graph($outletId){
		
		$promocode = DB::select("select COUNT(*) as orders,promode_code,promocode.promocode as code FROM Bookings inner join promocode on Bookings.promode_code = promocode.id Where Bookings.warehouseId='".$outletId."' AND  promode_code !=0 AND Bookings.Status='COMPLETED' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND  MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) GROUP by Bookings.promode_code");
		
		return json_encode($promocode); 
	}
	
	
	function outlet_status_graph_day($id){
		
		 $completearr  =   DB::select("select COUNT(*) as orders,Status FROM Bookings Where Bookings.warehouseId='".$id."' AND Status='COMPLETED'  AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  UNION ALL  select COUNT(*) as orders, Status FROM Bookings Where Bookings.warehouseId='".$id."' AND Status='CANCELLED' AND DAY(CancelDate) = DAY(NOW())  AND MONTH(CancelDate) = MONTH(CURRENT_DATE()) AND YEAR(CancelDate) = YEAR(NOW())"); 	


		foreach($completearr as $list){
			 
			 if($list->Status == null){  
				 
				 $list->Status = "";
			 }
		 } 			
		
		return  json_encode($completearr); 
		
	}
	
	
	function outlet_clothes_graph($id,$type,$outletId){
		
		switch ($type) {
			case "1":
			
			$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
			
			return json_encode($report);
			
			
			break;
			case "2":
			
			$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where   YEARWEEK(Bookings.DeliverySuccessDate) = YEARWEEK(NOW()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
			
			return json_encode($report);
			
			
			break;
			case "3":
			
			$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where  MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
			
			return json_encode($report);
			
			break;
			case "4":
			
			$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where   YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
			
			return json_encode($report);
			
			break;
			
			default:
				$report = DB::select("select COUNT(Booking_Items.id) as orders,groupName,CategoryList.Price,SUM(Booking_Items.quantity) as quantity,Booking_Items.categoryId,NewCategories.name, SUM(Booking_Items.quantity)  as quantity from Bookings inner join Booking_Items on Booking_Items.bookingId = Bookings.id inner join NewCategories on NewCategories.id = Booking_Items.categoryId inner join CategoryList on NewCategories.categoryId = CategoryList.id Where DAY(Bookings.DeliverySuccessDate) = DAY(NOW()) AND MONTH(Bookings.DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(Bookings.DeliverySuccessDate) = YEAR(CURRENT_DATE()) AND  CategoryList.id='".$id."'   Group by Booking_Items.categoryId");
				
				return json_encode($report);
			
		}
		
	}
	
	
	
	function outlet_avg_cost($id){
		
		/**********Today***********/
		$Today = DB::select("select SUM(totalPayment) as payment ,SUM(quantity) as quantity from Bookings Where warehouseId='".$id."' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1'");
		
	    if(json_encode(!$Today[0]->payment) == null){
		
		if(count($Today) > 0){
			
			$arr = [];
			foreach($Today as $rep){
			
			$stdday = (object) array();
			$stdday->payment  = $rep->payment;
			$stdday->quantity  = $rep->quantity;
			
			$today_sum  = $rep->payment / $rep->quantity;
		
			$today_avg  =  round($today_sum * 100 / 118, 2);
			
			$stdday->avg_cost  = $today_avg;
			
			array_push($arr,$stdday);
		}
		
		}else{
			
			$stdday = (object) array();
			$stdday->payment  = 0;
			$stdday->quantity  = 0;
			$stdday->avg_cost  = 0;
		}
		
		}else{
			
			$stdday = (object) array();
			$stdday->payment  = 0;
			$stdday->quantity  = 0;
			$stdday->avg_cost  = 0;
		}
		
		
	  
		/**********Week***********/
		
		$Week = DB::select("select SUM(totalPayment) as payment ,SUM(quantity) as quantity from Bookings Where warehouseId='".$id."' AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())  AND DeliverySuccess ='1'");
		
		// echo json_encode($Week[0]->payment);die;   
		
		if(!$Week[0]->payment == null){
			
		
		if(count($Week) > 0){
			
			$arr = [];
			foreach($Week as $rep){
			
			$stdweek = (object) array();
			$stdweek->payment  = $rep->payment;
			$stdweek->quantity  = $rep->quantity;
			
			$week_sum  = $rep->payment / $rep->quantity;
		
			$week_avg  =  round($week_sum * 100 / 118, 2);
			
			$stdweek->avg_cost  = $week_avg;
			
			array_push($arr,$stdweek);
		}
		
		}else{
			
			$stdweek = (object) array();
			$stdweek->payment  = 0;
			$stdweek->quantity  = 0;
			$stdweek->avg_cost  = 0;
		}
		
		}else{
			
			$stdweek = (object) array();
			$stdweek->payment  = 0;
			$stdweek->quantity  = 0;
			$stdweek->avg_cost  = 0;
		}
		
		

		/*********Month************/
		
		$Month = DB::select("select SUM(totalPayment) as payment ,SUM(quantity) as quantity from Bookings Where warehouseId='".$id."' AND MONTH(DeliverySuccessDate) = MONTH(CURRENT_DATE()) AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1'");
		
		  // echo json_encode ($Month[0]->payment);die;
		
		if(!$Month[0]->payment == null){
		
	
		
		if(count($Month) > 0){
			
			$arr = [];
			
			foreach($Month as $rep){
			
			$stdmonth = (object) array();
			$stdmonth->payment  = $rep->payment;
			$stdmonth->quantity  = $rep->quantity;
			
			$month_sum  = $rep->payment / $rep->quantity;
		
			$month_avg  =  round($month_sum * 100 / 118, 2);
			
			$stdmonth->avg_cost  = $month_avg;
			
			array_push($arr,$stdmonth);
		}
			
		
		}else{
			
			$stdmonth = (object) array();
			$stdmonth->payment  = 0;
			$stdmonth->quantity  = 0;
			$stdmonth->avg_cost  = 0;
		}
		
		}else{
			
			$stdmonth = (object) array();
			$stdmonth->payment  = 0;
			$stdmonth->quantity  = 0;
			$stdmonth->avg_cost  = 0;
			
			// echo 'hii';die;
		}
		
		// echo json_encode($stdmonth);die;
		
		/*********Year************/
		$Year = DB::select("select SUM(totalPayment) as payment ,SUM(quantity) as quantity from Bookings Where warehouseId='".$id."' AND YEAR(DeliverySuccessDate) = YEAR(NOW())  AND DeliverySuccess ='1'");
		
		
		$arr = [];
		if(!$Year[0]->payment == null){
		
		if(count($Year) > 0){
		
		foreach($Year as $rep){
			
			$stdyear = (object) array();
			$stdyear->payment  = $rep->payment;
			$stdyear->quantity  = $rep->quantity;
			
			$year_sum  = $rep->payment / $rep->quantity;
		
			$year_avg  =  round($year_sum * 100 / 118, 2);
			
			$stdyear->avg_cost  = $year_avg;
			
			array_push($arr,$stdyear);
		}
		
		}else{
			
			$stdyear = (object) array();
			$stdyear->payment  = 0;
			$stdyear->quantity  = 0;
			$stdyear->avg_cost  = 0;
		}
		
		}else{
			
			$stdyear = (object) array();
			$stdyear->payment  = 0;
			$stdyear->quantity  = 0;
			$stdyear->avg_cost  = 0;
		}
		
		
		
		
		
		return array('Today'=>$stdday,'Week'=>$stdweek,'Month'=>$stdmonth,'Year'=>$stdyear);
		
	}
	
	
	
	function outlet_avg_search($outletId,$fromdate,$todate){
		
		$Year = DB::select("select SUM(totalPayment) as payment ,SUM(quantity) as quantity from Bookings Where warehouseId='".$outletId."' AND DATE(Bookings.DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."'  AND DeliverySuccess ='1' ");
		
		
		$arr = [];
		if(!$Year[0]->payment == null){
		
		if(count($Year) > 0){
		
		foreach($Year as $rep){
			
			$stdyear = (object) array();
			$stdyear->payment  = $rep->payment;
			$stdyear->quantity  = $rep->quantity;
			
			$year_sum  = $rep->payment / $rep->quantity;
		
			$year_avg  =  round($year_sum * 100 / 118, 2);
			
			$stdyear->avg_cost  = $year_avg;
			
			array_push($arr,$stdyear);
		}
		
		}else{
			
			$stdyear = (object) array();
			$stdyear->payment  = 0;
			$stdyear->quantity  = 0;
			$stdyear->avg_cost  = 0;
		}
		
		}else{
			
			$stdyear = (object) array();
			$stdyear->payment  = 0;
			$stdyear->quantity  = 0;
			$stdyear->avg_cost  = 0;
		}
		
		$new  = json_encode($stdyear);
		
		return json_encode($stdyear);
		
	}
	
	
	function out_pickup_reports($userId){
		
		
		
		$TodayReport = DB::Select("SELECT id,bookingId,bookingDate,Status, 'Pickup'  FROM Bookings WHERE pickupDeliveryUserId='".$userId."' AND PickupSuccess='1' AND DAY(PickupSuccessDate) = DAY(NOW()) AND MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT id,bookingId,bookingDate,Status, 'Delivery' FROM Bookings WHERE DeliveryUserId='".$userId."' AND DeliverySuccess='1' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate	) = YEAR(NOW()) order by id desc");
		
		
		$WeekReport = DB::Select("SELECT id,bookingId,bookingDate,Status, 'Pickup'  FROM Bookings WHERE pickupDeliveryUserId='".$userId."'  AND YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) UNION ALL SELECT id,bookingId,bookingDate,Status, 'Delivery' FROM Bookings WHERE DeliveryUserId='".$userId."' AND DeliverySuccess='1' AND YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())  order by id desc");
		
		
		$MonthReport = DB::Select("SELECT id,bookingId,bookingDate,Status, 'Pickup'  FROM Bookings WHERE pickupDeliveryUserId='".$userId."' AND PickupSuccess='1' AND MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT id,bookingId,bookingDate,Status, 'Delivery' FROM Bookings WHERE DeliveryUserId='".$userId."' AND DeliverySuccess='1'  AND MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate) = YEAR(NOW()) order by id desc");
		
		$YearReport = DB::Select("SELECT id,bookingDate,bookingId,Status, 'Pickup'  FROM Bookings WHERE pickupDeliveryUserId='".$userId."' AND PickupSuccess='1'  AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT id,bookingDate,bookingId,Status, 'Delivery' FROM Bookings WHERE DeliveryUserId='".$userId."' AND DeliverySuccess='1'  AND YEAR(DeliverySuccessDate	) = YEAR(NOW()) order by id desc");
		
		$Days = DB::Select("SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'Pickup' FROM Bookings WHERE pickupDeliveryUserId='".$userId."' AND PickupSuccess='1' AND DAY(PickupSuccessDate) = DAY(NOW()) AND MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'delivery' FROM Bookings WHERE DeliveryUserId='".$userId."' AND DeliverySuccess='1' AND DAY(DeliverySuccessDate) = DAY(NOW()) AND MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate	) = YEAR(NOW())");
		
		$Weeks = DB::Select("SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'Pickup' FROM Bookings WHERE pickupDeliveryUserId='".$userId."' AND PickupSuccess='1'  AND YEARWEEK(PickupSuccessDate) = YEARWEEK(NOW()) UNION ALL SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'delivery' FROM Bookings WHERE DeliveryUserId='".$userId."' AND DeliverySuccess='1' AND  YEARWEEK(DeliverySuccessDate) = YEARWEEK(NOW())");
		
		
		$Months = DB::Select("SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'Pickup' FROM Bookings WHERE pickupDeliveryUserId='".$userId."' AND PickupSuccess='1' AND  MONTH(PickupSuccessDate) = MONTH(NOW()) AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'delivery' FROM Bookings WHERE DeliveryUserId='".$userId."' AND DeliverySuccess='1' AND  MONTH(DeliverySuccessDate) = MONTH(NOW()) AND YEAR(DeliverySuccessDate	) = YEAR(NOW())");
		
		$Years = DB::Select("SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'Pickup' FROM Bookings WHERE pickupDeliveryUserId='".$userId."' AND PickupSuccess='1'  AND YEAR(PickupSuccessDate) = YEAR(NOW()) UNION ALL SELECT COUNT(*) as orders,SUM(totalPayment) as total,SUM(quantity) as qty,'delivery' FROM Bookings WHERE DeliveryUserId='".$userId."' AND DeliverySuccess='1' AND  YEAR(DeliverySuccessDate	) = YEAR(NOW())");
		
		
		return array('TodayOrder'=>$TodayReport,'WeekOrder'=>$WeekReport,'MonthOrder'=>$MonthReport,'YearOrder'=>$YearReport,'Days'=>$Days,'Months'=>$Months,'Years'=>$Years,'Weeks'=>$Weeks);
	}
	
	
	
	
	function outlet_clothes_category($fromdate,$todate,$cateId,$outletId){
		

		if(empty($cateId)){
		
		
		$day_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$outletId."' AND  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' Group by CategoryList.id");
			
			
		$day_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$outletId."' AND  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' Group by CategoryList.id");
		    
		return array("amount"=>$day_amount,"quantity"=>$day_qty);
		
		
		}else if(empty($fromdate) && empty($todate)){
			
			
		$day_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$outletId."' AND CategoryList.id='".$cateId."' Group by CategoryList.id");
			
			
		$day_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$outletId."' AND CategoryList.id='".$cateId."' Group by CategoryList.id");
		    
		return array("amount"=>$day_amount,"quantity"=>$day_qty);
		
		// return $day_qty;
			
			
		}else if($fromdate && $todate && $cateId){
			
		$day_amount = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$outletId."' AND  DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND CategoryList.id='".$cateId."' Group by CategoryList.id");
			
			
		$day_qty = DB::select("select CategoryList.id,CategoryList.name,SUM(Booking_Items.quantity) as qty,CategoryList.Price * SUM(Booking_Items.quantity) as price_amount from CategoryList inner join NewCategories on NewCategories.categoryId = CategoryList.id inner join Booking_Items on Booking_Items.categoryId = NewCategories.id inner join Bookings on Bookings.id = Booking_Items.bookingId Where Bookings.warehouseId='".$outletId."' AND DATE(DeliverySuccessDate) BETWEEN '".$fromdate."' AND '".$todate."' AND CategoryList.id='".$cateId."' Group by CategoryList.id");
		    
		return array("amount"=>$day_amount,"quantity"=>$day_qty);
			
		}
		
	}
	
	
}







?>