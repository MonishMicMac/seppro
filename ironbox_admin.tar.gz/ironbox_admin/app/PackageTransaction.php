<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackageTransaction extends Model
{
    protected $table='package_transaction';
}
