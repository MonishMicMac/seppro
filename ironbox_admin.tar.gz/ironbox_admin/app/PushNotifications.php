<?php

namespace App;
class PushNotifications{
	
	
	
   function SentPush($title,$body,$token,$os,$arraydata){	
	
	$url = 'https://fcm.googleapis.com/fcm/send';
		
	$serverKey = "AAAAqPH72Rs:APA91bHxHX9b5faInlb-kyREhNSP7pE2N0euQJjemQqNORKkHYXRf2JhpXM4p9DAkQ4SHDdBY6pH17YasNuNX2Sfv51qaXeNnDWi-v_Fou_cLWQr-VeEIUCvCjMY_nrhUEOmyfBjZ1uw";
		
		
	$headers = array(
		'Authorization: key=' . $serverKey,
		'Content-Type: application/json'
	);
	
	
	
	if($arraydata['deliverystatus'] == 'Yes'){
		
		$Status = "Yes";
	}else{
		
		$Status = "";
	}
	
	if($os == 'ios'){
	
	$messagedata = array(
	             'title'=>$title,
				 'body'=>$body,
	             "BookingId"=>$arraydata['BookingId'],
				 "message"=>$arraydata['message'],
				 "DeliveryStatus"=>$Status
				 );
		//return $messagedata;die;
		
		$msg['title'] = $title;
        $msg['body'] = $body;
        $msg['icon'] = 'ic_launcher.png';

		
		$fields = array(
			 'to' => $token,
			 'data' => $messagedata,
			 'notification'=>$msg,
			 'content_available'=>true,
			 'icon'=>'ic_launcher.png',
			 'badge' => 1,
             'sound' => 'default'
			);
			
			
	}else{
		
		$messagedata = array(	
	             'title'=>$title,
				 'body'=>$body,
	             "BookingId"=>$arraydata['BookingId'],
				 "message"=>$arraydata['message'],
				 "DeliveryStatus"=>$Status
				 );
		//return $messagedata;die;
		
		// $msg['title'] = $title;
        // $msg['body'] = $body;
        // $msg['icon'] = 'ic_launcher.png';

		
		$fields = array(
			 'to' => $token,
			 'data' => $messagedata,
			 //'notification'=>$msg,
			 'content_available'=>true,
			 'icon'=>'ic_launcher.png',
			 'badge' => 1,
             'sound' => 'default'
			);
		
	}
		//return $fields;
	   $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, $url);
       curl_setopt($ch, CURLOPT_POST, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);  
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
       $result = curl_exec($ch);           
       if ($result === FALSE) {
           die('Curl failed: ' . curl_error($ch));
       }
       curl_close($ch);
       return $result;	
   }
	
}

?>