<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceAreas extends Model
{
     protected $table='ServiceAreas';
}
