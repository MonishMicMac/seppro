<?php



namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class Warehouses extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $table='warehouses';

    protected $fillable = ['name', 'email', 'password'];
}