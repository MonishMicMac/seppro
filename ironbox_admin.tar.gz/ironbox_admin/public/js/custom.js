// Base Url
var base_url = 'http://13.126.228.76/ironbox_admin/public/';


$(document).ready(function(){
   $("#booking_mobile").keyup(function(){
	  var Result = $('#promo_valid');
	  var mobile =  $("#booking_mobile").val();
      
		  var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/UserMobile',
				data: {_token: csrf,mobile : mobile},
				success: function (data) { 			
				        $("#useraddr").empty();
						$("#useraddr").append('<option value="">Select address</option>');
						if(data != 0){
							
							var user_addr = data.address;
							
							 $.each(user_addr, function (i) {
								 
								 $("#useraddr").append('<option '+user_addr[i].id+'>'+user_addr[i].address+'</option>');
							});	
						}
					}
				});
		
    });  
});



$("#Main_Category").change(function(){
	if(($('#Main_Category').val()) != ''){
	$('#Main_Category').removeClass('warn');	
	$('.main_cate').css({"display": "none"});
	}
});

$("#clothes_type").change(function(){
	if(($('#clothes_type').val()) != ''){
	$('#clothes_type').removeClass('warn');	
	$('.main_type').css({"display": "none"});
	}
});

 $('#Main_Category,#clothes_type').on('change',function(){
 // var id = $(this).val();
 
 if(($('#Main_Category').val()) == ''){
	$('#Main_Category').addClass('warn').focus();
	$('.main_cate').css({"display": "block"});
	return false;	   
}

if(($('#clothes_type').val()) == ''){
	$('#clothes_type').addClass('warn').focus();
	$('.main_type').css({"display": "block"});
	return false;
}
 
 var id = $("#Main_Category").val();
 
  var type = $("#clothes_type").val();
 
 // alert(type);
 var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/category_clothes_report',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
              //var test  =JSON.parse(data);
			  console.log(data);
			  demo.CategoryClothesRep(data);

            }
        });
});

//Check Promocode
$(document).ready(function(){
   $("#promocode").keyup(function(){
	  var Result = $('#promo_valid');
	  var promocode =  $("#promocode").val();
      
		  var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/CheckPromocode',
				data: {_token: csrf,promocode : promocode},
				success: function (data) { 			
				   if(data == 1){
				
					   $('#promo_btn2').attr('disabled', 'disabled');
					   Result.html('<span style="color:red;">Promo Code Already Used<span>');
						   
					   }else{
						   $('#promo_btn2').prop("disabled", false);
						   Result.html('<span style="color:green;">Available<span>');
						}
						
					}
				});
		
    });  
}); 


//Edit check promocode
$(document).ready(function(){
   $("#promocode_name").keyup(function(){
	   
	  var Result = $('#promo_valid');
	  var promocode =  $("#promocode_name").val();
	  var id =  $("#promocode_id").val();
	  
	  var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/EditCheckPromocode',
				data: {_token: csrf,promocode : promocode,id:id},
				success: function (data) {                
				     //console.log(data);
					 if(data == 1){
                       Result.html('<span style="color:green;">Current used</span>');
					   $('#promo_btn3').prop("disabled", false);
					}
					else if(data == 2){
						Result.html('<span style="color:red;">Promo Code Already Used</span>');
						$('#promo_btn3').attr('disabled', 'disabled');
					}else if(data == 3){
						Result.html('<span style="color:green;">Available</span>');
						$('#promo_btn3').prop("disabled", false); 
					}
					
					}
				});
	  

    });  
});

$(document).ready(function(){
   $("#mobile").keyup(function(){
	   
	   var mobile =  $("#mobile").val();
	   
	   var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/UserProfile',
				data: {_token: csrf,mobile : mobile},
				success: function (data) {                
				    
					if(data != 0){
					
					   console.log('true');
					$("#username").html("<b>"+data.name+"</b>");
					$("#usermobile").html("<b>"+data.mobile+"</b>");
					$("#useremail").html("<b>"+data.email+"</b>");
					}
					
					if(data.id == undefined){
						
						$("#username").html("<b> Invalid </b>");
					$("#usermobile").html("<b> Invalid </b>");
					$("#useremail").html("<b> Invalid </b>");
					}
					
					
					
					}
				});
	   
    });  
});

//PickUpuser active
$( ".Is_active" ).click(function() {
	  var id = $(this).attr('value');
	   //alert(id);
	   var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/PickUpuserActive',
				data: {_token: csrf,id : id},
				success: function (data) {                
	
			          //console.log(data);
					  location.reload();
					
					}
			});

});



//IroningVendor active
$( ".Is_active_vendor" ).click(function() {
	  var id = $(this).attr('value');
	   // alert(id);
	   var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/IroningVendorActive',
				data: {_token: csrf,id : id},
				success: function (data) {                
	
			          console.log(data);
					  location.reload();
					
					}
			});

});




//Check Pincode 
$(document).ready(function(){
	
   $("#pincode").keyup(function(){
	
       var pincode =  $("#pincode").val();
	    var Result = $('#pin_valid');
		
	   var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/CheckPincode',
				data: {_token: csrf,pincode : pincode},
				success: function (data) {                
				
					 if(data == 1){
						 
						Result.html('<span style="color:red;">Already Added</span>');
					    $('#pin_btn').prop("disabled", 'disabled');
					   
					    }else if(data == 0){
							
							 Result.html('<span style="color:green;">Not In db</span>');
							 $('#pin_btn').prop("disabled", false);
						}
					
					}
				});
	  
	  
    });  
});


//Edit PinCode
$( ".pin_edit" ).click(function() {
		 var id = $(this).attr('value');
			//alert(id);
			var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/EditCheckPincode',
				data: {_token: csrf,id : id},
				success: function (data) {                
	
			           var response  =JSON.parse(data);

					    $('#Epincode').val(response[0].code);
					    $('#Epinid').val(response[0].id);
					    $('#Eareaname').val(response[0].area);
						
						if(response[0].warehouseId == '1'){ var ware1= 'Selected' };
						if(response[0].warehouseId == '2'){ var ware2= 'Selected' };
						$("#editwarehousename").empty();
						
						$("#editwarehousename").append('<option value="">Select warehouse</option><option value = "1" '+ware1+'>Warehouse 1</option> <option value = "2" '+ware2+'>Warehouse 2</option>');
						
					    $('#warehouse').val(response[0].warehouseId);
					
					}
				});
	
		
});


//Edit Check pincode
$(document).ready(function(){
	
   $("#Epincode").keyup(function(){
	
        var pincode =  $("#Epincode").val();
        var id =  $("#Epinid").val();
	    var Result = $('#Epin_valid');
		
		//alert(pincode)
		
	   var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/EditPinCheck',
				data: {_token: csrf,pincode : pincode,id : id},
				success: function (data) {                
				console.log(data);
				
					 // if(data == 1){
						 
						// Result.html('<span style="color:red;">Already Added</span>');
					    // $('#pin_btn1').prop("disabled", 'disabled');
					   
					    // }else if(data == 0){
							
							 // Result.html('<span style="color:green;">Not In db</span>');
							 // $('#pin_btn1').prop("disabled", false);
						// }
						
						if(data == 1){
						   Result.html('<span style="color:green;">Current used</span>');
						   $('#pin_btn1').prop("disabled", false);
						}
						else if(data == 2){
							Result.html('<span style="color:red;">PinCode Already Used</span>');
							$('#pin_btn1').attr('disabled', 'disabled');
						}else if(data == 3){
							Result.html('<span style="color:green;">Available</span>');
							$('#pin_btn1').prop("disabled", false); 
						}
					
					}
				});
	  
	  
    });  
});



$( ".slot_edit" ).click(function() {
		 var id = $(this).attr('value');
			// alert(id);
			
			
			
			var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/ViewSlot',
				data: {_token: csrf,id : id},
				success: function (data) {                
	   
	                     // console.log(data);
					   var response  =JSON.parse(data);
                        
					    $('#Efromslot').val(response.fromSlots);
					    $('#Etoslot').val(response.toSlots);
					    $('#Eslotid').val(response.id);

					}
				});
	
		
});


$( ".outlet_edit" ).click(function() {
		 var id = $(this).attr('value');
			// alert(id);
			
			
			
			var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/ViewOutlet',
				data: {_token: csrf,id : id},
				success: function (data) {                
	                    
						
					   var response  =JSON.parse(data);
					   
					   // console.log(response.longitude);
                        
					    $('#out_id').val(response.id);
					    $('#Out_name').val(response.name);
					    $('#Out_address').val(response.address);
					    $('#Out_latitude').val(response.latitude);
					    $('#Out_longitude').val(response.longitude);

					}
				});
	
		
});

$('#warehousId').on('change',function(){
	var id = $(this).val();
		
	var csrf = $('meta[name="csrf-token"]').attr('content');
	$.ajax({
            type: "GET",
            url: base_url+'/GetServicearea',
            data: {_token: csrf,id: id},
            success: function (data) { 
			console.log(data);
			//console.log($('.selectpicker').length);
            $("#pincode").empty();
			$("#pincode").append('<option value="">Select area</option>');
				$.each(data, function (i) {
					 $("#pincode").append('<option  value="'+data[i].id+'">'+data[i].area+'</option>');
				 });
            }
        });	

		
});


//Edit Categoty
$( ".edit_categorylist" ).click(function() {
		 var id = $(this).attr('value');
			//alert(id);
			var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/EditCategory',
				data: {_token: csrf,id : id},
				success: function (data) {                
                       console.log(data);  
					   $('#Enames').val(data[0].name);
					   $('#Eprice').val(data[0].Price);
					   $('#Eqty').val(data[0].Qty);  
					   $('#Eid').val(data[0].id);
					}
				});
	
		
});


$('#MainCategory').on('change',function(){
	var id = $(this).val();
    var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/GetGroupName',
				data: {_token: csrf,id : id},
				success: function (data) {  
                      console.log(data);
                       $("#groupname").empty();					  
                       $("#groupname").append('<option value="">Select groupname</option>');
						$.each(data, function (i) {
					
							 $("#groupname").append('<option  value="'+data[i].name+'">'+data[i].name+'</option>');
						 });
					}
				});
	
});	

$("#addsudcategoty").on('submit',(function(e) {
e.preventDefault();
    // if(($('#name').val()) == ''){
	// $('#name').addClass('warn').focus();
	// return false;	   
	// }
	
	

   $.ajaxSetup({
        header:$('meta[name="_token"]').attr('content')
    });

      $.ajax({  
                url:base_url+'/SaveMainCategory',  
                method:"POST",  
                data:new FormData(this),  
                contentType:false,  
                processData:false,  
                success:function(data)  
                {  
                     console.log(data); 
                }  
           });

}));



$( ".pickup_report" ).click(function() {
	
	var id = $(this).attr('value');
	// alert(id);
	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/PickUpuserGraph',
            data: {_token: csrf,id: id},
            success: function (data) { 
                   console.log(data);
				   demo.initDashboardPageCharts();
            }
        });
		
	});

$("#checkall").click(function () {
	// alert(3);
    $('.checked5').not(this).prop('checked', this.checked);
	
	var fields = $("input[name='bookingId[]']").serializeArray();
	// alert(fields.length);
	if (fields.length == 0) {
			
			$('#assign_btn').css({"display": "none"});
		}else{
			$('#assign_btn').css({"display": "block"});
		}
});	

$("#checkalldelivery").click(function () {
	// alert(3);
    $('.checked6').not(this).prop('checked', this.checked);
	
	var fields = $("input[name='bookingId4[]']").serializeArray();
	// alert(fields.length);
	if (fields.length == 0) {
			
			$('#delivery_btn').css({"display": "none"});
		}else{
			$('#delivery_btn').css({"display": "block"});
		}
});	



$('.checkedboxclick').click(function() {
	var fields = $("input[name='bookingId[]']").serializeArray();
      	 if (fields.length == 0) {
			
			$('#assign_btn').css({"display": "none"});
		}else{
			$('#assign_btn').css({"display": "block"});
		}
   
	});
	
	$('.checkedboxclick5').click(function() {
	var fields = $("input[name='bookingId4[]']").serializeArray();
      	 if (fields.length == 0) {
			
			$('#delivery_btn').css({"display": "none"});
		}else{
			$('#delivery_btn').css({"display": "block"});
		}
   
	});
	


$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});


////////////////******************************form vallidation 