type = ['', 'info', 'success', 'warning', 'danger'];


demo = {
    initPickColor: function() {
        $('.pick-class-label').click(function() {
            var new_class = $(this).attr('new-class');
            var old_class = $('#display-buttons').attr('data-class');
            var display_div = $('#display-buttons');
            if (display_div.length) {
                var display_buttons = display_div.find('.btn');
                display_buttons.removeClass(old_class);
                display_buttons.addClass(new_class);
                display_div.attr('data-class', new_class);
            }
        });
    },

    initDocumentationCharts: function() {
        /* ----------==========     Daily Sales Chart initialization For Documentation    ==========---------- */

        dataDailySalesChart = {
            labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
            series: [
                [12, 17, 7, 17, 23, 18, 38]
            ]
        };

        optionsDailySalesChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: 50, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
        }

        var dailySalesChart = new Chartist.Line('#dailySalesChart', dataDailySalesChart, optionsDailySalesChart);

        md.startAnimationForLineChart(dailySalesChart);
    },
	
	TotalRevenue: function(data) {
		
		
		var arrdata=JSON.parse(data);
		orders = [];
		 orderdate = [];
		 
		 $.each(arrdata, function (i) {
                var ord=arrdata[i].orders;
                var ord_date=arrdata[i].order_date;
                
				orders.push(ord);
				orderdate.push(ord_date);
			 });
			 
			 var dataEmailsSubscriptionChart = {
            labels: orderdate,
            series: [
                orders

            ]
        };
		
		var high =  Math.max.apply(Math,orders);
		    var new_val = high + 1000;
			
        var optionsEmailsSubscriptionChart = {
            axisX: {
                showGrid: false
            },
            low: 0,
            high: new_val,
            chartPadding: {
                top: 0,
                right: 5,
                bottom: 0,
                left: 0
            }
        };
        var responsiveOptions = [
            ['screen and (max-width: 640px)', {
                seriesBarDistance: 5,
                axisX: {
                    labelInterpolationFnc: function(value) {
                        return value[0];
                    }
                }
            }]
        ];
        var emailsSubscriptionChart = Chartist.Bar('#TotalRevenue', dataEmailsSubscriptionChart, optionsEmailsSubscriptionChart, responsiveOptions);

        //start animation for the Emails Subscription Chart
        md.startAnimationForBarChart(emailsSubscriptionChart);
			 
	},
	
	pickupUserChart: function(data) {
		// console.log(data);
		var arrdata=JSON.parse(data);
		orders = [];
		 orderdate = [];
		 
		 $.each(arrdata, function (i) {
                var ord=arrdata[i].orders;
                var ord_date=arrdata[i].order_date;
                
				orders.push(ord);
				orderdate.push(ord_date);
			 });
			 
			
			 var high =  Math.max.apply(Math,orders);
		    var new_val = high + 50;
			 
			  var dataEmailsSubscriptionChart = {
            labels: orderdate,
            series: [
                orders

            ]
        };
        var optionsEmailsSubscriptionChart = {
            axisX: {
                showGrid: false
            },
            low: 0,
            high: new_val,
            chartPadding: {
                top: 0,
                right: 5,
                bottom: 0,
                left: 0
            }
        };
        var responsiveOptions = [
            ['screen and (max-width: 640px)', {
                seriesBarDistance: 5,
                axisX: {
                    labelInterpolationFnc: function(value) {
                        return value[0];
                    }
                }
            }]
        ];
        var emailsSubscriptionChart = Chartist.Bar('#pickupUserGraph', dataEmailsSubscriptionChart, optionsEmailsSubscriptionChart, responsiveOptions);

        //start animation for the Emails Subscription Chart
        md.startAnimationForBarChart(emailsSubscriptionChart);
		
	},
	
	CategoryClothesRep: function(data) {
		var arrdata=JSON.parse(data);
		
		// console.log(arrdata);
		
		orders = [];
		 order_name = [];
		 
		 $.each(arrdata, function (i) {
                var ord=arrdata[i].orders;
                var cate_name=arrdata[i].name;
                var group_name=arrdata[i].groupName;
                
			     var c_name = group_name +' / '+ cate_name;
				
				orders.push(ord);
				order_name.push(c_name);
			 });
			 
			 var high =  Math.max.apply(Math,orders);
		    var new_val = high + 20;
			 
			
			 
			 var dataEmailsSubscriptionChart = {
            labels: order_name,
            series: [
                orders

            ]
        };
        var optionsEmailsSubscriptionChart = {
            axisX: {
                showGrid: false
            },
            low: 0,
            high: new_val,
            chartPadding: {
                top: 0,
                right: 5,
                bottom: 0,
                left: 0
            }
        };
        var responsiveOptions = [
            ['screen and (max-width: 640px)', {
                seriesBarDistance: 5,
                axisX: {
                    labelInterpolationFnc: function(value) {
                        return value[0];
                    }
                }
            }]
        ];
        var emailsSubscriptionChart = Chartist.Bar('#CategoryClothesRep', dataEmailsSubscriptionChart, optionsEmailsSubscriptionChart, responsiveOptions);

        //start animation for the Emails Subscription Chart
        md.startAnimationForBarChart(emailsSubscriptionChart);
		
	},
	
	WalletChart: function(data) {
		
		// console.log(data);
		
		
		var arrdata=JSON.parse(data);
		orders = [];
		 orderdate = [];
		 
		 $.each(arrdata, function (i) {
                var ord=arrdata[i].orders;
                var ord_date=arrdata[i].order_date;
                
				orders.push(ord);
				orderdate.push(ord_date);
			 });
			 
			 var high =  Math.max.apply(Math,orders);
		    var new_val = high + 500;
			 
			 dataDailySalesChart = {
            labels: orderdate,
            series: [
                orders
            ]
        };

        optionsDailySalesChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: new_val, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
        }

        var dailySalesChart = new Chartist.Line('#WalletReport', dataDailySalesChart, optionsDailySalesChart);

        md.startAnimationForLineChart(dailySalesChart);
			 
		
	},
	
	ClothRevenue: function(data) {
		
		 // console.log(data);
		
		var arrdata=JSON.parse(data);
		category = [];
		 clothes = [];
		 
		 $.each(arrdata, function (i) {
                var cate=arrdata[i].name;
                var cloth=arrdata[i].price_amount;
               
				category.push(cate);
				clothes.push(cloth);
			 });
			 
			 var high =  Math.max.apply(Math,clothes);
		    var new_val = high + 1000;
			 
			 dataDailySalesChart = {
            labels: category,
            series: [
                clothes
            ]
        };

        optionsDailySalesChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: new_val, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 20
            },
        }

        var dailySalesChart = new Chartist.Line('#dailySalesRevenue', dataDailySalesChart, optionsDailySalesChart);

        md.startAnimationForLineChart(dailySalesChart);
		
	},
	
	SalesChart: function(data) {
		
		// console.log(data);
		
		var arrdata=JSON.parse(data);
		category = [];
		 clothes = [];
		 
		 // var find_val = [];
		 $.each(arrdata, function (i) {
                var cate=arrdata[i].name;
                var cloth=arrdata[i].qty;
                // highest = Math.max(highest, parseFloat(cloth));
				category.push(cate);
				clothes.push(cloth);
			 });
			 
			var high_qty =  Math.max.apply(Math,clothes);
			 // console.log(high_qty);
		    var new_val = high_qty + 200;
		dataDailySalesChart = {
            labels: category,
            series: [
                clothes
            ]
        };

        optionsDailySalesChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: new_val, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
        }

        var dailySalesChart = new Chartist.Line('#dailySales', dataDailySalesChart, optionsDailySalesChart);

        md.startAnimationForLineChart(dailySalesChart);
		
	},
	
	PaymentTypeChart: function(data) {
		
		// console.log(data);
		
		
		var arrdata=JSON.parse(data);
		payment = [];
		 amount = [];
		 
		 $.each(arrdata, function (i) {
                var type=arrdata[i].paymentType;
                var amt=arrdata[i].total;
                
				payment.push(type);
				amount.push(amt);
			 });
			 
			 var high =  Math.max.apply(Math,amount);
		    var new_val = high + 1000;
		
		dataCompletedTasksChart = {
            labels: payment,
            series: [
                amount
            ]
        };

        optionsCompletedTasksChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: new_val, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 4
            }
        }

        var completedTasksChart = new Chartist.Line('#PaymentTypeChart', dataCompletedTasksChart, optionsCompletedTasksChart);
	},
	
	HighestOrderChart: function(data) {
		
		// console.log(data);
		
		
		var arrdata=JSON.parse(data);
		 orders = [];
		 code = [];
		 
		 $.each(arrdata, function (i) {
                var ord=arrdata[i].orders;
                var pin=arrdata[i].code;
                
				orders.push(ord);
				code.push(pin);
			 });
			 
			  var high =  Math.max.apply(Math,orders);
		    var new_val = high + 10;
		
		 dataCompletedTasksChart = {
            labels: code,
            series: [
                orders
            ]
        };

        optionsCompletedTasksChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: new_val, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            }
        }

        var completedTasksChart = new Chartist.Line('#HighestOrder', dataCompletedTasksChart, optionsCompletedTasksChart);

        // start animation for the Completed Tasks Chart - Line Chart
        md.startAnimationForLineChart(completedTasksChart);
	},
	
	MostBooking: function(data) {
		
		var arrdata=JSON.parse(data);
		 orders = [];
		 code = [];
		 
		 $.each(arrdata, function (i) {
                var ord=arrdata[i].orders;
                var pin=arrdata[i].code;
                
				orders.push(ord);
				code.push(pin);
			 });
		
		var high =  Math.max.apply(Math,orders);
		    var new_val = high + 20;
		
		 dataCompletedTasksChart = {
            labels: code,
            series: [
                orders
            ]
        };

        optionsCompletedTasksChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: new_val, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            }
        }

        var completedTasksChart = new Chartist.Line('#MostBooking', dataCompletedTasksChart, optionsCompletedTasksChart);

        // start animation for the Completed Tasks Chart - Line Chart
        md.startAnimationForLineChart(completedTasksChart);
	},
	
	HighSlot: function(data) {
		
		var arrdata=JSON.parse(data);
		 orders = [];
		 slot = [];
		 
		 $.each(arrdata, function (i) {
                var ord=arrdata[i].orders;
                var fslot=arrdata[i].fromSlots;
                var toslot=arrdata[i].toSlots;
               
                 var time_slots  = 	fslot +' - '+toslot;		   
				orders.push(ord);
				slot.push(time_slots);
			 });
			 
			 var high =  Math.max.apply(Math,orders);
		    var new_val = high + 50;
			 
			  dataCompletedTasksChart = {
            labels: slot,
            series: [
                orders
            ]
        };

        optionsCompletedTasksChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: new_val, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            }
        }

        var completedTasksChart = new Chartist.Line('#HighSlot', dataCompletedTasksChart, optionsCompletedTasksChart);

        // start animation for the Completed Tasks Chart - Line Chart
        md.startAnimationForLineChart(completedTasksChart);
	},
	
	SuccessGraph: function(data) {
		console.log(data);
		var arrdata=JSON.parse(data);
		 orders = [];
		 status_1 = [];
		 
		 $.each(arrdata, function (i) {
                var ord=arrdata[i].orders;
                var ord_status=arrdata[i].Status;
                
				orders.push(ord);
				status_1.push(ord_status);
			 });
			 
			 var high =  Math.max.apply(Math,orders);
		    var new_val = high + 20;
			 
			 
			  var dataEmailsSubscriptionChart = {
            labels: status_1,
            series: [
                orders

            ]
        };
        var optionsEmailsSubscriptionChart = {
            axisX: {
                showGrid: false
            },
            low: 0,
            high: new_val,
            chartPadding: {
                top: 0,
                right: 5,
                bottom: 0,
                left: 0
            }
        };
        var responsiveOptions = [
            ['screen and (max-width: 640px)', {
                seriesBarDistance: 5,
                axisX: {
                    labelInterpolationFnc: function(value) {
                        return value[0];
                    }
                }
            }]
        ];
        var emailsSubscriptionChart = Chartist.Bar('#SuccessGraph', dataEmailsSubscriptionChart, optionsEmailsSubscriptionChart, responsiveOptions);

        //start animation for the Emails Subscription Chart
        md.startAnimationForBarChart(emailsSubscriptionChart);
		
	},

    initDashboardPageCharts: function(data) {

        /* ----------==========     Daily Sales Chart initialization    ==========---------- */

        dataDailySalesChart = {
            labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
            series: [
                [12, 17, 7, 17, 23, 18, 38]
            ]
        };

        optionsDailySalesChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: 50, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
        }

        var dailySalesChart = new Chartist.Line('#dailySalesChart', dataDailySalesChart, optionsDailySalesChart);

        md.startAnimationForLineChart(dailySalesChart);



        /* ----------==========     Completed Tasks Chart initialization    ==========---------- */

        dataCompletedTasksChart = {
            labels: ['12am', '3pm', '6pm', '9pm', '12pm', '3am', '6am', '9am'],
            series: [
                [230, 750, 450, 300, 280, 240, 200, 190]
            ]
        };

        optionsCompletedTasksChart = {
            lineSmooth: Chartist.Interpolation.cardinal({
                tension: 0
            }),
            low: 0,
            high: 1000, // creative tim: we recommend you to set the high sa the biggest value + something for a better look
            chartPadding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            }
        }

        var completedTasksChart = new Chartist.Line('#completedTasksChart', dataCompletedTasksChart, optionsCompletedTasksChart);

        // start animation for the Completed Tasks Chart - Line Chart
        md.startAnimationForLineChart(completedTasksChart);

          //orderdate
        /* ----------==========     Emails Subscription Chart initialization    ==========---------- */

         var dataEmailsSubscriptionChart = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            series: [
                [542, 443, 320, 780, 553, 453, 326, 434, 568, 610, 756, 895]

            ]
        };
        var optionsEmailsSubscriptionChart = {
            axisX: {
                showGrid: false
            },
            low: 0,
            high: 1000,
            chartPadding: {
                top: 0,
                right: 5,
                bottom: 0,
                left: 0
            }
        };
        var responsiveOptions = [
            ['screen and (max-width: 640px)', {
                seriesBarDistance: 5,
                axisX: {
                    labelInterpolationFnc: function(value) {
                        return value[0];
                    }
                }
            }]
        ];
        var emailsSubscriptionChart = Chartist.Bar('#emailsSubscriptionChart', dataEmailsSubscriptionChart, optionsEmailsSubscriptionChart, responsiveOptions);

        //start animation for the Emails Subscription Chart
        md.startAnimationForBarChart(emailsSubscriptionChart);

    },

    initGoogleMaps: function() {
        var myLatlng = new google.maps.LatLng(40.748817, -73.985428);
        var mapOptions = {
            zoom: 13,
            center: myLatlng,
            scrollwheel: false, //we disable de scroll over the map, it is a really annoing when you scroll through page
            styles: [{
                "featureType": "water",
                "stylers": [{
                    "saturation": 43
                }, {
                    "lightness": -11
                }, {
                    "hue": "#0088ff"
                }]
            }, {
                "featureType": "road",
                "elementType": "geometry.fill",
                "stylers": [{
                    "hue": "#ff0000"
                }, {
                    "saturation": -100
                }, {
                    "lightness": 99
                }]
            }, {
                "featureType": "road",
                "elementType": "geometry.stroke",
                "stylers": [{
                    "color": "#808080"
                }, {
                    "lightness": 54
                }]
            }, {
                "featureType": "landscape.man_made",
                "elementType": "geometry.fill",
                "stylers": [{
                    "color": "#ece2d9"
                }]
            }, {
                "featureType": "poi.park",
                "elementType": "geometry.fill",
                "stylers": [{
                    "color": "#ccdca1"
                }]
            }, {
                "featureType": "road",
                "elementType": "labels.text.fill",
                "stylers": [{
                    "color": "#767676"
                }]
            }, {
                "featureType": "road",
                "elementType": "labels.text.stroke",
                "stylers": [{
                    "color": "#ffffff"
                }]
            }, {
                "featureType": "poi",
                "stylers": [{
                    "visibility": "off"
                }]
            }, {
                "featureType": "landscape.natural",
                "elementType": "geometry.fill",
                "stylers": [{
                    "visibility": "on"
                }, {
                    "color": "#b8cb93"
                }]
            }, {
                "featureType": "poi.park",
                "stylers": [{
                    "visibility": "on"
                }]
            }, {
                "featureType": "poi.sports_complex",
                "stylers": [{
                    "visibility": "on"
                }]
            }, {
                "featureType": "poi.medical",
                "stylers": [{
                    "visibility": "on"
                }]
            }, {
                "featureType": "poi.business",
                "stylers": [{
                    "visibility": "simplified"
                }]
            }]

        }
        var map = new google.maps.Map(document.getElementById("map"), mapOptions);

        var marker = new google.maps.Marker({
            position: myLatlng,
            title: "Hello World!"
        });

        // To add the marker to the map, call setMap();
        marker.setMap(map);
    },

    showNotification: function(from, align) {
        color = Math.floor((Math.random() * 4) + 1);

        $.notify({
            icon: "notifications",
            message: "Welcome to <b>Material Dashboard</b> - a beautiful freebie for every web developer."

        }, {
            type: type[color],
            timer: 4000,
            placement: {
                from: from,
                align: align
            }
        });
    }



}