
//warehouse
$(document).ready(function () {

    $('#servicearea').validate({ // initialize the plugin
        rules: {
            warehousename: {
                required: true
            },
			areaname: {
                required: true
            },
			pincode: {
				required: true,
					 number: true, // as space is not a number it will return an error
				 minlength: 6, // will count space
				 maxlength: 6
			}
        },

    });

});


//warehouse
$(document).ready(function () {

    $('#addImages').validate({ // initialize the plugin
        rules: {
            title: {
                required: true
            },
			image: {
                required: true
            }
        },

    });

});

$(document).ready(function () {

    $('#editgallery').validate({ // initialize the plugin
        rules: {
            title: {
                required: true
            }
        },

    });

});

//warehouse
$(document).ready(function () {

    $('#Editservicearea').validate({ // initialize the plugin
        rules: {
            warehousename: {
                required: true
            },
			Eareaname: {
                required: true
            },
			pincode: {
				required: true,
					 number: true, // as space is not a number it will return an error
				 minlength: 6, // will count space
				 maxlength: 6
			}
        },

    });

});

$(document).ready(function () {

    $('#AddComplaints').validate({ // initialize the plugin
        rules: {
            mobile: {
				required: true,
                number: true, // as space is not a number it will return an error
				 minlength: 10, // will count space
				 maxlength: 10
            },
			type_complaints: {
                required: true
            },
			complaints: {
				required: true
			}
        },

    });

});

$(document).ready(function () {

    $('#adminpush').validate({ // initialize the plugin
        rules: {
            title: {
				required: true
            },
			body: {
                required: true
            },
			message: {
				required: true
			}
        },

    });

});


$(document).ready(function () {

    $('#EditSlot').validate({ // initialize the plugin
        rules: {
            Fslot: {
                required: true
            },
			Tslot: {
				required: true
			}
        },

    });

});

$(document).ready(function () {

    $('#TimeSlot').validate({ // initialize the plugin
        rules: {
            Fslot: {
                required: true
            },
			Tslot: {
				required: true
			}
        },

    });

});


$(document).ready(function () {
    $('#addmaincategory').validate({ // initialize the plugin
        rules: {
            cname: {
                required: true
            },
			price: {
				required: true
			},
			quantity: {
				required: true
			}
        },

    });

});

$(document).ready(function () {
    $('#addmaincategory5').validate({ // initialize the plugin
        rules: {
            cname: {
                required: true
            },
			price: {
				required: true
			},
			quantity: {
				required: true
			}
        },

    });

});




$(document).ready(function () {

    $('#editpickupuser').validate({ // initialize the plugin
        rules: {
            name: {
                required: true
            },
			pincode: {
				required: true
			}
        },

    });

});


$(document).ready(function () {

    $('#allowcateservice').validate({ // initialize the plugin
        rules: {
            warehousId: {
                required: true
            }
        },

    });

});



$(document).ready(function () {

    $('#addsubcategoty').validate({ // initialize the plugin
        rules: {
            name: {
                required: true
            },
			MainCategory: {
				required: true
			},
			image: {
				required: true
			},
			groupname: {
				required: true
			}
        },
		


    });

});


$(document).ready(function () {

    $('#editaddsubcategoty').validate({ // initialize the plugin
        rules: {
            name: {
                required: true
            },
			MainCategory: {
				required: true
			},
			groupname: {
				required: true
			}
        },
		


    });

});


$(document).ready(function () {

    $('#AddPromocode').validate({ // initialize the plugin
        rules: {
            promocode: {
                required: true,
				minlength: 3, // will count space
				maxlength: 10
            },
			discount: {
				required: true
			},
			payment_type: {
				required: true
			},
			description: {
				required: true
			},
			image: {
				required: true
			}
        },
		


    });

});



$(document).ready(function () {

    $('#EditPromocode').validate({ // initialize the plugin
        rules: {
            promocode: {
                required: true,
				minlength: 6, // will count space
				maxlength: 6
            },
			discount: {
				required: true
			},
			payment_type: {
				required: true
			},
			description: {
				required: true
			}
        },
		


    });

});

$(document).ready(function () {
    $('#assign_delivery').validate({ // initialize the plugin
        rules: {
            delivery_user: {
                required: true
            }
        },

    });

});

$(document).ready(function () {
    $('#assign_pickup').validate({ // initialize the plugin
        rules: {
            pickup_user: {
                required: true
            }
        },

    });

});

$(document).ready(function () {
    $('#Outlet').validate({ // initialize the plugin
        rules: {
            outletname: {
                required: true
            },
			authorizedperson: {
                required: true
            },
			address: {
                required: true
            },
			email: {
                required: true,
				email: true
            },
			password: {
                required: true,
				minlength: 6,
            },
			latitude: {
                required: true
            },
			longitude: {
                required: true
            },
			phone_number: {
                required: true
            },
			manager_name: {
                required: true
            },
			manager_email: {
                required: true,
				email: true
            },
			manager_mobile: {
                required: true
            },
        },

    });

});

$(document).ready(function () {
    $('#EditOutlet').validate({ // initialize the plugin
        rules: {
            outletname: {
                required: true
            },
			authorizedperson: {
                required: true
            },
			address: {
                required: true
            },
			email: {
                required: true,
				email: true
            },
			latitude: {
                required: true
            },
			longitude: {
                required: true
            },
			phone_number: {
                required: true
            },
			manager_name: {
                required: true
            },
			manager_email: {
                required: true,
				email: true
            },
			manager_mobile: {
                required: true
            },
        },

    });

});



$(document).ready(function () {
    $('#UpdatePickup').validate({ // initialize the plugin
        rules: {
            pickup_user: {
                required: true
            },
			comments: {
                required: true
            }
        },

    });

});


$(document).ready(function () {
    $('#Updatedelivery').validate({ // initialize the plugin
        rules: {
            delivery_user: {
                required: true
            },
			comments: {
                required: true
            }
        },

    });

});


$(document).ready(function () {
    $('#pickupblock').validate({ // initialize the plugin
        rules: {
            comments: {
                required: true
            }
        },

    });

});


$(document).ready(function () {
    $('#Search_reports').validate({ // initialize the plugin
        rules: {
            fromdate: {
                required: true
            },
			todate: {  
                required: true
            }
        },

    });

});


$(function() {
  $('body').on('keydown', '.emptyspace', function(e) {

    if (e.which === 32 &&  e.target.selectionStart === 0) {
      return false;
    }
  });
});

$('.numbersOnly').keyup(function () {
    if (this.value != this.value.replace(/[^0-9\.]/g, '')) {
       this.value = this.value.replace(/[^0-9\.]/g, '');
    }
});
