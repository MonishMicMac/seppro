$(document).ready(function(){

    $('div').last().css('display','none');
    
    //$('[name="name"]').focus();

    //$('[name="city"]').combobox();
    
    mapObject.initGoogleMaps();
    if($('#latitude').val()!='' && $('#longitude').val()!=''){
        mapObject.setUserLocation($('#latitude').val(),$('#longitude').val())
    }
    else{
        mapObject.getUserLocation();
    }

    
    $(".nospace").keypress(function (evt) {
        
        var keycode = evt.charCode || evt.keyCode;
        
        if (keycode  == 32) { 
            return false;
        }
        
    });

    $('[name="phone"]').keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    
    $('#hotelForm').validate({

        rules:{
            name:{
                required: true,
                rangelength: [4, 32],
            },
            description:{
                rangelength: [50, 250],
                required: true,
            },
            address:{
                rangelength: [10, 50],
                required: true,
            },
            city:{
                required: true,
            },
            phone:{
                required: true,
                fixedLineIN: true,
            },
            email:{
                required: true,
                email: true,
            },
            type:{
                required: true,
            },
            'images[]':{
                accept: 'image/*',
            },
        },

        submitHandler: function(form){
            form.submit();
        },

    });
});