
type = ['','info','success','warning','danger'];
myLat = 20.593684;
myLng = 78.962880;
var googleMap;
var marker;


mapObject = {
    getUserLocation: function(){
        
        
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(
                function(position){
                    myLat = position.coords.latitude;
                    myLng = position.coords.longitude;
                    $("#latitude").val(myLat);
                    $("#longitude").val(myLng);
                    myLatlng = new google.maps.LatLng(myLat, myLng)
                    
                    // To add the marker to the map, call setMap();
                    marker.setPosition(myLatlng);
                    googleMap.setCenter(myLatlng);
                    googleMap.setZoom(13);
                    marker.setAnimation(google.maps.Animation.BOUNCE);
                },function(err){},
                {
                    enableHighAccuracy: true, 
                    timeout: 5000,
                    maximumAge: 0,
                }
            );
        } else {
            alert('It seems like Geolocation, which is required for this page, is not enabled in your browser. Please use a browser which supports it.');
        }
    },

    setUserLocation: function(myLat,myLng){
        myLatlng = new google.maps.LatLng(myLat, myLng);
        marker.setPosition(myLatlng);
        googleMap.setCenter(myLatlng);
        googleMap.setZoom(13);
    },

    initGoogleMaps: function(){
        var myLatlng = new google.maps.LatLng(myLat, myLng);
        var mapOptions = {
        zoom: 3 ,
        center: myLatlng,
        scrollwheel: false, //we disable de scroll over the map, it is a really annoing when you scroll through page
        styles: [{"featureType":"water","stylers":[{"saturation":43},{"lightness":-11},{"hue":"#0088ff"}]},{"featureType":"road","elementType":"geometry.fill","stylers":[{"hue":"#ff0000"},{"saturation":-100},{"lightness":99}]},{"featureType":"road","elementType":"geometry.stroke","stylers":[{"color":"#808080"},{"lightness":54}]},{"featureType":"landscape.man_made","elementType":"geometry.fill","stylers":[{"color":"#ece2d9"}]},{"featureType":"poi.park","elementType":"geometry.fill","stylers":[{"color":"#ccdca1"}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"color":"#767676"}]},{"featureType":"road","elementType":"labels.text.stroke","stylers":[{"color":"#ffffff"}]},{"featureType":"poi","stylers":[{"visibility":"off"}]},{"featureType":"landscape.natural","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#b8cb93"}]},{"featureType":"poi.park","stylers":[{"visibility":"on"}]},{"featureType":"poi.sports_complex","stylers":[{"visibility":"on"}]},{"featureType":"poi.medical","stylers":[{"visibility":"on"}]},{"featureType":"poi.business","stylers":[{"visibility":"simplified"}]}]

        }

        googleMap = new google.maps.Map(document.getElementById("map"), mapOptions);

        marker = new google.maps.Marker({
            position: myLatlng,
            animation: google.maps.Animation.BOUNCE,
            draggable: true,
            title:"Current Location"
        });
        
        // To add the marker to the map, call setMap();
        marker.setMap(googleMap);

        google.maps.event.addListener(marker, 'dragend', function(marker){
            currentLatitude = marker.latLng.lat();
            currentLongitude = marker.latLng.lng();
            $("#latitude").val(currentLatitude);
            $("#longitude").val(currentLongitude);
        });

        var input = document.getElementById('mapSearch');
        var searchBox = new google.maps.places.SearchBox(input);
        // googleMap.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
        googleMap.addListener('bounds_changed', function() {
          searchBox.setBounds(googleMap.getBounds());
        });

        searchBox.addListener('places_changed', function() {
          var places = searchBox.getPlaces();

          if (places.length == 0) {
            return;
          }

          // For each place, get the icon, name and location.
          var bounds = new google.maps.LatLngBounds();
          places.forEach(function(place) {
            if (!place.geometry) {
              console.log("Returned place contains no geometry");
              return;
            }
            var icon = {
              url: place.icon,
              size: new google.maps.Size(71, 71),
              origin: new google.maps.Point(0, 0),
              anchor: new google.maps.Point(17, 34),
              scaledSize: new google.maps.Size(25, 25)
            };

            marker.setPosition(place.geometry.location);
            marker.setAnimation(null);
            $('#latitude').val(place.geometry.location.lat());
            $('#longitude').val(place.geometry.location.lng());

            if (place.geometry.viewport) {
              // Only geocodes have viewport.
              bounds.union(place.geometry.viewport);
            } else {
              bounds.extend(place.geometry.location);
            }
          });
          googleMap.fitBounds(bounds);
        });



    },



}