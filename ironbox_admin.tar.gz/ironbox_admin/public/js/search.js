
$(document).ready(function() {


	
    });
	
	
var base_url = 'http://13.126.228.76/ironbox_admin/public/';

/************************ TimeSlots *******************************************/

$("#Slotsto").change(function(){
	if(($('#Slotsto').val()) != ''){
	$('#Slotsto').removeClass('warn');	
	$('.slots_to').css({"display": "none"});
	}
});

$("#Slotsfrom").change(function(){
	if(($('#Slotsfrom').val()) != ''){
	$('#Slotsfrom').removeClass('warn');	
	$('.slots_from').css({"display": "none"});
	}
});

$( "#Slotsfrom,#Slotsto,#timeId" ).change(function() {

    var fromdate = $("#Slotsfrom").val();
    var todate = $("#Slotsto").val();
    var timeId = $("#timeId").val();

	// if(($('#Slotsfrom').val()) == ''){
	// $('#Slotsfrom').addClass('warn').focus();
	// $('.slots_from').css({"display": "block"});
	// return false;	   
// }

// if(($('#Slotsto').val()) == ''){
	// $('#Slotsto').addClass('warn').focus();
	// $('.slots_to').css({"display": "block"});
	// return false;	   
// }
	
	
	 var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchTimeSlots',
            data: {_token: csrf,fromdate: fromdate, todate:todate, timeId:timeId},
            success: function (data) { 
				  $("#Time_report").empty();
				  if(data.length == 0){
					  $("#Time_report").empty();
					   $("#Time_report").append('<tr><td colspan="5">No record</td></tr>');
				  }				  
				  if(data.length > 0){
				  $.each(data, function (i) {
					     
					          $("#Time_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].fromSlots+' - '+data[i].toSlots+'</td><td>'+data[i].Status+'</td><td><a href="ViewBookings/'+data[i].id+'">View</a></td>');
						  
						 
					   });
				  }
            }
        });
});

/************************ Pincode *******************************************/

$("#areafrom").change(function(){
	if(($('#areafrom').val()) != ''){
	$('#areafrom').removeClass('warn');	
	$('.area_from').css({"display": "none"});
	}
});

$("#areato").change(function(){
	if(($('#areato').val()) != ''){
	$('#Slotsfrom').removeClass('warn');	
	$('.area_to').css({"display": "none"});
	}
});


$( "#areafrom,#areato,#pinId,#pindays" ).change(function() {
	
	var fromdate = $("#areafrom").val();
    var todate = $("#areato").val();
    var pinId = $("#pinId").val();
   
	
	// if(($('#areafrom').val()) == ''){
		// $('#areafrom').addClass('warn').focus();
		// $('.area_from').css({"display": "block"});
		// return false;	   
	// }

	// if(($('#areato').val()) == ''){
		// $('#areato').addClass('warn').focus();
		// $('.area_to').css({"display": "block"});
		// return false;	   
	// }
	

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchPincode',
            data: {_token: csrf,fromdate: fromdate, todate:todate, pinId:pinId},
            success: function (data) { 
                  // console.log(data);
				  
				  if(data.length == 0){
					  $("#area_report").empty();
					   $("#area_report").append('<tr><td colspan="4">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#area_report").empty();
                 
				  
				  $.each(data, function (i) {

						   $("#area_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].code+'</td><td><a href="ViewBookings/'+data[i].id+'">View</a></td>');

					   });
				  }
            }
        });
	
});

/****************************** Payment type ******************************************/

$("#paymentfrom").change(function(){
	if(($('#paymentfrom').val()) != ''){
	$('#paymentfrom').removeClass('warn');	
	$('.payment_from').css({"display": "none"});
	}
});

$("#paymentto").change(function(){
	if(($('#paymentto').val()) != ''){
	$('#paymentto').removeClass('warn');	
	$('.payment_to').css({"display": "none"});
	}
});

$( "#paymentfrom,#paymentto,#paytypeId" ).change(function() {
	
	var fromdate = $("#paymentfrom").val();
    var todate = $("#paymentto").val();
    var paytypeId = $("#paytypeId").val();
	
    
	// if(($('#paymentfrom').val()) == ''){
	// $('#paymentfrom').addClass('warn').focus();
	// $('.payment_from').css({"display": "block"});
	// return false;	   
	// }

	// if(($('#paymentto').val()) == ''){
		// $('#paymentto').addClass('warn').focus();
		// $('.payment_to').css({"display": "block"});
		// return false;	   
	// }
	
	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchPaymentType',
            data: {_token: csrf,fromdate: fromdate, todate:todate, paytypeId:paytypeId},
            success: function (data) { 
                  // console.log(data);
				  
				  if(data.length == 0){
					  $("#payment_report").empty();
					   $("#payment_report").append('<tr><td colspan="5">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#payment_report").empty();
				  
				  $.each(data, function (i) {
					     
					          $("#payment_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].PaymentType+'</td><td><a href="ViewBookings/'+data[i].id+'">View</a></td>');
						  
					
						 
					   });
				  }
            }
        });
	
});


/************************ Success/Cancel****************/

$("#statusfrom").change(function(){
	if(($('#statusfrom').val()) != ''){
	$('#statusfrom').removeClass('warn');	
	$('.status_from').css({"display": "none"});
	}
});

$("#statusto").change(function(){
	if(($('#statusto').val()) != ''){
	$('#statusto').removeClass('warn');	
	$('.status_to').css({"display": "none"});
	}
});

$( "#statusfrom,#statusto,#typeId" ).change(function() {
	
	var fromdate = $("#statusfrom").val();
    var todate = $("#statusto").val();
    var typeId = $("#typeId").val();
	
		// alert(typeId);
	// if(($('#statusfrom').val()) == ''){
	// $('#statusfrom').addClass('warn').focus();
	// $('.status_from').css({"display": "block"});
	// return false;	   
// }


// if(($('#statusto').val()) == ''){
	// $('#statusto').addClass('warn').focus();
	// $('.status_to').css({"display": "block"});
	// return false;	   
// }

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchOrderStatus',
            data: {_token: csrf,fromdate: fromdate, todate:todate, typeId:typeId},
            success: function (data) { 
                  // console.log(data);  
				  $("#orderstatus_report").empty();
				  if(data.length == 0){
					  $("#orderstatus_report").empty();  
					   $("#orderstatus_report").append('<tr><td colspan="5">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 // $("#orderstatus_report").empty();
                      
						$.each(data, function (i) {					  
					$("#orderstatus_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].Status+'</td><td>'+data[i].cancelReason+'</td><td><a href="ViewBookings/'+data[i].id+'">View</a>');
			 
			        });
			
				  }
            }
        });
	
});

/**************** Search InActive Members *******************************/

$( "#noofdays" ).change(function() {
	
	
    var noofdays = $("#noofdays").val();
	   if(noofdays == 10){
	 	   $('#but1').css('display','block');	
	 	   $('#but2').css('display','none');	
	 	   $('#but3').css('display','none');	
	 	}
	 	else if(noofdays == 15){
	 		$('#but1').css('display','none');	
	 		$('#but2').css('display','block');	
	 		$('#but3').css('display','none');	
	 	}
	 	else if(noofdays == 30){
	 		$('#but1').css('display','none');	
	 		$('#but2').css('display','none');	
	 		$('#but3').css('display','block');	
	 	}

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/InactiveUser',
            data: {_token: csrf, noofdays:noofdays},
            success: function (data) { 
            	//console.log(data);
            	 var j=0;

            	 	$('#default_result').css('display','none');
				  	$("#datatables >tbody").empty();
						  if(data.length == 0){
							  $("#datatables >tbody").empty();  
							   $("#datatables >tbody").append('<tr><td colspan="5">No record</td></tr>');
						  }
						  
						  if(data.length > 0){
								$.each(data, function (i) {	
		  						j++;

							 $("#datatables >tbody").append('<tr class="child"><td>'+j+'</td><td>'+data[i].name+'</td><td>'+data[i].mobile+'</td><td>'+data[i].email+'</td><td>'+data[i].last_booking+'</td></tr>');
					 
					        });
			
				  }

            }
        });
	
});

/**************** Search revenue *******************************/

$("#revenuefrom").change(function(){
	if(($('#revenuefrom').val()) != ''){
	$('#revenuefrom').removeClass('warn');	
	$('.revenue_from').css({"display": "none"});
	}
});

$("#revenueto").change(function(){
	if(($('#revenueto').val()) != ''){
	$('#revenueto').removeClass('warn');	
	$('.revenue_to').css({"display": "none"});
	}
});


$( "#revenuefrom,#revenueto" ).change(function() {
	
	var fromdate = $("#revenuefrom").val();
    var todate = $("#revenueto").val();


	// if(($('#revenuefrom').val()) == ''){
	// $('#revenuefrom').addClass('warn').focus();
	// $('.revenue_from').css({"display": "block"});
	// return false;	   
// }


// if(($('#revenueto').val()) == ''){
	// $('#revenueto').addClass('warn').focus();
	// $('.revenue_to').css({"display": "block"});
	// return false;	   
// }
	
	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchRevenue',
            data: {_token: csrf,fromdate: fromdate, todate:todate},
            success: function (data) { 
				  
				  // console.log(data);
				  if(data.length == 0){
					  $("#revenue_report").empty();
					   $("#revenue_report").append('<tr><td colspan="4">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#revenue_report").empty();
				  
				  $.each(data, function (i) {
					  
					  $("#revenue_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].Status+'</td><td><a href="ViewBookings/'+data[i].id+'">View</a>');
					     
						 
					   });
				  }
            }
        });
	
});


/******************Promocode******************************/
$("#promofrom").change(function(){
	if(($('#promofrom').val()) != ''){
	$('#promofrom').removeClass('warn');	
	$('.promo_from').css({"display": "none"});
	}
});

$("#promoto").change(function(){
	if(($('#promoto').val()) != ''){
	$('#promoto').removeClass('warn');	
	$('.promo_to').css({"display": "none"});
	}
});

$( "#promofrom,#promoto,#promoId" ).change(function() {
	
	var fromdate = $("#promofrom").val();
    var todate = $("#promoto").val();
    var promoId = $("#promoId").val();
	// alert(promoId);
	
	// if(($('#promofrom').val()) == ''){
		// $('#promofrom').addClass('warn').focus();
		// $('.promo_from').css({"display": "block"});
		// return false;	   
	// }


	// if(($('#promoto').val()) == ''){
		// $('#promoto').addClass('warn').focus();
		// $('.promo_to').css({"display": "block"});
		// return false;	   
	// }

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchPromocode',
            data: {_token: csrf,fromdate: fromdate, todate:todate, promoId:promoId},
            success: function (data) { 
                  // console.log(data);
				  
				  if(data.length == 0){
					  $("#promo_report").empty();
					   $("#promo_report").append('<tr><td colspan="4">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#promo_report").empty();
                  
				  
				  $.each(data, function (i) {

						    $("#promo_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].code+'</td><td>'+data[i].Status+'</td><td><a href="ViewBookings/'+data[i].id+'">View</a></td>');
						 
					   });
				  }
            }
        });
	
});

/***************************Wallet report ************************/
$("#walletfrom").change(function(){
	if(($('#walletfrom').val()) != ''){
	$('#walletfrom').removeClass('warn');	
	$('.wallet_from').css({"display": "none"});
	}
});

$("#walletto").change(function(){
	if(($('#walletto').val()) != ''){
	$('#walletto').removeClass('warn');	
	$('.wallet_to').css({"display": "none"});
	}
});
 

$( "#walletfrom,#walletto" ).change(function() {
	
	var fromdate = $("#walletfrom").val();
    var todate = $("#walletto").val();
	
	if(($('#walletfrom').val()) == ''){
		$('#walletfrom').addClass('warn').focus();
		$('.wallet_from').css({"display": "block"});
		return false;	   
	}


	if(($('#walletto').val()) == ''){
		$('#walletto').addClass('warn').focus();
		$('.wallet_to').css({"display": "block"});
		return false;	   
	}

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchWalletReport',
            data: {_token: csrf,fromdate: fromdate, todate:todate},
            success: function (data) { 
                  console.log(data);
				  var j=0;
				  if(data.length == 0){
					  $("#Wallet_report").empty();
					   $('#Wallet_report').append('<tr><td colspan="9">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#Wallet_report").empty();
				  
				  $.each(data, function (i) {
				  	j++;
				  		if (!data[i].bookingId) {
				  			data[i].bookingId="";
				  		}
						$("#Wallet_report").append('<tr><td>'+j+'</td><td>'+data[i].bookingId+'</td><td>'+data[i].orderId+'</td><td>'+data[i].transactionId+'</td><td>'+data[i].amount+'</td><td>'+data[i].transation_status+'</td><td>'+data[i].type+'</td><td>'+data[i].payment_date+'</td><td><a href="UserDetails/'+data[i].userId+'">View</a></tr>');
						 
					   });
				  }
            }
        });
	
});

/***************************** Clothes ***************************/

$("#clothesfrom").change(function(){
	if(($('#clothesfrom').val()) != ''){
	$('#clothesfrom').removeClass('warn');	
	$('.clothes_from').css({"display": "none"});
	}
});

$("#clothesto").change(function(){
	if(($('#clothesto').val()) != ''){
	$('#clothesto').removeClass('warn');	
	$('.clothes_to').css({"display": "none"});
	}
});

$( "#clothesfrom,#clothesto,#cateId" ).change(function() {
	
	var fromdate = $("#clothesfrom").val();
    var todate = $("#clothesto").val();
    var cateId = $("#cateId").val();
	
	// if(($('#clothesfrom').val()) == ''){
		// $('#clothesfrom').addClass('warn').focus();
		// $('.clothes_from').css({"display": "block"});
		// return false;	   
	// }


	// if(($('#clothesto').val()) == ''){
		// $('#clothesto').addClass('warn').focus();
		// $('.clothes_to').css({"display": "block"});
		// return false;	   
	// }

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchClothesReport',
            data: {_token: csrf,fromdate: fromdate, todate:todate, cateId:cateId},
            success: function (data) { 
                  // console.log(data);
				  
				  if(data.length == 0){
					  $("#Cloth_report").empty();
					   $('#Cloth_report').append('<tr><td colspan="3">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#Cloth_report").empty();
				  
				  $.each(data, function (i) {

						   $("#Cloth_report").append('<tr><td>'+data[i].name+'</td><td>'+data[i].qty+'</td><td>'+data[i].price_amount+'</td></tr>');
						 
					   });
				  }
            }
        });
	
});

/**************************Clothes category************************/
$("#categoryfrom").change(function(){
	if(($('#categoryfrom').val()) != ''){
	$('#categoryfrom').removeClass('warn');	
	$('.category_from').css({"display": "none"});
	}
});

$("#categoryto").change(function(){
	if(($('#categoryto').val()) != ''){
	$('#categoryto').removeClass('warn');	
	$('.category_to').css({"display": "none"});
	}
});

$( "#categoryfrom,#categoryto" ).change(function() {
	
	var fromdate = $("#categoryfrom").val();
    var todate = $("#categoryto").val();
	
	if(($('#categoryfrom').val()) == ''){
		$('#categoryfrom').addClass('warn').focus();
		$('.category_from').css({"display": "block"});
		return false;	   
	}


	if(($('#categoryto').val()) == ''){
		$('#categoryto').addClass('warn').focus();
		$('.category_to').css({"display": "block"});
		return false;	   
	}

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchCategoryReports',
            data: {_token: csrf,fromdate: fromdate, todate:todate},
            success: function (data) { 
                  // console.log(data);
				  
				  if(data.length == 0){
					  $("#Cloth_category_report").empty();
					   $('#Cloth_category_report').append('<tr><td colspan="3">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#Cloth_category_report").empty();
				  
				  $.each(data, function (i) {

						   $("#Cloth_category_report").append('<tr><td>'+data[i].name+'</td><td>'+data[i].quantity+'</td><td>'+data[i].amount+'</td></tr>');
						 
					   });
				  }
            }
        });
	
});

/**************************AVG Cost************************************/

$("#avgfrom").change(function(){
	if(($('#avgfrom').val()) != ''){
	$('#avgfrom').removeClass('warn');	
	$('.avg_from').css({"display": "none"});
	}
});

$("#avgto").change(function(){
	if(($('#avgto').val()) != ''){
	$('#avgto').removeClass('warn');	
	$('.avg_to').css({"display": "none"});
	}
});

$( "#avgfrom,#avgto" ).change(function() {
	
	var fromdate = $("#avgfrom").val();
    var todate = $("#avgto").val();
	
	if(($('#avgfrom').val()) == ''){
		$('#avgfrom').addClass('warn').focus();
		$('.avg_from').css({"display": "block"});
		return false;	   
	}


	if(($('#avgto').val()) == ''){
		$('#avgto').addClass('warn').focus();
		$('.avg_to').css({"display": "block"});
		return false;	   
	}

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchAvgCost',
            data: {_token: csrf,fromdate: fromdate, todate:todate},
            success: function (data) { 
				  console.log(data[1]);
				   //var arrdata = JSON.parse(data);
				 	var avg_cost;
				  if(data.length == 0){
					  $("#Avg_report").empty();
					   $('#Avg_report').append('<td colspan="4">No record</td>');
				  }
				  
				if(data.length > 0){
				 $("#Avg_report").empty();
						   
					$.each(data[1], function (i) {
						totalquantity=data[0];
						if((data[1][i].quantity)!=0){
							var avg= ((data[1][i].quantity) / totalquantity) * 100;
							 avg_cost=avg.toFixed(2);
						}else{
							 avg_cost=0;
						}
						
					   $("#Avg_report").append('<tr><td>'+data[1][i].Categoryname+'</td><td>'+data[1][i].payments+'</td><td>'+data[1][i].quantity+'</td><td>'+avg_cost+'</td></tr>');
						 
					});
						 
				}
            }
        });
	
});


/*****************************Vendor search***********************************/

$("#vendorfrom").change(function(){
	if(($('#vendorfrom').val()) != ''){
	$('#vendorfrom').removeClass('warn');	
	$('.vendor_from').css({"display": "none"});
	}
});

$("#vendorto").change(function(){
	if(($('#vendorto').val()) != ''){
	$('#vendorto').removeClass('warn');	
	$('.vendor_to').css({"display": "none"});
	}
});

$( "#vendorfrom,#vendorto" ).change(function() {
	
	var fromdate = $("#vendorfrom").val();
    var todate = $("#vendorto").val();
    var vendorId = $("#vendorId").val();
	
	if(($('#vendorfrom').val()) == ''){
		$('#vendorfrom').addClass('warn').focus();
		$('.vendor_from').css({"display": "block"});
		return false;	   
	}


	if(($('#vendorto').val()) == ''){
		$('#vendorto').addClass('warn').focus();
		$('.vendor_to').css({"display": "block"});
		return false;	   
	}

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchVendorReports',
            data: {_token: csrf,fromdate: fromdate, todate:todate, vendorId:vendorId},
            success: function (data) { 
                  // console.log(data);
				  
				  if(data.length == 0){
					  $("#Vendor_report").empty();
					   $('#Vendor_report').append('<tr><td colspan="5">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#Vendor_report").empty();
				   var j=0;
				  $.each(data, function (i) {
				  	j++;
						   $("#Vendor_report").append('<tr><td>'+j+'</td><td>'+data[i].start_time+'</td><td>'+data[i].bookingId+'</td><td>'+data[i].quantity+'</td><td>'+data[i].totalPayment+'</td></tr>');
						 
					   });
				  }
            }
        });
	
});

/****************************Pickup Report********************************/
$("#pickupfrom").change(function(){
	if(($('#pickupfrom').val()) != ''){
	$('#pickupfrom').removeClass('warn');	
	$('.pickup_from').css({"display": "none"});
	}
});

$("#pickupto").change(function(){
	if(($('#pickupto').val()) != ''){
	$('#pickupto').removeClass('warn');	
	$('.pickup_to').css({"display": "none"});
	}
});

$( "#pickupfrom,#pickupto" ).change(function() {
	
	var fromdate = $("#pickupfrom").val();
    var todate = $("#pickupto").val();
    var pickupId = $("#pickupId").val();
	
	if(($('#pickupfrom').val()) == ''){
		$('#pickupfrom').addClass('warn').focus();
		$('.pickup_from').css({"display": "block"});
		return false;	   
	}


	if(($('#pickupto').val()) == ''){
		$('#pickupto').addClass('warn').focus();
		$('.pickup_to').css({"display": "block"});
		return false;	   
	}

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchPickupReports',
            data: {_token: csrf,fromdate: fromdate, todate:todate, pickupId:pickupId},
            success: function (data) { 

				  if(data.length == 0){
					  $("#pickup_report").empty();
					   $('#pickup_report').append('<tr><td colspan="4">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#pickup_report").empty();
				 
				  
				  $.each(data, function (i) {

						   $("#pickup_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].Pickup+'</td><td>'+data[i].Status+'</td><td><a href="'+base_url+'ViewBookings/'+data[i].id+'">View</a></td></tr>');
						 
					   });
				  }
            }
        });
	
});




$( "#ser_area" ).change(function() {
	
	 var id=$(this).val();
	 var type = 'graph';
	 
	 // if(id == 5){

		 // $("#areafrom").removeAttr('disabled');
		 
	 // }
	
	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/DownloadAreaReport',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
                  // console.log(data);
				  demo.HighestOrderChart(data);
            }
	
	
	});
	});
	

	
	$( ".get_slot_value" ).click(function() {
		 var id = $(this).attr('value');
		 // alert(id);
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/DownloadAreaReport',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
                  // console.log(data);
				  demo.HighestOrderChart(data);
            }
		 
		 
		 });
		 });
		 
	 $( ".custom_graph_pin" ).change(function() {
	 
		 var areafrom = $('#areafrom').val();
		 var areato = $('#areato').val();
		 var pinId = $('#pinId').val();
		 // alert(pinId);
	     var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_area_graph',
            data: {_token: csrf,areafrom: areafrom, areato:areato, pinId:pinId},
            success: function (data) { 
                  // console.log(data);
				  demo.HighestOrderChart(data);
            }
		 
		 
		 });
	 
	  });
	  
	  
	 $( ".get_paytype_value" ).click(function() {
		 var id = $(this).attr('value');
		 // alert(id);
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/DownloadPaymentType',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
			        // console.log(data);
				  demo.PaymentTypeChart(data);
            }
		 
		 
		 });
		 });
		 
		 
		 $( ".custom_graph_paytype" ).change(function() {
	 
		 var paymentfrom = $('#paymentfrom').val();
		 var paymentto = $('#paymentto').val();
		 var paytypeId = $('#paytypeId').val();
		 // alert(paytypeId);
	     var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_paymenttype_graph',
            data: {_token: csrf,paymentfrom: paymentfrom, paymentto:paymentto, paytypeId:paytypeId},
            success: function (data) { 
                  // console.log(data);
				 demo.PaymentTypeChart(data);
            }
		 
		 
		 });
	 
	  });
	  
	  
	  $( ".get_order_status" ).click(function() {
		 var id = $(this).attr('value');
		 // alert(id);
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/DownloadCancel',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
                  // console.log(data);
				 demo.SuccessGraph(data);
            }
		 
		 
		 });
		 });
		 
		 
		 
$( ".custom_graph_status2" ).change(function() {
	 
	var fromdate = $("#statusfrom").val();
    var todate = $("#statusto").val();
    var typeId = $("#typeId").val();

	 // alert(typeId);
	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_orders_graph',
            data: {_token: csrf,fromdate: fromdate, todate:todate, typeId:typeId},
            success: function (data) { 
				 demo.SuccessGraph(data);
            }
		 });
		 
});
		 
		 
		 
	 $( ".get_revenue_status" ).click(function() {
	 var id = $(this).attr('value');
		 // alert(id);
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/RevenueDownload',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
                  // console.log(data);
				 demo.TotalRevenue(data);
            }
		 
		 
		 });
		 });
		 
		 
	$( ".custom_revenue" ).change(function() {
	 
	 var fromdate = $("#revenuefrom").val();
    var todate = $("#revenueto").val();

	 // alert(typeId);
	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_revenue_graph',
            data: {_token: csrf,fromdate: fromdate, todate:todate},
            success: function (data) { 
                  // console.log(data);
				 demo.TotalRevenue(data);
            }
		 
		 
		 });
		 
		 
		 });
		 
		 
	 $( ".get_promo_status" ).click(function() {
	 var id = $(this).attr('value');
		 // alert(id);
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/DownloadPromocode',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
                  // console.log(data);
				 demo.HighestOrderChart(data);
            }
		 
		 
		 });
		 });
		 
		 
   $( ".custom_graph_promo" ).change(function() {
	 
	 var fromdate = $("#promofrom").val();
    var todate = $("#promoto").val();
    var promoId = $("#promoId").val();

	 // alert(fromdate);
	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_graph_promocode',
            data: {_token: csrf,fromdate: fromdate, todate:todate, promoId:promoId},
            success: function (data) { 
                  // console.log(data);
				 demo.HighestOrderChart(data);
            }
		 
		 
		 });

		 });
		 
		 
		 $( ".get_time_value" ).click(function() {
	 var id = $(this).attr('value');
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SlotReportDownload',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
                  // console.log(data);
				demo.HighSlot(data);
            }
		 
		 
		 });
		 });
		 
		 
		 $( ".custom_graph_time" ).change(function() {
	 
	 var fromdate = $("#Slotsfrom").val();
    var todate = $("#Slotsto").val();
    var timeId = $("#timeId").val();

	 // alert(timeId);
	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_graph_timeslot',
            data: {_token: csrf,fromdate: fromdate, todate:todate, timeId:timeId},
            success: function (data) { 
                  // console.log(data);
				demo.HighSlot(data);
            }
		 
		 
		 });

		 });
		 
		 $( ".get_wallet_amount" ).click(function() {
	 var id = $(this).attr('value');
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WalletReport',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
                  // console.log(data);
				demo.WalletChart(data);
            }
		 
		 
		 });
		 });
		 
		 
		 
		 $( ".custom_wallet" ).change(function() {
	 
	 var fromdate = $("#walletfrom").val();
    var todate = $("#walletto").val();

	 // alert(timeId);
	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_graph_wallet',
            data: {_token: csrf,fromdate: fromdate, todate:todate},
            success: function (data) { 
                  console.log(data);
				demo.WalletChart(data);
            }
		 
		 
		 });

		 });
		 
		 
		 
   $( ".get_category_value" ).click(function() {
	 var id = $(this).attr('value');
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/ClothesReport',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 

                 var obj2 = JSON.stringify(data.amount);
                 var obj3 = JSON.stringify(data.quantity);

		          demo.SalesChart(obj2); 
				  
				  demo.ClothRevenue(obj3);

            }
		 
		 
		 });
		 });
		 
		 
		 
	$( ".custom_graph_cate" ).change(function() {
	 
	 var fromdate = $("#clothesfrom").val();
    var todate = $("#clothesto").val();
    var cateId = $("#cateId").val();

	 // alert(timeId);
	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_category_graph',
            data: {_token: csrf,fromdate: fromdate, todate:todate, cateId:cateId},
            success: function (data) { 
                  // console.log(data);
				var obj2 = JSON.stringify(data.amount);
                 var obj3 = JSON.stringify(data.quantity);

		          demo.SalesChart(obj2); 
				  
				  demo.ClothRevenue(obj3);
            }
		 
		 
		 });

		 });
		 
		 
		 $("#Main_Category").change(function(){
	if(($('#Main_Category').val()) != ''){
	$('#Main_Category').removeClass('warn');	
	$('.main_cate').css({"display": "none"});
	}
});

$("#clothes_type").change(function(){
	if(($('#clothes_type').val()) != ''){
	$('#clothes_type').removeClass('warn');	
	$('.main_type').css({"display": "none"});
	}
});

 $('#Main_Category,#clothes_type').on('change',function(){
 // var id = $(this).val();
 
 if(($('#Main_Category').val()) == ''){
	$('#Main_Category').addClass('warn').focus();
	$('.main_cate').css({"display": "block"});
	return false;	   
}

if(($('#clothes_type').val()) == ''){
	$('#clothes_type').addClass('warn').focus();
	$('.main_type').css({"display": "block"});
	return false;
}
 
 var id = $("#Main_Category").val();
 
  var type = $("#clothes_type").val();
 
 // alert(type);
 var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/category_clothes_report',
            data: {_token: csrf,id: id, type:type},
            success: function (data) { 
              //var test  =JSON.parse(data);
			  // console.log(data);
			  demo.CategoryClothesRep(data);

            }
        });
});

//Check Promocode
$(document).ready(function(){
   $("#promocode").keyup(function(){
	  var Result = $('#promo_valid');
	  var promocode =  $("#promocode").val();
      
		  var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/CheckPromocode',
				data: {_token: csrf,promocode : promocode},
				success: function (data) { 			
				   if(data == 1){
				
					   $('#promo_btn2').attr('disabled', 'disabled');
					   Result.html('<span style="color:red;">Promo Code Already Used<span>');
						   
					   }else{
						   $('#promo_btn2').prop("disabled", false);
						   Result.html('<span style="color:green;">Available<span>');
						}
						
					}
				});
		
    });  
}); 




$( ".pickup_graph" ).click(function() {
	 var id = $(this).attr('value');
	  var type = 'graph';
	  var pickupId = $("#pickupId").val();
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/Pickup_Report',
            data: {_token: csrf,id: id, type:type, pickupId:pickupId},
            success: function (data) { 

				  demo.pickupUserChart(data);
            }
		 });
});