var base_url = 'http://13.126.228.76/ironbox_admin/public/';

$( ".outlet_area" ).click(function() {
	 var id = $(this).attr('value');
	 
	  var outletId = $('#outletId').val();

	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarletPinReport',
            data: {_token: csrf,id: id, type:type, outletId:outletId},
            success: function (data) { 
                
				
				demo.HighestOrderChart(data);
				
            }		 
    });
 });
 
 
 
 $( "#areafrom,#areato,#pinId" ).change(function() {
	
	var fromdate = $("#areafrom").val();
    var todate = $("#areato").val();
    var pinId = $("#pinId").val();
    var outletId = $("#outletId").val();
   
	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchWarPin',
            data: {_token: csrf,fromdate: fromdate, todate:todate, pinId:pinId, outletId:outletId},
            success: function (data) { 

				  if(data.length == 0){
					  $("#area_report").empty();
					   $("#area_report").append('<tr><td colspan="4">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#area_report").empty();
                 
				  
				  $.each(data, function (i) {

						   $("#area_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].code+'</td><td><a href="'+base_url+'WarBookings/'+data[i].id+'">View</a></td></tr>');

					   });
				  }
            }
        });
	
});


$( ".custom_graph_pin" ).change(function() {
	 
		 var areafrom = $('#areafrom').val();
		 var areato = $('#areato').val();
		 var pinId = $('#pinId').val();
		 var outletId = $("#outletId").val();

	     var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_war_pingraph',
            data: {_token: csrf,areafrom: areafrom, areato:areato, pinId:pinId, outletId:outletId},
            success: function (data) { 
			
				  demo.HighestOrderChart(data);
            }
		 
		 
	 });
	 
  });
  
  
  
   $( ".get_paytype_value" ).click(function() {
	 var id = $(this).attr('value');
	 var outletId = $("#outletId").val();
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarPayDownload',
            data: {_token: csrf,id: id, type:type, outletId:outletId},
            success: function (data) { 
				  demo.PaymentTypeChart(data);
            }
		 
		 
		 });
     });
	 
	 
	 
	 $( "#paymentfrom,#paymentto,#paytypeId" ).change(function() {
	
	var fromdate = $("#paymentfrom").val();
    var todate = $("#paymentto").val();
    var paytypeId = $("#paytypeId").val();
    var outletId = $("#outletId").val();

	
	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchWarPayment',
            data: {_token: csrf,fromdate: fromdate, todate:todate, paytypeId:paytypeId, outletId:outletId},
            success: function (data) { 
                  // console.log(data);
				  
				  if(data.length == 0){
					  $("#payment_report").empty();
					   $("#payment_report").append('<tr><td colspan="4">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#payment_report").empty();
				  
				  $.each(data, function (i) {
					     
					          $("#payment_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].PaymentType+'</td><td><a href="'+base_url+'WarBookings/'+data[i].id+'">View</a></td></tr>');
						  
					
						 
					   });
				  }
            }
        });
	
});



$( ".custom_graph_paytype" ).change(function() {
	 
		 var paymentfrom = $('#paymentfrom').val();
		 var paymentto = $('#paymentto').val();
		 var paytypeId = $('#paytypeId').val();
		 var outletId = $("#outletId").val();
		 // alert(paytypeId);
	     var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/war_paymentgraph',
            data: {_token: csrf,paymentfrom: paymentfrom, paymentto:paymentto, paytypeId:paytypeId, outletId:outletId},
            success: function (data) { 
        
				 demo.PaymentTypeChart(data);
            }
		 
		 
		 });
	 
});


$( ".get_revenue_status" ).click(function() {
	 var id = $(this).attr('value');
	  var type = 'graph';
	  var outletId = $('#outletId').val();
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarRevenueExcel',
            data: {_token: csrf,id: id, type:type, outletId:outletId},
            success: function (data) { 
                
				 demo.TotalRevenue(data);
            }
	});
});


$("#revenuefrom,#revenueto").change(function() {
	
	var fromdate = $("#revenuefrom").val();
    var todate = $("#revenueto").val();
    var outletId = $("#outletId").val();
	
	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchWarRevenue',
            data: {_token: csrf,fromdate: fromdate, todate:todate, outletId:outletId},
            success: function (data) { 
				  
				  // console.log(data);
				  if(data.length == 0){
					  $("#revenue_report").empty();
					   $("#revenue_report").append('<tr><td colspan="3">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#revenue_report").empty();
				  
				  $.each(data, function (i) {
					  
					  $("#revenue_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].Status+'</td><td><a href="'+base_url+'WarBookings/'+data[i].id+'">View</a></td></tr>');
					     
						 
					   });
				  }
            }
        });
	
});
	 
$( ".custom_revenue" ).change(function() {
	 
	 var fromdate = $("#revenuefrom").val();
     var todate = $("#revenueto").val();
	 var outletId = $("#outletId").val();

	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_war_revenue',
            data: {_token: csrf,fromdate: fromdate, todate:todate, outletId:outletId},
            success: function (data) { 
				 demo.TotalRevenue(data);
            }
		 
		 
		 });
		 		 
});


 $( ".get_time_value" ).click(function() {
	 var id = $(this).attr('value');
      var outletId = $('#outletId').val();
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarTimeSlotReport',
            data: {_token: csrf,id: id, type:type, outletId:outletId},
            success: function (data) { 
				demo.HighSlot(data);
            }	 
    });
});


$( "#Slotsfrom,#Slotsto,#timeId" ).change(function() {

    var fromdate = $("#Slotsfrom").val();
    var todate = $("#Slotsto").val();
    var timeId = $("#timeId").val();
    var outletId = $("#outletId").val();
	
	 var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarSearchTime',
            data: {_token: csrf,fromdate: fromdate, todate:todate, timeId:timeId, outletId:outletId},
            success: function (data) { 
				  $("#Time_report").empty();
				  if(data.length == 0){
					  $("#Time_report").empty();
					   $("#Time_report").append('<tr><td colspan="4">No record</td></tr>');
				  }				  
				  if(data.length > 0){				  
				  $.each(data, function (i) {
					     
					          $("#Time_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].fromSlots+' - '+data[i].toSlots+'</td><td>'+data[i].Status+'</td><td><a href="'+base_url+'WarBookings/'+data[i].id+'">View</a></td></tr>');
						  
						 
					   });
				  }
            }
        });
});


$( ".custom_graph_time" ).change(function() {
	 
	var fromdate = $("#Slotsfrom").val();
    var todate = $("#Slotsto").val();
    var timeId = $("#timeId").val();
	var outletId = $("#outletId").val();

	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_war_graph_slot',
            data: {_token: csrf,fromdate: fromdate, todate:todate, timeId:timeId, outletId:outletId},
            success: function (data) { 
			console.log(data);
				demo.HighSlot(data);
            }
		 
		 
		 });

});


$( ".get_promo_status" ).click(function() {
	 var id = $(this).attr('value');
	var outletId = $("#outletId").val();
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarPromoDown',
            data: {_token: csrf,id: id, type:type, outletId:outletId},
            success: function (data) { 
                  console.log(data);
				 demo.HighestOrderChart(data);
            }
   });
});


$( "#promofrom,#promoto,#promoId" ).change(function() {
	
	var fromdate = $("#promofrom").val();
    var todate = $("#promoto").val();
    var promoId = $("#promoId").val();
    var outletId = $("#outletId").val();
	// alert(promoId);
	

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarSearchPromo',
            data: {_token: csrf,fromdate: fromdate, todate:todate, promoId:promoId, outletId:outletId},
            success: function (data) { 

				  if(data.length == 0){
					  $("#promo_report").empty();
					   $("#promo_report").append('<tr><td colspan="4">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#promo_report").empty();
                  
				  
				  $.each(data, function (i) {

						    $("#promo_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].code+'</td><td>'+data[i].Status+'</td><td><a href="'+base_url+'WarBookings/'+data[i].id+'">View</a></td></tr>');
						 
					   });
				  }
            }
        });
	
});


$( ".custom_graph_promo" ).change(function() {
	 
	 var fromdate = $("#promofrom").val();
    var todate = $("#promoto").val();
    var promoId = $("#promoId").val();
	var outletId = $("#outletId").val();

	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_graph_warpromo',
            data: {_token: csrf,fromdate: fromdate, todate:todate, promoId:promoId, outletId:outletId},
            success: function (data) { 
                  // console.log(data);
				 demo.HighestOrderChart(data);
            }

	});

});


$( ".get_order_status" ).click(function() {
		 var id = $(this).attr('value');
		 var outletId = $("#outletId").val();
	  var type = 'graph';
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarStatusReport',
            data: {_token: csrf,id: id, type:type, outletId:outletId},
            success: function (data) { 
                  // console.log(data);
				 demo.SuccessGraph(data);
            }
		 
		 
	});
});


$( "#statusfrom,#statusto,#typeId" ).change(function() {
	
	var fromdate = $("#statusfrom").val();
    var todate = $("#statusto").val();
    var typeId = $("#typeId").val();
	var outletId = $("#outletId").val();
	

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarSearchSat',
            data: {_token: csrf,fromdate: fromdate, todate:todate, typeId:typeId, outletId:outletId},
            success: function (data) {
                   console.log(data);				
				  $("#orderstatus_report").empty();
				  if(data.length == 0){
					  $("#orderstatus_report").empty();  
					   $("#orderstatus_report").append('<tr><td colspan="5">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
						$.each(data, function (i) {					  
					$("#orderstatus_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].Status+'</td><td>'+data[i].cancelReason+'</td><td><a href="'+base_url+'WarBookings/'+data[i].id+'">View</a></td></tr>');
			 
			        });
			
				  }
            }
        });
	
});
	  
	  
	  
	  
$("#Main_Category").change(function(){
	if(($('#Main_Category').val()) != ''){
	$('#Main_Category').removeClass('warn');	
	$('.main_cate').css({"display": "none"});
	}
});

$("#clothes_type").change(function(){
	if(($('#clothes_type').val()) != ''){
	$('#clothes_type').removeClass('warn');	
	$('.main_type').css({"display": "none"});
	}
});

 $('#Main_Category,#clothes_type').on('change',function(){
 // var id = $(this).val();
 
 if(($('#Main_Category').val()) == ''){
	$('#Main_Category').addClass('warn').focus();
	$('.main_cate').css({"display": "block"});
	return false;	   
}

if(($('#clothes_type').val()) == ''){
	$('#clothes_type').addClass('warn').focus();
	$('.main_type').css({"display": "block"});
	return false;
}
 
 var id = $("#Main_Category").val();
 
  var type = $("#clothes_type").val();
  var outletId = $("#outletId").val();
 
 // alert(type);
 var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarDaygraph',
            data: {_token: csrf,id: id, type:type, outletId:outletId},
            success: function (data) { 
			  demo.CategoryClothesRep(data);

            }
        });
});





$( ".pickup_graph" ).click(function() {
	 var id = $(this).attr('value');
	  var type = 'graph';
	  var pickupId = $("#pickupId").val();
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/War_Pickup_Report',
            data: {_token: csrf,id: id, type:type, pickupId:pickupId},
            success: function (data) { 
				  demo.pickupUserChart(data);
            }
		 });
});


/****************************Pickup Report********************************/
$("#pickupfrom").change(function(){
	if(($('#pickupfrom').val()) != ''){
	$('#pickupfrom').removeClass('warn');	
	$('.pickup_from').css({"display": "none"});
	}
});

$("#pickupto").change(function(){
	if(($('#pickupto').val()) != ''){
	$('#pickupto').removeClass('warn');	
	$('.pickup_to').css({"display": "none"});
	}
});

$( "#pickupfrom,#pickupto" ).change(function() {
	
	var fromdate = $("#pickupfrom").val();
    var todate = $("#pickupto").val();
    var pickupId = $("#pickupId").val();
	
	if(($('#pickupfrom').val()) == ''){
		$('#pickupfrom').addClass('warn').focus();
		$('.pickup_from').css({"display": "block"});
		return false;	   
	}


	if(($('#pickupto').val()) == ''){
		$('#pickupto').addClass('warn').focus();
		$('.pickup_to').css({"display": "block"});
		return false;	   
	}

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchOutPickup',
            data: {_token: csrf,fromdate: fromdate, todate:todate, pickupId:pickupId},
            success: function (data) { 

				  if(data.length == 0){
					  $("#pickup_report").empty();
					   $('#pickup_report').append('<tr><td colspan="4">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#pickup_report").empty();
				 
				  
				  $.each(data, function (i) {

						   $("#pickup_report").append('<tr><td>'+data[i].bookingId+'</td><td>'+data[i].bookingDate+'</td><td>'+data[i].Pickup+'</td><td>'+data[i].Status+'</td><td><a href="'+base_url+'ViewBookings/'+data[i].id+'">View</a></td></tr>');
						 
					   });
				  }
            }
        });
	
});



/*****************************Vendor search***********************************/

$("#vendorfrom").change(function(){
	if(($('#vendorfrom').val()) != ''){
	$('#vendorfrom').removeClass('warn');	
	$('.vendor_from').css({"display": "none"});
	}
});

$("#vendorto").change(function(){
	if(($('#vendorto').val()) != ''){
	$('#vendorto').removeClass('warn');	
	$('.vendor_to').css({"display": "none"});
	}
});

$( "#vendorfrom,#vendorto" ).change(function() {
	
	var fromdate = $("#vendorfrom").val();
    var todate = $("#vendorto").val();
    var vendorId = $("#vendorId").val();
	
	if(($('#vendorfrom').val()) == ''){
		$('#vendorfrom').addClass('warn').focus();
		$('.vendor_from').css({"display": "block"});
		return false;	   
	}


	if(($('#vendorto').val()) == ''){
		$('#vendorto').addClass('warn').focus();
		$('.vendor_to').css({"display": "block"});
		return false;	   
	}

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchOutVendorReports',
            data: {_token: csrf,fromdate: fromdate, todate:todate, vendorId:vendorId},
            success: function (data) { 
				  
				  if(data.length == 0){
					  $("#Vendor_report").empty();
					   $('#Vendor_report').append('<tr><td colspan="3">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#Vendor_report").empty();
				  
				  $.each(data, function (i) {

						   $("#Vendor_report").append('<tr><td>'+data[i].name+' - '+data[i].groupName+'</td><td>'+data[i].orders+'</td><td>'+data[i].quantity+'</td><td>'+data[i].amount+'</td></tr>');
						 
					   });
				  }
            }
        });
	
});


$( ".get_category_value" ).click(function() {
	 var id = $(this).attr('value');
	  var type = 'graph';
	  var outletId = $('#outletId').val();
	   // alert(id);
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/WarClotheReport',
            data: {_token: csrf,id: id, type:type, outletId:outletId},
            success: function (data) { 
                 var obj2 = JSON.stringify(data.amount);
                 var obj3 = JSON.stringify(data.quantity);

		          demo.SalesChart(obj2); 
				  
				  demo.ClothRevenue(obj3);

            }		 
  });
});


$( "#clothesfrom,#clothesto,#cateId" ).change(function() {
	
	var fromdate = $("#clothesfrom").val();
    var todate = $("#clothesto").val();
    var cateId = $("#cateId").val();
    var outletId = $("#outletId").val();
	
	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchClothesWar',
            data: {_token: csrf,fromdate: fromdate, todate:todate, cateId:cateId, outletId:outletId},
            success: function (data) { 
                  // console.log(data);
				  
				  if(data.length == 0){
					  $("#Cloth_report").empty();
					   $('#Cloth_report').append('<tr><td colspan="3">No record</td></tr>');
				  }
				  
				  if(data.length > 0){
				 $("#Cloth_report").empty();
				  
				  $.each(data, function (i) {

						   $("#Cloth_report").append('<tr><td>'+data[i].name+'</td><td>'+data[i].qty+'</td><td>'+data[i].price_amount+'</td></tr>');
						 
					   });
				  }
            }
        });
	
});


$( ".custom_graph_cate" ).change(function() {
	 
	 var fromdate = $("#clothesfrom").val();
    var todate = $("#clothesto").val();
    var cateId = $("#cateId").val();
	var outletId = $("#outletId").val();
	
	  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/custom_war_category',
            data: {_token: csrf,fromdate: fromdate, todate:todate, cateId:cateId, outletId:outletId},
            success: function (data) { 
                  // console.log(data);
				var obj2 = JSON.stringify(data.amount);
                 var obj3 = JSON.stringify(data.quantity);

		          demo.SalesChart(obj2); 
				  
				  demo.ClothRevenue(obj3);
            }
		 
		 
		 });

		 });
		 
		 
		 
/**************************AVG Cost************************************/

$("#avgfrom").change(function(){
	if(($('#avgfrom').val()) != ''){
	$('#avgfrom').removeClass('warn');	
	$('.avg_from').css({"display": "none"});
	}
});

$("#avgto").change(function(){
	if(($('#avgto').val()) != ''){
	$('#avgto').removeClass('warn');	
	$('.avg_to').css({"display": "none"});
	}
});

$( "#avgfrom,#avgto" ).change(function() {
	
	var fromdate = $("#avgfrom").val();
    var todate = $("#avgto").val();
	var outletId = $("#outletId").val();
	
	if(($('#avgfrom').val()) == ''){
		$('#avgfrom').addClass('warn').focus();
		$('.avg_from').css({"display": "block"});
		return false;	   
	}


	if(($('#avgto').val()) == ''){
		$('#avgto').addClass('warn').focus();
		$('.avg_to').css({"display": "block"});
		return false;	   
	}

	var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url: base_url+'/SearchWarAvg',
            data: {_token: csrf,fromdate: fromdate, todate:todate, outletId:outletId},
            success: function (data) { 
				  
				  var arrdata = JSON.parse(data);

				  if(data.length == 0){
					  $("#Avg_report").empty();
					   $('#Avg_report').append('<td colspan="3">No record</td>');
				  }
				  if(data.length > 0){
				 $("#Avg_report").empty();
						   
						   $("#Avg_report").append('<tr><td>'+arrdata.payment+'</td><td>'+arrdata.quantity+'</td><td>'+arrdata.avg_cost+'</td></tr>');
						 
					   // });
				  }
            }
        });
	
});