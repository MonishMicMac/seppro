@extends('layouts.layouts')

@section('content')

<div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('user.list') }}">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="orange">
                                     <i class="fa fa-users"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Users</p>
                                    <h3 class="title">{{ $Users }}
                                    </h3>
                                </div>
                            </div>
							</a>
                        </div>
						
						<!-- <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="fa fa-users"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Active users</p>
                                    <h3 class="title">{{ $active }}</h3>
                                </div>
                            </div>
                        </div>
						
						<div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="red">
                                     <i class="fa fa-users"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Inactive users</p>
                                    <h3 class="title">{{ $Inactive }}</h3>
                                </div>
                            </div>
                        </div>-->
						
                        <div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('pickupuser.list') }}">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="material-icons">store</i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Pickup users</p>
                                    <h3 class="title">{{ $PickupUser }}</h3>
                                </div>
                            </div>
							</a>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('ironing.vendor') }}">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="red">
                                    <i class="material-icons">info_outline</i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Ironing vendor</p>
                                    <h3 class="title">{{ $Ironing }}</h3>
                                </div>
                            </div>
							</a>
                        </div>
						<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('get.outlet') }}">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="material-icons">store</i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Outlets</p>
                                    <h3 class="title">{{ $warehours }}</h3>
                                </div>
                            </div>
							</a>
                        </div>
						 
						 <div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('order.list') }}">
                            <div class="card card-stats ">
                                <div class="card-header" data-background-color="red">
                                    <i class="fa fa-list-ul"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Total orders</p>
                                    <h3 class="title">{{ $Orders }}</h3>
                                </div>
                            </div>
							</a>
                        </div>
						
                        <div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('completed.order.list') }}">
                            <div class="card card-stats ">
                                <div class="card-header" data-background-color="blue">
                                    <i class="fa fa-list-ul"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Completed orders</p>
                                    <h3 class="title">{{ $Bookings }}</h3>
                                </div>
                            </div>
							</a>
                        </div>

						
						<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('pending.order') }}">
                            <div class="card card-stats ">
                                <div class="card-header" data-background-color="blue">
                                    <i class="fa fa-list-ul"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Pending orders</p>
                                    <h3 class="title">{{ $Confirm }}</h3>
                                </div>
                            </div>
							</a>
                        </div>
						
						<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('cancelled.order') }}">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="blue">
                                    <i class="fa fa-list-ul"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Cancelled orders</p>
                                    <h3 class="title">{{ $Cancel }}</h3>
                                </div>
                            </div>
							</a>
                        </div>
						
						
						
						 
						
						
						<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="https://websmsapp.in/Account/Login.aspx">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="red">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">SMS</p>
									<h3 class="title"></h3>
                                </div>
                            </div>
							</a>
                        </div>
						
						<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="https://firebase.google.com/">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">FCM push</p>
									<h3 class="title"></h3>
                                </div>
                            </div>
							</a>
                        </div>
						<!--<div class="clearfix"></div>-->
						
						<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('deleted.pickup.user') }}">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="red">
                                    <i class="fa fa-users"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Deleted pickup user</p>
									<h3 class="title"></h3>
                                </div>
                            </div>
							</a>
                        </div>
						
						
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="dailySales"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Daily sales clothes vs quantity</h4>
                                </div>
                                </div>
                            </div>
							
							<div class="col-md-6">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="PaymentTypeChart"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Daily payment type</h4>
                                </div>
                            </div>
                        </div>
                    </div>
					
					<div class="row">
					    <div class="col-md-6">

                           <div class="card">
                                <div class="card-header card-chart" data-background-color="blue">
                                    <div class="ct-chart" id="MostBooking"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Most booking user</h4>
                                </div>
                            </div>
                         					   
                         </div>	


                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="dailySalesRevenue"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Daily sales clothes vs amount</h4>
                                </div>
                                </div>
                            </div>
						 
					   </div>
					   
					   
					   <div class="row">
					      <div class="col-md-12">
                            <div class="card"> 
                                <div class="card-content center">
								   <h4 class="title">Clothes report</h4>
								<div id="clothes"></div>
                                   
                                </div>
                                </div>  
                            </div>
					   
					   </div>
					   
					   
					   <div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Pickup/delivery route</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Mobile</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Mobile</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($pickup as $user)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $user->name }}</td>
										<td>{{ $user->mobile }}</td>
                                        

										<td class="text-right">
											
											<a  href="{{ route('delivery.routes',[$user->userId]) }}" class="btn btn-simple btn-info btn-icon like"> <i class="fa fa-map-marker"></i></a>
											
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
						
						
					</div>
				</div>
			</div>
		</div>
					
                </div>
            </div>
<script>

$.get("{{route('piechart.clothes')}}")
	  .done(function(reponse) {
		  
		  console.log(reponse);
			
			var newdata = reponse;
			
		  
	var pie = new d3pie("clothes", {
		// header: {
			// title: {
				// text: "Clothes Reports"
			// }
		// },
		size: {
			pieOuterRadius: "100%",
			canvasHeight: 400
		},
		data: {
			content: newdata
		}
	});
	
	
	});
</script>
<script type="text/javascript">
    $(document).ready(function() {
       //Total sales grahp
		$.get("{{route('today.sales')}}")
	  .done(function(data) {
		
			demo.SalesChart(data);
							
		});	
		
		//Payment type grahp
	   $.get("{{route('payment.type')}}")
	  .done(function(data) {
			demo.PaymentTypeChart(data);
							
		});	
		
		$.get("{{route('most.booking')}}")
	  .done(function(data) {
		  
			demo.MostBooking(data);
							
		});	
		
		
		$.get("{{route('clothes.revenue.graph')}}")
	  .done(function(data) {
			demo.ClothRevenue(data);
							
		});	   
		
		
    });
</script>

@endsection
