@extends('layouts.layouts')

@section('content')


<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>

   <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Add Complaints</h4>
				</div>
				<div class="card-content">
				   <form  action="{{ route('add.complients') }}" method="post" id="AddComplaints" enctype="multipart/form-data">
					   {{ csrf_field() }}
					   
					   
					   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Mobile No
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" maxlength ="10" name="mobile" id="mobile" type="text" />
							  @if(session()->has('error_message'))
								   <p class="error">
									{{ session()->get('error_message') }}
								</p>
								@endif
                           </div>
						   
						   <div class="form-group label-floating">
                             <!-- <label class="control-label">
                                Complaints
                              <small>*</small>
                              </label>-->
                             <select class="form-control" id="type_complaints" name="type_complaints">
							   <option value="">Select Complaints type</option>
							   @foreach($complaint as $type)
							   <option value="{{ $type->id }}">{{ $type->compliant_name	 }}</option>
								@endforeach
							 </select>
                           </div> 

                           <div class="form-group label-floating">
                              <label class="control-label">
                                Complaints
                              <small>*</small>
                              </label>
                              <input class="form-control  emptyspace" name="complaints" id="complaints" type="text" />
                           </div> 

						   
                          </div>
						 
						<div class="col-md-6">
                            <div class="box_shadow box_shadow2">
				                <h4 class="yellowtext">User Details</h4> 
								 
								<div class="urdetails">
								   <strong >Name :</strong> <span id="username"></span>
								</div>
								
								<div class="urdetails">
								   <strong>Mobile :</strong> <span id="usermobile"></span>
								</div>
								
								<div class="urdetails">
								   <strong>Email :</strong> <span id="useremail"></span>
								</div>
								 
							</div> 	
                        </div>
						
						<div class="clearfix"></div>

						
						<div class="col-md-12">
						<button class="btn btn-primary" id="pin_btn">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>	


	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Customer complients</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Complaint Id</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Comments</th>
										<th>Types</th>
										<th>Open / Not</th>
										<th>Date</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Complaint Id</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Comments</th>
										<th>Types</th>
										<th>Open / Not</th>
										<th>Date</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($Customer as $Support)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $Support->complaint_id }}</td>
										<td>{{ $Support->name }}</td>
										<td>{{ $Support->mobile }}</td>
										<td>{{ $Support->Comments }}</td>
										<td>{{ $Support->complaints_type }}</td>
										<td>@if($Support->Is_open == 1) open @else Not open @endif</td>
                                        <td>{{ $Support->comp_date }}</td>

										<td class="text-right">
								          <a href="{{ route('view.complient',[$Support->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


@endsection