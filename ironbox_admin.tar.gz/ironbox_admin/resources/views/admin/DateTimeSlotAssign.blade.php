@extends('layouts.layouts')

@section('content')
<style type="text/css">
	.fa-close{
		margin-top: 17px;
		color: #ff0000;
		font-size: 20px;
	}
</style>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Date Timeslot Assign</h4>
					</div>
					<div class="card-content">
						<form action="{{ route('admin.datetimeslotassign.action') }}" method="post" id="assigntimeslot" enctype="multipart/form-data">
							{{ csrf_field() }}
							<div class="col-md-4">
								<div class="form-group label-floating">
									<select class="form-control" id="month" name="month">
										<option value="">Select Month</option>
										@foreach($months as $month)
										@if($month==$sel_month)
										<option value="{{ $month }}" selected>{{ $month }}</option>
										@else
										<option value="{{ $month }}">{{ $month }}</option>
										@endif
										@endforeach
									</select>
								</div>
							</div>
							<div class="clearfix"></div>

							@foreach($dates as $date)

							@php
							$sel_leaves=array();
							$leave_reasons=array();
							foreach($all_leaves as $leave){
								$sel_leaves[]=$leave['date'];
								$leave_reasons[$leave['date']]=$leave['reason'];
							}
							@endphp

							<br>
							<div class="row all_data" style="margin-left: 0% !important;">
								<div class="col-md-3">
									<div class="form-group label-floating">
										<label class="control-label">Date<small>*</small></label>
										<input class="form-control emptyspace date" type="text" value="{{ $date }}" readonly />
									</div>
								</div>

								@php
								$disabled='disabled';
								if($date>=date('Y-m-d')){
									$disabled='';
								}
								@endphp

								<div class="col-md-6 warehouse_list">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group label-floating">
												@if(in_array($date,$sel_leaves)==true)
												<select class="form-control sel_warehouse" date="{{ $date }}" {{ $disabled }} disabled>
												@else
												<select class="form-control sel_warehouse" date="{{ $date }}" {{ $disabled }}>
												@endif
													<option value="">Select warehouse</option>
													@foreach($warehouses as $warehouse)
													<option value="{{ $warehouse->id }}"> {{ $warehouse->name }} </option>
													@endforeach
												</select>
											</div>
										</div>

										<div class="col-md-2">
											<div class="leave_check" style="margin-top: 15px;">
												@if(in_array($date,$sel_leaves)==true)
												<input type="checkbox" name="leave[]" class="leave" value="{{ $date }}" {{ $disabled }} checked> Leave
												@else
												<input type="checkbox" name="leave[]" class="leave" value="{{ $date }}" {{ $disabled }}> Leave
												@endif
											</div>
										</div>

										<div class="col-md-4">
											@if(in_array($date,$sel_leaves)==true)
											<div class="form-group label-floating reason_show">
												<label class="control-label">Reason<small>*</small></label>
												<input class="form-control emptyspace" type="text" name="leave_reason_{{ $date }}" {{ $disabled }} value="{{ $leave_reasons[$date] }}">
											</div>
											@else
											<div class="form-group label-floating reason_show" hidden>
												<label class="control-label">Reason<small>*</small></label>
												<input class="form-control emptyspace" type="text" name="leave_reason_{{ $date }}" {{ $disabled }} value="">
											</div>
											@endif
										</div>
									</div>
									<div class="row warehouses">
										@php
										$sel_leaves=array();
										foreach($all_leaves as $leave){
											$sel_leaves[]=$leave['date'];
										}

										foreach($fetchArray as $dates_array){
											if(!empty($dates_array[$date])){

												if(in_array($date,$sel_leaves)==true){
													
												}

												foreach($dates_array[$date] as $whs){
													if(!empty($whs)){
														if(!is_array($whs)){
															$pin_id=explode("$",$whs);
															@endphp
															<div class="every_warehouse">
																<div class="col-md-6">
																	<div class="form-group label-floating">
																		<select class="form-control real_warehouses" readonly>
																			<option value="{{ $pin_id[0] }}">{{ $pin_id[1] }}</option>
																		</select>
																	</div>
																</div>

																<div class="ts_list">
																	<div class="col-md-5">
																		<div class="form-group label-floating">

																			@if(in_array($date,$sel_leaves)==true)
																			<select class="form-control sel_timeslot" date="{{ $date }}" onchange="sel_timeslot(this)" {{ $disabled }} disabled>
																			@else
																			<select class="form-control sel_timeslot" date="{{ $date }}" onchange="sel_timeslot(this)" {{ $disabled }}>
																			@endif
																				<option value="">Select Time Slot</option>
																				@foreach($time_slots as $time_slot)
																				<option value="{{ $time_slot->id }}"> {{ $time_slot->fromSlots.' - '.$time_slot->toSlots }} </option>
																				@endforeach
																			</select>
																		</div>
																	</div>

																	<div class="col-md-1">
																		@if($date>=date('Y-m-d'))
																		<a href="javascript:void(0)" onclick="remove_warehouse(this)"><i class="fa fa-close" style="margin-left: 75%;"></i></a>
																		@endif
																	</div>

																	<div class="row time_slots">
																		@php
																		foreach($fetchArray_ts as $dates_array_ts){
																			if(!empty($dates_array_ts[$date])){
																				if(!empty($dates_array_ts[$date][$whs])){
																					foreach($dates_array_ts[$date][$whs] as $timeslots){
																						if(!empty($timeslots)){
																							$slots=explode("$",$timeslots);

																							$all_details=$date.' $ '.$pin_id[0].' $ '.$slots[0].' $ '.$slots[2];
																							@endphp

																							<div class="slots_and_counts">
																								<div class="col-md-6"></div>
																								<div class="col-md-3">
																									<div class="form-group label-floating">
																										<select class="form-control tslots" readonly>
																											<option value="{{ $slots[0] }}">{{ $slots[1] }}</option>
																										</select>
																									</div>
																								</div>
																								<div class="col-md-2">
																									<div class="form-group label-floating">
																										<label class="control-label">Slots<small>*</small></label>
																										@if(in_array($date,$sel_leaves)==true)
																										<input class="form-control emptyspace slots" type="text" onkeyup="slot_count(this)" value="{{ $slots[2] }}" disabled {{ $disabled }}>
																										@else
																										<input class="form-control emptyspace slots" type="text" onkeyup="slot_count(this)" value="{{ $slots[2] }}" {{ $disabled }}>
																										@endif
																										<input type="hidden" class="all_details" name="all_details[]" value="{{ $all_details }}">
																									</div>
																								</div>
																								<div class="col-md-1">
																									@if($date>=date('Y-m-d'))
																									<a href="javascript:void(0)" onclick="remove_timeslot(this)"><i class="fa fa-close"></i></a>
																									@endif
																								</div>
																							</div>
																							<div class="clearfix"></div>

																							@php
																						}
																					}
																				}
																			}
																		}
																		@endphp
																	</div>
																</div>
															</div>

															<div class="clearfix"></div>
															@php
														}
													}
												}
											}
										}
										@endphp
									</div>
								</div>

								<div class="time_slots_div" hidden>
									<div class="ts_list">
										<div class="col-md-5">
											<div class="form-group label-floating">
												<select class="form-control sel_timeslot" date="{{ $date }}" onchange="sel_timeslot(this)">
													<option value="">Select Time Slot</option>
													@foreach($time_slots as $time_slot)
													<option value="{{ $time_slot->id }}"> {{ $time_slot->fromSlots.' - '.$time_slot->toSlots }} </option>
													@endforeach
												</select>
											</div>
										</div>
										<div class="col-md-1">
											<a href="javascript:void(0)" onclick="remove_warehouse(this)"><i class="fa fa-close" style="margin-left: 75%;"></i></a>
										</div>
										<div class="row time_slots">

										</div>
									</div>
								</div>
							</div>
							@endforeach

							<div class="clearfix"></div>
							<button class="btn btn-primary">
								Submit
								<div class="ripple-container"></div>
							</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function(){
		$("#month").change(function(){
			var month=$(this).val();
			window.location.href="{{URL::to('DateTimeSlotAssign')}}/"+month;
		});

		$(".sel_warehouse").change(function(){
			var id=$(this).val();
			var date=$(this).attr("date");
			var value=$(this).children("option:selected").html();
			var time_slots=$(this).closest(".all_data").find(".time_slots_div").html();

            var sel_warehouses=[];
            $(this).closest(".warehouse_list").find(".real_warehouses").each(function(){
               sel_warehouses.push($(this).val());
            });

            if(jQuery.inArray(id, sel_warehouses) == -1){
            	$(this).closest(".warehouse_list").find(".warehouses").append('<div class="every_warehouse"><div class="col-md-6"><div class="form-group label-floating"><select class="form-control real_warehouses" readonly><option value="'+id+'">'+value+'</option></select></div></div>'+time_slots+'</div><div class="clearfix"></div>');
            }

			$(".sel_warehouse option:selected").prop("selected", false);
		});

		$(".leave").click(function(){
			if($(this).prop("checked")==true){
				$(this).closest(".warehouse_list").find(".sel_warehouse").prop("disabled",true);
				$(this).closest(".warehouse_list").find(".sel_timeslot").prop("disabled",true);
				$(this).closest(".warehouse_list").find(".slots").prop("disabled",true);
				$(this).closest(".warehouse_list").find(".reason_show").show();
			} else {
				$(this).closest(".warehouse_list").find(".sel_warehouse").prop("disabled",false);
				$(this).closest(".warehouse_list").find(".sel_timeslot").prop("disabled",false);
				$(this).closest(".warehouse_list").find(".slots").prop("disabled",false);
				$(this).closest(".warehouse_list").find(".reason_show").hide();
			}
		});
	});

	function sel_timeslot(this1){
		var id=$(this1).val();
		var date=$(this1).attr("date");
		var pin_id=$(this1).closest(".every_warehouse").find(".real_warehouses").val();
		var value=$(this1).children("option:selected").html();


		var sel_timeslots=[];
		$(this1).closest(".every_warehouse").find(".tslots").each(function(){
			sel_timeslots.push($(this).val());
		});

		if(jQuery.inArray(id, sel_timeslots) == -1){
			$(this1).closest(".ts_list").find(".time_slots").append('<div class="slots_and_counts"><div class="col-md-6"></div><div class="col-md-3"><div class="form-group label-floating"><select class="form-control tslots" readonly><option value="'+id+'">'+value+'</option></select></div></div><div class="col-md-2"><div class="form-group label-floating"><label class="control-label">Slots<small>*</small></label><input class="form-control emptyspace" type="text" onkeyup="slot_count(this)"> <input type="hidden" class="all_details" name="all_details[]"></div></div><div class="col-md-1"><a href="javascript:void(0)" onclick="remove_timeslot(this)"><i class="fa fa-close"></i></a></div></div><div class="clearfix"></div>');
		}

		$(".sel_timeslot option:selected").prop("selected", false);
	}

	function slot_count(this1){
		var date=$(this1).closest(".all_data").find(".date").val();
		var warehouse=$(this1).closest(".every_warehouse").find(".real_warehouses").val();
		var time_slots=$(this1).closest(".slots_and_counts").find(".tslots").val();
		var slot_count=$(this1).val();

		var all_details=date+' $ '+warehouse+' $ '+time_slots+' $ '+slot_count;

		$(this1).closest(".slots_and_counts").find(".all_details").val(all_details);

	}

	function remove_timeslot(this1){
		$(this1).closest(".slots_and_counts").remove();
	}

	function remove_warehouse(this1){
		$(this1).closest(".every_warehouse").remove();
	}

</script>
@endsection