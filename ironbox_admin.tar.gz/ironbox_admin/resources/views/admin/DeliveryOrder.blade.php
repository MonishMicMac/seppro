@extends('layouts.layouts')

@section('content')


<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Delivery Order</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Booking date</th>
										<th>Delivery date</th>
										<th>Order for</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Booking Date</th>
										<th>Delivery Date</th>
										<th>Order for</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($DeliveryOrder as $Order)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $Order->bookingId }}</td>
										<td>{{ $Order->name }}</td>
										<td>{{ $Order->mobile }}</td>
										<td>{{ $Order->bookingDate }}</td>
										<td>{{ $Order->delivery_date }}</td>
										<td>{{ $Order->Order_for }}</td>


										<td class="text-right">
											<a 	href="{{ route('order.assign',[$Order->id]) }}" class="btn btn-simple btn-warning btn-icon edit"><i class="fa fa-pencil-square-o"></i></a>
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


@endsection