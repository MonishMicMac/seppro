@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	   <div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Sub Category</h4>
					</div>
					<div class="card-content">
						<form  action="{{ route('update.category.items') }}" method="post" id="editaddsubcategoty" enctype="multipart/form-data">
					     {{ csrf_field() }}
						 
						 @foreach($Items as $GetItems)
						   <div class="col-md-6">
							 <div class="form-group label-floating">
								
								<select  class="form-control" id="MainCategory" name="MainCategory">
									<option value="">Select Category</option>
									@foreach($Category as $CategoryList)
									
                                    <option value="{{ $CategoryList->id }}"
									  
									   <?php
                                          foreach($Items as $GetItems){
											  
											  if($CategoryList->id == $GetItems->categoryId){
												  
												  echo "Selected";
											  }
										  }
                                         ?>									   
									  
									  > {{ $CategoryList->name }} </option>
									@endforeach
								</select>
							 </div>
						   </div>
						   
						   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Name
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="name" id="name" type="text" value="{{ $GetItems->name }}" />
                            </div>
                            <input type="hidden" name="id" value="{{ $GetItems->id }}">
                          </div>
						  <div class="clearfix"></div>
						  <div class="col-md-6">
                           
                              <label class="">
                                Image
                              <small>*</small>
                              </label>
                              <input class=""  name="image" id="image" type="file" />
                           

                          </div>
						  <p>{{ $GetItems->groupName }}</p>
						  <div class="col-md-6">
						 <div class="form-group label-floating">
							
							<select  class="form-control" id="groupname" name="groupname">
								<option value="">Select GroupName</option>
								@foreach($Group as $GetGroupName)
								<option value="{{ $GetGroupName->name }}"
								
								   <?php
                                        if($GetGroupName->name == $GetItems->groupName){
											
											
											echo "Selected";
										}
										 
                                    ?>	
								
								>{{ $GetGroupName->name }}</option>
								@endforeach
							</select>
						 </div>
					   </div>
						 @endforeach 
						  <div class="clearfix"></div>
						<button class="btn btn-primary">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						   
						 </form>
					</div>
				</div>
			</div>
		</div>
	
	
	
	
    </div>
</div>

@endsection