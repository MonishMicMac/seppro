@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Edit outlet</h4>
				</div>
				<div class="card-content">
				   <form  action="{{ route('update.outlet') }}" method="post" id="EditOutlet" enctype="multipart/form-data">
					   {{ csrf_field() }}
                       @foreach($Outlet as $Out)
                      <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                               Company Name
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="outletname" id="outletname" type="text"  value="{{ $Out->name }}"/>
                           </div>
                        </div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Authorized person
                              <small>*</small>
                              </label>  
                              
							   <input class="form-control emptyspace"  name="authorizedperson" id="authorizedperson" type="text" value="{{ $Out->authorized_person }}"/>
                           </div>
                        </div>
						
						<div class="clearfix"></div>
                    
					    <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Email
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="email" id="email" type="email" value="{{ $Out->email }}" />
							   @if(!empty($errors->first('email')))
    												<font color="red">	{{ $errors->first('email') }}</font>
    													@endif
                           </div>
                        </div>
						<input type="hidden" name="id" value="{{ $Out->id }}">
					    
					     

						
						<div class="col-md-6">
							<div class="form-group label-floating">
							  <label class="control-label">
								Address
							  <small>*</small>
							  </label>
							  <input class="form-control emptyspace"  name="address" id="mapSearch" type="text" value="{{ $Out->address }}" />
							  <input id="latitude" name="latitude" type="hidden" value="{{ $Out->latitude }}">
								<input id="longitude" name="longitude" type="hidden" value="{{ $Out->longitude }}">
						   </div>
						</div>
						 <div class="clearfix"></div>
						 
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Phone Number
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="phone_number" id="phone_number" type="text" value="{{ $Out->phoneNumber }}" />
                           </div>
                        </div> 
						<div class="clearfix"></div>
						
						<h4 class="card-title"><b>Manager Info</b></h4>
						 
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Manager name
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="manager_name" id="manager_name" type="text" value="{{ $Out->manager_name }}" />
                           </div>
                        </div>
						
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Email
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="manager_email" id="manager_email" type="email" value="{{ $Out->manager_email }}"/>
                           </div>
                        </div>
						
						<div class="clearfix"></div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Phone Number
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="manager_mobile" id="manager_mobile" type="text" value="{{ $Out->manager_mobile }}"/>
                           </div>
                        </div>
						 
						<div class="col-md-12">
							<div class="form-group">
								<div id="map" class="form-control" style="min-height:200px"></div>
							</div>
						</div>
						
						 @endforeach
						<div class="clearfix"></div>
						<div class="col-md-6">
						<button class="btn btn-primary">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>
	
	

	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		$('.active-outlet').addClass('active');

    });
</script>

  
@endsection