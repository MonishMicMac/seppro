@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	  <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
			   <div class="card-header" data-background-color="blue">
					<h4 class="title">Promo Code</h4>
				</div>
				 <div class="card-content">
			        
					 <form  action="{{ route('update.promo') }}" method="post" id="EditPromocode" enctype="multipart/form-data">
					   {{ csrf_field() }}
					   
					   @foreach($Promocode as $GetCode)
					   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                promocode
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace" maxlength ="6" name="promocode" id="promocode_name" type="text"  value="{{ $GetCode->promocode }}"/>
							  <p id="promo_valid"></p>
                           </div>
                        </div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Discount
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly"  name="discount" id="discount" type="text" value="{{ $GetCode->discount }}" />
                           </div>
                        </div>
						
						<div class="clearfix"></div>
						
						<!--<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Maximum discount
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" name="max_amount" id="max_amount" type="text" value="{{ $GetCode->maximum_amount }}" />
                           </div>
                        </div>-->
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Expiry from
                              
                              </label>
                              <input class="form-control" name="expiry_from" id="expiry_from" type="date" value="{{ $GetCode->expiry_from }}"/>
                           </div>
                        </div>
						
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Expiry to
                              
                              </label>
                              <input class="form-control" name="expiry_to" id="expiry_to" type="date" value="{{ $GetCode->expiry_to }}" />
                           </div>
                        </div>	
						
	                  	

                       

                       
					    <div class="clearfix"></div>

                         <div class="col-md-6">
						 <div class="form-group label-floating is-empty">
							<select class="form-control" id="payment_type" name="payment_type">
								<option value="">Select offer type *</option>
								<option <?php if($GetCode->offer_type == "Wallet") { echo "selected"; } ?> value="Wallet">Wallet</option>
								<option <?php if($GetCode->offer_type == "Booking") { echo "selected"; } ?> value="Booking">Booking</option>
							</select>
						 <span class="material-input"></span></div>
					   </div>	
					   
					    <div class="col-md-6">
                           No expiry: <input type="checkbox" <?php if($GetCode->no_expiry == "Yes") { echo "checked"; } ?> id="no_expiry" name="no_expiry" value="Yes">
                        </div>						
    					<input type="hidden" name="id" id="promocode_id" value="{{ $GetCode->id  }}">	
						
						<div class="clearfix"></div>	

                        <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Discription
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace" value="{{ $GetCode->description }}" name="description" id="description" type="text" />
                           </div>
                        </div>	
						
						<div class="col-md-6">
						 <div class="file-upload">
                              <label class="">
                                Images
                              
                              </label>
                              <input class="upload_img_file" name="image" id="image" accept="image/*" type="file">
							  </div>
                             <div class="img_pre1">							  
                               <img class='img img_preview' src='http://13.126.228.76/ironbox_admin/public/images/offers/{{ $GetCode->images }}' />
							  </div> 
                          </div>

                        <!-- <div class="col-md-6">
                          <?php foreach($Pincode as $GetPincode){
							  
							  ?>
						  
						  <input type="checkbox" id="pincode" name="pincode[]" <?php 
						  
						         foreach($Area as $SelectAreas){
									 
									 if($GetPincode->id == $SelectAreas->serviceArea_Id){
										 
										 echo "checked";
									 }
								 }



						  ?>  
						  
						  
						            value="<?php echo $GetPincode->id;?>">  <?php echo $GetPincode->area;?>
						  
						  <?php } ?>
						  
                      </div>	-->					   
						@endforeach	
						<div class="clearfix"></div>
						<button class="btn btn-primary" id="promo_btn3">
						   Submit
						   <div class="ripple-container"></div>
						</button>
					 </form>
			
			     </div>
			   </div>
			</div>
		</div>	
	
	
	
		</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		$('.active-promo').addClass('active');

    });
</script>
@endsection