@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Add Outlet</h4>
				</div>
				<div class="card-content">
				   <form  action="{{ route('add.outlet') }}" method="post" id="Outlet" enctype="multipart/form-data">
					   {{ csrf_field() }}

                      <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Company Name
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="outletname" id="outletname" type="text" />
                           </div>
                        </div>
						
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Authorized person
                              <small>*</small>
                              </label>
                              
							   <input class="form-control emptyspace"  name="authorizedperson" id="authorizedperson" type="text" />
                           </div>
                        </div>
                    
					    <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Email
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="email" id="email" type="email" />
							    @if(!empty($errors->first('email')))
    												<font color="red">	{{ $errors->first('email') }}</font>
    													@endif
                           </div>
                        </div>
						
					   
					     
						 
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                              Password
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace" name="password" type="password" required="true" />
                           </div>
                        </div>
						 <div class="clearfix"></div>
						 
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Phone Number
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="phone_number" id="phone_number" type="text" />
                           </div>
                        </div>
						 
						<div class="col-md-6">
							<div class="form-group label-floating">
							  <label class="control-label">
								Address
							  <small>*</small>
							  </label>
							  <input class="form-control emptyspace"  name="address" id="mapSearch" type="text" onfocus="this.placeholder=''"  onblur="this.placeholder='Enter a query'" />
							  <input id="latitude" name="latitude" type="hidden" value="">
								<input id="longitude" name="longitude" type="hidden" value="">
						   </div>
						</div>
						 <div class="clearfix"></div>
						 
						 <h4 class="card-title"><b>Manager Info</b></h4>
						 
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Manager name
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="manager_name" id="manager_name" type="text" />
                           </div>
                        </div>
						
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Email
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="manager_email" id="manager_email" type="email" />
                           </div>
                        </div>
						
						<div class="clearfix"></div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Phone Number
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="manager_mobile" id="manager_mobile" type="text" />
                           </div>
                        </div>
						 
						<div class="col-md-12">
							<div class="form-group">
								<div id="map" class="form-control" style="min-height:200px"></div>
							</div>
						</div>

						<div class="clearfix"></div>
						<div class="col-md-6">
						<button class="btn btn-primary">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>
	
	
	
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Outlets</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Address</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Address</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($Outlet as $GetOutlet)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $GetOutlet->name }}</td>
										<td>{{ $GetOutlet->address }}</td>
                                        

										<td class="text-right">
											
											<a href="{{ route('view.outlet',[$GetOutlet->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-pencil-square-o"></i></a>
											
											<a href="{{ route('outlet.board',['id'=>$GetOutlet->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
											
											<a  onclick="return confirm('Are you sure you want to delete outlet');" class="delete_outlet" href="{{route('delete.outlet')}}?id={{$GetOutlet->id}}"> <i class="fa fa-trash"></i></a>
											
											<!--<a  data-toggle="modal" data-target="#editoutlet" class="btn btn-simple btn-warning btn-icon edit outlet_edit" value="{{ $GetOutlet->id }}" href=""><i class="fa fa-pencil-square-o"></i></a>-->
											
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<div id="editoutlet" class="modal fade" role="dialog">
          <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
          <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Outlet</h4>
          </div>
          <div class="modal-body">
               <div class="row">
                 <form  action="{{ route('update.outlet') }}" id="EditOutlet" method="post">
						{{ csrf_field() }}
						
		              <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Outlet Name
                              <small>*</small>
                              </label>
                              <input class="txt_box  emptyspace"  name="outletname" id="Out_name" type="text" />
                           </div>
                        </div>
                    
					
						<div class="col-md-6">
							<div class="form-group label-floating">
							  <label class="control-label">
								Address
							  <small>*</small>
							  </label>
							  <input class="txt_box  emptyspace"  name="address" id="Out_address" type="text" />
						   </div>
						</div>
					    <div class="clearfix"></div>
					     
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Latitude
                              <small>*</small>
                              </label>
                              <input class="txt_box  numbersnot emptyspace numbersOnly" name="latitude" id="Out_latitude" type="text" />
                           </div>
						   <input type='hidden' id='out_id' name="id" >
                        </div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Longitude
                              <small>*</small>
                              </label>
                              <input class="txt_box  numbersnot emptyspace numbersOnly" name="longitude" id="Out_longitude" type="text" />
                           </div>
                        </div>
						 
						<div class="clearfix"></div>
						<div class="col-md-6">
						<button class="btn btn-primary">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
						
                    
                  </form>
               </div>
          </div>

          </div>
          </div>
          </div>

		  <script>
		  
  
		  $(document).ready(function(){
		$(".delete_outlet").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"{{route('delete.outlet')}}?id="+id);
        });

        });
		  </script>
  

@endsection