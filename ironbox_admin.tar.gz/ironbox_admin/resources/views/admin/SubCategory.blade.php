@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Add clothes</h4>
					</div>
					<div class="card-content">
						<form  action="{{ route('savesub.category') }}" method="post" id="addsubcategoty" enctype="multipart/form-data">
					     {{ csrf_field() }}
						   <div class="col-md-6">
							 <div class="form-group label-floating">
								
								<select  class="form-control" id="MainCategory" name="MainCategory">
									<option value="">Select Category</option>
									@foreach($Category as $CategoryList)
									
                                      <option value="{{ $CategoryList->id }}"> {{ $CategoryList->name }} </option>
									@endforeach
								</select>
							 </div>
						   </div>
						   
						   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Name
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="name" id="name" type="text" />
                            </div>

                          </div>
						  <div class="clearfix"></div>
						  <div class="col-md-6">
                           
                              <label class="">
                                Image
                              <small>*</small>
                              </label>
                              <input class=""  name="image" id="image" type="file" />
                           

                          </div>
						  
						  <div class="col-md-6">
						 <div class="form-group label-floating">
							
							<select  class="form-control" id="groupname" name="groupname">
								<option value="">Select Group name</option>
							</select>
						 </div>
					   </div>
						  
						  <div class="clearfix"></div>
						<button class="btn btn-primary">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						   
						 </form>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Clothes list</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>GroupName</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>GroupName</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($ItemsList as $List)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $List->name }}</td>
										<td>{{ $List->groupName }}</td>
                                        

										<td class="text-right">
											<a  onclick="return confirm('Are you sure you want to delete clothes');" class="delete_sub_cate" href="{{route('delete.sub.cate')}}?id={{$List->id}}" data-toggle="tooltip" data-original-title="Delete"> <i class="fa fa-trash"></i></a>
											<a href="{{ route('edit.items.category',[$List->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-pencil-square-o"></i></a>
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</div>
</div>


		  <script>
		  
$(function () {


});
		  
		  $(document).ready(function(){
		$(".delete_sub_cate").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"{{route('delete.pin')}}?id="+id);
        });

        });
		  </script>




@endsection