@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Add Time Slot </h4>
				</div>
				<div class="card-content">
				   <form  action="{{ route('add.slot') }}" method="post" id="TimeSlot" enctype="multipart/form-data">
					   {{ csrf_field() }}
					   
					   
					   <div class="col-md-6">
					   <div class="datetimepicker" class="input-append">
					   <label class="control-label">
						From slot
					  <small>*</small>
					  </label>
						<input data-format="hh:mm:ss" type="text" class="txt_box emptyspace" name="Fslot"></input>
						<span class="add-on">
						  <i data-time-icon="icon-time" data-date-icon="icon-calendar">
						  </i>
						</span>
					  </div>
                     <!-- <div class="form-group label-floating">
					  <label class="control-label">
						From slot
					  <small>*</small>
					  </label>
					  <input class="txt_box without_ampm" name="Fslot" type="text" data-timepicker />
				   </div>-->
                    </div>
					
					<div class="col-md-6">
					
					<div class="datetimepicker" class="input-append">
					   <label class="control-label">
						To slot
					  <small>*</small>
					  </label>
						<input data-format="hh:mm:ss" type="text" class="txt_box emptyspace" name="Tslot"></input>
						<span class="add-on">
						  <i data-time-icon="icon-time" data-date-icon="icon-calendar">
						  </i>
						</span>
					  </div>
					<!--<div class="form-group label-floating">
					  <label class="control-label">
						To slot
					  <small>*</small>
					  </label>
					  <input class="txt_box without_ampm" name="Tslot" type="text" data-timepicker />
				   </div>-->
                       
                    </div>
					     
						<div class="clearfix"></div>
						<div class="col-md-6">
						<button class="btn btn-primary" id="pin_btn">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>
	
	
	
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Time Slots</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>From slot </th>
										<th>To slot</th>
										<th>TimeSlot</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>From slot </th>
										<th>To slot</th>
										<th>TimeSlot</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($slot as $TimeSlot)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $TimeSlot->fromSlots }}</td>
										<td>{{ $TimeSlot->toSlots }}</td>
										<td>{{ $TimeSlot->TimeSlot }}</td>
                                        

										<td class="text-right">
											<a  data-toggle="modal" data-target="#editslot" class="btn btn-simple btn-warning btn-icon edit slot_edit" value="{{ $TimeSlot->id }}" href="" id=""><i class="fa fa-pencil-square-o"></i></a>
											
											<a  onclick="return confirm('Are you sure you want to delete pincode');" class="delete_Slot" href="{{route('delete.timeslot')}}?id={{$TimeSlot->id}}"> <i class="fa fa-trash"></i></a>
											
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<div id="editslot" class="modal fade" role="dialog">
          <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
          <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Time Slot</h4>
          </div>
          <div class="modal-body">
               <div class="row">
                 <form  action="{{ route('update.slot') }}" id="EditSlot" method="post">
						{{ csrf_field() }}
						
		
						
                    <div class="col-md-6">
                      <div class="form-group label-floating">
					  <label class="control-label">
						From slot
					  <small>*</small>
					  </label>
					  <input class="txt_box without_ampm" name="Fslot" id="Efromslot" type="text" />
				   </div>
                    </div>
					
					<div class="col-md-6">
                      <div class="form-group label-floating">
					  <label class="control-label">
						To slot
					  <small>*</small>
					  </label>
					  <input class="txt_box without_ampm" name="Tslot" id="Etoslot" type="text" />
					  
					  <input type="hidden" id="Eslotid" name="id">
					  
				   </div>
				
                    </div>
					
                    <div class="clearfix"></div>
					
					
                    <button class="btn btn-primary" id="pin_btn1">
                       Submit
                       <div class="ripple-container"></div>
                    </button>
                  </form>
               </div>
          </div>

          </div>
          </div>
          </div>


  
		  <script>
		  
$(function () {


});
		  
		  $(document).ready(function(){
		$(".delete_Slot").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"{{route('delete.timeslot')}}?id="+id);
        });

        });
		  </script>
@endsection