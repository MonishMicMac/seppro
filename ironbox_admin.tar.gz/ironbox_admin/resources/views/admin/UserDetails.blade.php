@extends('layouts.layouts')

@section('content')

<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	  <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
				@foreach($GetUserDetails as $UserDetails)
					<h4 class="title">{{ $UserDetails->name }}</h4>
				@endforeach	
				</div>
				
				<div class="card-content">
				  @foreach($GetUserDetails as $UserDetails)
				  <div class="box_shadow box_shadow2">
				  <h4 class="yellowtext">User Details</h4>
				   <div class="row">
                    <div class="col-md-6">
                        <div class="user_profile">
						   <img src=" <?php if($UserDetails->image == null){ echo "http://139.59.37.241/Ironman/public/images/pic.png"; }else{ echo $UserDetails->image; } ?>" class="img-responsive  img-circle">
						    
						</div>
                     
 
                     
					  
					    <div class="urdetails">
						   <strong>Name :</strong> {{ $UserDetails->name }}
						</div>
						
						<div class="urdetails">
						   <strong>Mobile :</strong> {{ $UserDetails->mobile }}
						</div>
						
						<div class="urdetails">
						   <strong>Email :</strong> {{ $UserDetails->email }}
						</div>
						
						<div class="urdetails">
						   <strong>DOB :</strong> {{ $UserDetails->dob }}
						</div>
					  
					 </div>
					 
					 <div class="col-md-3">
					    <div class="urdetails">
						   <strong>Gender :</strong> {{ $UserDetails->gender }}
						</div>
						
						 <div class="urdetails">
						   <strong>Referral Code :</strong> {{ $UserDetails->referral_code }}
						</div>
						
						<div class="urdetails">
						   <strong>Wallet amount :</strong>Rs.{{ $UserDetails->wallet_amount }}
						</div>
						
						<div class="urdetails">
						   <strong>Joining  date :</strong> {{ $UserDetails->join_date}}
						</div>
					 </div>
					 
					  @foreach($order as $ord)
					 <div class="col-md-3">
					    <div class="urdetails">
						   <strong>Total orders :</strong> {{ $ord->total }}
						</div>
						<div class="urdetails">
						   <strong>Completed orders :</strong>{{ $ord->complete }}
						</div>
						 <div class="urdetails">
						   <strong>Pending orders :</strong> {{ $ord->pending }}
						</div>
						<div class="urdetails">
						   <strong>Cancelled  orders :</strong> {{ $ord->cancel }}
						</div>
					 </div>
					  @endforeach 
				   </div>
				   </div>
				@endforeach
				<div class="box_shadow box_shadow6 mt20">
				<h4 class="skybluetext">User Address</h4>
				<div class="row">
				      <div class="col-md-12">
					   
					      <div id="mixedSlider" class="exampleSlider">
                    <div class="MS-content">
					
					  @foreach($Address as $UserAddr)
                        <div class="item">
                           <p><strong>Type</strong> : {{ $UserAddr->title }}</p>
                            <p><strong>flatNo</strong> : {{ $UserAddr->flatNo }}</p>
                            <p><strong>Landmark</strong> : {{ $UserAddr->landmark }}</p>
                            <p><strong>Address</strong> : {{ $UserAddr->address }}</p>
                            
                        </div>
						
						@endforeach

                    </div>
                    <div class="MS-controls">
                        <button class="MS-left"><i class="fa fa-angle-left" aria-hidden="true"></i></button>
                        <button class="MS-right"><i class="fa fa-angle-right" aria-hidden="true"></i></button>
                    </div>
                </div>
					  </div>
				</div>
				</div>
				
				  <a href="{{ url('UserBookingDown/' . 1 . '') }}" class="btn btn-primary btn-r6"> 
						   Download report
						   <div class="ripple-container"></div>
						</a>
				  <div class="row" style="margin-top:40px;">
				      <div class="col-md-12">
					     <div class="card-header" data-background-color="blue">
								<h4 class="title">Booking List</h4>
							</div>
					     <div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($BookingsList as $BookingsDetails)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $BookingsDetails->bookingId }}</td>
										<td>{{ $BookingsDetails->bookingDate }}</td>
										<td>{{ $BookingsDetails->fromSlots }} -  {{ $BookingsDetails->toSlots }}</td>
										<td>{{ $BookingsDetails->Status }}</td>


										<td class="text-right">
											<a href="{{ route('view.bookings',[$BookingsDetails->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
							</table>
						</div>
					  </div>
				  </div>
				
				
				</div>
				
	      </div>
	    </div>
	  </div>
    </div>
</div>


<script>
        $(document).ready(function () {
            $('.nav-active').addClass('active');
        });
</script>

@endsection