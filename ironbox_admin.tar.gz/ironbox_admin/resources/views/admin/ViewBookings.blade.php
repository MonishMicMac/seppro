@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
<?php if(count($GetOrders) > 0 ){?>
 @foreach($Bookings as $Book)
 @if($Book->Status == 'CONFIRMED')
<a href="{{ url('EditOrders/' . $Book->id . '') }}" class="btn btn-primary btn-rit"> 
						   Edit Bookings
						   <div class="ripple-container"></div>
						</a>
						@endif
						@endforeach
<?php } ?>
               <div class="container-fluid">
                  <div class="row">
                     <div class="col-lg-12 col-md-12">
                        <div class="card">
                           <div class="card-header" data-background-color="blue">
                              <h4 class="title">View Booking Details</h4>
                           </div>
                           <div class="card-content">
                              <div class="row">
							  @foreach($Bookings as $Book)
                                <a href="{{ url('UserDetails/' . $Book->userId . '') }}" class="bl0"> 
								  <div class="col-md-4 ht250">
                                    <div class="box_shadow box_shadow1">
                                       <h4 class="greentext">User Details</h4>
                                       <div class="urdetails">
                                          <strong>Name :</strong> {{ $Book->username }}
                                       </div>
                                       <div class="urdetails">
                                          <strong>Email :</strong> {{ $Book->useremail }}
                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong> {{ $Book->usermobile }}
                                       </div>
                                       <div class="urdetails">
                                          <strong>Alternate :</strong> {{ $Book->user_al_number }}
                                       </div>
                                    </div>
                                 </div></a>
								
                                 <div class="col-md-8 ht250">
                                    <div class="box_shadow box_shadow2">
                                       <h4 class="yellowtext">Bookings Details</h4>
                                       <div class="right_box">
                                          <div class="urdetails">
                                             <strong>BookingId :</strong> {{ $Book->bookingId }}
                                          </div>
										  
                                          <div class="urdetails">
                                             <strong>Pickup date :</strong> {{ $Book->bookingDate }}
                                          </div>
                                          <div class="urdetails">
                                             <strong>TimeSlot :</strong> {{ $Book->fromSlots }} - {{ $Book->toSlots }}
                                          </div>
										  <div class="urdetails">
                                             <strong>Payment type :</strong> {{ $Book->paymentType }}
                                          </div>
                                          <div class="urdetails">
                                             <strong>Promocode :</strong>  {{ $Book->promocode }}
                                          </div>
                                       </div>
                                       <div class="left_box">
                                          <div class="urdetails">
                                             <strong>Flat No :</strong> {{ $Book->flatNo }}
                                          </div>
                                          <div class="urdetails">
                                             <strong>Landmark :</strong> {{ $Book->landmark }}
                                          </div>
                                          <div class="urdetails">
                                             <strong>Address :</strong> {{ $Book->address }}
                                          </div>
                                       </div>
                                    </div>
                                 </div>
								 
                              </div>
                              <hr>
                              <div class="row">
                                 <div class="col-md-4 ht300">
                                    <div class="box_shadow box_shadow3">
									 <a href="{{ url('EditPickupUser/' . $Book->pickupDeliveryUserId . '') }}" class="bl0"> 
                                       <h4 class="redtext">PickupMan Details</h4>
                                       <div class="urdetails">
                                          <strong>Name :</strong> {{ $Book->pickupusers }}
                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong> {{ $Book->pick_us_mobile }}
                                       </div>
									   </a>
									   @foreach($Deliveyuser as $DeliveryMan)
									    <a href="{{ url('EditPickupUser/' . $DeliveryMan->DeliveryUserId . '') }}" class="bl0"> 
                                       <h4 class="redtext">DeliveryMan Details</h4>

                                       <div class="urdetails">
                                          <strong>Name :</strong> {{ $DeliveryMan->name }}
                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong> {{ $DeliveryMan->mobile }}
                                       </div>
									   </a>
									   @endforeach 
                                    </div>
                                 </div>
								  
								  @foreach($Ironing as $IroningVendor)
                                 <div class="col-md-3 ht300">
                                    <div class="box_shadow box_shadow4">
									<a href="{{ url('VendorDetails/' . $IroningVendor->VendorUserId . '') }}" class="bl0"> 
                                       <h4 class="bluetext">Ironing Vendor</h4>
                                       <div class="urdetails">
                                          <strong>Name :</strong>{{ $IroningVendor->name }}
                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong>{{ $IroningVendor->mobile }}
                                       </div>
									   <div class="urdetails">
                                          <strong>Start date / time :</strong>{{ $Book->work_date }}, {{ $Book->work_time }}
                                       </div>
									   <div class="urdetails">
                                          <strong>End date / time :</strong>{{ $Book->wr_end_date }}, {{ $Book->wr_end_time }}
                                       </div>
									   </a>
                                    </div>
                                 </div>
								@endforeach
								<?php if(count($GetOrders) > 0 ){?>
                                 <div class="col-md-5 ht300">
                                    <div class="box_shadow box_shadow5">
                                       <h4 class="purpletext">Booking Items</h4>
									  
                                       <div class="table-responsive tblebook">
                                            <table class="booktable" style="width:100%">
                                                <thead>
                                                 <tr>
                                                    <th>S.no</th>
                                                    <th>Category</th>
                                                    <th>Name</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                 </tr>
                                                 </thead>
                                                 <tbody>
												 <?php $count = 1; ?>
												@foreach($GetOrders as $Orders)
                                                 <tr>
                                                     <td>{{ $count++ }}</td>
													<td>{{ $Orders->groupName }}</td>
													<td>{{ $Orders->name }}</td>
													<td>{{ $Orders->quantity }}</td>
													<td>{{ $Orders->amount }}</td>
                                                 </tr>
												  @endforeach
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Total</td>
												
													
													<td>Rs.<?php if($Book->first_offer == 1){ echo $Book->totalPayment +50; }else{ echo $Book->totalPayment + $Book->discount_amount;} ?></td>    
                                                 </tr>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Discount</td>
													<td>Rs.{{ $Book->discount_amount }}</td>
                                                 </tr>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Grand total</td>
                                                    <td>Rs.<?php if($Book->first_offer == 1){  
													echo $Book->totalPayment;
													}else{ 
													echo $Book->totalPayment + $Book->discount_amount - $Book->discount_amount; 
													}?></td>
                                                 </tr>
                                              </tbody>
                                           </table>
                                       </div>
                                       
                                    </div>
                                 </div>
								 
								 <?php } ?>
                              </div>
                              <div class="row top-pad">
                                 <div class="col-md-12">
                                    <div class="box_shadow box_shadow6 mt20">
                                       <h4 class="skybluetext">Order Status</h4>
                                       <table style="width:100%" class="ta4">
                                          <tbody>
                                             <tr>
                                                <th>Booked on</th>
                                                <th>On the way to pickup</th>
                                                <th>Pickup success</th>
                                                <th>On the way to delivery</th>
                                                <th>Delivery success</th>
                                                <th>Bill Image</th>
                                                <th>Cancelled</th>
                                             </tr>
                                             <tr>
                                                <td> @if($Book->ConfirmOrder == 1) Yes @else No @endif</td>
												<td>@if($Book->WaytoPickup == 1) Yes @else No @endif</td>
												<td>@if($Book->PickupSuccess == 1) Yes @else No @endif</td>
												<td>@if($Book->WaytoDelivery == 1) Yes @else No @endif</td>
                        <td>@if($Book->DeliverySuccess == 1) Yes @else No @endif</td>	
                        <td rowspan="2">@if(!$Book->bill_image) Not Available @else <img src="{{ $Book->bill_image }}" style="width: 150px;height: 50px;"> @endif</td>
												<td>@if($Book->reasons == null) No @else Yes @endif</td>
                                             </tr>
                                             <tr>
                                                <td>{{ $Book->order_date }} <br> {{ $Book->order_time }}</td>
												<td>{{ $Book->WaytoPick_date }} <br> {{ $Book->WaytoPick_time }}</td>
												<td>{{ $Book->pick_date }} <br> {{ $Book->pick_time }}</td>
												<td>{{ $Book->Waytodeliv_date }} <br> {{ $Book->Waytodeliv_time }}</td>
												<td>{{ $Book->delivery_date }} <br> {{ $Book->delivery_time }}</td>
												<td>{{ $Book->cancel_date }} <br> {{ $Book->cancel_time }}</td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                 </div>
                              </div>
							  @endforeach
							  
							  <?php if(count($Rating) > 0){ ?>
							  
							  <div class="row">
                                 <div class="col-md-12">
                                    <div class="box_shadow box_shadow6 mt20">
                                       <h4 class="skybluetext">Ratings</h4>
									     <table style="width:100%" class="ta4">
                                          <tbody>
                                             <tr>
                                                <th>Pickup</th>
                                                <th>Service</th>
                                                <th>Delivery</th>
                                                <th>Comments</th>
                                             </tr>
											 
											 @foreach($Rating as $Rate)
											   <td>{{ $Rate->forPickup }}</td>
											   <td>{{ $Rate->forService }}</td>
											   <td>{{ $Rate->forDelivery }}</td>
											   <td>{{ $Rate->comments }}</td>

											 
											 @endforeach
											 
										</tbody>
									   </table>
							      </div>
							    </div>
							  </div>
							  
							  <?php  } ?>
							  
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
			
			<script type="text/javascript">
    $(document).ready(function() {
		$('.active-order').addClass('active');

    });
</script>

@endsection