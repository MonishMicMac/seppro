@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">View complients</h4>
				</div>
				<div class="card-content">
				
				
				   <div class="row">
				     <div class="complient ht">
                                    <div class="box_shadow box_shadow2">
                                       <h4 class="yellowtext">Complients Details</h4>
                                       <div class="right_box">
									    @foreach($Support as $View)
                                          <div class="urdetails">
                                             <strong>ComplientId :</strong> {{ $View->complaint_id }}
                                          </div>
                                          <div class="urdetails">
                                             <strong>Name :</strong> {{ $View->name }}
                                          </div>
                                          <div class="urdetails">
                                             <strong>Mobile :</strong> {{ $View->mobile }}
                                          </div>
										  <div class="urdetails">
                                             <strong>Complients type:</strong>  {{ $View->complaints_type }}
                                          </div>
										  <div class="urdetails">
                                             <strong>Complients date:</strong>  {{ $View->comp_date }}
                                          </div>
                                          <div class="urdetails">
                                             <strong>Comments :</strong>  {{ $View->Comments }}
                                          </div>
										  
										  <form  action="{{ route('update.complient') }}" method="post"  enctype="multipart/form-data">
					   {{ csrf_field() }}
										  
										  <label class="switch">
  <input type="checkbox" name="active_user1" <?php if($View->Is_open == 1){  echo "checked"; } ?> value="{{ $View->Is_open }}">
  <span class="slider round"></span>
</label> 

<div class="clearfix"></div>

<input type="hidden" name="complaint_id" value="{{ $View->id }}">
<input type="hidden" name="Is_open" value="{{ $View->Is_open }}">

<div class="col-md-12 center">

<button class="btn btn-primary" id="pin_btn">
						   Submit
						   <div class="ripple-container"></div>
						</button>
</div>

</form>
										  
										  
										 @endforeach 
                                       </div>
                                      
                                    </div>
                                 </div>
				   
				   </div>
				    
					   
					   
					  
					 
				</div>
			</div>
		</div>		
	</div>
	

	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		$('.active-support').addClass('active');

    });
</script>
  
	
@endsection