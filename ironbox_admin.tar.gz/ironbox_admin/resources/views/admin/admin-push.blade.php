@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Notifications</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					 
                                <form  action="{{ route('admin.sent.push') }}" method="post" id="adminpush" enctype="multipart/form-data">
								   {{ csrf_field() }}
								  <div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Title
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace" name="title" id="title" type="text" />
									   </div>
									</div> 
									
									<div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Message
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace" name="body" id="body" type="text" />
									   </div>
									</div> 
									<div class="clearfix"></div>
									<div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Description
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace" name="message" id="message" type="text" />
									   </div>
									</div> 
									
									<div class="clearfix"></div>
									<div class="col-md-12">
									<button class="btn btn-primary" id="pin_btn">
									   Submit
									   <div class="ripple-container"></div>
									</button>
									</div>
								 </form>		   
					           </div>
							   
							   
							   <div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Notifications List</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Title</th>
										<th>Message</th>
										<th>Description</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Title</th>
										<th>Message</th>
										<th>Description</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($push as $data)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $data->title }}</td>
										<td>{{ $data->body }}</td>
										<td>{{ $data->message }}</td>


										
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
					   
					 
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


@endsection