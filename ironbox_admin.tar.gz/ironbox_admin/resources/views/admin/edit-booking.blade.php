@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
<a  href="javascript:void(0);" id="printPage" class="btn btn-primary btn-rit">Print<div class="ripple-container"></div></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Edit bookings</h4>
					</div>
					<div class="card-content">
					<div class="row" id="your_content">
							  @foreach($Bookings as $Book)
                                <a href="{{ url('UserDetails/' . $Book->userId . '') }}" class="bl0"> 
								  <div class="col-md-4 ht250">
                                    <div class="box_shadow box_shadow1">
                                       <h4 class="greentext">User Details</h4>
									    <div class="urdetails">
                                             <strong>BookingId :</strong> {{ $Book->bookingId }}
                                         </div>
                                       <div class="urdetails">
                                          <strong>Name :</strong> {{ $Book->username }}
                                       </div>
                                       <div class="urdetails">
                                          <strong>Email :</strong> {{ $Book->useremail }}
                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong> {{ $Book->usermobile }}
                                       </div>
                                       <div class="urdetails">
                                          <strong>Alternate :</strong> {{ $Book->user_al_number }}
                                       </div>
									   <div class="urdetails">
                                             <strong>Pickup date :</strong> {{ $Book->bookingDate }}
                                          </div>
                                          <div class="urdetails">
                                             <strong>TimeSlot :</strong> {{ $Book->fromSlots }} - {{ $Book->toSlots }}
                                          </div>
                                    </div>
                                 </div></a>
								
                                 <div class="col-md-8 ht250" >
                                    <div class="box_shadow box_shadow2">
                                       <h4 class="yellowtext">Bookings Details</h4>
                                        <table class="booktable" style="width:100%">
                                                <thead>
                                                 <tr>
                                                    <th>S.no</th>
                                                    <th>Category</th>
                                                    <th>Name</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                 </tr>
                                                 </thead>
                                                 <tbody>
												 <?php $count = 1; ?>
												@foreach($GetOrder as $Orders)
                                                 <tr>
                                                     <td>{{ $count++ }}</td>
													<td>{{ $Orders->groupName }}</td>
													<td>{{ $Orders->name }}</td>
													<td>{{ $Orders->quantity }}</td>
													<td>{{ $Orders->amount }}</td>
                                                 </tr>
												  @endforeach
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Total Amount</td>
													<td>Rs.{{ $Book->totalPayment + $Book->discount_amount }}</td>
                                                 </tr>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Discount Amount</td>
													<td>Rs.{{ $Book->discount_amount }}</td>
                                                 </tr>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Grand total</td>
                                                    <td>Rs.<?php echo $Book->totalPayment + $Book->discount_amount - $Book->discount_amount; ?></td>
                                                 </tr>
                                              </tbody>
                                           </table>
                                    </div>
                                 </div>
								 
                              </div>
							 
					
                       <div class="row">
					 
						<form  action="{{ route('update.Bookings') }}" method="post" id="updateBookings" enctype="multipart/form-data">
						   {{ csrf_field() }}
						   
						   <div class="row pad20">
							  <div class="col-md-12 ">
							  <div class="box_shadow box_shadow6">
							   <h4 class="skybluetext">Orders</h4>
							  <div class="tab_border">
								 <table class="table2 test" style="width:100%">
									<thead>
								 <tr>
								 <th> <button type="button"  class="btn btn-danger delete" ><i class="fa fa-trash-o" aria-hidden="true"></button></th>
								   <th class="text-center">Clothes</th>
								   <th class="text-center">Quantity</th>
								   <th></th>
								   <th><button type="button"  class="btn btn-primary addmore"><i class="fa fa-plus" aria-hidden="true"></i></button></th>
								 </tr>
							   </thead>
							    <input type="hidden" name="bookingId" value="{{ $Book->id }}">
							   <tbody class="detail">
								@foreach($GetOrder as $order)
							   <tr>
							   <td><input class="case remove_check" type="checkbox"/></td>
								   <td>
								<select class="form-control valid1" name="clothes[]" required="true">
									<option value="">Select Clothes</option>
										 @foreach($Clothes as $cloth)
										 <option value="{{ $cloth->id }}" @if($order->categoryId == $cloth->id)  selected @endif  > {{ $cloth->groupName }} / {{ $cloth->name }}</option>
										 @endforeach  
									 </select>
									  </td>
									  <td>
										<input type="text" class="form-control numbersnot emptyspace numbersOnly" name="qty[]" required="true" placeholder="Quantity" value="{{ $order->quantity }}" style="margin-left: 11px;">
								   </td>
									  <td></td>
								   </tr>
								  
 								   @endforeach
							   </tbody>
							 </table>
							  </div>
							  </div>
							  </div>
						   </div>
						    <div class="clearfix"></div>
									<div class="col-md-12">
									<div class="center">
									<button class="btn btn-primary" id="pin_btn">
									   Submit
									   <div class="ripple-container"></div>
									</button>
									</div>
									</div>
						 </form>
						  @endforeach
				   
					   </div>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<script>

$('.active-order').addClass('active');

var i=$('table tr').length;
$(".addmore").click(function(e){
      var table = $('.table2');
    var rows = table.find('tr');
    var error = 0;

    for (i = 0; i < rows.length; i++) {
      var cell = rows.eq(i).find('td');
      for (a = 0; a < cell.length; a++) {
        var input = cell.eq(a).find(':input');

        if (input.val() === "") {
          input.css("border", "solid 1px red");
          error++;
        } else {
          input.css("border", "solid 1px rgb(169, 169, 169)");
        }
      }
    }

    if (error > 0){
      return false;
    } else {
	    $(".test").append("<tr><td><input class='case remove_check' type='checkbox'/></td><td><select class='form-control'  name='clothes[]'><option value=''>Select clothes</option> @foreach ($Clothes as $cloth)<option value='{{ $cloth->id }}'>{{ $cloth->groupName }} / {{ $cloth->name }}</option>@endforeach</select></td><td> <input class='emptyspace form-control' type='text' name='qty[]' required='true' placeholder='Quantity' style='margin-left: 11px;' ></td><td></td></tr>");
	}
	});


	//deletes the selected table rows
$(".delete").on('click', function() {
	$('.case:checkbox:checked').parents("tr").remove();
	$('#check_all').prop("checked", false);
	var count=$('.table2 tbody tr').length;
	if(count<=0){
		$('.addmore').click();
		}
	calculateTotal();
});


</script>
 <script lang='javascript'>
 $(document).ready(function(){
  $('#printPage').click(function(){
        var data ='<link rel="stylesheet" href="http://127.0.0.1:8000/css/bootstrap.min.css" type="text/css" />';           
        data += '<link rel="stylesheet" href="http://127.0.0.1:8000/css/material-dashboard.css" type="text/css" />';           
        data += '<link rel="stylesheet" href="http://127.0.0.1:8000/css/material-dashboard.css" type="text/css" />';           
        data += '<div id="div_print">';
        data += $('#your_content').html();
        data += '</div>';
        data +='<a  href="" id="printPage" class="btn btn-primary btn-rit" onclick="window.print()">Print<div class="ripple-container"></div></a>';

        myWindow=window.open();
        myWindow.innerWidth = screen.width;
        myWindow.innerHeight = screen.height;
        myWindow.screenX = 0;
        myWindow.screenY = 0;
        myWindow.document.write(data);
        myWindow.focus();
    });
 });
 </script>



@endsection