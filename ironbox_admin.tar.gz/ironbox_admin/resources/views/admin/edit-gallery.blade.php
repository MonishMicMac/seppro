@extends('layouts.layouts')
@section('content')


<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Gallery</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					 
                                <form  action="{{ route('upadte.gallery') }}" method="post" id="editgallery" enctype="multipart/form-data">
								   {{ csrf_field() }}
								   @foreach($gallery as $photo)
								  <div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Image title
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace" name="title" id="title" value="{{ $photo->title }}" type="text" />
										  
										  
									   </div>
									</div> 
									  <input name="id" id="id" value="{{ $photo->id }}" type="hidden" />
									<div class="col-md-6">
                           
									  <label class="">
										Image
									  <small>*</small>
									  </label>
									  <input  name="image" id="image" type="file" value="{{ $photo->title }}" />
								   @endforeach

								  </div>
									<div class="clearfix"></div>
									
									<div class="clearfix"></div>
									<div class="col-md-12">
									<button class="btn btn-primary" id="pin_btn">
									   Submit
									   <div class="ripple-container"></div>
									</button>
									</div>
								 </form>
                         					   
					   </div>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>


@endsection