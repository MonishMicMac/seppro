@extends('layouts.layouts')

@section('content')


<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Edit Service Area</h4>
				</div>
				<div class="card-content">
				   <form  action="{{ route('update.pincode.area') }}" method="post" id="servicearea" enctype="multipart/form-data">
					   {{ csrf_field() }}
					    @foreach($pincode as $data)
					   <div class="col-md-6">
						 <div class="form-group label-floating">
							
							<select  class="form-control" id="warehousename" name="warehousename">
							<option value="">Select warehouse</option>
							  @foreach($outlet as $Out)
								<option value="{{ $Out->id }}" @if($Out->id == $data->warehouseId) Selected @endif>{{ $Out->name }}</option>
                              @endforeach
							</select>
						 </div>
					   </div>
					   
					   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Pincode
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" maxlength ="6" name="pincode" id="Epincode" type="text" value="{{ $data->code }}" />
                           </div>
						   <div id="Epin_valid"></div>
						   <input type='hidden' name="id" value=" {{ $data->id }}"/>
                        </div>
						
						<div class="clearfix"></div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Areaname
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="areaname" id="areaname" type="text" value="{{ $data->area }}"/>
                           </div>
                        </div>
					      @endforeach
						<div class="clearfix"></div>
						<div class="col-md-12">
						<button class="btn btn-primary" id="pin_btn1">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>		
	</div>
</div>




		  
		  
		  


@endsection