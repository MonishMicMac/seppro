@extends('layouts.layouts')
@section('content')


<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Gallery</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					 
                                <form  action="{{ route('add.gallery.image') }}" method="post" id="addImages" enctype="multipart/form-data">
								   {{ csrf_field() }}
								  <div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Image title
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace" name="title" id="title" type="text" />
									   </div>
									</div> 
									
									<div class="col-md-6">
                           
									  <label class="">
										Image
									  <small>*</small>
									  </label>
									  <input class=""  name="image" id="image" type="file" />
								   

								  </div>
									<div class="clearfix"></div>
									
									<div class="clearfix"></div>
									<div class="col-md-12">
									<button class="btn btn-primary" id="pin_btn">
									   Submit
									   <div class="ripple-container"></div>
									</button>
									</div>
								 </form>
                         					   
					   </div>
					   
					   
					   <div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Categories List</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Title</th>
										<th>Image</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Title</th>
										<th>Image</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($gallery as $photo)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $photo->title }}</td>
										<td>  <img src="{{ $photo->images }}" class="table_img" style="height:57px; width:75px;"></td>
										<td class="text-right">
											
											<a href="{{ route('edit.gallery',[$photo->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-pencil-square-o"></i></a>
											
											<a  onclick="return confirm('Are you sure you want to delete image');" class="del_image" href="{{route('delete.gal.image')}}?id={{$photo->id}}" data-toggle="tooltip" data-original-title="Delete"> <i class="fa fa-trash"></i></a>
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


	  <script>
		  
$(function () {


});
		  
		  $(document).ready(function(){
		$(".del_image").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"{{route('delete.gal.image')}}?id="+id);
        });

        });
		  </script>
@endsection