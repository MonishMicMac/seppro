@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Assing pickup / delivery person</h4>
				</div>
				<div class="card-content">
	
				   <div class="box_shadow box_shadow2">
				       <h4 class="yellowtext">Assign pickup</h4>
				        <form  action="{{ route('assign.pending.update') }}" method="post" id="UpdatePickup" enctype="multipart/form-data">
					   {{ csrf_field() }}

                        <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label>
                                Pickup Users
                              </label>
                               <select class="select_box_2" id="pickup_user" name="pickup_user">
								    <option value="">Select pick person</option>
									@foreach($User as $PickupUser)
									<option value="{{ $PickupUser->id }}">{{ $PickupUser->name }}</option>
									@endforeach
								</select>
								
                           </div>
						   Check all: <input type="checkbox" class="checkAllbox"  id="checkall">
                        </div>
						
						<div class="col-md-6">
						       <label class="lb2">
                                Comments
                              </label>
                           <textarea rows="4" cols="50" name="comments"></textarea>
                        </div>
                    
						 
						<div class="clearfix"></div>
						<div class="row" style="margin-top:30px;">
						  <div class="col-md-12">
						  <div class="card">
						        <div class="card-content">
								<div class="card-header" data-background-color="blue">
							  <h5 class="title col3">Pickup orders</h5>
						   </div>
						<div class="material-datatables">
						   
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
									    <th></th>
										<th>S.No</th>
										<th>BookingId </th>
										<th>Booking Date</th>
										<th>Name</th>
										<th>Order for</th>
										<th>Status</th>
										<th>Mobile</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th></th>
										<th>S.No</th>
										<th>BookingId </th>
										<th>Booking Date</th>
										<th>Name</th>
										<th>Order for</th>
										<th>Status</th>
										<th>Mobile</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($Bookings as $GetBookings)
									<tr>
										<td><input type="checkbox" class="checked5 checkedboxclick" name="bookingId[]" value="{{ $GetBookings->id }}"></td>
										<td>{{$count++}}</td>
										<td>{{ $GetBookings->bookingId }}</td>
										<td>{{ $GetBookings->bookingDate }}</td>
										<td>{{ $GetBookings->name }}</td>
										<td>{{ $GetBookings->order_for }}</td>
										<td>{{ $GetBookings->Status }}</td>
										<td>{{ $GetBookings->mobile }}</td>
                                        
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
					<div class="col-md-6">
						<button class="btn btn-primary" id="assign_btn" style="display:none">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					</div>
					</div>
						  </div>
						  
					 </form>
						</div>
						
	
						
						
						
				   </div>
				   
				</div>
			</div>
		</div>		
	</div>
	
	
	
		
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		$('.active-pickup').addClass('active');

    });
</script>
@endsection