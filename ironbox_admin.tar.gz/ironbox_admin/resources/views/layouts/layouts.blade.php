<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>IronBox</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <!-- Bootstrap core CSS     -->
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
	
    <link href="{{ asset('css/demo.css') }}" rel="stylesheet" />
    <!--  Material Dashboard CSS    -->
    <link href="{{ asset('css/material-dashboard.css') }}" rel="stylesheet" />
    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<script src="{{ asset('js/d3.js') }}" type="text/javascript"></script>
    <script src="{{ asset('js/d3pie.js') }}" type="text/javascript"></script>
</head>
<body>
  <div class="wrapper">
     <div class="sidebar" data-active-color="blue" data-background-color="white">
            <div class="logo">
                <a href="{{ route('admin.dashboard') }}" class="simple-text">
                    <img src="{{ asset('images/ironbox.png') }}" alt="" class="responsive-img ironbox_logo">
					<span>IronBox</span>
					
                </a>
				<span class="login_user">{{ Auth::User()->roles }}</span>
            </div>
            <div class="sidebar-wrapper">
			
	
			
                <ul class="nav">
                    <li class="{{ Request::path() == 'admin' ? 'active' : '' }}">
                        <a href="{{ route('admin.dashboard') }}">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
					
					
					<li class="{{ Request::path() == 'Categories' ? 'active' : '' }}">
                        <a data-toggle="collapse" href="#Categories" class="collapsed" aria-expanded="false">
                            <!--<i class="fa fa-tags" aria-hidden="true"></i>-->
							<img src="{{ asset('images/menu/Categories.png') }}" class="menu_icon">
                            <p class="menu_text">Add Categories
                                <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="Categories" aria-expanded="false" style="height: 0px;">
                            <ul class="nav">
                                <li>
                                    <a href="{{ route('categories') }}">Categories</a>
                                </li>
                                <li>
                                    <a href="{{ route('sub.categories') }}">Sub Categories</a>
                                </li>
                            </ul>
                        </div>
                    </li>
					
					<!--<li  class="{{ Request::path() == 'Categories' ? 'active' : '' }}">
                        <a href="{{  route('categories') }}">
                            <i class="material-icons">person</i>
                            <p>Categories</p>
                        </a>
                    </li>-->
					
					
                    <!-- <li class="{{ Request::path() == 'CreditPoints' ? 'active' : '' }}">
                        <a href="{{ route('admin.creditpoints') }}">
                            <i class="fa fa-clock-o"></i>
                            <p>Credit Points</p>
                        </a>
                    </li> -->
					
					<li  class="{{ Request::path() == 'ServiceArea' ? 'active' : '' }}">
                        <a href="{{ route('service.area') }}">
                            <!--<i class="fa fa-tags"></i>-->
							<img src="{{ asset('images/menu/service_area.png') }}" class="menu_icon">
                            <p class="menu_text">Add Service Area</p>
                        </a>
                    </li>
				
					
					<li class="{{ Request::path() == 'TimeSlot' ? 'active' : '' }}">
                        <a href="{{ route('time.slot') }}">
                            <i class="fa fa-clock-o"></i>
                            <p>Time Slot</p>
                        </a>
                    </li>

                    <!-- <li class="{{ Request::segment(1) == 'DateTimeSlotAssign' ? 'active' : '' }}">
                        <a href="{{ route('admin.datetimeslotassign') }}/{{ date('M Y') }}">
                            <i class="fa fa-clock-o"></i>
                            <p>Time Slot Assign</p>
                        </a>
                    </li> -->
					
					<li class="{{ Request::path() == 'OutletViews' ? 'active' : '' }} active-outlet">
                        <a href="{{ route('get.outlet') }}">
                           <img src="{{ asset('images/menu/outlets.png') }}" class="menu_icon">
                            <p class="left1">Outlet</p>
                        </a>
                    </li>
					
					
                    <li class="{{ Request::path() == 'OrderList' ? 'active' : '' }} active-order">
                        <a href="{{ route('order.list') }}">
                            <i class="fa fa-list-alt"></i>
                            <p>Order List</p>
                        </a>
                    </li>
					
                  <!--- <li class="{{ Request::path() == 'DeliveryOrderList' ? 'active' : '' }}">
                        <a href="{{ route('order.delivery') }}">
                            <i class="fa fa-list-alt"></i>
                            <p>Assign Orders</p>
                        </a>
                    </li>-->
					
					<li class="{{ Request::path() == 'PickupUser' ? 'active' : '' }} active-pickup">
					    <a href="{{ route('pickupuser.list') }}">
                           <img src="{{ asset('images/menu/delivery_user.png') }}" class="menu_icon">
                            <p class="menu_text">PickupUser List</p>
                        </a>
                    </li>
					
					<li class="{{ Request::path() == 'IroningVendor' ? 'active' : '' }} active-vendor">
                        <a href="{{ route('ironing.vendor') }}">
                            <img src="{{ asset('images/menu/vendor.png') }}" class="menu_icon">
                            <p class="left1">IroningVendor List</p>
                        </a>
                    </li>
					<li class="{{ Request::path() == 'AddPromocode' ? 'active' : '' }} active-promo">
                        <a href="{{ route('add.promo') }}">
						<img src="{{ asset('images/menu/promocode.png') }}" class="menu_icon">
                            <!--<i class="material-icons">person</i>-->
                            <p class="menu_text">Promocode</p>
                        </a>
                    </li>

					<li class="{{ Request::path() == 'UsersList' ? 'active' : '' }} nav-active">
                        <a href="{{ route('user.list') }}">
                            <i class="fa fa-users"></i>
                            <p>Users</p>
                        </a>
                    </li>
					
					<li class="{{ Request::path() == 'Notifications' ? 'active' : '' }}">
                        <a href="{{ route('admin.notify') }}">
                            <i class="fa fa-bell"></i>
                            <p>Notifications</p>
                        </a>
                    </li>
					
					<li class="{{ Request::path() == 'ReportsView' ? 'active' : '' }} active-report">
                        <a href="{{ route('get.reports') }}">
                            <i class="fa fa-file"></i>
                            <p>Report</p>
                        </a>
                    </li>
					
					<li class="{{ Request::path() == 'Support' ? 'active' : '' }} active-support">
                        <a href="{{ route('customer.support') }}">
                            <i class="fa fa-support"></i>  
                            <p>Customer Support</p>
                        </a>
                    </li>
					
					<li class="{{ Request::path() == 'GalleryPage' ? 'active' : '' }} active-support">
                        <a href="{{ route('gallery.page') }}">
                            <i class="fa fa-file-image-o"></i>  
                            <p>Gallery</p>
                        </a>
                    </li>
					
					<!--<li class="{{ Request::path() == 'DeliveryManLocation' ? 'active' : '' }}">
                        <a href="{{ route('deliveryuser.location') }}">
                            <i class="fa fa-map-marker"></i>
                            <p>Map</p>
                        </a>
                    </li>-->

                    </li>                  
                </ul>
            </div>
        </div>
		
		<div class="main-panel">
		  <nav class="navbar navbar-transparent navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
							<a href="{{ route('admin.logout') }}"
                            onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                                   <i class="material-icons">exit_to_app</i>
								   
                                </a>
								<form id="logout-form" action="{{ route('admin.logout') }}" method="POST" style="display: none;">
                             {{ csrf_field() }}
                         </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
		     @yield('content')
			 
			 
			 <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                            <li>
                                <a href="#">
                                    Home
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Company
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Blog
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <!--<p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        <a href="http://www.pillowmint.in">Pillow Mint</a>
                    </p>-->
                </div>
            </footer>
		
		</div>
  
  </div>
  
  
  <!--   Core JS Files   -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

  <script src="{{ asset('js/multislider.js') }}" type="text/javascript"></script>
<script>
$('#mapSearch').removeAttr('placeholder');


$('#mixedSlider').multislider({
			duration: 750,
			interval: 3000
		});
		
		$('.exampleSlider').multislider('pause')
</script>
  <script>

$('.upload_img_file').bind('change', function() {
    
  var fl=this.files[0].size;
  
       if (fl > 2218309)
        {
			alert("Allowed file size exceeded. (Max. 2 MB)");
			$('.upload_img_file').val('');
			
		}else{
			readimgURL5(this);
		}
  
});



function readimgURL5(input) {

  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
	  $('.img_preview').show();
      $('.img_preview').attr('src', e.target.result);
    }

    reader.readAsDataURL(input.files[0]);
  }
}

</script>
<script src="{{ asset('js/jquery-3.2.1.min.js') }}" type="text/javascript"></script>
<script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.min.js">
    </script>
<script type="text/javascript">
  $(function() {
    $('.datetimepicker3').datetimepicker({
      pickDate: false
    });
  });
</script>



<script src="{{ asset('js/custom.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/search.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/jquery.validate.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/form_validation.js') }}" type="text/javascript"></script>


<script src="{{ asset('js/bootstrap.min.js') }}" type="text/javascript"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
<script>
$(function() {
  $('.selectpicker').selectpicker();
});

$(document).ready(function(){
 $('#areapincode').multiselect({
  nonSelectedText: 'Select Area',
  enableFiltering: true,
  enableCaseInsensitiveFiltering: true,
  buttonWidth:'400px'
 });
 

 
 
});

</script>
<script src="{{ asset('js/material.min.js') }}" type="text/javascript"></script>
<!--  Charts Plugin -->
<script src="{{ asset('js/chartist.min.js') }}" type="text/javascript"></script>
<!--  Dynamic Elements plugin -->
<script src="{{ asset('js/arrive.min.js') }}" type="text/javascript"></script>
<!--  PerfectScrollbar Library -->
<script src="{{ asset('js/perfect-scrollbar.jquery.min.js') }}" type="text/javascript"></script>
<!--  Notifications Plugin    -->
<script src="{{ asset('js/bootstrap-notify.js') }}" type="text/javascript"></script>
<!--  datatables Plugin    -->
<script src="{{ asset('js/jquery.datatables.js') }}" type="text/javascript"></script>
<!--  Google Maps Plugin    -->
<!-- Material Dashboard javascript methods -->
<script src="{{ asset('js/material-dashboard.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/demo.js') }}" type="text/javascript"></script>



<script type="text/javascript">
    

    $(document).ready(function() {
        // demo.initDashboardPageCharts();
        $('#datatables').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            responsive: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search records",
            }

        });
    });
	
	$(document).ready(function() {
        // demo.initDashboardPageCharts();
        $('.datatables').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            responsive: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search records",
            }

        });
    });
</script>
<script src="{{ asset('js/bootstrap-combobox.js') }}" type="text/javascript"></script>
<script src="{{ asset('js/hotel.js') }}" type="text/javascript"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=false&key=AIzaSyACGUvhcqr81pE1B0LQehgJs1oyh_XoJKc&libraries=places"></script>
<script src="{{ asset('js/map.js') }}" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function(){
	
	$('#mapSearch').attr('placeholder', '');
	
$('#mapSearch').removeAttr('placeholder');
});
 //setInterval(function(){
	
			
			  var base_url= 'http://13.126.228.76/ironbox_admin/public/'; 
			
			var csrf = $('meta[name="csrf-token"]').attr('content');
			 $.ajax({
				type: "GET",
				url: base_url+'/GetDeliveryLocation',
				data: {_token: csrf},
				success: function (data) {                
	             
				   //console.log(data);
				  // var newname = [];
					 // $.each(data, function (i) {
						// var names  =data[i].name;
						// var latitudes  =data[i].latitude;
						// var longitudes  =data[i].longitude;
						// newname.push(names);
						// newname.push(latitudes);
						// newname.push(longitudes);
						
						
					 // });
			          // $('#Epinid').val(response[0].id);

	
	
	
					
					}
				});
	
		
 //},4000);

  </script>
</body>
</html>