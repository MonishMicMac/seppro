Your username Otp

<div class="row">
  <div class="col-md-6">
  Email :<p>{{ $email }}<p>
  </div>
  
  <div class="col-md-6">
  otp :<p>{{ $otp }}</p>
  </div>

</div>


