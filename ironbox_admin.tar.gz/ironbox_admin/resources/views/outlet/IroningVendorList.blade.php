@extends('layouts.outlet')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
			</input type="text" id="outletId" value="<?php echo $id; ?>">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Ironing Vendors</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Phone Number</th>
										<th>DOB</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Phone Number</th>
										<th>DOB</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($User as $UserList)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $UserList->name }}</td>
										<td>{{ $UserList->mobile }}</td>
										<td>{{ $UserList->dob }}</td>


										<td class="text-right">
											<a href="{{ route('getoutvendor.report',['id'=>$id,'vendorId'=>$UserList->id]) }}" value="{{ $UserList->id }}" class="btn btn-simple btn-info btn-icon like pickup_report" data-toggle="tooltip" data-original-title="Report"><i class="fa fa-bar-chart"></i></a>  
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection