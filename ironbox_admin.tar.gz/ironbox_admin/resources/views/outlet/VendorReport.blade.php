@extends('layouts.outlet')

@section('content')
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Vendor Report</h4>
				</div>
				<div class="card-content">
				   <div class="row">
				        <div class="col-md-12">
                            <div class="card">
                               <!-- <div class="card-header card-chart" data-background-color="orange">
                                    <div class="ct-chart" id="pickupUserGraph"></div>
                                </div>
                               
                                <div class="card-content">
                                    <h4 class="title">Vendor vs cost</h4>
                                </div>-->
								
								<div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="CategoryClothesRep"></div>
                                </div>
                                <div class="card-content">
                                   <h4 class="title">Clothes category</h4>
                                </div>
								
								<div class="col-md-6">
								<label>Select Category * </label>
								 <select class="select_box" id="Main_Category_id" name="Main_Category"> 
                                       @foreach($category as $Cate)									  
                                      <option value="{{ $Cate->id }}"> {{ $Cate->name }} </option>
                                       @endforeach
								</select>
								
								</div>
								
								<input type='hidden' id="vendorId" value="{{ $userId }}">
								<input type='hidden' id="category_id" value="{{ $cate_first->id }}">
								<input type='hidden' id="outletId" value="{{ $id }}">
							
                            </div>
                        </div>
				   </div>
				   
				   
				   <!---<div class="row">
					   <div class="card-content">
					   <div class="box_shadow box_shadow1">
                                    <h4 class="greentext">Clothes report</h4> 
                               
					   <form method="post" id="Search_reports" action="{{ route('vendor.clothes.down') }}" enctype="multipart/form-data">
					   {{ csrf_field() }}
					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="fromdate" id="vendorfrom" type="date"/>
							  <input type='hidden' id="vendorId_1" name="vendorId" value="{{ $userId }}">
							  <span class="error vendor_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="todate" id="vendorto" type="date"/>
							  <span class="error vendor_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>Clothes</th>
						    <th>Orders</th>
						    <th>quantity</th>
							<th>Amount</th>							
						  </tr>
						
                           
						    <tbody id="Vendor_report">
                                  <td colspan="4">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
						  
					   </div>
					   </div>
					   </div>--->
				   
				   
                     <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 <h4 class="yellowtext">Reports</h4>
					   

        <div id="exTab1" class="">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">
			    <div class="tab-pane active" id="1a">
				  
				     <a href="{{ route('vendor.reports',['id'=>1,'vendorId'=>$userId]) }}" class="btn btn-primary down_btn3">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
						   
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($today_rep) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($today_rep as $OrderDay)
						  <tr>
							
							<td>{{ $OrderDay->orders }}</td>
							<td>{{ $OrderDay->qty }}</td>							
							<td>{{ $OrderDay->total }}</td>							
							
                           
						  </tr>
						   @endforeach
						</table>
				  
				  <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
				  <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
										
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($Day as $Order)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $Order->groupName }} / {{ $Order->name }}</td>
										<td>{{ $Order->orders }}</td>
										<td>{{ $Order->quantity }}</td>
										<td>{{ $Order->amount }}</td>
										
                                        

									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
                     
				</div>
				</div>
				</div>
				<div class="tab-pane" id="2a">
				
				 <a href="{{ route('vendor.reports',['id'=>2,'vendorId'=>$userId]) }}" class="btn btn-primary down_btn3">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
						   
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($week_rep) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($week_rep as $OrderDay)
						  <tr>
							
							<td>{{ $OrderDay->orders }}</td>
							<td>{{ $OrderDay->qty }}</td>							
							<td>{{ $OrderDay->total }}</td>							
							
                           
						  </tr>
						   @endforeach
						</table>
				
                   <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Orders</h4>				
				
                    <table id="" class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
										
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($Week as $Order)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $Order->groupName }} / {{ $Order->name }}</td>
										<td>{{ $Order->orders }}</td>
										<td>{{ $Order->quantity }}</td>
										<td>{{ $Order->amount }}</td>
										
                                        

									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
				   
				</div>
				</div>
				</div>
                <div class="tab-pane" id="3a">
				
				<a href="{{ route('vendor.reports',['id'=>3,'vendorId'=>$userId]) }}" class="btn btn-primary down_btn3">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
						   
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($month_rep) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($month_rep as $OrderDay)
						  <tr>
							
							<td>{{ $OrderDay->orders }}</td>
							<td>{{ $OrderDay->qty }}</td>							
							<td>{{ $OrderDay->total }}</td>							
							
                           
						  </tr>
						   @endforeach
						</table>
				
				<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Monthly Orders</h4>
				  <table id="" class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
										
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($Month as $Order)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $Order->groupName }} / {{ $Order->name }}</td>
										<td>{{ $Order->orders }}</td>
										<td>{{ $Order->quantity }}</td>
										<td>{{ $Order->amount }}</td>
										
                                        

									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
                     
				</div>
				</div>
				</div>
                <div class="tab-pane" id="4a">
				
				<a href="{{ route('vendor.reports',['id'=>4,'vendorId'=>$userId]) }}" class="btn btn-primary down_btn3">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
						   
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($year_rep) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($year_rep as $OrderDay)
						  <tr>
							
							<td>{{ $OrderDay->orders }}</td>
							<td>{{ $OrderDay->qty }}</td>							
							<td>{{ $OrderDay->total }}</td>							
							
                           
						  </tr>
						   @endforeach
						</table>
				  
				  <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Yearly Orders</h4>
				   <table id="" class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
										
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($Year as $Order)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $Order->groupName }} / {{ $Order->name }}</td>
										<td>{{ $Order->orders }}</td>
										<td>{{ $Order->quantity }}</td>
										<td>{{ $Order->amount }}</td>
										
                                        

									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
                       
				</div>
				</div>
				</div>
				
				
				 <div class="tab-pane" id="5a">
				 
				      <form method="post" id="Search_reports" action="{{ route('vendor.clothes.down') }}" enctype="multipart/form-data">
					   {{ csrf_field() }}
					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="fromdate" id="vendorfrom" type="date"/>
							  <input type='hidden' id="vendorId_1" name="vendorId" value="{{ $userId }}">
							  <span class="error vendor_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="todate" id="vendorto" type="date"/>
							  <span class="error vendor_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>Clothes</th>
						    <th>Orders</th>
						    <th>quantity</th>
							<th>Amount</th>							
						  </tr>
						
                           
						    <tbody id="Vendor_report">
                                  <td colspan="4">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
				 </div>
				
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
				   
				</div>
			</div>
		</div>		
	</div>

	</div>
</div>

<script type="text/javascript">

 $('#Main_Category_id').on('change',function(){
 var cate_id = $(this).val();
 var id =  $("#vendorId").val();

  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/VendorClothesGraph',
            data: {_token: csrf,id: id,cate_id: cate_id},
            success: function (data) { 

				   demo.CategoryClothesRep(data);
            }
        });

 });

    $(document).ready(function() {
		$('.active-vendor').addClass('active');

		 var cate_id = $("#category_id").val();
          var id =  $("#vendorId").val();

  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/VendorClothesGraph',
            data: {_token: csrf,id: id,cate_id: cate_id},
            success: function (data) { 
				
				   demo.CategoryClothesRep(data);
            }
        });

        $.ajax({
            type: "GET",
            url:  base_url+'/VendorGraph',
            data: {_token: csrf,id: id},
            success: function (data) { 
				   demo.pickupUserChart(data);
            }
        });
		
	   
    });
</script>



@endsection