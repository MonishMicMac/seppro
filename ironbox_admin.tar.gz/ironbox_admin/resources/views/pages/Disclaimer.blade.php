<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>

<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">


<style type="text/css">
	
	.content-sec {
		padding: 0 15px;
		font-family: 'PT Sans', sans-serif; 	
	}

	.content-sec h1 {
    	text-align: left;
    	text-transform: uppercase;
    	font-weight: bold;
    	font-size: 16px;
    	color: #272727;
}


	.content-sec p {
		text-align: left;
		font-size: 14px;

	}

	.content-sec h2 {
		text-align: left;
		font-weight: bold;
		font-size: 14px;
		color: #272727;
	}

	

</style>

</head>
<body>

	<div class="text-area">

			<div class="content-sec">
			
				<h1 style="text-align: center;"><u>Disclaimer</u></h1>

				<h2>Introduction:</h2>
				<p>The information provided by ironbox mobile application is for general informational purpose only.All information on this application is provided in good faith,however we make no representation or warranty of any kind,epress or implied,regarding the accuracy,adequacy,validity,availability or completness of any information on our mobile application</p>
				
				<p>Under no circumstances shall we have any liability for any loss or damage of any kind incurred as a result of the use of our mobile application.</p>
				
				<h2>Eternal links:</h2>
				
				<p>Our mobile application may contain links or originating from third parties or links to website and features in banner. Such eternal links are not investigated,monitored or checked for accuracy, adequacy,validity,reliability,availability by us.</p>
		

				<p>This mobile app is intended for informational, educational and studying purposes only. It is not, and is not intended, for use in the diagnosis of disease or other conditions, or in the cure, mitigation, treatment, or prevention of disease, in man or other animals . Sura Publication publishing this Mobile app with their own contents . It will help to tamilnadu school students to write their exams.</p>

				
			</div>						

	</div>

</body>

</html>
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												