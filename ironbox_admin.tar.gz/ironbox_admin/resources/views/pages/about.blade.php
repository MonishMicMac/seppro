<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>

<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">


<style type="text/css">
	
	.content-sec {
		padding: 0 15px;
		font-family: 'PT Sans', sans-serif; 	
	}

	.content-sec h1 {
    	text-align: left;
    	text-transform: uppercase;
    	font-weight: bold;
    	font-size: 16px;
    	color: #272727;
}


	.content-sec p {
		text-align: left;
		font-size: 14px;

	}

	.content-sec h2 {
		text-align: left;
		font-weight: bold;
		font-size: 14px;
		color: #272727;
	}

	

</style>

</head>
<body>

	<div class="text-area">

			<div class="content-sec">
			
				<h1 style="text-align: center;"><u>About</u></h1>

				
				 <h1>What is Lorem Ipsum?</h1>

				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
				
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p>
				
			</div>						

	</div>

</body>

</html>
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												