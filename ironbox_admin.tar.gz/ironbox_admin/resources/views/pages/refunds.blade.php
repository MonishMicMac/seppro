<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>

<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">


<style type="text/css">
	
	.content-sec {
		padding: 0 15px;
		font-family: 'PT Sans', sans-serif; 	
	}

	.content-sec h1 {
    	text-align: left;
    	text-transform: uppercase;
    	font-weight: bold;
    	font-size: 16px;
    	color: #272727;
}


	.content-sec p {
		text-align: left;
		font-size: 14px;

	}

	.content-sec h2 {
		text-align: left;
		font-weight: bold;
		font-size: 14px;
		color: #272727;
	}

	

</style>

</head>
<body>

	<div class="text-area">

			<div class="content-sec">
			
				<h1 style="text-align: center;"><u>PURCHASE OF PRODUCTS or SERVICES/REFUNDS</u></h1>

				
				 <p>When purchasing a product of service from theMobile application, the contract to provide such services becomes binding when we confirm your booking. You have a right to cancel any such booking and understand that any cancellations or re-scheduling requires 4hours’ notice. Payment for Product or Services can be made online through the application or in person by cash, credit or debit card through the payment gateway of the mobile application.</p>

				  <h2>Return/Exchange Policy</h2>
				  <p>•	Please contact us at 9090903456 prior to sending any refund request back to us.</p>
				  <p>•	All refunds may take up to 2 weeks to process, and the refund will be processed only if you have a defective service from our end or any damage from shipping, You can very well mail us at COMPLAINS@IRONBOX.CO.IN which should Include a description of the damages and defect, and include pictures if possible. </p>
				  <p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days..For all genuine cases the maximum refund would be Ten times of the rate charged for Steam Ironing,</p>
				  
				  <h2>Late or Missing Refunds</h2>
				  
				  <p>If you haven’t received a refund yet, first check your bank account again. Then contact your credit card company, it may take some time before your refund is officially posted. Next contact your bank. There is often some processing time before a refund is posted.</p>
				  
				<p>If you’ve done all of this and you still have not received your refund yet, please contact us at9090903456 or mail us at complains@ironbox.co.in</p>

				
			</div>						

	</div>

</body>

</html>
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												