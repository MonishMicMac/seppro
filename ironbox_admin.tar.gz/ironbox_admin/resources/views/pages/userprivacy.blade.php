<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>

<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">


<style type="text/css">
	
	.content-sec {
		padding: 0 15px;
		font-family: 'PT Sans', sans-serif; 	
	}

	.content-sec h1 {
    	text-align: left;
    	text-transform: uppercase;
    	font-weight: bold;
    	font-size: 16px;
    	color: #272727;
}


	.content-sec p {
		text-align: left;
		font-size: 14px;

	}

	.content-sec h2 {
		text-align: left;
		font-weight: bold;
		font-size: 14px;
		color: #272727;
	}

	

</style>

</head>
<body>

	<div class="text-area">

			<div class="content-sec">
			
				<h1 style="text-align: center;"><u>IRONBOX PRIVACY POLICY</u></h1>



				<p>This IronboxPrivacy Policy describes how we treat Personal Data that you provide or we collect when you use any of our services such as mobile app or web-based service made available to you by or on behalf of Ironboxvia the Site (hereinafter called as “Web-based Offering”), all  content published on our Site  (other than user content) (the “Content”). The Site, the Web-based Offerings, the Apps, the Tools, and the Content are referred to collectively in this Privacy Policy as our “Service” and each a “Service”.</p>
				
				<p>“Personal Data” means any information that can be used to identify, contact, or locate you, such as: your name, address, email address, or phone number, but does not include any information that has been fully anonymized so that a specific individual can no longer be identified from it.</p>
				<p>Please take a moment to read the following to learn more about our information practices, including what type of Personal Data is gathered, how the Personal Data is used and for what purposes, to whom we disclose Personal Data, and how we safeguard your Personal Data.
				Within the Ironbox, our most important asset is our relationship with our user community. We are committed to maintaining the confidentiality, integrity, and security of the Personal Data of our users. We are proud of our privacy practices and want you to know how we protect your information submitted or collected through your use of our service.
				</p>
				<h2>WHAT INFORMATION WE COLLECT</h2>
				<p><strong>Account Information. </strong>When you sign up for aIronboxAccount, we ask you for Personal Data such as your name, email address and company name.</p>
				<p><strong>Social Networking Site Information.</strong> For your convenience, we may allow you to register to join Ironboxby using log in credentials. You may choose to create a public Ironboxprofile, a project page or a profile page, and to share Personal Data or make user contributions as part of the same. Please be aware that any Personal Data or contribution you choose to share in this way, will be published, and made generally available to other users and third parties via the Site. This user generated content is publicly available and we are not responsible for the privacy practices of the other users or third parties who may view and use that information. If you do not want your Personal Data or user contributions to be accessible in this way, please do not post it. </p>
				<p><strong>Customer Support.</strong> We may collect Personal Data through your communications with our customer support team. Please ensure that no sensitive personal data is submitted in connection with your requests for support.</p>
				
				<p><strong>Payment Information.</strong> We use Services on Payment, you may need to provide Personal Data to our third-party payment processors, such as your credit card number.</p>
				
				<h2>OUR USE OF COOKIES AND RELATED TECHNOLOGIES</h2>
				
				<p>Ironboxuses cookies, which are alphanumeric identifiers in the form of text files that are stored on your computer, to make the Service easier to use, to improve our advertising, and to protect you and Ironbox. For example, we use them to store your login ID (but never your password) to make it easier for you to login whenever you come back to the Site. We also use them to remember the last application page you visited and advertisements you’ve already seen. You can remove or block cookies using the settings in your browser, but in some cases that may impact your ability to use the Service.</p>
				<p>Many of the advertisements you see when using the Service have been placed by third parties. These third parties may choose to use their own cookies for the purposes of collecting information relating to the viewing of their advertising. This Privacy Policy is intended to cover the use of cookies implemented by Ironboxand does not describe third party cookies in detail or their privacy policies.</p>
				<p>We use a third-party service provider to serve ads on our behalf across the Internet and sometimes on our site. They may collect anonymous information about your visits to our Site and your interaction with our products and services.</p>
				<p>We also work with a third party to monitor certain pages of our Site for the purpose of reporting Site traffic and other advertising statistics. Where authorized by us, this third party may use cookies and/or other monitoring technologies to compile anonymous statistics about our Site visitors. No Personal Data is transferred to this third party.
				In addition, we use Google Analytics to monitor and analyze Service usage.  More information on how Google uses data when you use services like ours can be found at www.google.com/policies/privacy/partners.
				</p>
				
				<h2>HOW AND WHY WE USE PERSONAL DATA</h2>
				
				<p>We collect information, which may include Personal Data, because it helps us deliver the absolute best user experience we possibly can. It is one of our core beliefs that we can only achieve that goal with your help and by customizing your experience. Gathering this information enables us to connect you with other people interested in technology like yourself and technology vendors, provide you with convenient and accurate information about discussion topics you may be interested in, and bring you timely and relevant information about the products and services that you may need. In addition, this information helps us keep you informed on the latest product and service announcements, software updates, and support information in a timely fashion. Most importantly, this information allows us to tune the product experience over time (including showing your more relevant content and ads), optimizing the Service based on your feedback and how you actually use the Service.</p>
				<p>We use your Personal Data to contact you about administrative notices, application & network alerts, product updates, offers and promotions, and general news about Ironbox  and our partners. This communication may be in the form of an alert, email or possibly a phone call, where permitted under applicable law.</p>
				
				<h2>YOUR RIGHTS AND YOUR CHOICES</h2>
				
				<p>Under Applicable Data Protection Laws, you may have the right, in certain cases, to request access to your Personal Data that we process, to request details about such Personal Data, including the purposes and potential recipients of this data, to have such Personal Data rectified or deleted, to have the processing thereof restricted, or to object to the processing of your Personal Data, as well as to request a copy of your Personal Data in a standardized format so that it can be provided to another vendor.</p>
				<p>You can ask us or third parties to stop sending you marketing messages at any time by following the opt-out links on any marketing message sent to you or by contacting us at any time using the contact details below.</p>
				<p>You may also have the right to lodge a complaint with your national data protection authority or other public authority governing the protection of your personal information.
Further rights are covered in the EU Standard Contractual Clauses referenced above.
</p>
				<p>In addition, you may decline to provide Personal Data to us and/or refuse cookies in your browser, but if you do (or if successfully object to the processing of your Personal Data by us, or successfully request that such Personal Data be deleted) some if not all of our features or services may not function properly as a result.</p>
				<p>To exercise these rights, please follow the steps set out below, or contact us via email at CUSTOMERCARE@IRONBOX.CO.INor send us a notice in writing, addressed to 3/2, Aravamudhan Garden street, Ground floor, Egmore Chennai 600 008.</p>
				
				<h2>INFORMATION CONFIDENTIALITY AND SECURITY</h2>
				
				<p>By using the Service or providing Personal Data to us, you agree that we may communicate with you electronically regarding your use of the Site. If we learn of a security system’s breach, we may attempt to notify you electronically by posting a notice or sending an email to you. </p>
				
				<h2>RETENTION OF DATA</h2>
				
				<p>Where you choose to create a public Ironboxprofile, we generally do not delete or disable any information contained in such page, profile or contribution until and unless you ask us to. To request this, please or contact us via email at CUSTOMERCARE@IRONBOX.CO.INor send us a notice in writing, addressed to 3/2, Aravamudhan Garden street, Ground floor, Egmore Chennai 600 008</p>
				<p>In all other cases, your Personal Data will be stored by Ironboxfor as long as necessary in order to fulfill the purposes set out in this Privacy Policy and to comply with minimum retention periods under applicable law. Unless otherwise specified in our Terms of Use, or notified to you in writing, we generally aim to put this Personal Data beyond further use within 12 months after the end of the provision of any Service to you. However, you can request earlier deletion by contacting us via email or at CUSTOMERCARE@IRONBOX.CO.IN or send us a notice in writing, addressed to3/2, Aravamudhan Garden street, Ground floor, Egmore Chennai 600 008.</p>
				
				<h2>THIRD PARTY SITES</h2>
				
				<p>Please be aware that other websites that may be accessed through the Service may collect Personal Data about you. Please note that the privacy policies of these sites may differ from those of Ironbox. Ironboxis not responsible for the privacy policies and practices of any linked website. This Privacy Policy does not cover the information practices of those third-party websites linked to our site. We encourage you to read the privacy statement of any website you may visit.</p>
				<p>Parts of the Service may include social media features, such as the Facebook Like button, and widgets, such as the Google Maps button or interactive mini-programs that run on the Service. These features may collect your IP address and which page you are visiting on our Site and may set a cookie to enable the feature to function properly. These features and widgets are either hosted by a third party or hosted directly on the Service. Your interactions with these features are governed by the privacy policy of the company providing it.</p>
				
				<h2>CHILDREN’S PRIVACY</h2>
				
				<p>Our Service is not intended for or directed to persons under the age of 18 and we do not knowingly collect, maintain, or use Personal Data from children under 18 years of age.  Any person who provides their information to Ironbox through the account login page for new customers or any other part of the Service represents to Ironbox that they are 18 years of age or older. </p>
				
				<h2>CHANGES TO PRIVACY STATEMENT</h2>
				
				<p>Ironbox may update this Privacy Policy from time to time. We will post any adjustments to the Privacy Policy on this web page, and the revised version will be effective when it is posted. When we change this Privacy Policy in a material way, a prominent notice will be posted on our Site along with the updated this Privacy Policy prior to the changes becoming effective. Please check this URL frequently to see the latest version of this this Privacy Policy.</p>
				
				
				<h2>FEEDBACK AND CONTACT FOR FURTHER ENQUIRIES</h2>
				
				<p>If you wish to exercise any of your legal rights referred to in this Privacy Policy, or if you have any questions in relation to this Privacy Policy, please contact Ironboxat CUSTOMERCARE@IRONBOX.CO.INor send us a notice in writing, addressed to 3/2, Aravamudhan Garden street, Ground floor, Egmore Chennai 600 008.</p>

				
			</div>						

	</div>

</body>

</html>
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												