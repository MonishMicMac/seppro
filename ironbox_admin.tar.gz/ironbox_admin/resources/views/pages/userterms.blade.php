<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>

<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">


<style type="text/css">
	
	.content-sec {
		padding: 0 15px;
		font-family: 'PT Sans', sans-serif; 	
	}

	.content-sec h1 {
    	text-align: left;
    	text-transform: uppercase;
    	font-weight: bold;
    	font-size: 16px;
    	color: #272727;
}


	.content-sec p {
		text-align: left;
		font-size: 14px;

	}

	.content-sec h2 {
		text-align: left;
		font-weight: bold;
		font-size: 14px;
		color: #272727;
	}

	

</style>

</head>
<body>

	<div class="text-area">

			<div class="content-sec">
			
				<h1 style="text-align: center;"><u>MOBILE APP – TERMS AND CONDITIONS</u></h1>

				
				 <!--<h1>What is Lorem Ipsum?</h1>-->

				<p>By downloading or using either the IRONBOX: these terms will automatically apply to you – you should make sure therefore that you read them carefully before using either app. We are offering you these apps to use for your own personal use without cost, but you should be aware that you cannot send it on to anyone else, and you’re not allowed to copy, or modify either app, any part of the apps, or our trademarks in any way. You’re not allowed to attempt to extract the source code of the apps, and you also shouldn’t try to translate the apps into other languages, or make derivative versions. The apps themselves, and all the trade marks, copyright, database rights and other intellectual property rights related to it, still belong to IRONBOX.</p>
				
				<p>At the bottom of these terms and conditions you will be able to find links to our website where we set out our Privacy Policy, Acceptable Use of the apps, and the General Terms and Conditions for using our services, which will be relevant if you use the app to book appointments with IRONBOX in the future.</p>
				<p>Iron box is committed to ensuring that the app is as useful and efficient as possible. For that reason, we reserve the right to make changes to the app, withdraw the apps, or to charge for its services, at any time and for any reason. We will never charge you for the app and charge only for the services which we offer. We amend these terms from time to time. Please check these terms regularly to ensure you understand the terms that apply at that time.</p>
				
				<h1 style="text-align: center;"><u>IRONBOX</u></h1>
				
				<p>The IRONBOX app, stores and processes personal data that you have provided to us for booking our services. It’s your responsibility to keep your phone and access to the app secure. We therefore recommend that you do not jailbreak or root your phone, which is the process of removing software restrictions and limitations imposed by the official operating system of your device. It could make your phone vulnerable to malware/viruses/malicious programs, compromise your phone’s security features and it could mean that the IRONBOX app won’t work properly or at all.</p>
				<p>You should be aware that there are certain things that IRONBOX will not take responsibility for. certain functions of the app, such as Push Notification function which all require the app to have an active internet connection. The connection can be Wi-Fi, or provided by your mobile network provider, but IRONBOX cannot take responsibility for the app not working at full functionality if you don’t have access to Wi-Fi, and you don’t have any of your data allowanceleft.</p>
				<p>If you’re using the app outside of an area with Wi-Fi, you should remember that your terms of agreement with your mobile network provider will still apply. As a result, you may be charged by your mobile provider for the cost of data for the duration of the connection while accessing the app, or other third party charges. In using the app, you’re accepting responsibility for any such charges, including roaming data charges if you use the app outside of your home territory (i.e. region or country) without turning off data roaming. If you are not the bill payer for the device on which you’re using the app, please be aware that we assume that you have received permission from the bill payer for using theapp.</p>
				<p>IRONBOX cannot always take responsibility for the way you use the app. At some point we may wish to update the app. The app is currently available on Android and iOS – the requirements for both systems (and for any additional systems we decide to extend the availability of the app to) may change, and you’ll need to download the updates if you want to keep using the app. IRONBOX does not promise that it will always update the app so that it is relevant to you and/or works with the iOS/Android version that you have installed on your device. However, you promise to always accept updates to the application when offered to you, We may also wish to stop providing the app, and may terminate use of it at any time without giving notice of termination to you. Unless we tell you otherwise, upon any termination, (a) the rights and licenses granted to you in these terms will end; (b) you must stop using the app, and (if needed) delete it from your device.</p>
				
				
			</div>						

	</div>

</body>

</html>
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												