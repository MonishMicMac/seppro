@extends('layouts.layouts')

@section('content')
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Avg cost</h4>
					</div>
					<div class="card-content">
					   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 
					   
                <h4 class="yellowtext">Avg cost reports</h4>

		
		<div id="exTab1" class="pad4">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">

			  <div class="tab-pane active" id="1a">
			  
			         <table class="table_1">
						  <tr>
						    <th>Category Name</th>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						  <?php 
						   	$Totalquantity1=$Total1;
						   ?>
						 	@foreach($Today as $todayy)
						 	<?php 
						 	if ($Totalquantity1) {
						 		$avg=($todayy->quantity/$Totalquantity1)*100;	
						 	}else{
						 		$avg=0;
						 	}						 	
						 	?>

						  <tr>
							<td>{{ $todayy->Categoryname }}</td>
							<td>{{ $todayy->payments }}</td>
							<td>{{ $todayy->quantity }}</td>							
							<td>{{ round($avg,2) }}</td>
							</tr>
							@endforeach
						</table>
			
				</div>
				<div class="tab-pane" id="2a">
			  
			         <table class="table_1">
						  <tr>
						    <th>Category Name</th>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						  <?php 
						   	$Totalquantity2=$Total2;
						   ?>
						 	@foreach($Week as $week)
						 	<?php 
						 	if ($Totalquantity2) {
						 		$avg=($week->quantity/$Totalquantity2)*100;	
						 	}else{
						 		$avg=0;
						 	}						 	
						 	?>

						  <tr>
							<td>{{ $week->Categoryname }}</td>
							<td>{{ $week->payments }}</td>
							<td>{{ $week->quantity }}</td>							
							<td>{{ round($avg,2) }}</td>
							</tr>
							@endforeach
						</table>
			
				</div>
				<div class="tab-pane" id="3a">
			  
			         <table class="table_1">
						  <tr>
						    <th>Category Name</th>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						  <?php 
						   	$Totalquantity3=$Total3;
						   ?>
						 	@foreach($Month as $month)
						 	<?php 
						 	if ($Totalquantity3) {
						 		$avg=($month->quantity/$Totalquantity3)*100;
						 	}else{
						 		$avg=0;
						 	}						 	
						 	?>

						  <tr>
							<td>{{ $month->Categoryname }}</td>
							<td>{{ $month->payments }}</td>
							<td>{{ $month->quantity }}</td>							
							<td>{{ round($avg,2) }}</td>
							</tr>
							@endforeach
						</table>
			
				</div>

            <div class="tab-pane" id="4a">
			  
			         <table class="table_1">
						  <tr>
						    <th>Category Name</th>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						  <?php 
						   	$Totalquantity4=$Total4;
						   ?>
						 	@foreach($Year as $years)
						 	<?php 
						 	if ($Totalquantity4) {
						 		$avg=($years->quantity/$Totalquantity4)*100;
						 	}else{
						 		$avg=0;
						 	}						 	
						 	?>


						  <tr>
							<td>{{ $years->Categoryname }}</td>
							<td>{{ $years->payments }}</td>
							<td>{{ $years->quantity }}</td>							
							<td>{{ round($avg,2) }}</td>
							</tr>
							@endforeach
						</table>
			
				</div>
				
				<div class="tab-pane" id="5a">
				
				    <form method="post" id="Search_reports" action="" enctype="multipart/form-data">
					   {{ csrf_field() }}
					      <div class="col-md-4">
						    <div class="form-group">
							<label class="control-label">
                                From date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="fromdate" id="avgfrom" type="date"/>
							  <span class="error avg_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="todate" id="avgto" type="date"/>
							  <span class="error avg_to">Please select date</span>
                           </div>
						  </div>
						  
						  <!--<div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>-->
						  </form>
						  <div class="clearfix"></div>
						  
						  
						  <table class="table_1">
						   <tr>
						    <th>Category Name</th>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						 	
						<tbody id="Avg_report">
						<td colspan="4">No record</td>
					
							
							 </tbody>
						</table>
				</div>
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
   $(document).ready(function() {
		$('.active-report').addClass('active');
		
		var id = $('#cate_id').val();
		
		$.get("{{route('clothes.category')}}?id="+id)
	  .done(function(data) {
		

		});
		
	
		
		
    });
</script>

@endsection