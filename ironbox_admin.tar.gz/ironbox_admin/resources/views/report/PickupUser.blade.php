@extends('layouts.layouts')

@section('content')
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					@foreach($User as $PickupUser)
					<h4 class="title">{{ $PickupUser->name }} - Report</h4>
					@endforeach
				</div>
				<div class="card-content">
				   <div class="row">
				        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="orange">
                                    <div class="ct-chart" id="pickupUserGraph"></div>
									
                                </div>
                               
							   <div class="card-content">
                                    <h4 class="title">Pickup user report</h4>
                                </div>
                             
								<input type='hidden' id="pickupId" value="{{ $userId }}">
							
                            </div>
                        </div>
				   </div>
				   
				   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 <h4 class="yellowtext">Reports</h4>
					 
					    

        <div id="exTab1">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab" value="1" class="pickup_graph">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab" value="2" class="pickup_graph">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab" value="3" class="pickup_graph">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab" value="4" class="pickup_graph">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab" value="5" class="pickup_graph">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
			     
				  <a href="{{ route('pickup.reports',['type'=>'normal','id'=>1,'pickupId'=>$userId]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
							<th>Orders</th>							
							<th>Order for</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						  @foreach($Days as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->orders }}</td>
							<td>{{ $OrderDay->Pickup }}</td>
							<td>{{ $OrderDay->qty }}</td>							
							<td>{{ $OrderDay->total }}</td>							
                           
						  </tr>
						   @endforeach
						</table>
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Report</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($TodayOrder as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->Pickup }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
			  
                     
				</div>
				<div class="tab-pane" id="2a">
				
				<a href="{{ route('pickup.reports',['type'=>'normal','id'=>2,'pickupId'=>$userId]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
							<th>Orders</th>							
							<th>Order for</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						  @foreach($Weeks as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->orders }}</td>
							<td>{{ $OrderDay->Pickup }}</td>
							<td>{{ $OrderDay->qty }}</td>							
							<td>{{ $OrderDay->total }}</td>							
                           
						  </tr>
						   @endforeach
						</table>
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Report</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($WeekOrder as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->Pickup }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
                      
				</div>
               <div class="tab-pane" id="3a">
			   
			   <a href="{{ route('pickup.reports',['type'=>'normal','id'=>3,'pickupId'=>$userId]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
							<th>Orders</th>							
							<th>Order for</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						  @foreach($Months as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->orders }}</td>
							<td>{{ $OrderDay->Pickup }}</td>
							<td>{{ $OrderDay->qty }}</td>							
							<td>{{ $OrderDay->total }}</td>							
                           
						  </tr>
						   @endforeach
						</table>
						
						
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Month Report</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($MonthOrder as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->Pickup }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
						
                   
				</div>
            <div class="tab-pane" id="4a">
                
				 <a href="{{ route('pickup.reports',['type'=>'normal','id'=>4,'pickupId'=>$userId]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
							<th>Orders</th>							
							<th>Order for</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						  @foreach($Years as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->orders }}</td>
							<td>{{ $OrderDay->Pickup }}</td>
							<td>{{ $OrderDay->qty }}</td>							
							<td>{{ $OrderDay->total }}</td>							
                           
						  </tr>
						   @endforeach
						</table>
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Year Report</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($YearOrder as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->Pickup }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						 
				</div>
				
				<div class="tab-pane" id="5a">
				    <form method="post" id="Search_reports" action="{{ route('pickup.orders.down') }}" enctype="multipart/form-data">
					   {{ csrf_field() }}
					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="fromdate" id="pickupfrom" type="date"/>
							  <input type='hidden' id="pickupId_1" name="pickupId" value="{{ $userId }}">
							  <span class="error pickup_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="todate" id="pickupto" type="date"/>
							  <span class="error pickup_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>BookingId</th>
							<th>Booking date</th>
							<th>Order for</th>
							<th>Status</th>						
							<th>Actions</th>						
						  </tr>
						
                           
						    <tbody id="pickup_report">
                                  <td colspan="5">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
				
				</div>
				
				
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
				   
				</div>
			</div>
		</div>		
	</div>
	
	
	
	
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		$('.active-pickup').addClass('active');
		 var id =  $("#pickupId").val();
		var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/PickUpuserGraph',
            data: {_token: csrf,id: id},
            success: function (data) { 
				   demo.pickupUserChart(data);
            }
        });
		
	   
    });
</script>


@endsection