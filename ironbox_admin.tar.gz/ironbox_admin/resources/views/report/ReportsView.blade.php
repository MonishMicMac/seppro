@extends('layouts.layouts')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					     
						 <div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('high.order') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
										<img src="{{ asset('images/menu/service_area.png') }}" class="img-responsive center-block">
										<p class="text2">Highest order area</p>
									</div>
								</div>
								</a>
							</div>	
							
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('report.payment.view') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
										<img src="{{ asset('images/menu/payment_type.png') }}" class="img-responsive center-block">
										<p class="text2">Payment type</p>
									</div>
								</div>
								</a>
							</div>
							
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('order.complete.view') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
										<img src="{{ asset('images/menu/success_cancel.png') }}" class="img-responsive center-block">
										<p class="text2">Success/Cancel</p>
									</div>
								</div>
								</a>
							</div>
							
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('total.revenue.view') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
										<img src="{{ asset('images/menu/total_revenue.png') }}" class="img-responsive center-block">
										<p class="text2">Revenue</p>
									</div>
								</div>
								</a>
							</div>
							
							<div class="clearfix"></div>
							
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('promo.code.view') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
										<img src="{{ asset('images/menu/promocode.png') }}" class="img-responsive center-block">
										<p class="text2">Promocode</p>
									</div>
								</div>
								</a>
							</div>
							
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('wallet.report.view') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
									  <div class="center">
										<i class="fa fa-google-wallet fon-1"></i>
										</div>
										<p class="text2">Wallet</p>
									</div>
								</div>
								</a>
							</div>
							
							
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('clothes.revenue') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
										<img src="{{ asset('images/menu/clothes.png') }}" class="img-responsive center-block">
										<p class="text2">Clothes</p>
									</div>
								</div>
								</a>
							</div>
							
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('time.slot.report') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
									  <div class="center">
										<i class="fa fa-clock-o fon-1"></i>
										</div>
										<p class="text2">Timeslots</p>
									</div>
								</div>
								</a>
							</div>
							<div class="clearfix"></div>
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('user.not.use') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
									<div class="center">
										<i class="fa fa-users fon-1"></i>
										</div>
										<p class="text2">User not use</p>
									</div>
								</div>
								</a>
							</div>
							
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('clothes.cate') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
										<img src="{{ asset('images/menu/clothes.png') }}" class="img-responsive center-block">
										<p class="text2">Clothes category</p>
									</div>
								</div>
								</a>
							</div>
							
							<div class="col-lg-3 col-md-3 col-sm-3">
							<a href="{{ route('avg.cost') }}">
								<div class="card2 card-stats">
									<div class="card-content card-content2">
									  <div class="center">
									    <i class="fa fa-inr fon-1"></i>
									  </div>
										<p class="text2">Avg cost</p>
									</div>
								</div>
								</a>
							</div>		   
					   </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



@endsection