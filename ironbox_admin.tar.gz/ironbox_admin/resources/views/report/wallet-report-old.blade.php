@extends('layouts.layouts')

@section('content')
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-12">
                             
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="WalletReport"></div>
                                </div>
                               <div class="card-content">
                                    <h4 class="title">Monthly wallet transaction</h4>
                                </div>
                            </div>
                         					   
					  
                         </div>					   
					   </div>
					   
					   
					   <!--<div class="row">
					   <div class="card-content">
					   <div class="box_shadow box_shadow1">
                                    <h4 class="greentext">Search wallet report</h4>
                                
					   <form method="post" id="Search_reports" action ="{{ route('serach.promo.down') }}" enctype="multipart/form-data">
					   {{ csrf_field() }}
					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control" name="fromdate" id="walletfrom" type="date"/>
							  <span class="error wallet_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control" name="todate" id="walletto" type="date"/>
							  <span class="error wallet_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>Date</th>
							<th>Amount</th>							
						  </tr>
						
                           
						    <tbody id="Wallet_report">
                                  <td colspan="2">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
						  
					   </div>
					   </div>
					   </div>-->
					   
					   <div class="row">
						   <div class="col-md-12">
						   <div class="box_shadow box_shadow2">
						      <h4 class="yellowtext">Reports</h4> 
							  <div id="exTab1">
								 <ul  class="nav nav-pills">
									<li class="active">
									   <a  href="#1a" data-toggle="tab">Today</a>
									</li>
									<li><a href="#2a" data-toggle="tab">Weekly</a>
									</li>
									<li><a href="#3a" data-toggle="tab">Monthly</a>
									</li>
									<li><a href="#4a" data-toggle="tab">Yearly</a></li>
								 </ul>
								 <div class="tab-content clearfix">
								 
								  <a href="{{ url('WalletReport/' . 1 . '') }}" class="btn btn-primary down_btn2">  
								   Download report
								   <div class="ripple-container"></div>
								 </a>
								 
									<div class="tab-pane active" id="1a">
									  <table class="table_1">
										  <tr>
											<th>Date</th>
											<th>Amount</th>							
										  </tr>
										   <?php 
										  if(count($Day) == 0){
											 ?> 
											   <tr>
											   <td colspan="2">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  @foreach($Day as $OrderDay)
										  <tr>						
											<td>{{ $OrderDay->order_date }}</td>
											<td>{{ $OrderDay->amount }}</td>
										   
										  </tr>
										   @endforeach
										</table>
									</div>
									<div class="tab-pane" id="2a">
									 <a href="{{ url('WalletReport/' . 2 . '') }}" class="btn btn-primary down_btn2">  
									   Download report
									   <div class="ripple-container"></div>
									</a>
									    <table class="table_1">
										  <tr>
											<th>Date</th>
											<th>Amount</th>							
										  </tr>
										   <?php 
										  if(count($Week) == 0){
											 ?> 
											   <tr>
											   <td colspan="2">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  @foreach($Week as $OrderDay)
										  <tr>						
											<td>{{ $OrderDay->order_date }}</td>
											<td>{{ $OrderDay->amount }}</td>
										   
										  </tr>
										   @endforeach
										</table>
									</div>
									<div class="tab-pane" id="3a">
									 <a href="{{ url('WalletReport/' . 3 . '') }}" class="btn btn-primary down_btn2">  
									   Download report
									   <div class="ripple-container"></div>
									</a>
									   <table class="table_1">
										  <tr>
											<th>Date</th>
											<th>Amount</th>							
										  </tr>
										   <?php 
										  if(count($Month) == 0){
											 ?> 
											   <tr>
											   <td colspan="2">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  @foreach($Month as $OrderDay)
										  <tr>						
											<td>{{ $OrderDay->order_date }}</td>
											<td>{{ $OrderDay->amount }}</td>
										   
										  </tr>
										   @endforeach
										</table>
									</div>
									<div class="tab-pane" id="4a">
									 <a href="{{ url('WalletReport/' . 4 . '') }}" class="btn btn-primary down_btn2">  
									   Download report
									   <div class="ripple-container"></div>
									</a>
									    <table class="table_1">
										  <tr>
											<th>Date</th>
											<th>Amount</th>							
										  </tr>
										   <?php 
										  if(count($Year) == 0){
											 ?> 
											   <tr>
											   <td colspan="2">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  @foreach($Year as $OrderDay)
										  <tr>						
											<td>{{ $OrderDay->order_date }}</td>
											<td>{{ $OrderDay->amount }}</td>
										   
										  </tr>
										   @endforeach
										</table>
									</div>
								 </div>
							  </div>
							  </div>
						   </div>
						</div>
					   
					   <!--<div class="row" style="margin-top:20px;">
							<div class="col-lg-12 col-md-12">
								<div class="card">
									<div class="card-header" data-background-color="blue">
										<h4 class="title">Wallet transaction</h4>
									</div>
									<div class="card-content">
										<div class="material-datatables">
											<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
												<thead>
													<tr>
														<th>S.No</th>
														<th>Name</th>
														<th>Mobile</th>
														<th>OrderId</th>
														<th>amount</th>
														<th>Status</th>
														<th>Transaction date</th>
														
													</tr>
												</thead>
												<tfoot>
													<tr>
														<th>S.No</th>
														<th>Name</th>
														<th>Mobile</th>
														<th>OrderId</th>
														<th>amount</th>
														<th>Status</th>
														<th>Transaction date</th>
														
													</tr>
												</tfoot>
												
												<tbody>
												 <?php   $count = 1; ?>
												@foreach($transaction as $amount)
													<tr>
														<td>{{$count++}}</td>
														<td>{{ $amount->name }}</td>
														<td>{{ $amount->mobile }}</td>
														<td>{{ $amount->orderId }}</td>
														<td>{{ $amount->amount }}</td>
														<td>{{ $amount->transation_status }}</td>
														<td>{{ $amount->trans_date }}</td>


														
													</tr>
												@endforeach
																								   
												</tbody>
												
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>-->
			
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		$('.active-report').addClass('active');
		$.get("{{route('wallet.report.graph')}}")
	  .done(function(data) {
		
		// console.log(data);
			demo.WalletChart(data);
							
		});	
		
	
		
		
    });
</script>

@endsection