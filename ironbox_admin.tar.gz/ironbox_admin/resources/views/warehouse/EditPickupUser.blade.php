@extends('layouts.warehouse')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
				 @foreach($User as $PickupUser)
					<h4 class="title">Pickup / delivery - {{ $PickupUser->name }}</h4>
					@endforeach
				</div>
				<div class="card-content">
				@foreach($User as $PickupUser)
				
				  <div class="box_shadow box_shadow2">
				   <h4 class="yellowtext">Pickup user details</h4>
				    <div class="row">
                      <div class="col-md-6">
					    <div class="user_profile">
						   <img src=" <?php if($PickupUser->image == ''){ echo "http://139.59.37.241/Ironman/public/images/pic.png"; }else{ echo $PickupUser->image; } ?>" class="img-responsive center-block img-circle">
						    
						</div>
						
						<div class="urdetails">
						   <strong>Name :</strong> {{ $PickupUser->name }}
						</div>
						
						<div class="urdetails">
						   <strong>Mobile :</strong> {{ $PickupUser->mobile }}
						</div>
						
						<div class="urdetails">
						   <strong>Email :</strong> {{ $PickupUser->email }}
						</div>
						
						<div class="urdetails">
						   <strong>Alternate number :</strong> {{ $PickupUser->alternate_number }}
						</div>
						
				     </div>
					 
					 <div class="col-md-3">
					     <div class="urdetails">
						   <strong>DOB :</strong> {{ $PickupUser->dob }}
						</div>
						<div class="urdetails">
						   <strong>Gender :</strong> {{ $PickupUser->gender }}
						</div>
						<div class="urdetails">
						   <strong>Address :</strong> {{ $PickupUser->address }}
						</div>
					 
					 </div>
					 
					 <div class="col-md-3">
					     <div class="urdetails">
						   <strong>Pickup order :</strong> <?php echo $pickup_count; ?>
						</div>
						
						<div class="urdetails">
						   <strong>delivery order :</strong> <?php echo $delivery_count; ?>
						</div>
						
					</div>	
					 
					 
					 
				    </div>
				  </div>
				   
				   
				   <!--<hr class="border_line">
				   <div class="row">
                        <div class="col-md-6">
                             <h4 class="title">Service Area</h4>
							 <form action="{{ route('add.new.service') }}" method="post" id="allowcateservice"> 
							  {{ csrf_field() }}
							  <div class="col-md-12">
							     <div class="form-group">
								 <label class="control-label">
										warehous
									   <small>*</small>
									  </label>
							      <select class="Select_box1" id="warehousId" name="warehousId">
								      <option value="">Select warehous</option>
									    @foreach($houses as $warehouse)
									    <option value="{{ $warehouse->id }}" 
										
                                         <?php
										 
										 foreach($User as $PickupUser){
										   
										   if($PickupUser->warehouseId == $warehouse->id){
											   
											   echo "Selected";
										   }
									    }?>

										>{{ $warehouse->name }}</option>
                                         @endforeach
								  </Select>
								  <input type="hidden" name="id" value="{{ $PickupUser->id}}">
                                 </div>
							  </div>
							  <div class="clearfix"></div>
							  <div class="col-md-12">
							      <div class="form-group">
									  <label class="control-label">
										Pincode
									   <small>*</small>
									  </label>
					  
									<!--<select class="selectpicker" name="pincode" id="pincode" data-live-search="true">
									<select class="Select_box1" name="pincode" id="pincode">
									<option value="">Select Area</option>	
									@foreach($Area as $SelectAreas )
									<option value="{{ $SelectAreas->id }}" <?php   
									
									   foreach($User as $PickupUser){
										   
										   if($PickupUser->code == $SelectAreas->code){
											   
											   echo "Selected";
										   }
									   }
									
									?>  data-tokens="{{ $SelectAreas->area }}">{{ $SelectAreas->area }}</option>
									 @endforeach
									</select>
					             </div>
							  </div>
							  <div class="clearfix"></div>
					
					             <div class="col-md-12">
								<button class="btn btn-primary">
								   Submit
								   <div class="ripple-container"></div>
								</button>
								</div>
							  </form>
                        </div>	
                         <div class="col-md-6">
					      <h4 class="title">Block user</h4>
						  
						  <form action="{{ route('pickup.block') }}" method="post" id="pickupblock"> 
								{{ csrf_field() }}
						   <div class="col-md-12">
						    <div class="form-group">
							<input type='hidden' name='userid' value='{{ $PickupUser->id }}'>
							<input type='hidden' name='active_user' value='{{ $PickupUser->Is_active }}'>
							
							<label class="switch">
							  <input type="checkbox" name="active_user1" <?php if($PickupUser->Is_active == 1){  echo "checked"; } ?> value="{{ $PickupUser->Is_active }}">
							  <span class="slider round"></span>
							</label>
						  </div>
						  </div>
						  
						  <div class="col-md-12">
						    <textarea rows="4" cols="50" placeholder="comments" name="comments"></textarea>
						  </div>
						  
						  <div class="clearfix"></div>
					
					             <div class="col-md-12">
								<button class="btn btn-primary">
								   Submit
								   <div class="ripple-container"></div>
								</button>
								</div>
						  
						  </form>
					   </div>
                    						
				   </div>  --->
				   
				   @endforeach
				   
				   <!-- <hr class="border_line">-->
					
					
				   <div class="row" style="margin-top:50px;">
				     <div class="col-md-12">
					 <div class="card-header" data-background-color="blue">
						 <h4 class="title">Pickup Service</h4>
					</div>
					 
					   <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<th>Booking date</th>
										<th>Action</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<th>Booking date</th>
										<th>Action</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
                                     @foreach($UserBookings as $Bookings)
									<tr>
										<td>{{ $count++ }}</td>
										<td>{{ $Bookings->bookingId }}</td>
										<td>{{ $Bookings->name }}</td>
										<td>{{ $Bookings->mobile }}</td>
										<td>{{ $Bookings->pick_date }} </td>
										<td class="text-right">
											<a href="{{ route('view.bookings',[$Bookings->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>

									</tr>
                                   @endforeach									
								</tbody>
								
							</table>
					 </div>
					 
				   </div>
				   
				   <div class="row" style="margin-top:20px;">
				     <div class="col-md-12">
					 <div class="card-header" data-background-color="blue">
						<h4 class="title">Delivery Service</h4>
					</div>
					   <table id="datatablesss" class="datatables table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<th>Booking date</th>
										<th>Action</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<th>Booking date</th>
										<th>Action</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
                                     @foreach($Delivery as $DeliveryService)
									<tr>
										<td>{{ $count++ }}</td>
										<td>{{ $DeliveryService->bookingId }}</td>
										<td>{{ $DeliveryService->name }}</td>
										<td>{{ $DeliveryService->mobile }}</td>
										<td>{{ $DeliveryService->delivery_date }}</td>
										<td class="text-right">
											<a href="{{ route('view.bookings',[$DeliveryService->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>

									</tr>
                                   @endforeach									
								</tbody>
								
							</table>
					 </div>
				   
				   </div>
				   
				   
				   
				   
				   
				</div>
			</div>
		  </div>		
	   </div>	
	</div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
		$('.active-pickup').addClass('active');

    });
</script>
@endsection