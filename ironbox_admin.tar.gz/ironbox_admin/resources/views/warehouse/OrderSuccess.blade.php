@extends('layouts.warehouse')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-6">
						<h4 class="title">Success / cancel vs Orders</h4>
                             
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="SuccessGraph"></div>
									<span class="graph_text">Orders</span>
									<span>success / cancel</span>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Success / cancel</h4>
									<input type="hidden" id="outletId" value="<?php echo $id ?>">
                                </div>
                            </div>
                         					   
					  
                         </div>	

                         <div class="col-md-6">
                          <h4 class="title">success / cancel orders total summary</h4>

						   <table class="table_1">
						   
						      <tr>
								<th>Orders</th>
								<th>Status</th>														
							  </tr>
							  
							  <?php 
							  if(count($summary) == 0){
								 ?> 
								   <tr>
								   <td colspan="2">No record</td>
									</tr>
								  <?php
							  }
							  
							  ?>
							  
							  @foreach($summary as $date)
							  <tr>
								<td>{{ $date->orders }}</td>
								<td>{{ $date->Status }}</td>							
							  </tr>
							   @endforeach
						   
						   </table>
						  
                         </div>						 
							
					   </div>
					   
					  <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 
					   <h4 class="yellowtext">Reports</h4> 

        <div id="exTab1">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab" value="1" class="get_order_status">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab" value="2" class="get_order_status">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab" value="3" class="get_order_status">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab" value="4" class="get_order_status">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab" value="5" class="get_order_status">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
			  
                   <a href="{{ route('out.status.rep',['id'=>1,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
			  
                     <table class="table_1">
						  <tr>
						    <th>Orders</th>
							<th>Status</th>							
							
						  </tr>
						  
						   <?php 
						  if(count($Day) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						
						  <tr>
							<td><?php echo json_encode($Day[0]->orders); ?></td>
							<td>COMPLETED</td>

						  </tr>
						  <tr>
						    <td><?php echo json_encode($Day[1]->orders); ?></td>
							<td>CANCELLED</td>
						  </tr>
						   
						</table> 
						
						

                       <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Status</th>									
										<th>Cancelled reasons</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Status</th>									
										<th>Cancelled reasons</th>									
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($DayRep as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->Status }}</td>
										<td>{{ $rep->cancelReason }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
			  
			 
				</div>
				<div class="tab-pane" id="2a">
                     
					 <a href="{{ route('out.status.rep',['id'=>2,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
					 
                    <table class="table_1">
						  <tr>
						    <th>Orders</th>
							<th>Status</th>							
							
						  </tr>
						  
						   <?php 
						  if(count($Week) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						
						  <tr>
							<td><?php echo json_encode($Week[0]->orders); ?></td>
							<td>COMPLETED</td>

						  </tr>
						  <tr>
						    <td><?php echo json_encode($Week[1]->orders); ?></td>
							<td>CANCELLED</td>
						  </tr>
						   
						</table> 
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Status</th>									
										<th>Cancelled reasons</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Status</th>									
										<th>Cancelled reasons</th>									
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($WeekRe as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->Status }}</td>
										<td>{{ $rep->cancelReason }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
					 
				</div>
               <div class="tab-pane" id="3a">
			  
			          <a href="{{ route('out.status.rep',['id'=>3,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
			   
                      <table class="table_1">
						  <tr>
						    <th>Orders</th>
							<th>Status</th>							
							
						  </tr>
						  
						   <?php 
						  if(count($Month) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						
						  <tr>
							<td><?php echo json_encode($Month[0]->orders); ?></td>
							<td>COMPLETED</td>

						  </tr>
						  <tr>
						    <td><?php echo json_encode($Month[1]->orders); ?></td>
							<td>CANCELLED</td>
						  </tr>
						   
						</table> 
						
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Monthly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Status</th>									
										<th>Cancelled reasons</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Status</th>									
										<th>Cancelled reasons</th>									
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($MonthRep as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->Status }}</td>
										<td>{{ $rep->cancelReason }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
            <div class="tab-pane" id="4a">
			
			          <a href="{{ route('out.status.rep',['id'=>4,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                    
					<table class="table_1">
						  <tr>
						    <th>Orders</th>
							<th>Status</th>							
							
						  </tr>
						  
						   <?php 
						  if(count($Year) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						
						  <tr>
							<td><?php echo json_encode($Year[0]->orders); ?></td>
							<td>COMPLETED</td>

						  </tr>
						  <tr>
						    <td><?php echo json_encode($Year[1]->orders); ?></td>
							<td>CANCELLED</td>
						  </tr>
						   
						</table>
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Yearly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Status</th>									
										<th>Cancelled reasons</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Status</th>									
										<th>Cancelled reasons</th>									
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($YearRep as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->Status }}</td>
										<td>{{ $rep->cancelReason }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
				
				<div class="tab-pane" id="5a">
				  
						  
					<form method="post" id="Search_report" action ="{{ route('war.outstatus.down') }}" enctype="multipart/form-data">
					   {{ csrf_field() }}
					      <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_status2" name="fromdate" id="statusfrom" type="date"/>
							  <span class="error status_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_status2" name="todate" id="statusto" type="date"/>
							  <span class="error status_to">Please select date</span>
                           </div>
						  </div>
						  <input type="hidden" name="outletId" id="outletId" value="<?php echo $id ?>">
						  <div class="col-md-3">
							 <div class="form-group">
								<label class="control-label">
                                Typs
                              <small>*</small>
                              </label>
								<select  class="form-control custom_graph_status2" id="typeId" name="typeId">
									 <option value="">Select type</option>
									
                                      <option value="COMPLETED">COMPLETED</option>
                                      <option value="CANCELLED">CANCELLED</option>
								</select>
							 </div>
						   </div>
						  
						  <div class="col-md-3">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>BookingId</th>
						    <th>BookingD date</th>
							<th>Status</th>							
							<th>Cancelled reason</th>							
							<th>Actions</th>							
						  </tr>
						
                           
						    <tbody id="orderstatus_report">
                                  <td colspan="5">No record</td>
                            </tbody>
						   
						 
						  
						</table> 	  
				  
			      	</div>
			     </div>
               </div>

					 </div>
					 </div>
				   </div>
					   
					   
					
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		$('.active-report').addClass('active');
		
		var id = $('#outletId').val();
		$.get("{{route('war.order.statusgraph')}}?id="+id)
	  .done(function(data) {
		
		// console.log(data);
			demo.SuccessGraph(data);
							
		});	
		
	
		
		
    });
</script>

@endsection