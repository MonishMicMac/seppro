@extends('layouts.warehouse')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-12">
                             <h4 class="title">Promo code vs orders</h4>
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="HighestOrder"></div>
                                </div>
								<input type="hidden" value="<?php echo $id ?>" id="outletId">
                                <div class="card-content">
                                   <div class="col-md-12">
								   <h4 class="title">Promo code summary</h4>
								     <table class="table_1">
										  <tr>
											<th>Bookings</th>
											<th>Promo code</th>
											<th>Total amount</th>							
											<th>Discount amount</th>													
										  </tr>
										   <?php 
										  if(count($summary) == 0){
											 ?> 
											   <tr>
											   <td colspan="4">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  @foreach($summary as $date)
										  <tr>
											<td>{{ $date->orders }}</td>
											<td>{{ $date->promocode }}</td>							
											<td>{{ $date->total }}</td>							
											<td>{{ $date->discount }}</td>							
										  </tr>
										   @endforeach
										</table>
								   </div>
                                </div>
                            </div>
                         					   
					  
                         </div>					   
					   </div>
					   
					   
					   
					   
					   <div class="row">
				     <div class="col-md-12">
					 <div class="box_shadow box_shadow2">
					  <h4 class="yellowtext">Reports</h4> 
        <div id="exTab1">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab" value="1" class="get_promo_status">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab" value="2" class="get_promo_status">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab" value="3" class="get_promo_status">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab" value="4" class="get_promo_status">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab" value="5" class="get_promo_status">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
			     
				 <a href="{{ route('war.promo.down',['id'=>1,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">  
						   Download report
						   <div class="ripple-container"></div>
						</a>
			  
                   <table class="table_1">
						  <tr>
						    <th>Promocode</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						   <?php 
						  if(count($Day) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Day as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->code }}</td>
							<td>{{ $OrderDay->orders }}</td>							
							<td>{{ $OrderDay->qty }}</td>
							<td>{{ $OrderDay->total }}</td>
                           
						  </tr>
						   @endforeach
						</table>   
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Promo code</th>
										<th>Status</th>									
			
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Promo code</th>									
										<th>Status</th>									
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Days as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->code }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('outlet.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
				<div class="tab-pane" id="2a">
                     <a href="{{ route('war.promo.down',['id'=>2,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">  
						   Download report
						   <div class="ripple-container"></div>
						</a>
                   <table class="table_1">
						  <tr>
						    <th>Promocode</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						   <?php 
						  if(count($Week) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Week as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->code }}</td>
							<td>{{ $OrderDay->orders }}</td>							
							<td>{{ $OrderDay->qty }}</td>
							<td>{{ $OrderDay->total }}</td>
                           
						  </tr>
						   @endforeach
						</table>  
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Promo code</th>
										<th>Status</th>									
			
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Promo code</th>									
										<th>Status</th>									
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Weekly as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->code }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('outlet.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
					 
				</div>
               <div class="tab-pane" id="3a">
			   <a href="{{ route('war.promo.down',['id'=>3,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">  
						   Download report
						   <div class="ripple-container"></div>
						</a>
                    <table class="table_1">
						  <tr>
						    <th>Promocode</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						   <?php 
						  if(count($Month) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Month as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->code }}</td>
							<td>{{ $OrderDay->orders }}</td>							
							<td>{{ $OrderDay->qty }}</td>
							<td>{{ $OrderDay->total }}</td>
                           
						  </tr>
						   @endforeach
						</table>  

						 <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Monthly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Promo code</th>
										<th>Status</th>									
			
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Promo code</th>									
										<th>Status</th>									
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Monthly as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->code }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('outlet.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
            <div class="tab-pane" id="4a">
			<a href="{{ route('war.promo.down',['id'=>4,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">  
						   Download report
						   <div class="ripple-container"></div>
						</a>
                    <table class="table_1">
						  <tr>
						    <th>Promocode</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						   <?php 
						  if(count($Year) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Year as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->code }}</td>
							<td>{{ $OrderDay->orders }}</td>							
							<td>{{ $OrderDay->qty }}</td>
							<td>{{ $OrderDay->total }}</td>
                           
						  </tr>
						   @endforeach
						</table>  
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Yearly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Promo code</th>
										<th>Status</th>									
			
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Promo code</th>									
										<th>Status</th>									
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Yearly as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->bookingDate }}</td>
										<td>{{ $rep->code }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('outlet.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
				      </div>
				 
				       <div class="tab-pane" id="5a">
					   
					       <form method="post" id="Search_report" action ="{{ route('war.searchpromo.down') }}" enctype="multipart/form-data">
					   {{ csrf_field() }}
					      <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_promo" name="fromdate" id="promofrom" type="date"/>
							  <span class="error promo_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_promo" name="todate" id="promoto" type="date"/>
							  <span class="error promo_to">Please select date</span>
                           </div>
						  </div>
						  <input type="hidden" name="outletId" value="<?php echo $id ?>" id="outletId">
						  <div class="col-md-3">
							 <div class="form-group">
								<label class="control-label">
                                Promo code
                              <small>*</small>
                              </label>
								<select  class="form-control custom_graph_promo" id="promoId" name="promoId">
									<option value="">Select promo code</option>
									@foreach($Promo as $code)
									
                                      <option value="{{ $code->id }}"> {{ $code->promocode }} </option>
									@endforeach
								</select>
							 </div>
						   </div>
						  
						  <div class="col-md-3">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>BookingId</th>
							<th>Booking date</th>							
							<th>Promo code</th>
							<th>Status</th>
							<th>Actions</th>
						  </tr>
						
                           
						    <tbody id="promo_report">
                                  <td colspan="5">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
					       
					   
					   </div>
				
				
				
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		$('.active-report').addClass('active');
		$.get("{{route('war.promo.graph')}}")
	  .done(function(data) {

			demo.HighestOrderChart(data);
							
		});	
		
	
		
		
    });
</script>

@endsection