@extends('layouts.warehouse')

@section('content')


<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Users List</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Email</th>
										<th>DOB</th>
										<th>Gender</th>
										<th>Otp</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Email</th>
										<th>DOB</th>
										<th>Gender</th>
										<th>Otp</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($UserList as $List)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $List->name }}</td>
										<td>{{ $List->mobile }}</td>
										<td>{{ $List->email }}</td>
										<td>{{ $List->dob }}</td>
										<td>{{ $List->gender }}</td>
										<td>{{ $List->otp }}</td>


										<td class="text-right">
											<!--<a  data-toggle="modal" data-target="#Viewuser" class="btn btn-simple btn-warning btn-icon edit View_user" value="{{ $List->id }}" href="" id=""><i class="fa fa-pencil-square-o"></i></a>-->
											
											<a href="{{ route('outlet.users.details',[$List->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
											
											<a href="{{ route('outlet.wallet.trans',[$List->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-google-wallet"></i></a>
											
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


@endsection