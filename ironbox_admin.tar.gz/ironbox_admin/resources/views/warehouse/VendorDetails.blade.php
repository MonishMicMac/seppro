@extends('layouts.warehouse')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>

	<div class="container-fluid">
	  <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">{{ $VendorInfo->name }}</h4>
				</div>
				
				<div class="card-content">
				 
                  
                 <div class="box_shadow box_shadow2">
				   <h4 class="yellowtext">Vendor details</h4>
				    <div class="row">
                      <div class="col-md-6">
					    <div class="user_profile">
						   <img src="  <?php if($VendorInfo->image == ''){ echo "http://139.59.37.241/Ironman/public/images/pic.png"; }else{ echo $VendorInfo->image; } ?>" class="img-responsive center-block img-circle">
						    
						</div>
						
						<div class="urdetails">
						   <strong>Name :</strong> {{ $VendorInfo->name }}
						</div>
						
						<div class="urdetails">
						   <strong>Mobile :</strong> {{ $VendorInfo->mobile }}
						</div>

						<div class="urdetails">
						   <strong>Gender :</strong> {{ $VendorInfo->gender }}
						</div>
						
						<div class="urdetails">
						   <strong>Total jobs :</strong>{{ $jobs }}
						</div>
						
				     </div>

					 	
					 
					 
					 
				    </div>
				  </div>
	             
				   <div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="card">
							<div class="card-header" data-background-color="blue">
								<h4 class="title">Order History</h4>
							</div>

							<div class="card-content">
								<div class="material-datatables">
									<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
										<thead>
											<tr>
												<th>S.No</th>
												<th>BookingId</th>
												<th>Username</th>
												<th>BookingDate</th>
												<!--<th>TimeSlot</th>--->
												<th class="text-right">Actions</th>
											</tr>
										</thead>
										<tfoot>
											<tr>
												<th>S.No</th>
												<th>BookingId</th>
												<th>username</th>
												<th>BookingDate</th>
												<!--<th>TimeSlot</th>-->
												<th class="text-right">Actions</th>
											</tr>
										</tfoot>
										
										<tbody>
										 <?php   $count = 1; ?>
										@foreach($Bookings as $GetBookings)
											<tr>
												<td>{{$count++}}</td>
												<td>{{ $GetBookings->bookingId }}</td>
												<td>{{ $GetBookings->username }}</td>
												<td>{{ $GetBookings->bookingDate }}</td>
												<!---<td>{{ $GetBookings->bookingTimeSlot }}</td>-->
												

												<td class="text-right">
													<a href="{{ route('war.bookings',[$GetBookings->id]) }}" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
												</td>
											</tr>
										@endforeach
																						   
										</tbody>
										
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				  
				  
				
				
				</div>
				
	      </div>
	    </div>
	  </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
		$('.active-vendor').addClass('active');

    });
</script>
@endsection