@extends('layouts.warehouse')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-12">
                             
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="CategoryClothesRep"></div>
                                </div>
                                <div class="card-content">
                                   <h4 class="title">Clothes reports</h4>
                                </div>
								
								<div class="col-md-6">
							 <div class="form-group">
								 <label>Select category</label>   
								<select class="select_box" id="Main_Category" name="Main_Category"> 
								      <option value=""> select category </option>
                                       @foreach($category as $Cate)									  
                                      <option value="{{ $Cate->id }}"> {{ $Cate->name }} </option>
                                       @endforeach
								</select>
								<span class="main_cate error">Please select category</span>
                             <input type='hidden' value="{{ $cateId }}" id="cate_id">
                             <input type='hidden' value="{{ $id }}" id="outletId">
						   </div>
								
                            </div>
							
							<div class="col-md-6">
							 <div class="form-group">
								 <label>Select Type</label>   
								<select class="select_box" id="clothes_type" name="clothes_type">  
                                      <option value=""> select type </option> 								  
                                      <option value="1"> Day </option>
                                      <option value="2"> Weekly </option>
                                      <option value="3"> Monthly </option>
                                      <option value="4"> Yearly </option>
                                       
								</select>
								<span class="main_type error">Please select type</span>
                             
						   </div>
								
                            </div>
							
                            </div>
                         					   
					  
                         </div>					   
					   </div>
					   
					   
					 
					   
					   
					   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 <h4 class="yellowtext">Reports</h4>
					 
					   

        <div id="exTab1" class="">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab">Yearly</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
    
	                   <a href="{{ route('warhs.clothes.down',['id'=>1,'outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                  @foreach($Day as $OrderDay)
									  <tr>
										<td>{{ $count++ }}</td>
										<td>{{ $OrderDay->groupName }} / {{ $OrderDay->name }}</td>
										<td>{{ $OrderDay->orders }}</td>							
										<td>{{ $OrderDay->quantity }}</td>
										<td>{{ $OrderDay->amount }}</td>
									   
									  </tr>
									@endforeach											   
								</tbody>
							</table>
							</div>
							</div>
   
                       
 					
				</div>
				<div class="tab-pane" id="2a">
                     
					 <a href="{{ route('warhs.clothes.down',['id'=>2,'outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
					 
                  <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                  @foreach($Week as $OrderDay)
									  <tr>
										<td>{{ $count++ }}</td>
										<td>{{ $OrderDay->groupName }} / {{ $OrderDay->name }}</td>
										<td>{{ $OrderDay->orders }}</td>							
										<td>{{ $OrderDay->quantity }}</td>
										<td>{{ $OrderDay->amount }}</td>
									   
									  </tr>
									@endforeach											   
								</tbody>
							</table>
							</div>
							</div>  
					 
				</div>
               <div class="tab-pane" id="3a">
			   
			   <a href="{{ route('warhs.clothes.down',['id'=>3,'outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
			   
                     <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Monthly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                  @foreach($Month as $OrderDay)
									  <tr>
										<td>{{ $count++ }}</td>
										<td>{{ $OrderDay->groupName }} / {{ $OrderDay->name }}</td>
										<td>{{ $OrderDay->orders }}</td>							
										<td>{{ $OrderDay->quantity }}</td>
										<td>{{ $OrderDay->amount }}</td>
									   
									  </tr>
									@endforeach											   
								</tbody>
							</table>
							</div>
							</div> 
				</div>
                <div class="tab-pane" id="4a">
                   
				   <a href="{{ route('warhs.clothes.down',['id'=>4,'outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
				   
				   <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Yearly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                  @foreach($Year as $OrderDay)
									  <tr>
										<td>{{ $count++ }}</td>
										<td>{{ $OrderDay->groupName }} / {{ $OrderDay->name }}</td>
										<td>{{ $OrderDay->orders }}</td>							
										<td>{{ $OrderDay->quantity }}</td>
										<td>{{ $OrderDay->amount }}</td>
									   
									  </tr>
									@endforeach											   
								</tbody>
							</table>
							</div>
							</div>
				   
				</div>
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
   $(document).ready(function() {
		$('.active-report').addClass('active');
		
		var id = $('#cate_id').val();
		var outletId = $('#outletId').val();
		var type = 6;
		
		$.get("{{route('war.day.graph')}}?id="+id+"type="+type+"outletId="+outletId)
	  .done(function(data) {
			// console.log(data);

			demo.CategoryClothesRep(data);
		});
		
	
		
		
    });
</script>

@endsection