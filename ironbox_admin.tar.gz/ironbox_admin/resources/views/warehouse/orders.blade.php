@extends('layouts.warehouse')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Order List</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>User Name</th>
										<!--<th>Delivery Users</th>-->
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>User Name</th>
										<!--<th>Delivery Users</th>-->
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($Bookings as $BookingsList)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $BookingsList->bookingId }}</td>
										<td>{{ $BookingsList->name }}</td>
										<!--<td>{{ $BookingsList->deliveryusers }}</td>-->
										<td>{{ $BookingsList->bookingDate }}</td>
										<td>{{ $BookingsList->fromSlots }} -  {{ $BookingsList->toSlots }}</td>
										<td>{{ $BookingsList->Status }}  @if($BookingsList->cancelReason != null) / CANCELLED @endif</td>


										<td class="text-right">
											<a href="{{ route('war.bookings',[$BookingsList->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
								@endforeach
																				   
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
        $(document).ready(function () {
            $('.active-order').addClass('active');
        });
</script>
@endsection