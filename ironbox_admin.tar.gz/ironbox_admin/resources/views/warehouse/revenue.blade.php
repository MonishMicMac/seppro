@extends('layouts.warehouse')

@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Report</h4>
				</div>
				<div class="card-content">
				   <div class="row">
				        <div class="col-md-12">
						<h4 class="title">Order date vs total cost</h4>
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="orange">
                                    <div class="ct-chart" id="TotalRevenue"></div>
									<span class="graph_text">Cost</span>
									<span>Dates</span>
                                </div>
								<input type ='hidden' id="outletId" value="<?php echo $id; ?>">
                                <div class="card-content">
                                    <div class="col-md-12">
								   <h4 class="title">Total revenue summary</h4>
								     <table class="table_1">
										  <tr>
											<th>Bookings</th>
											<th>Total quantity</th>							
											<th>Total revenue</th>													
										  </tr>
										   <?php 
										  if(count($summary) == 0){
											 ?> 
											   <tr>
											   <td colspan="4">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  @foreach($summary as $date)
										  <tr>
											<td>{{ $date->booking }}</td>
											<td>{{ $date->revenue }}</td>							
											<td>{{ $date->quantity }}</td>							
										  </tr>
										   @endforeach
										</table>
								   </div>
                                </div>
							
                            </div>
                        </div>
				   </div>
				   
			    <div class="row">
				<div class="col-md-12">
				<div class="box_shadow box_shadow2">
				 <h4 class="yellowtext">Reports</h4>

				<div id="exTab1">
				   <ul  class="nav nav-pills">
					  <li class="active">
						 <a  href="#1a" data-toggle="tab" value="1" class="get_revenue_status">Today</a>
					  </li>
					  <li><a href="#2a" data-toggle="tab" value="2" class="get_revenue_status">Weekly</a>
					  </li>
					  <li><a href="#3a" data-toggle="tab" value="3" class="get_revenue_status">Monthly</a>
					  </li>
					  <li><a href="#4a" data-toggle="tab" value="4" class="get_revenue_status">Yearly</a></li>
					  <li><a href="#5a" data-toggle="tab" value="5" class="get_revenue_status">Custom</a></li>
				   </ul>
				   <div class="tab-content clearfix">
					  <div class="tab-pane active" id="1a">
					  <a href="{{ route('war.revenue.excel',['id'=>1,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
					     <table class="table_1">
						  <tr>
							<th>Bookings</th>							
							<th>Quantity</th>							
							<th>Total amount</th>
							
						  </tr>
						  
						  
						  @foreach($Days as $Order)
						  <tr>
							<td>{{ $Order->booking }}</td>						
							<td>{{ $Order->qty }}</td>						
							<td>{{ $Order->orders }}</td>
                           
						  </tr>
						   @endforeach
						</table> 
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>																			
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>								
										
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Day as $OrderDay)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $OrderDay->bookingId }}</td>
										<td>{{ $OrderDay->Status }}</td>
										<td class="text-right">
											 <a href="{{ route('view.bookings',[$OrderDay->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>							


									
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
					  </div>
					  <div class="tab-pane" id="2a">
					     <a href="{{ route('war.revenue.excel',['id'=>2,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						<table class="table_1">
						  <tr>
							<th>Bookings</th>							
							<th>Quantity</th>							
							<th>Total amount</th>
							
						  </tr>
						  
						   <?php 
						  if(count($Weekly) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Weekly as $Order)
						  <tr>
						    <td>{{ $Order->booking }}</td>	
							<td>{{ $Order->qty }}</td>						
							<td>{{ $Order->orders }}</td>
                           
						  </tr>
						   @endforeach
						</table> 
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>																			
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>								
										
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Week as $OrderDay)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $OrderDay->bookingId }}</td>
										<td>{{ $OrderDay->Status }}</td>
										<td class="text-right">
											 <a href="{{ route('view.bookings',[$OrderDay->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>							


									
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						 
					  </div>
					  <div class="tab-pane" id="3a">
					    <a href="{{ route('war.revenue.excel',['id'=>3,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						 <table class="table_1">
						  <tr>
							<th>Bookings</th>							
							<th>Quantity</th>							
							<th>Total amount</th>
							
						  </tr>
						  
						   <?php 
						  if(count($Monthly) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Monthly as $Order)
						  <tr>
						    <td>{{ $Order->booking }}</td>	
							<td>{{ $Order->qty }}</td>						
							<td>{{ $Order->orders }}</td>
                           
						  </tr>
						   @endforeach
						</table> 
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Monthly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>																			
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>								
										
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Month as $OrderDay)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $OrderDay->bookingId }}</td>
										<td>{{ $OrderDay->Status }}</td>
										<td class="text-right">
											 <a href="{{ route('view.bookings',[$OrderDay->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>							


									
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
					  </div>
					  <div class="tab-pane" id="4a">
					  <a href="{{ route('war.revenue.excel',['id'=>4,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
					     <table class="table_1">
						  <tr>
						  
							<th>Bookings</th>							
							<th>Quantity</th>							
							<th>Total amount</th>
							
						  </tr>
						  
						   <?php 
						  if(count($Yearly) == 0){
							 ?> 
							   <tr>
							   <td colspan="3">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Yearly as $Order)
						  <tr>
						  <td>{{ $Order->booking }}</td>	
							<td>{{ $Order->qty }}</td>						
							<td>{{ $Order->orders }}</td>
                           
						  </tr>
						   @endforeach
						</table> 
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Yearly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>																			
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>								
										
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Year as $OrderDay)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $OrderDay->bookingId }}</td>
										<td>{{ $OrderDay->Status }}</td>
										<td class="text-right">
											 <a href="{{ route('view.bookings',[$OrderDay->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>							


									
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
					  </div>
					  
					  
					  <div class="tab-pane" id="5a">
					  
					     <form method="post" id="Search_reports" action ="{{ route('war.revenue.down') }}" enctype="multipart/form-data">
					   {{ csrf_field() }}
					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_revenue" name="fromdate" id="revenuefrom" type="date"/>
							  <span class="error revenue_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_revenue" name="todate" id="revenueto" type="date"/>
							  <span class="error revenue_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>BookingID</th>
						    <th>Status</th>
						    <th>Actions</th>							
						  </tr>
						
                           
						    <tbody id="revenue_report">
                                  <td colspan="3">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
					  </div>
					  
				   </div>
				</div>
				   
		
				   
				</div>
				</div>
			</div>
		</div>		
	</div>
	
	
	
		
	</div>
</div>

<script type="text/javascript">
  $(document).ready(function() {
		
		$('.active-report').addClass('active');
		
		var id = $('#outletId').val();
		
		$.get("{{route('war.revenue.graph')}}?id="+id)
	  .done(function(data) {

			demo.TotalRevenue(data);
							
		});	
		
	
		
		
    });
</script>


@endsection