@extends('layouts.warehouse')
@section('content')
<div class="content">
<a  href="{{ URL::previous() }}" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-12">
                             <h4 class="title">Highest timeslot vs bookings</h4>
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="HighSlot"></div>
									<input type ='hidden' id="outletId" value="<?php echo $id; ?>">
                                </div>
                                <div class="card-content">
                                    <div class="col-md-12">
								   <h4 class="title">Time slots total summary</h4>
								     <table class="table_1">
										  <tr>
											<th>Time slots</th>
											<th>Total orders</th>							
											<th>Total quantity</th>							
											<th>Total amount</th>							
										  </tr>
										   <?php 
										  if(count($summary) == 0){
											 ?> 
											   <tr>
											   <td colspan="4">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  @foreach($summary as $date)
										  <tr>
											<td>{{ $date->fromSlots }} - {{ $date->toSlots }}</td>
											<td>{{ $date->booking }}</td>							
											<td>{{ $date->quantity }}</td>							
											<td>{{ $date->revenue }}</td>							
										   
										  </tr>
										   @endforeach
										</table>
								   </div>
                                </div>
                            </div>
                         					   
					  
                         </div>					   
					   </div>

					   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 <h4 class="yellowtext">Reports</h4> 
					 

        <div id="exTab1" class="">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab" value="1" class="get_time_value">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab" value="2" class="get_time_value">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab" value="3" class="get_time_value">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab" value="4" class="get_time_value">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab" value="5" class="get_time_value">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
			  
			  <a href="{{ route('outlet.time.report',['id'=>1,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
		
                     <table class="table_1">
						  <tr>
						    <th>TimeSlot</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php 
						  if(count($Day) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Day as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->fromSlots }} - {{ $OrderDay->toSlots }}</td>
							<td>{{ $OrderDay->orders }}</td>							
							<td>{{ $OrderDay->quantity }}</td>
							<td>{{ $OrderDay->total }}</td>
                           
						  </tr>
						   @endforeach
						</table> 
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>TimeSlot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Dayrep as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->fromSlots }} - {{ $rep->toSlots }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
				<div class="tab-pane" id="2a">
				<a href="{{ route('outlet.time.report',['id'=>2,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     
					 <table class="table_1">
						  <tr>
						    <th>TimeSlot</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php 
						  if(count($Week) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Week as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->fromSlots }} - {{ $OrderDay->toSlots }}</td>
							<td>{{ $OrderDay->orders }}</td>							
							<td>{{ $OrderDay->quantity }}</td>
							<td>{{ $OrderDay->total }}</td>
                           
						  </tr>
						   @endforeach
						</table>  
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>TimeSlot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Weekrep as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->fromSlots }} - {{ $rep->toSlots }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
               <div class="tab-pane" id="3a">
			   <a href="{{ route('outlet.time.report',['id'=>3,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     <table class="table_1">
						  <tr>
						    <th>TimeSlot</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php 
						  if(count($Month) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Month as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->fromSlots }} - {{ $OrderDay->toSlots }}</td>
							<td>{{ $OrderDay->orders }}</td>							
							<td>{{ $OrderDay->quantity }}</td>
							<td>{{ $OrderDay->total }}</td>
                           
						  </tr>
						   @endforeach
						</table> 
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Monthly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>TimeSlot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Monthrep as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->fromSlots }} - {{ $rep->toSlots }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
            <div class="tab-pane" id="4a">
			<a href="{{ route('outlet.time.report',['id'=>4,'type'=>'normal','outletId'=>$id]) }}" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     <table class="table_1">
						  <tr>
						    <th>TimeSlot</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php 
						  if(count($Year) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  @foreach($Year as $OrderDay)
						  <tr>
							<td>{{ $OrderDay->fromSlots }} - {{ $OrderDay->toSlots }}</td>
							<td>{{ $OrderDay->orders }}</td>							
							<td>{{ $OrderDay->quantity }}</td>
							<td>{{ $OrderDay->total }}</td>
                           
						  </tr>

						   @endforeach
						</table>
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				        <h4 class="yellowtext">Yearly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>TimeSlot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 @foreach($Yearrep as $rep)
									<tr>
										<td>{{$count++}}</td>
										<td>{{ $rep->bookingId }}</td>
										<td>{{ $rep->fromSlots }} - {{ $rep->toSlots }}</td>
										<td>{{ $rep->Status }}</td>


										<td class="text-right">
											 <a href="{{ route('view.bookings',[$rep->id]) }}" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           @endforeach
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				      </div>
					  
					  <div class="tab-pane" id="5a">
					  
					     <form method="post" id="Search_report" action ="{{ route('war.slot.down') }}" enctype="multipart/form-data">
					   {{ csrf_field() }}
					      <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_time" name="fromdate" id="Slotsfrom" type="date"/>
							  <span class="error slots_from">Please select date</span>
                           </div>
						  </div>
						  
						  <input type ='hidden' id="outletId" name="outletId" value="<?php echo $id; ?>">
						  <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_time" name="todate" id="Slotsto" type="date"/>
							  <span class="error slots_to">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-3">
							 <div class="form-group">
								<label class="control-label">
                                TimeSlots
                              <small>*</small>
                              </label>
								<select  class="form-control custom_graph_time" id="timeId" name="timeId">
									<option value="">Select TimeSlots</option>
									@foreach($Slot as $time)
									
                                      <option value="{{ $time->id }}"> {{ $time->fromSlots }} - {{ $time->toSlots }} </option>
									@endforeach
								</select>
							 </div>
						   </div>
						  
						  <div class="col-md-3">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>BookingId</th>
							<th>TimeSlot</th>							
							<th>Status</th>
							<th>Actions</th>
						  </tr>
						
                           
						    <tbody id="Time_report">
                                  <td colspan="4">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
					  </div>
					  
			      </div>
               </div>

					 </div>
					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		$('.active-report').addClass('active');
		
		var id = $('#outletId').val();
		$.get("{{route('war.slot.graph')}}?id="+id)
	  .done(function(data) {
			demo.HighSlot(data);
							
		});	

    });
</script>

@endsection