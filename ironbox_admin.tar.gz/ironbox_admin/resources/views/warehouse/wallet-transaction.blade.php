@extends('layouts.warehouse')

@section('content')


<div class="content">
	<div class="container-fluid">
	<div class="row">
		<!--<div class="col-lg-12 col-md-12">
		   <a href="{{ url('UserWalletReport/' . $id . '') }}" class="btn btn-primary down_btn">
			   Download report
			   <div class="ripple-container"></div>
			</a> 
		</div>-->		
	</div>
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Users wallet transctions</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>OrderId </th>
										<th>TransactionId</th>
										<th>bookingId</th>
										<th>Amount</th>
										<th>Status</th>
										<th>Type</th>
										<th>Payment date</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>OrderId </th>
										<th>TransactionId</th>
										<th>bookingId</th>
										<th>Amount</th>
										<th>Status</th>
										<th>Type</th>
										<th>Payment date</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								@foreach($Transc as $List)
									<tr>
										<td>{{ $count++ }}</td>
										<td>{{ $List->orderId }}</td>
										<td>{{ $List->transactionId }}</td>
										<td>{{ $List->bookingId }}</td>
										<td>{{ $List->amount }}</td>
										<td>{{ $List->transation_status }}</td>
										<td>{{ $List->type }}</td>
										<td>{{ $List->payment_date }}</td>
									</tr>
							@endforeach
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		$('.nav-active').addClass('active');

	
		
		
    });
</script>


@endsection