@extends('layouts.warehouse')

@section('content')
<div class="content">
   <div class="container-fluid">
       <div class="row">
			
		<div class="col-lg-3 col-md-6 col-sm-6">
		<a href="{{ route('outlet.users') }}">
			<div class="card card-stats">
				<div class="card-header" data-background-color="orange">
					 <i class="fa fa-users"></i>
				</div>

				<?php   $id; ?>
				<input type ='hidden' id="outletId" value="<?php echo $id; ?>">   
				<div class="card-content">
					<p class="category">Users</p>
					<h3 class="title">{{ $Users }}
					</h3>
				</div>
			</div>
			</a>
		</div>	


           <div class="col-lg-3 col-md-6 col-sm-6">
			<a href="{{ route('war.pickupuser.list') }}">
				<div class="card card-stats">
					<div class="card-header" data-background-color="green">
						<i class="material-icons">store</i>
					</div>
					<div class="card-content">
						<p class="category">Pickup users</p>
						<h3 class="title">{{ $PickupUser }}</h3>
					</div>
				</div>
				</a>
			</div>	

            <div class="col-lg-3 col-md-6 col-sm-6">
				<a href="{{ route('out.ironing.vendor') }}">
					<div class="card card-stats">
						<div class="card-header" data-background-color="red">
							<i class="material-icons">info_outline</i>
						</div>
						<div class="card-content">
							<p class="category">Ironing vendor</p>
							<h3 class="title">{{ $Ironing }}</h3>
						</div>
					</div>
					</a>
				</div>	

               <div class="col-lg-3 col-md-6 col-sm-6">
				<a href="{{ route('war.order.list') }}">
					<div class="card card-stats">
						<div class="card-header" data-background-color="blue">
							<i class="fa fa-list-ul"></i>
						</div>
						<div class="card-content">
							<p class="category">Total orders</p>
							<h3 class="title">{{ $total_booking }}</h3>
						</div>
					</div>
					</a>
				</div>	

                <div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('war.order.list') }}">
                            <div class="card card-stats ">
                                <div class="card-header" data-background-color="blue">
                                    <i class="fa fa-list-ul"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Completed orders</p>
                                    <h3 class="title">{{ $Bookings }}</h3>
                                </div>
                            </div>
							</a>
                        </div>	
						
						
						<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('war.order.list') }}">
                            <div class="card card-stats ">
                                <div class="card-header" data-background-color="blue">
                                    <i class="fa fa-list-ul"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Pending orders</p>
                                    <h3 class="title">{{ $pending }}</h3>
                                </div>
                            </div>
							</a>
                        </div>
						
						<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="{{ route('war.order.list') }}">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="blue">
                                    <i class="fa fa-list-ul"></i>
                                </div>
                                <div class="card-content con2">
                                    <p class="category">Cancelled orders</p>
                                    <h3 class="title">{{ $cancelled }}</h3>
                                </div>
                            </div>
							</a>
                        </div>
                 <div class="clearfix"></div>						

               <div class="row">
                     <div class="col-md-6">  
					   <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="dailySales"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Daily sales clothes vs quantity</h4>
                                </div>
                            </div>
                     </div>
					 
					 
					 <div class="col-md-6">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="PaymentTypeChart"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Daily payment type</h4>
                                </div>
                            </div>
                        </div>
						
					   <div class="clearfix"></div>
					    <div class="col-md-6">
                             
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="MostBooking"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Most booking user</h4>
                                </div>
                            </div>
                         					   
					  
                         </div>	

                       <div class="col-md-6">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="dailySalesRevenue"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Daily sales clothes vs amount</h4>
                                </div>
                                </div>
                            </div>						 
					
					 
               </div>

               <div class="row">
					      <div class="col-md-12">
                            <div class="card"> 
                                <div class="card-content center">
								   <h4 class="title">Clothes report</h4>
								<div id="clothes_chart"></div>
                                   
                                </div>
                                </div>  
                            </div>
					   
					   </div>			   
					
       </div>
   </div>
</div>

<script>
var id = $('#outletId').val();
$.get("{{route('war.outlet.piechart')}}?id="+id)

	  .done(function(reponse) {
		  
		  console.log(reponse);
			
			var newdata = reponse;
			
		  
	var pie = new d3pie("clothes_chart", {
		// header: {
			// title: {
				// text: "Clothes Reports"
			// }
		// },
		size: {
			pieOuterRadius: "100%",
			canvasHeight: 400
		},
		data: {
			content: newdata
		}
	});
	
	
	});
</script>

<script>

        $(document).ready(function () {
            $('.active-board').addClass('active');

			var id = $('#outletId').val();
			
			$.get("{{route('war.outlet.sales')}}?id="+id)
			  .done(function(data) {				
					demo.SalesChart(data);

				});	
				
				$.get("{{route('war.outlet.payment')}}?id="+id)
			  .done(function(data) {
				
					demo.PaymentTypeChart(data);
				
				});	
				
				$.get("{{route('war.outlet.most.order')}}?id="+id)
			  .done(function(data) {
					
					demo.MostBooking(data);
									
				});	
				
				$.get("{{route('war.outlet.cloth.graph')}}?id="+id)
			  .done(function(data) {
					demo.ClothRevenue(data);  
									
				});	
				
				});	

</script>				
@endsection
