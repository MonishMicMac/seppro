<?php




Route::post('AccessLogin','Api\IroningVendorController@AccessLogin');

Route::post('AccessLoginUser','Api\IroningVendorController@AccessLoginUser')->middleware('auth:IroningVendorapi');



Route::post('VendorLogin','Api\IroningVendorController@VendorLogin')->name('VendorLogin');
Route::post('VendorCheckOtp','Api\IroningVendorController@VendorCheckOtp')->name('VendorCheckOtp');
Route::post('ResentOtp','Api\IroningVendorController@ResentOtp')->name('ResentOtp');
Route::post('EditProfile','Api\IroningVendorController@EditVendorProfile')->middleware('auth:IroningVendorapi');
Route::post('Home','Api\IroningVendorController@Home')->middleware('auth:IroningVendorapi');
Route::post('ViewItems','Api\IroningVendorController@ViewItems')->middleware('auth:IroningVendorapi');
Route::post('StartJob','Api\IroningVendorController@StartJob')->middleware('auth:IroningVendorapi');  
Route::post('CurrentOrder','Api\IroningVendorController@CurrentOrder')->middleware('auth:IroningVendorapi');  
Route::post('GetOrders','Api\IroningVendorController@GetOrders')->middleware('auth:IroningVendorapi');  
Route::post('ScanOrder','Api\IroningVendorController@ScanOrder')->middleware('auth:IroningVendorapi');  
Route::post('OrderHistory','Api\IroningVendorController@OrderHistory')->middleware('auth:IroningVendorapi');  
Route::post('ContentPages','Api\IroningVendorController@ContentPages')->middleware('auth:IroningVendorapi');  
Route::post('VendorSupport','Api\IroningVendorController@VendorSupport')->middleware('auth:IroningVendorapi');  
Route::post('UploadBill','Api\IroningVendorController@UploadBill')->middleware('auth:IroningVendorapi');  
Route::post('logout','Api\IroningVendorController@logout')->middleware('auth:IroningVendorapi');  




?>