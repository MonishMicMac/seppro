<?php



Route::post('AdminLogin','Api\UserLoginController@AdminLogin')->name('adminlogin');
Route::post('AdminDsahboard','Api\UserLoginController@AdminDsahboard')->middleware('auth:admin');

?>