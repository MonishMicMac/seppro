<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});



Route::post('UserDashboard','Api\UserLoginController@UserDashboard')->middleware('auth:api');
Route::post('LoginAccess','Api\UserLoginController@LoginAccess')->name('LoginAccess');
Route::post('DemoOrder','Api\UserLoginController@DemoOrder')->name('DemoOrder');

Route::post('Categories','Api\UserLoginController@Categories')->name('Categories');



Route::post('UserLogin','Api\UserLoginController@UserLogin')->name('UserLogin');
Route::post('UserCheckOpt','Api\UserLoginController@UserCheckOpt')->name('UserCheckOpt');
Route::post('ResentOtp','Api\UserLoginController@ResentOtp')->name('UserCheckOpt');
Route::post('RateCard','Api\UserLoginController@RateCard')->middleware('auth:api');
Route::post('Home','Api\UserLoginController@Home')->middleware('auth:api');
Route::post('UserDetails','Api\UserLoginController@UserDetails')->middleware('auth:api');
Route::post('CheckPincode','Api\UserLoginController@CheckPincode')->middleware('auth:api');
Route::post('Pincode','Api\UserLoginController@Pincode')->middleware('auth:api');
Route::post('EditUserProfile','Api\UserLoginController@EditUserProfile')->middleware('auth:api');
Route::post('UserBooking','Api\UserLoginController@UserBooking')->middleware('auth:api');
Route::post('AddAddresses','Api\UserLoginController@AddAddresses')->middleware('auth:api');
Route::post('GetAddress','Api\UserLoginController@GetAddress')->middleware('auth:api');
Route::post('GetTimeSlots','Api\UserLoginController@GetTimeSlots');
Route::post('GetTimeSlots_test','Api\UserLoginController@GetTimeSlots_test');
Route::post('DeleteAddress','Api\UserLoginController@DeleteAddress')->middleware('auth:api');
Route::post('EditAddress','Api\UserLoginController@EditAddress')->middleware('auth:api');
Route::post('UserOrderList','Api\UserLoginController@UserOrderList')->middleware('auth:api');
Route::post('OrderCancel','Api\UserLoginController@OrderCancel')->middleware('auth:api');
Route::post('BookingHistory','Api\UserLoginController@BookingHistory')->middleware('auth:api');
Route::post('ViewItems','Api\UserLoginController@ViewItems')->middleware('auth:api');
Route::post('CustomerSupport','Api\UserLoginController@CustomerSupport')->middleware('auth:api');
Route::post('CancelReason','Api\UserLoginController@CancelReason')->middleware('auth:api');
Route::post('Rating','Api\UserLoginController@Rating')->middleware('auth:api');
Route::post('AddWallet','Api\UserLoginController@AddWallet')->middleware('auth:api');
Route::post('WalletAmount','Api\UserLoginController@WalletAmount')->middleware('auth:api');
Route::post('WalletTransaction','Api\UserLoginController@WalletTransaction')->middleware('auth:api'); 
Route::post('CardPayment','Api\UserLoginController@CardPayment')->middleware('auth:api'); 
Route::post('WalletPayment','Api\UserLoginController@WalletPayment')->middleware('auth:api'); 
Route::post('CheckReferral','Api\UserLoginController@CheckReferral')->middleware('auth:api');
Route::post('GenerateCheckSum','Api\UserLoginController@GenerateCheckSum')->middleware('auth:api');
Route::post('VerifyChecksum','Api\UserLoginController@VerifyChecksum')->middleware('auth:api');
Route::post('GetOrderId','Api\UserLoginController@GetOrderId')->middleware('auth:api');
Route::post('Payment','Api\UserLoginController@Payment')->middleware('auth:api');
Route::post('UserPromocode','Api\UserLoginController@UserPromocode')->middleware('auth:api');
Route::post('ValidPromocode','Api\UserLoginController@ValidPromocode')->middleware('auth:api');
Route::post('Packages','Api\UserLoginController@Packages')->middleware('auth:api');
Route::post('packagesPayment','Api\UserLoginController@packagesPayment')->middleware('auth:api');
Route::post('MyPackages','Api\UserLoginController@MyPackages')->middleware('auth:api');
Route::post('MyPackageTransactions','Api\UserLoginController@MyPackageTransactions')->middleware('auth:api');
Route::post('logout','Api\UserLoginController@logout')->middleware('auth:api');


Route::post('CheckPush','Api\UserLoginController@CheckPush')->middleware('auth:api');
Route::post('CheckTime','Api\UserLoginController@CheckTime')->middleware('auth:api');
Route::post('TestOpt','Api\UserLoginController@TestOpt')->middleware('auth:api');
Route::post('ContentPages', 'Api\UserLoginController@ContentPages')->middleware('auth:api'); 


Route::post('EmailCheck','Api\UserLoginController@EmailCheck')->middleware('auth:api');


Route::post('SortMethod','Api\UserLoginController@SortMethod');
Route::post('AdminFunction','Api\UserLoginController@AdminFunction');




/********************APP VERSION 2*********************/

Route::prefix('v2')->group(function(){
	
    Route::post('UserLogin','Api\v2\UserLoginController@UserLogin')->name('UserLogin');
	Route::post('UserCheckOpt','Api\v2\UserLoginController@UserCheckOpt')->name('UserCheckOpt');
	Route::post('RateCard','Api\v2\UserLoginController@RateCard')->middleware('auth:api');
	Route::post('Home','Api\v2\UserLoginController@Home')->middleware('auth:api');
	Route::post('UserDetails','Api\v2\UserLoginController@UserDetails')->middleware('auth:api');
	Route::post('CheckPincode','Api\v2\UserLoginController@CheckPincode')->middleware('auth:api');
	Route::post('Pincode','Api\v2\UserLoginController@Pincode')->middleware('auth:api');
	Route::post('EditUserProfile','Api\v2\UserLoginController@EditUserProfile')->middleware('auth:api');
	Route::post('UserBooking','Api\v2\UserLoginController@UserBooking')->middleware('auth:api');
	Route::post('AddAddresses','Api\v2\UserLoginController@AddAddresses')->middleware('auth:api');
	Route::post('GetAddress','Api\v2\UserLoginController@GetAddress')->middleware('auth:api');
	Route::post('GetTimeSlots','Api\v2\UserLoginController@GetTimeSlots');
	Route::post('DeleteAddress','Api\v2\UserLoginController@DeleteAddress')->middleware('auth:api');
	Route::post('EditAddress','Api\v2\UserLoginController@EditAddress')->middleware('auth:api');
	Route::post('UserOrderList','Api\v2\UserLoginController@UserOrderList')->middleware('auth:api');
	Route::post('OrderCancel','Api\v2\UserLoginController@OrderCancel')->middleware('auth:api');
	Route::post('BookingHistory','Api\v2\UserLoginController@BookingHistory')->middleware('auth:api');
	Route::post('ViewItems','Api\v2\UserLoginController@ViewItems')->middleware('auth:api');
	Route::post('CustomerSupport','Api\v2\UserLoginController@CustomerSupport')->middleware('auth:api');
	Route::post('CancelReason','Api\v2\UserLoginController@CancelReason')->middleware('auth:api');
	Route::post('Rating','Api\v2\UserLoginController@Rating')->middleware('auth:api');
	Route::post('AddWallet','Api\v2\UserLoginController@AddWallet')->middleware('auth:api');
	Route::post('WalletAmount','Api\v2\UserLoginController@WalletAmount')->middleware('auth:api');
	Route::post('WalletTransaction','Api\v2\UserLoginController@WalletTransaction')->middleware('auth:api'); 
	Route::post('CardPayment','Api\v2\UserLoginController@CardPayment')->middleware('auth:api'); 
	Route::post('WalletPayment','Api\v2\UserLoginController@WalletPayment')->middleware('auth:api'); 
	Route::post('CheckReferral','Api\v2\UserLoginController@CheckReferral')->middleware('auth:api');
	Route::post('GenerateCheckSum','Api\v2\UserLoginController@GenerateCheckSum')->middleware('auth:api');
	Route::post('VerifyChecksum','Api\v2\UserLoginController@VerifyChecksum')->middleware('auth:api');
	Route::post('GetOrderId','Api\v2\UserLoginController@GetOrderId')->middleware('auth:api');
	Route::post('Payment','Api\v2\UserLoginController@Payment')->middleware('auth:api');
	Route::post('UserPromocode','Api\v2\UserLoginController@UserPromocode')->middleware('auth:api');
	Route::post('ValidPromocode','Api\v2\UserLoginController@ValidPromocode')->middleware('auth:api');
	Route::post('logout','Api\v2\UserLoginController@logout')->middleware('auth:api');

   Route::post('testapi','Api\v2\UserLoginController_1@testapi')->name('testapi');

});






