<?php




//Route::post('deliveryuser','Api\UserLoginController@deliveryuser')->middleware('auth:pickupdeliveryuserapi');


Route::post('DeliveryUserLogin','Api\DeliveryUserController@DeliveryUserLogin')->name('DeliveryUserLogin');
Route::post('DeliveryUserCheckOpt','Api\DeliveryUserController@DeliveryUserCheckOpt')->name('DeliveryUserCheckOpt');
Route::post('ResentOtp','Api\DeliveryUserController@ResentOtp')->name('ResentOtp');
Route::post('EditProfile','Api\DeliveryUserController@EditProfile')->middleware('auth:pickupdeliveryuserapi');
Route::post('Categories','Api\DeliveryUserController@Categories')->middleware('auth:pickupdeliveryuserapi');
Route::post('OrderList','Api\DeliveryUserController@OrderList')->middleware('auth:pickupdeliveryuserapi');  
Route::post('MapView','Api\DeliveryUserController@MapView')->middleware('auth:pickupdeliveryuserapi');  
Route::post('UserDetails','Api\DeliveryUserController@UserDetails')->middleware('auth:pickupdeliveryuserapi');  
Route::post('BookingItems','Api\DeliveryUserController@BookingItems')->middleware('auth:pickupdeliveryuserapi');  
Route::post('OrderHistory','Api\DeliveryUserController@OrderHistory')->middleware('auth:pickupdeliveryuserapi');  
Route::post('PickupDeliveryStart','Api\DeliveryUserController@PickupDeliveryStart')->middleware('auth:pickupdeliveryuserapi');  
Route::post('DeliverySuccess','Api\DeliveryUserController@DeliverySuccess')->middleware('auth:pickupdeliveryuserapi'); 
Route::post('PrintView','Api\DeliveryUserController@PrintView')->middleware('auth:pickupdeliveryuserapi');   
Route::post('CashCollect','Api\DeliveryUserController@CashCollect')->middleware('auth:pickupdeliveryuserapi');  
Route::post('PayByWallet','Api\DeliveryUserController@PayByWallet')->middleware('auth:pickupdeliveryuserapi');  
Route::post('WalletCash','Api\DeliveryUserController@WalletCash')->middleware('auth:pickupdeliveryuserapi');  
Route::post('GetOrders','Api\DeliveryUserController@GetOrders')->middleware('auth:pickupdeliveryuserapi');  
Route::post('ContentPages','Api\DeliveryUserController@ContentPages')->middleware('auth:pickupdeliveryuserapi');  
Route::post('CustomerSupport','Api\DeliveryUserController@CustomerSupport')->middleware('auth:pickupdeliveryuserapi');  
Route::post('PrintOrder','Api\DeliveryUserController@PrintOrder')->middleware('auth:pickupdeliveryuserapi');  
Route::post('Rating','Api\DeliveryUserController@Rating')->middleware('auth:pickupdeliveryuserapi');  
Route::post('logout','Api\DeliveryUserController@logout')->middleware('auth:pickupdeliveryuserapi');  


Route::post('PushNote','Api\DeliveryUserController@PushNote')->middleware('auth:pickupdeliveryuserapi'); 
Route::post('Qrcode','Api\DeliveryUserController@Qrcode'); 
Route::post('AssignOrder','Api\DeliveryUserController@AssignOrder'); 
Route::post('PushNotifications','Api\DeliveryUserController@PushNotifications'); 
Route::post('OrderListDistance','Api\DeliveryUserController@OrderListDistance')->middleware('auth:pickupdeliveryuserapi'); 
Route::post('SortDistance','Api\DeliveryUserController@SortDistance');
Route::post('SortRoute','Api\DeliveryUserController@SortRoute');



Route::prefix('v2')->group(function(){
	
	Route::post('BookingItems','Api\v2\DeliveryUserController@BookingItems')->middleware('auth:pickupdeliveryuserapi'); 
	Route::post('DeliverySuccess','Api\v2\DeliveryUserController@DeliverySuccess')->middleware('auth:pickupdeliveryuserapi'); 
	
});

?>