<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('/', 'Auth\AdminLoginController@showLoginForm')->name('admin.login');


Route::prefix('admin')->group(function(){
  Route::get('/login', 'Auth\AdminLoginController@showLoginForm')->name('admin.login');
  Route::post('/login', 'Auth\AdminLoginController@login')->name('admin.login.submit');
  Route::get('/', 'AdminController@index')->name('admin.dashboard');
  Route::post('logout', 'Auth\AdminLoginController@logout')->name('admin.logout');
});

Route::prefix('manager')->group(function(){
  Route::get('/login', 'Auth\ManagerLoginController@showLoginForm')->name('manager.login');
  Route::post('/login', 'Auth\ManagerLoginController@login')->name('manager.login.submit');
  Route::get('/', 'ManagerController@index')->name('manager.dashboard');
  Route::post('logout', 'Auth\ManagerLoginController@logout')->name('manager.logout');
});

Route::prefix('outlet')->group(function(){
  Route::get('/login', 'Auth\WarehousesLoginController@showLoginForm')->name('outlet.login');
  Route::post('/login', 'Auth\WarehousesLoginController@login')->name('outlet.login.submit');
  Route::get('/view', 'WarehousesController@index')->name('outlet.dashboard');
  Route::post('logout', 'Auth\WarehousesLoginController@logout')->name('outlet.logout');
});


//Bookings
Route::get('OrderList', 'AdminController@OrderList')->name('order.list');
Route::get('CompletedOrders', 'AdminController@CompletedOrders')->name('completed.order.list');
Route::get('ViewBookings/{id}', 'AdminController@ViewBookings')->name('view.bookings');
Route::get('DeliveryOrderList', 'AdminController@DeliveryOrderList')->name('order.delivery');
Route::get('OrderAssign/{id}', 'AdminController@OrderAssign')->name('order.assign');
Route::post('AssignPickup', 'AdminController@AssignPickup')->name('assign.pickup');
Route::post('AssignDelivery', 'AdminController@AssignDelivery')->name('assign.delivery');
Route::get('PendingOrders', 'AdminController@PendingOrders')->name('pending.order');
Route::get('CalcelledOrders', 'AdminController@CalcelledOrders')->name('cancelled.order');
Route::get('OrderCancel', 'AdminController@OrderCancel')->name('delete.order');

//Orders download
Route::get('DownloadOrders', 'AdminController@DownloadOrders')->name('download.orders');


//PickupUser Routes
Route::get('PickupUser', 'AdminController@PickupUser')->name('pickupuser.list');
Route::get('EditPickupUser/{id}', 'AdminController@EditPickupUser')->name('edit.pickupuser');
Route::post('EditPickupUserSave', 'AdminController@EditPickupUserSave')->name('edit.pickupuser.profile');
Route::get('PickUpuserActive', 'AdminController@PickUpuserActive')->name('pickupuser.active');
Route::post('PickUpuserBlock', 'AdminController@PickUpuserBlock')->name('pickup.block');

Route::get('DeletedPickupUser', 'AdminController@DeletedPickupUser')->name('deleted.pickup.user');

Route::get('GetServicearea', 'AdminController@GetServicearea')->name('get.servicearea');
Route::post('AddNewService', 'AdminController@AddNewService')->name('add.new.service');
Route::get('DeletePicupUser', 'AdminController@DeletePicupUser')->name('delete.pickupuser');



//promocode
Route::get('AddPromocode', 'AdminController@AddPromocode')->name('add.promo');
Route::post('AddNewPromo', 'AdminController@AddNewPromo')->name('add.new.promo');
Route::get('EditPromoCode/{id}', 'AdminController@EditPromoCode')->name('edit.promo');
Route::post('UpdatePromo', 'AdminController@UpdatePromo')->name('update.promo');
Route::get('DeletePromo', 'AdminController@DeletePromo')->name('delete.promo');
//Check promocode
Route::get('CheckPromocode', 'AdminController@CheckPromocode')->name('check.promo');
Route::get('EditCheckPromocode', 'AdminController@EditCheckPromocode')->name('edit.check.promo');

//IroningVendor Routes
Route::get('IroningVendor', 'AdminController@IroningVendor')->name('ironing.vendor');
Route::get('IroningVendorActive', 'AdminController@IroningVendorActive')->name('ironingvendor.active');
Route::get('VendorDetails/{id}', 'AdminController@VendorDetails')->name('vendor.details');
Route::post('SaveMainCategory', 'AdminController@SaveMainCategory')->name('save.category');
Route::post('VendorBlock', 'AdminController@VendorBlock')->name('vendor.block');
Route::get('DeleteIroningVendor', 'AdminController@DeleteIroningVendor')->name('delete.ironingvendor');

//categories
Route::get('Categories', 'AdminController@Categories')->name('categories');
Route::post('AddCategory', 'AdminController@AddMainCategory')->name('add.main.category');
Route::get('EditCategory', 'AdminController@EditCategory')->name('edit.cate');
Route::post('UpdateCategory', 'AdminController@UpdateCategory')->name('update.category');
Route::get('SubCategories', 'AdminController@SubCategories')->name('sub.categories');
Route::get('GetGroupName', 'AdminController@GetGroupName')->name('get.group');
Route::post('SaveSubCategory', 'AdminController@SaveSubCategory')->name('savesub.category');
Route::get('EditCategoryItems/{id}', 'AdminController@EditCategoryItems')->name('edit.items.category');
Route::post('UpdateCategoryItems', 'AdminController@UpdateCategoryItems')->name('update.category.items');
Route::get('DeleteSubCategory', 'AdminController@delete_sub_category')->name('delete.sub.cate');
Route::get('DeleteMainCategory', 'AdminController@delete_main_categorydelete_main_category')->name('delete.main.cate');

//User List
Route::get('UsersList', 'AdminController@UsersList')->name('user.list');
Route::get('UserDetails/{id}', 'AdminController@UserDetails')->name('user.details');
/***************ServiceArea and Pincode ********************/

Route::get('ServiceArea', 'AdminController@ServiceArea')->name('service.area');
Route::post('AddServiceArea', 'AdminController@AddServiceArea')->name('add.service.area');
Route::get('CheckPincode', 'AdminController@CheckPincode')->name('check.pin');
Route::get('UpdateService/{id}', 'AdminController@UpdateService')->name('update.service');
Route::post('UpdatePincodeArea', 'AdminController@UpdatePincodeArea')->name('update.pincode.area');
Route::get('EditCheckPincode', 'AdminController@EditCheckPincode')->name('edit.check.pin');
Route::get('EditPinCheck', 'AdminController@EditPinCheck')->name('edit.pin');

Route::post('EditPincode', 'AdminController@EditPincode')->name('editpincode');
Route::post('EditPincodeSave', 'AdminController@EditPincodeSave')->name('edit.pin.save');
Route::get('DeletePincode', 'AdminController@DeletePincode')->name('delete.pin');


/***************Time Slot ********************/
Route::get('TimeSlot', 'AdminController@TimeSlot')->name('time.slot');
Route::get('ViewSlot', 'AdminController@ViewSlot')->name('view.slot');
Route::post('UpdateEditSlot', 'AdminController@UpdateEditSlot')->name('update.slot');
Route::post('AddSlot', 'AdminController@AddSlot')->name('add.slot');
Route::get('DeleteSlot', 'AdminController@DeleteSlot')->name('delete.timeslot');


//Manage Outlet
Route::get('OutletViews', 'AdminController@Outlet')->name('get.outlet');
Route::post('SaveOutlet', 'AdminController@SaveOutlet')->name('add.outlet');
Route::get('ViewOutlet/{id}', 'AdminController@ViewOutlet')->name('view.outlet');
Route::post('UpdateOutlet', 'AdminController@UpdateOutlet')->name('update.outlet');
Route::get('DeleteOutlet', 'AdminController@DeleteOutlet')->name('delete.outlet');


Route::get('GetDemo', 'AdminController@GetDemo')->name('get.demo');
Route::get('DeliveryManLocation', 'AdminController@DeliveryManLocation')->name('deliveryuser.location');
Route::get('GetDeliveryLocation', 'AdminController@GetDeliveryLocation')->name('delivery.location');
Route::get('GetRoutes', 'AdminController@GetRoutes')->name('get.routes');
Route::get('DeliveryRoutes/{id}', 'AdminController@DeliveryRoutes')->name('delivery.routes');


//New Bookings
Route::get('NewBooking', 'AdminController@NewBooking')->name('new.booking');
Route::get('UserMobile', 'AdminController@UserMobile')->name('user.mobile');
Route::get('EditOrders/{id}', 'AdminController@EditOrders')->name('edit.order');
Route::post('UpdateBookings', 'AdminController@UpdateBookings')->name('update.Bookings');
Route::get('UserProfile', 'AdminController@UserProfile')->name('user.profile');

//Reports
//Reports
// Route::get('PickupReport2', 'AdminController@PickupUserReport2')->name('pickup.report');
Route::get('PickupReport/{id}', 'AdminController@PickupUserReport')->name('getpickup.report');
Route::get('PickUpuserGraph', 'AdminController@PickUpuserGraph')->name('pickup.graph');
Route::get('TodaySales', 'AdminController@TodaySales')->name('today.sales');
Route::get('PaymentTypeGraph', 'AdminController@PaymentTypeGraph')->name('payment.type');
Route::get('ReportsView', 'AdminController@ReportsView')->name('get.reports');
Route::get('HighestOrder', 'AdminController@HighestOrder')->name('high.order');
Route::get('HighestOrderGraph', 'AdminController@HighestOrderGraph')->name('high.order.graph');
Route::get('PaymentTypeView', 'AdminController@PaymentTypeView')->name('report.payment.view');
Route::get('ReportPaymentType', 'AdminController@ReportPaymentType')->name('report.payment.type');
Route::get('OrderCompletedView', 'AdminController@OrderCompletedView')->name('order.complete.view');
Route::get('OrderStatusGraph', 'AdminController@OrderStatusGraph')->name('order.status.graph');
Route::get('PromocodeView', 'AdminController@PromocodeView')->name('promo.code.view');
Route::get('PromocodeGraph', 'AdminController@PromocodeGraph')->name('promocode.graph');
Route::get('MostBookings', 'AdminController@MostBookings')->name('most.booking');
Route::get('TotalRevenue', 'AdminController@TotalRevenue')->name('total.revenue.view');
Route::get('TotalRevenueGraph', 'AdminController@TotalRevenueGraph')->name('total.revenue.graph');
Route::get('ClothesRevenue', 'AdminController@ClothesRevenue')->name('clothes.revenue.graph');   
Route::get('ReportClothes', 'AdminController@ReportClothes')->name('clothes.revenue');  
Route::get('MonthClothSales', 'AdminController@MonthClothSales')->name('month.cloth.sales');  
Route::get('MonthClothRevenue', 'AdminController@MonthClothRevenue')->name('month.cloth.revenue');  
//
Route::get('WalletView', 'ReportController@WalletView')->name('wallet.report.view');
Route::get('WalletReportGraph', 'ReportController@WalletReportGraph')->name('wallet.report.graph');
Route::get('UserNotUse', 'AdminController@UserNotUse')->name('user.not.use');
Route::get('TimeSlotReport', 'AdminController@TimeSlotReport')->name('time.slot.report');
Route::get('HighSlotGraph', 'AdminController@HighSlotGraph')->name('high.slot.graph');
Route::get('WalletReportTrans/{id}', 'AdminController@WalletReportTrans')->name('wallet.trans');
Route::get('ClothesCategory', 'AdminController@ClothesCategory')->name('clothes.cate');
Route::get('category_clothes_report', 'AdminController@category_clothes_report')->name('clothes.category');
Route::get('Pie_Chart_clothes', 'AdminController@Pie_Chart_clothes')->name('piechart.clothes');  
Route::get('AvgCost', 'AdminController@AvgCost')->name('avg.cost');  
Route::get('SearchOrderList', 'AdminController@SearchOrderList')->name('search.order.list');  
Route::get('DeleteGallery', 'AdminController@DeleteGallery')->name('delete.gal.image');  


//Gallery  
Route::get('GalleryPage', 'AdminController@GalleryPage')->name('gallery.page'); 
Route::post('AddGallery', 'AdminController@AddGallery')->name('add.gallery.image'); 
Route::get('EditGallery/{id}', 'AdminController@EditGallery')->name('edit.gallery'); 
Route::post('UpdateGallery', 'AdminController@UpdateGallery')->name('upadte.gallery'); 


//Total reports
Route::get('PickUpuserGraph', 'AdminController@PickUpuserGraph')->name('pickup.graph');

Route::get('VendorReport/{id}', 'AdminController@VendorReport')->name('getvendor.report');
Route::get('VendorGraph', 'AdminController@VendorGraph')->name('vendor.graph');
Route::get('VendorClothesGraph', 'AdminController@VendorClothesGraph')->name('vendor.clothes.graph');

//Order Assign
Route::get('PickupOrderAssign/{id}', 'AdminController@PickupOrderAssign')->name('pickup.order.assign');
Route::post('UpdateOrderAssign', 'AdminController@UpdateOrderAssign')->name('update.order.assign');
Route::post('UpdateDeliveryAssign', 'AdminController@UpdateDeliveryAssign')->name('update.delivery.assign');

// Assign pending orders
Route::get('AssignPendingOrder/{id}', 'AdminController@AssignPendingOrder')->name('assign.pending.order');
Route::post('UpdatePendingAssign', 'AdminController@UpdatePendingAssign')->name('assign.pending.update');

//Customer Support
Route::get('Support', 'AdminController@CustomerSupport')->name('customer.support');
Route::post('Addcomplaints', 'AdminController@Addcomplaints')->name('add.complients');
Route::get('ViewComplaint/{id}', 'AdminController@ViewComplaint')->name('view.complient');
Route::post('UpdateComplient', 'AdminController@UpdateComplient')->name('update.complient');

//admin notifications
Route::get('Notifications', 'AdminController@push_notifications')->name('admin.notify');
Route::post('admin_sent_push', 'AdminController@admin_sent_push')->name('admin.sent.push');

//////////////////////////////////// MIC & MAC ////////////////////////////////////

// Pincode And TimeSlot Assign
Route::get('DateTimeSlotAssign', 'AdminController@DateTimeSlotAssign')->name('admin.datetimeslotassign');
Route::get('DateTimeSlotAssign/{month}', 'AdminController@DateTimeSlotAssign')->name('admin.datetimeslotassign.month');
Route::post('DateTimeSlotAssignAction', 'AdminController@DateTimeSlotAssignAction')->name('admin.datetimeslotassign.action');

// Credit Points Assign
Route::get('CreditPoints', 'AdminController@CreditPoints')->name('admin.creditpoints');
Route::post('CreditPointsAction', 'AdminController@CreditPointsAction')->name('admin.creditpoints.action');

//////////////////////////////////// MIC & MAC ////////////////////////////////////

/******************************************************Download Report************************************************/
Route::get('DownloadAreaReport', 'ReportController@DownloadAreaReport')->name('area.report');
Route::get('DownloadPaymentType', 'ReportController@DownloadPaymentType')->name('payment.type.report');
Route::get('DownloadPromocode', 'ReportController@DownloadPromocode')->name('promo.code.report');
Route::get('WalletReport', 'ReportController@WalletReport')->name('wallet.report.download');
Route::get('RevenueDownload', 'ReportController@RevenueDownload')->name('revenue.report.excel');
Route::get('DownloadCancel', 'ReportController@DownloadCancel')->name('download.cancel');
Route::get('ClothesReport', 'ReportController@ClothesReport')->name('clothe.report.download');
Route::get('NotUseBooking', 'ReportController@NotUseBooking')->name('user.not.report');
Route::get('SlotReportDownload', 'ReportController@SlotReportDownload')->name('slot.report.down');
Route::get('UserWalletReport/{id}', 'ReportController@UserWalletReport')->name('user.wallet.report');

Route::get('Categoty_Clothes/{id}', 'ReportController@Categoty_Clothes')->name('category.clothe.rep');
Route::get('Vendor_Report', 'ReportController@Vendor_Report')->name('vendor.reports');
Route::get('Pickup_Report', 'ReportController@Pickup_Report')->name('pickup.reports');
Route::get('download_user', 'ReportController@download_user')->name('download.user.list'); 
Route::get('UserBookingDown/{id}', 'ReportController@UserBookingDown')->name('user.booking'); 
Route::get('download_pickup', 'ReportController@download_pickup')->name('download.pickupuser.list'); 
Route::get('download_vendor', 'ReportController@download_vendor')->name('download.vendor.list'); 

/////Custom Graph 	

Route::get('custom_area_graph', 'ReportController@custom_area_graph')->name('custom.area.graph'); 
Route::get('custom_paymenttype_graph', 'ReportController@custom_paymenttype_graph')->name('custom.paytype.graph'); 
Route::get('custom_orders_graph', 'ReportController@custom_orders_graph')->name('custom.orders.graph'); 
Route::get('custom_graph_promocode', 'ReportController@custom_graph_promocode')->name('custom.promo.graph'); 
Route::get('custom_revenue_graph', 'ReportController@custom_revenue_graph')->name('custom.revenue.graph'); 
Route::get('custom_graph_timeslot', 'ReportController@custom_graph_timeslot')->name('custom.time.graph'); 
Route::get('custom_graph_wallet', 'ReportController@custom_graph_wallet')->name('custom.wallet.graph'); 
Route::get('custom_category_graph', 'ReportController@custom_category_graph')->name('custom.cate.graph'); 

//active and non active users
Route::get('active_users_rep', 'ReportController@active_users_rep')->name('active.users.rep'); 

/******************************************************OutletControl************************************************/
Route::get('OutletDashboard', 'OutletController@OutletDashboard')->name('outlet.board');
Route::get('OutletService/{id}', 'OutletController@OutletService')->name('outlet.service');
Route::get('OutletOrders/{id}', 'OutletController@OutletOrders')->name('outlet.orders');
Route::get('OutletBookings/{id}', 'OutletController@OutletBookings')->name('outlet.bookings');
//Outlet dashboard graph  
Route::get('OutletSales', 'OutletController@OutletSales')->name('outlet.sales');  
Route::get('OutletPayment', 'OutletController@OutletPayment')->name('outlet.payment');  
Route::get('OutletPayment', 'OutletController@OutletPayment')->name('outlet.payment');  
Route::get('OutletMostOrder', 'OutletController@OutletMostOrder')->name('outlet.most.order');  
Route::get('OutletPieChart', 'OutletController@OutletPieChart')->name('outlet.piechart');  


//Outlet report
Route::get('OutletReports/{id}', 'OutletController@OutletReports')->name('outlet.report');
Route::get('OutletHighOrders/{id}', 'OutletController@OutletHighOrders')->name('outlet.high.order');
Route::get('OutletPincodeGraph', 'OutletController@OutletPincodeGraph')->name('outlet.code.graph'); 
Route::get('OutletPinReport', 'OutletController@OutletPinReport')->name('outlet.pin.report');
Route::get('OutletPaymentType/{id}', 'OutletController@OutletPaymentType')->name('outlet.payment.type');
Route::get('OutletPayDownload', 'OutletController@OutletPayDownload')->name('outlet.payment.download');
Route::get('OutletPaymentGraph', 'OutletController@OutletPaymentGraph')->name('outlet.pay.graph');
Route::get('OutletRevenue/{id}', 'OutletController@OutletRevenue')->name('outlet.revenue');
Route::get('OutletRevenueGraph', 'OutletController@OutletRevenueGraph')->name('outlet.revenue.graph');
Route::get('OutletRevenueExcel', 'OutletController@OutletRevenueExcel')->name('outlet.revenue.excel');
Route::get('OutletClothGraph', 'OutletController@OutletClothGraph')->name('outlet.cloth.graph');
Route::get('OutletClothes/{id}', 'OutletController@OutletClothes')->name('outlet.clothe');
Route::get('OutletMonthClothSales', 'OutletController@OutletMonthClothSales')->name('outlet.month.cloth.sales');  
Route::get('OutletMonthClothRev', 'OutletController@OutletMonthClothRev')->name('outlet.month.cloth.rev');  
Route::get('OutletClotheReport', 'OutletController@OutletClotheReport')->name('outlet.clothe.excel');
Route::get('OutletTimeSlots/{id}', 'OutletController@OutletTimeSlots')->name('outlet.time.slots');
Route::get('OutletSlotGraph', 'OutletController@OutletSlotGraph')->name('outlet.time.graphslots');
Route::get('OutletTimeSlotReport', 'OutletController@OutletTimeSlotReport')->name('outlet.time.report');
Route::get('OutletSearchTime', 'OutletController@OutletSearchTime')->name('outlet.search.time');
Route::post('OutletSlotReport', 'OutletController@OutletSlotReport')->name('outlet.slot.rep');
Route::get('SearchOutletRevenue', 'OutletController@SearchOutletRevenue')->name('search.outlet.rep');
Route::post('OutletRevReport', 'OutletController@OutletRevReport')->name('outlet.rev.rep');
Route::post('OutletPaymentReport', 'OutletController@OutletPaymentReport')->name('outlet.payment.down');
Route::get('SearchClothesOutlet', 'OutletController@SearchClothesOutlet')->name('search.cloth.outlet');
Route::post('OutletClothesDown', 'OutletController@OutletClothesDown')->name('outlet.clothes.down');
Route::get('OutletClothesCate/{id}', 'OutletController@OutletClothesCate')->name('outlet.clothes.cate');
Route::get('category_clothes_outlet', 'OutletController@category_clothes_outlet')->name('clothes.category.outlet');
Route::get('Outlet_Category_Clothes', 'OutletController@Outlet_Category_Clothes')->name('out.category.clothe');
Route::get('OutletPromocode/{id}', 'OutletController@OutletPromocode')->name('out.promo.code'); 
Route::get('OutletSearchPromo', 'OutletController@OutletSearchPromo')->name('out.promo.search'); 
Route::get('OutletPromoDown', 'OutletController@OutletPromoDown')->name('out.promo.down'); 
Route::get('OutletPromoDayGraph', 'OutletController@OutletPromoDayGraph')->name('out.promo.day'); 
Route::get('custom_graph_outpromo', 'OutletController@custom_graph_outpromo')->name('custom.promo.graph'); 
Route::post('out_search_promo', 'OutletController@out_search_promo')->name('out.promo.ser'); 
Route::get('OutletStatus/{id}', 'OutletController@OutletStatus')->name('out.status'); 
Route::get('OutletStatusReport', 'OutletController@OutletStatusReport')->name('out.status.rep'); 
Route::get('OutletSearchSat', 'OutletController@OutletSearchSat')->name('out.status.sat');
Route::get('OutStatusDayGraph', 'OutletController@OutStatusDayGraph')->name('out.status.day');
Route::post('OutletStatusDown', 'OutletController@OutletStatusDown')->name('outlet.ordersataus.down');
Route::get('warhs_Category_Clothes', 'OutletController@warhs_Category_Clothes')->name('warhs.clothes.down');
Route::get('OutletAvg/{id}', 'OutletController@OutletAvg')->name('out.avg');
Route::get('SearchOutAvg', 'OutletController@SearchOutAvg')->name('search.out.avg');


//pickup user 
Route::get('OutletPickUser/{id}', 'OutletController@OutletPickUser')->name('out.pickuser');
Route::get('OutletPickUserReports', 'OutletController@OutletPickUserReports')->name('getoutpickup.report');


//vendor
Route::get('OutletVendors/{id}', 'OutletController@OutletVendors')->name('out.vendors');
Route::get('OutletVendorDetails', 'OutletController@OutletVendorDetails')->name('getoutvendor.report');

//Search Reports
Route::get('OutletReports/{id}', 'OutletController@OutletReports')->name('outlet.report');
Route::get('SearchOutletPin', 'OutletController@SearchOutletPin')->name('search.out.pin');
Route::get('custom_outlet_pingraph', 'OutletController@custom_outlet_pingraph')->name('outlet.custom.pin');  
Route::get('outlet_paymentgraph', 'OutletController@outlet_paymentgraph')->name('outlet.payment.graph');  
Route::get('SearchOutletPayment', 'OutletController@SearchOutletPayment')->name('search.payment.outlet');  
Route::get('custom_outlet_graph_slot', 'OutletController@custom_outlet_graph_slot')->name('custom.out.slot');  
Route::get('custom_outlet_revenue', 'OutletController@custom_outlet_revenue')->name('custom.out.rev');  
Route::get('custom_outlet_category', 'OutletController@custom_outlet_category')->name('custom.outlet.graph');  

/***************************************WarehouseController*********************************/

/***************************************Search dates*********************************/

Route::get('SearchTimeSlots', 'SearchReportController@SearchTimeSlots')->name('search.timeslots'); 
Route::post('search_slot_download', 'SearchReportController@search_slot_download')->name('serach.slot.down'); 
Route::get('SearchPincode', 'SearchReportController@SearchPincode')->name('search.pin.code');
Route::post('search_pin_download', 'SearchReportController@search_pin_download')->name('serach.pincode.down'); 
Route::get('SearchPaymentType', 'SearchReportController@SearchPaymentType')->name('search.payment.type');
Route::post('search_payment_download', 'SearchReportController@search_payment_download')->name('serach.payment.down'); 
Route::get('SearchOrderStatus', 'SearchReportController@SearchOrderStatus')->name('search.order.status');
Route::post('search_orderstatus_download', 'SearchReportController@search_orderstatus_download')->name('serach.ordersataus.down'); 
Route::get('SearchRevenue', 'SearchReportController@SearchRevenue')->name('search.revenue');
Route::post('Search_revenue_download', 'SearchReportController@Search_revenue_download')->name('serach.revenue.down');
Route::get('SearchPromocode', 'SearchReportController@SearchPromocode')->name('search.promo'); 
Route::post('Search_promo_download', 'SearchReportController@Search_promo_download')->name('serach.promo.down');
Route::get('SearchWalletReport', 'SearchReportController@SearchWalletReport')->name('serach.wallet.report');
Route::post('Search_wallet_download', 'SearchReportController@Search_wallet_download')->name('serach.wallet.down');
Route::get('SearchClothesReport', 'SearchReportController@SearchClothesReport')->name('serach.clothes.report');
Route::post('Search_clothes_download', 'SearchReportController@Search_clothes_download')->name('serach.clothes.down');
Route::get('SearchCategoryReports', 'SearchReportController@SearchCategoryReports')->name('serach.category.reports');
Route::post('Category_clothes_download', 'SearchReportController@Category_clothes_download')->name('cate.clothes.down');
Route::get('SumAvg', 'SearchReportController@SumAvg')->name('sum.avg');  
Route::get('SearchAvgCost', 'SearchReportController@SearchAvgCost')->name('search.avg.cost');  
Route::get('SearchVendorReports', 'SearchReportController@SearchVendorReports')->name('search.vendor.clothes'); 
Route::get('SearchPickupReports', 'SearchReportController@SearchPickupReports')->name('search.pickup.clothes'); 
Route::post('Pickup_order_dowmload', 'SearchReportController@Pickup_order_dowmload')->name('pickup.orders.down'); 
Route::post('Vendor_clothes_download', 'SearchReportController@Vendor_clothes_download')->name('vendor.clothes.down'); 
Route::get('InactiveUser', 'SearchReportController@InactiveUser')->name('user.inactive.use'); 

/*******************************WarehousesController*******************************************************************/
Route::get('WarOutletSales', 'WarehousesController@WarOutletSales')->name('war.outlet.sales');  
Route::get('WarOutletPayment', 'WarehousesController@WarOutletPayment')->name('war.outlet.payment');
Route::get('WarOutletMostOrder', 'WarehousesController@WarOutletMostOrder')->name('war.outlet.most.order');
Route::get('WarOutletClothGraph', 'WarehousesController@WarOutletClothGraph')->name('war.outlet.cloth.graph'); 
Route::get('WarOutletPieChart', 'WarehousesController@WarOutletPieChart')->name('war.outlet.piechart');  
Route::get('WarOrderList', 'WarehousesController@WarOrderList')->name('war.order.list');  
Route::get('WarBookings/{id}', 'WarehousesController@WarBookings')->name('war.bookings');
Route::get('WarPincodeGraph', 'WarehousesController@WarPincodeGraph')->name('war.outlet.codegraph');  
Route::get('WarletPinReport', 'WarehousesController@WarletPinReport')->name('war.pin.report');
Route::get('SearchWarPin', 'WarehousesController@SearchWarPin')->name('search.war.pin');
Route::get('custom_war_pingraph', 'WarehousesController@custom_war_pingraph')->name('war.custom.pin'); 
Route::post('WarPincodeDown', 'WarehousesController@WarPincodeDown')->name('war.pincode.down');  
Route::get('WarPaymentType', 'WarehousesController@WarPaymentType')->name('war.payment'); 
Route::get('WarPaymentGraph', 'WarehousesController@WarPaymentGraph')->name('war.pay.graph');
Route::get('WarPayDownload', 'WarehousesController@WarPayDownload')->name('war.pay.down');
Route::get('SearchWarPayment', 'WarehousesController@SearchWarPayment')->name('search.war.pay');
Route::get('war_paymentgraph', 'WarehousesController@war_paymentgraph')->name('war.payment.graph');
Route::post('WarPaymentReport', 'WarehousesController@WarPaymentReport')->name('war.payment.down');  
Route::get('WarRevenue', 'WarehousesController@WarRevenue')->name('war.revenue');
Route::get('WarRevenueGraph', 'WarehousesController@WarRevenueGraph')->name('war.revenue.graph');
Route::get('WarRevenueExcel', 'WarehousesController@WarRevenueExcel')->name('war.revenue.excel');
Route::get('SearchWarRevenue', 'WarehousesController@SearchWarRevenue')->name('war.revenue.search');
Route::get('custom_war_revenue', 'WarehousesController@custom_war_revenue')->name('war.revenue.custom');
Route::post('WarRevenueDownload', 'WarehousesController@WarRevenueDownload')->name('war.revenue.down');
Route::get('WarTimeslots', 'WarehousesController@WarTimeslots')->name('war.timeslot');
Route::get('WarSlotGraph', 'WarehousesController@WarSlotGraph')->name('war.slot.graph');
Route::get('WarTimeSlotReport', 'WarehousesController@WarTimeSlotReport')->name('war.slot.graphreport');
Route::get('WarSearchTime', 'WarehousesController@WarSearchTime')->name('war.slot.search');
Route::get('custom_war_graph_slot', 'WarehousesController@custom_war_graph_slot')->name('war.slot.custom');
Route::post('WarSlotReport', 'WarehousesController@WarSlotReport')->name('war.slot.down');
Route::get('WarPromocode', 'WarehousesController@WarPromocode')->name('war.promo.code');
Route::get('WarPromocodeGraph', 'WarehousesController@WarPromocodeGraph')->name('war.promo.graph');
Route::get('WarPromoDown', 'WarehousesController@WarPromoDown')->name('war.promo.down');
Route::get('WarSearchPromo', 'WarehousesController@WarSearchPromo')->name('war.search.promo');
Route::post('war_search_promo_down', 'WarehousesController@war_search_promo_down')->name('war.searchpromo.down');
Route::get('custom_graph_warpromo', 'WarehousesController@custom_graph_warpromo')->name('war.searchpromo.graph');
Route::get('WarOrderStatus', 'WarehousesController@WarOrderStatus')->name('war.order.status');
Route::get('WarOrderStatusGraph', 'WarehousesController@WarOrderStatusGraph')->name('war.order.statusgraph');
Route::get('WarStatusReport', 'WarehousesController@WarStatusReport')->name('war.status.report');
Route::post('WarStatusDown', 'WarehousesController@WarStatusDown')->name('war.outstatus.down');
Route::get('WarSearchSat', 'WarehousesController@WarSearchSat')->name('war.outstatus.sar');
Route::get('WarCategoryClothes', 'WarehousesController@WarCategoryClothes')->name('war.category.cat');
Route::get('WarDaygraph', 'WarehousesController@WarDaygraph')->name('war.day.graph');
Route::get('warhs_Category_Clothes', 'WarehousesController@warhs_Category_Clothes')->name('warhs.clothes.down');
Route::get('WarClothesRep', 'WarehousesController@WarClothesRep')->name('war.clothes');
Route::get('WarClothesSales', 'WarehousesController@WarClothesSales')->name('war.clothes.sale');
Route::get('WarClothesRev', 'WarehousesController@WarClothesRev')->name('war.clothes.rev');
Route::get('WarClotheReport', 'WarehousesController@WarClotheReport')->name('war.clothes.reports');
Route::get('SearchClothesWar', 'WarehousesController@SearchClothesWar')->name('war.clothes.ser');
Route::post('WarClothesDown', 'WarehousesController@WarClothesDown')->name('war.clothes.download');
Route::get('custom_war_category', 'WarehousesController@custom_war_category')->name('war.clothes.custom');
Route::get('WarAvgCost', 'WarehousesController@WarAvgCost')->name('war.avg.cost');
Route::get('SearchWarAvg', 'WarehousesController@SearchWarAvg')->name('war.avg.search');



//users 
Route::get('OutletUserList', 'WarehousesController@OutletUserList')->name('outlet.users');
Route::get('OutletUserDetails/{id}', 'WarehousesController@OutletUserDetails')->name('outlet.users.details');
Route::get('OutWalletReportTrans/{id}', 'WarehousesController@OutWalletReportTrans')->name('outlet.wallet.trans');


//pickup user
Route::get('WarPickupUser', 'WarehousesController@WarPickupUser')->name('war.pickupuser.list');  
Route::get('outlet_pickup_user/{id}', 'WarehousesController@outlet_pickup_user')->name('war.pickupuser.edit');  
Route::get('WarPickupReport', 'WarehousesController@WarPickupReport')->name('getwarpickup.report');  
Route::get('WarPickuserDay', 'WarehousesController@WarPickuserDay')->name('war.pick.daygraph');  
Route::get('War_Pickup_Report', 'WarehousesController@War_Pickup_Report')->name('war.pick.report');  
Route::get('SearchOutPickup', 'WarehousesController@SearchOutPickup')->name('search.out.pick');  
Route::post('OutPickupRepDownload', 'WarehousesController@OutPickupRepDownload')->name('outpickup.down.rep');
Route::get('GetVendorReport', 'WarehousesController@GetVendorReport')->name('getwarvendor.report');  


//vendor
Route::get('OutletVendor', 'WarehousesController@OutletVendor')->name('out.ironing.vendor');  
Route::get('OutletVendorDetails/{id}', 'WarehousesController@OutletVendorDetails')->name('out.vendor.details');    
Route::get('OutletVendorGraph', 'WarehousesController@OutletVendorGraph')->name('outlet.vendor.day');    
Route::get('SearchOutVendorReports', 'WarehousesController@SearchOutVendorReports')->name('ser.vendor.rep');    
Route::post('OutVendorRepDown', 'WarehousesController@OutVendorRepDown')->name('out.vendor.repdown');    

//Report
Route::get('WarReports', 'WarehousesController@WarReports')->name('war.reports'); 
Route::get('WarHighestArea', 'WarehousesController@WarHighestArea')->name('war.highest.area');

//New Search

Route::get('slots_search_report', 'SearchReportController@slots_search_report')->name('slots.search.rep'); 

Route::get('PickDelivery', 'AdminController@PickDelivery')->name('pick.delivery');



//Privacy Policy and Term & conditions pages
Route::get('UserPrivacy', 'PrivacyController@UserPrivacy')->name('user.privacy');
Route::get('UserTerms', 'PrivacyController@UserTerms')->name('user.trems');
Route::get('Refunds', 'PrivacyController@Refunds')->name('refunds');
Route::get('Disclaimer', 'PrivacyController@Disclaimer')->name('Disclaimer');
