

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	  <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">User Details</h4>
				</div>
				
				<div class="card-content">
				 
   
    
	              <div class="row">
                    <div class="col-md-12">
                        <div class="profile_pic">
						   <img src=" <?php if($VendorInfo->image == ''){ echo "http://139.59.37.241/Ironman/public/images/pic.png"; }else{ echo $VendorInfo->image; } ?>" class="img-responsive center-block img-circle">
						    
						</div>
                    </div>					
				</div>
				
				
				<div class="row">
				      
					  <div class="col-md-12">
					      <table class="table">
							<thead>
							  <tr>
								<th>Name</th>
								<th>Mobile</th>
								<th>DOB</th>
								<th>Gender</th>
							  </tr>
							</thead>
							<tbody>
							  <tr>
								<td><?php echo e($VendorInfo->name); ?></td>
								<td><?php echo e($VendorInfo->mobile); ?></td>
								<td><?php echo e($VendorInfo->dob); ?></td>
								<td><?php echo e($VendorInfo->gender); ?></td>
							  </tr>
							</tbody>
						  </table>
					  </div>
					  
				   </div>
	 
				   
				   <div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="card">
							<!--<div class="card-header" data-background-color="blue">
								<h4 class="title">Order History</h4>
							</div>-->
							<h4>Order History</h4>
							<div class="card-content">
								<div class="material-datatables">
									<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
										<thead>
											<tr>
												<th>S.No</th>
												<th>BookingId</th>
												<th>Username</th>
												<th>BookingDate</th>
												<!--<th>TimeSlot</th>--->
												<th class="text-right">Actions</th>
											</tr>
										</thead>
										<tfoot>
											<tr>
												<th>S.No</th>
												<th>BookingId</th>
												<th>username</th>
												<th>BookingDate</th>
												<!--<th>TimeSlot</th>-->
												<th class="text-right">Actions</th>
											</tr>
										</tfoot>
										
										<tbody>
										 <?php   $count = 1; ?>
										<?php $__currentLoopData = $Bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetBookings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($count++); ?></td>
												<td><?php echo e($GetBookings->bookingId); ?></td>
												<td><?php echo e($GetBookings->username); ?></td>
												<td><?php echo e($GetBookings->bookingDate); ?></td>
												<!---<td><?php echo e($GetBookings->bookingTimeSlot); ?></td>-->
												

												<td class="text-right">
													<a href="<?php echo e(route('view.bookings',[$GetBookings->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																						   
										</tbody>
										
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				  
				  
				
				
				</div>
				
	      </div>
	    </div>
	  </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>