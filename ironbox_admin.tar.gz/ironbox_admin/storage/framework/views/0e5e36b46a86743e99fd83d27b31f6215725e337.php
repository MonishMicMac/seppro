

<?php $__env->startSection('content'); ?>
<div class="content">
   <div class="container-fluid">
       <div class="row">
	   
	    <div class="col-lg-3 col-md-6 col-sm-6">
		<a href="#">
			<div class="card card-stats">
				<div class="card-header" data-background-color="orange">
					 <i class="fa fa-users"></i>
				</div>

				<?php   $id; ?>
				<div class="card-content">
					<p class="category">Users</p>
					<h3 class="title">4534
					</h3>
				</div>
			</div>
			</a>
		</div>	
   </div>	   
  </div>	   
</div>	   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.warehouse', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>