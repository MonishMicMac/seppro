

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Report</h4>
				</div>
				<div class="card-content">
				   <div class="row">
				        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="orange">
                                    <div class="ct-chart" id="pickupUserGraph"></div>
									
                                </div>
                               
							   <div class="card-content">
                                    <h4 class="title">Pickup user report</h4>
                                </div>
                             
								<input type='hidden' id="pickupId" value="<?php echo e($userId); ?>">
							
                            </div>
                        </div>
				   </div>
				   
				   
				   <div class="row">
					   <div class="card-content">
					   <div class="box_shadow box_shadow1">
                                    <h4 class="greentext">Pickup report</h4> 
                               
					   <form method="post" id="Search_reports" action="<?php echo e(route('pickup.orders.down')); ?>" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="fromdate" id="pickupfrom" type="date"/>
							  <input type='hidden' id="pickupId_1" name="pickupId" value="<?php echo e($userId); ?>">
							  <span class="error pickup_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="todate" id="pickupto" type="date"/>
							  <span class="error pickup_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>Orders</th>
						    <th>quantity</th>
							<th>Amount</th>							
						  </tr>
						
                           
						    <tbody id="pickup_report">
                                  <td colspan="4">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
						  
					   </div>
					   </div>
					   </div>
				   
				   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 <h4 class="yellowtext">Reports</h4>
					 
					    

        <div id="exTab1">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab">Yearly</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
			     
				  <a href="<?php echo e(route('pickup.reports',['id'=>1,'pickupId'=>$userId])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
			  
                     <table class="table_1">
						  <tr>
							<th>Orders</th>
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php $__currentLoopData = $TodayOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TodayRep_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <?php if($TodayRep_val->orders == 0): ?>
							  
							<tr>
							  <td colspan="4">No record</td>
							</tr>
						  
						  <?php else: ?>
						  <tr>
							
								
							
							<td><?php echo e($TodayRep_val->orders); ?></td>
							<td><?php echo e($TodayRep_val->qty); ?></td>
							<td><?php echo e($TodayRep_val->total); ?></td>
                           
						  </tr>
						  
						  <?php endif; ?>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
				</div>
				<div class="tab-pane" id="2a">
				
				<a href="<?php echo e(route('pickup.reports',['id'=>2,'pickupId'=>$userId])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                       <table class="table_1">
						  <tr>
							<th>Orders</th>
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php $__currentLoopData = $WeekOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $WeekRep_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							
							<td><?php echo e($WeekRep_val->orders); ?></td>
							<td><?php echo e($WeekRep_val->qty); ?></td>
							<td><?php echo e($WeekRep_val->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
				</div>
               <div class="tab-pane" id="3a">
			   
			   <a href="<?php echo e(route('pickup.reports',['id'=>3,'pickupId'=>$userId])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                   <table class="table_1">
						  <tr>
							<th>Orders</th>
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php $__currentLoopData = $MonthOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MonthRep_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							
							<td><?php echo e($MonthRep_val->orders); ?></td>
							<td><?php echo e($MonthRep_val->qty); ?></td>
							<td><?php echo e($MonthRep_val->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
				</div>
            <div class="tab-pane" id="4a">
                 <table class="table_1">
				 <a href="<?php echo e(route('pickup.reports',['id'=>4,'pickupId'=>$userId])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						  <tr>
							<th>Orders</th>
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php $__currentLoopData = $YearOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $YearRep_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  
						  <tr>
							
							<td><?php echo e($YearRep_val->orders); ?></td>
							<td><?php echo e($YearRep_val->qty); ?></td>
							<td><?php echo e($YearRep_val->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
				</div>
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
				   
				</div>
			</div>
		</div>		
	</div>
	
	
	
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Pickup Report</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Orders </th>
										<th>Date</th>
										
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Orders </th>
										<th>Date</th>
									
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								 
								 
								<?php $__currentLoopData = $Pickup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($GetData->orders); ?></td>
										<td><?php echo e($GetData->order_date); ?></td>
                                      
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		// var id = '1';
		$('.active-pickup').addClass('active');
		 var id =  $("#pickupId").val();
		 // alert(id);
		
		var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/PickUpuserGraph',
            data: {_token: csrf,id: id},
            success: function (data) { 
                   // console.log(data);
				   demo.pickupUserChart(data);
            }
        });
		
       // demo.initDashboardPageCharts();
	   
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>