

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-12">
                             
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="HighSlot"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">TimeSlots</h4>
                                </div>
                            </div>
                         					   
					  
                         </div>					   
					   </div>
					   
					   
					   <!--<div class="row">
					   <div class="card-content">
					   <div class="box_shadow box_shadow1">
                                    <h4 class="greentext">Search timeslots</h4>
                                
					   <form method="post" id="Search_reports" action ="<?php echo e(route('serach.slot.down')); ?>" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control" name="fromdate" id="Slotsfrom" type="date"/>
							  <span class="error slots_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control" name="todate" id="Slotsto" type="date"/>
							  <span class="error slots_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>TimeSlot</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						
                           
						    <tbody id="Time_report">
                                  <td colspan="4">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
						  
					   </div>
					   </div>
					   </div>-->
					   
					   
					   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 <h4 class="yellowtext">Reports</h4> 
					 

        <div id="exTab1" class="">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab" value="1" class="get_time_value">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab" value="2" class="get_time_value">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab" value="3" class="get_time_value">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab" value="4" class="get_time_value">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab" value="5" class="get_time_value">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
			  
			  <a href="<?php echo e(route('slot.report.down',['id'=>1,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
		
                     <table class="table_1">
						  <tr>
						    <th>TimeSlot</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php 
						  if(count($Day) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->fromSlots); ?> - <?php echo e($OrderDay->toSlots); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>							
							<td><?php echo e($OrderDay->quantity); ?></td>
							<td><?php echo e($OrderDay->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table> 
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>TimeSlot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $Dayrep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->fromSlots); ?> - <?php echo e($rep->toSlots); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
				<div class="tab-pane" id="2a">
				<a href="<?php echo e(route('slot.report.down',['id'=>2,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     
					 <table class="table_1">
						  <tr>
						    <th>TimeSlot</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php 
						  if(count($Week) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->fromSlots); ?> - <?php echo e($OrderDay->toSlots); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>							
							<td><?php echo e($OrderDay->quantity); ?></td>
							<td><?php echo e($OrderDay->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>  
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>TimeSlot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $Weekrep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->fromSlots); ?> - <?php echo e($rep->toSlots); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
               <div class="tab-pane" id="3a">
			   <a href="<?php echo e(route('slot.report.down',['id'=>3,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     <table class="table_1">
						  <tr>
						    <th>TimeSlot</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php 
						  if(count($Month) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->fromSlots); ?> - <?php echo e($OrderDay->toSlots); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>							
							<td><?php echo e($OrderDay->quantity); ?></td>
							<td><?php echo e($OrderDay->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table> 
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Monthly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>TimeSlot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $Monthrep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->fromSlots); ?> - <?php echo e($rep->toSlots); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
            <div class="tab-pane" id="4a">
			<a href="<?php echo e(route('slot.report.down',['id'=>4,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     <table class="table_1">
						  <tr>
						    <th>TimeSlot</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php 
						  if(count($Year) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->fromSlots); ?> - <?php echo e($OrderDay->toSlots); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>							
							<td><?php echo e($OrderDay->quantity); ?></td>
							<td><?php echo e($OrderDay->total); ?></td>
                           
						  </tr>

						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				        <h4 class="yellowtext">Yearly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>TimeSlot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $Yearrep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->fromSlots); ?> - <?php echo e($rep->toSlots); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				      </div>
					  
					  <div class="tab-pane" id="5a">
					  
					     <form method="post" id="Search_report" action ="<?php echo e(route('serach.slot.down')); ?>" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					      <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_time" name="fromdate" id="Slotsfrom" type="date"/>
							  <span class="error slots_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_time" name="todate" id="Slotsto" type="date"/>
							  <span class="error slots_to">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-3">
							 <div class="form-group">
								<label class="control-label">
                                TimeSlots
                              <small>*</small>
                              </label>
								<select  class="form-control custom_graph_time" id="timeId" name="timeId">
									<option value="">Select TimeSlots</option>
									<?php $__currentLoopData = $Slot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									
                                      <option value="<?php echo e($time->id); ?>"> <?php echo e($time->fromSlots); ?> - <?php echo e($time->toSlots); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							 </div>
						   </div>
						  
						  <div class="col-md-3">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>BookingId</th>
							<th>TimeSlot</th>							
							<th>Status</th>
							<th>Actions</th>
						  </tr>
						
                           
						    <tbody id="Time_report">
                                  <td colspan="4">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
					  </div>
					  
			      </div>
               </div>

					 </div>
					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">



    $(document).ready(function() {
		$('.active-report').addClass('active');
		$.get("<?php echo e(route('high.slot.graph')); ?>")
	  .done(function(data) {
		

			demo.HighSlot(data);
			
			// console.log(data);
							
		});	
		
	
		
		
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>