

<?php $__env->startSection('content'); ?>
<div class="content">
   <div class="container-fluid">
       <div class="row">
	   
	      <div class="col-lg-3 col-md-6 col-sm-6">
		<a href="#">
			<div class="card card-stats">
				<div class="card-header" data-background-color="orange">
					 <i class="fa fa-users"></i>
				</div>

				<?php   $id; ?>
				<input type ='hidden' id="outletId" value="<?php echo $id; ?>">
				<div class="card-content">
					<p class="category">Users</p>
					<h3 class="title"><?php echo e($Users); ?>

					</h3>
				</div>
			</div>
			</a>
		</div>	


           <div class="col-lg-3 col-md-6 col-sm-6">
			<a href="<?php echo e(route('pickupuser.list')); ?>">
				<div class="card card-stats">
					<div class="card-header" data-background-color="green">
						<i class="material-icons">store</i>
					</div>
					<div class="card-content">
						<p class="category">Pickup users</p>
						<h3 class="title"><?php echo e($PickupUser); ?></h3>
					</div>
				</div>
				</a>
			</div>	

            <div class="col-lg-3 col-md-6 col-sm-6">
				<a href="<?php echo e(route('ironing.vendor')); ?>">
					<div class="card card-stats">
						<div class="card-header" data-background-color="red">
							<i class="material-icons">info_outline</i>
						</div>
						<div class="card-content">
							<p class="category">Ironing vendor</p>
							<h3 class="title"><?php echo e($Ironing); ?></h3>
						</div>
					</div>
					</a>
				</div>	

               <div class="col-lg-3 col-md-6 col-sm-6">
				<a href="<?php echo e(route('order.list')); ?>">
					<div class="card card-stats">
						<div class="card-header" data-background-color="blue">
							<i class="fa fa-list-ul"></i>
						</div>
						<div class="card-content">
							<p class="category">Total orders</p>
							<h3 class="title"><?php echo e($Bookings); ?></h3>
						</div>
					</div>
					</a>
				</div>	
       </div>	   
    </div>	   
</div>	   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.warehouse', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>