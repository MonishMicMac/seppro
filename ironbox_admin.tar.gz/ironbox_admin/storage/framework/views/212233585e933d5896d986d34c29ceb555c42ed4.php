

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Avg cost</h4>
					</div>
					<div class="card-content">
                       <!--<div class="row">
					    <div class="col-md-12">
                             
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="CategoryClothesRep"></div>
                                </div>
                                <div class="card-content">
                                   <h4 class="title">Monthly avg cost</h4>
                                </div>
								
                            </div>
                         					   
					  
                         </div>					   
					   </div>-->
					   
					   
					   <div class="row">
					   <div class="card-content">
					   <div class="box_shadow box_shadow1">
							<h4 class="greentext">Avg cost </h4>									
					   <form method="post" id="Search_reports" action="" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					      <div class="col-md-4">
						    <div class="form-group">
							<label class="control-label">
                                From date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="fromdate" id="avgfrom" type="date"/>
							  <span class="error avg_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="todate" id="avgto" type="date"/>
							  <span class="error avg_to">Please select date</span>
                           </div>
						  </div>
						  
						  <!--<div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>-->
						  </form>
						  <div class="clearfix"></div>
						  
						  
						  <table class="table_1">
						  <tr>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						 	
						<tbody id="Avg_report">
						<td colspan="3">No record</td>
					
							
							 </tbody>
						</table>
						  
						   </div>
					   </div>
					   </div>
					   
					   
					   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 
					   
                <h4 class="yellowtext">Avg cost reports</h4>

		
		<div id="exTab1" class="pad4">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab">Yearly</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">

                     <table class="table_1">
						  <tr>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						  
				
						  <tr>
							<td><?php echo e($Today->payment); ?></td>
							<td><?php echo e($Today->quantity); ?></td>							
							<td><?php echo e($Today->avg_cost); ?></td>
                           
                          </tr>
						   
						</table>
				</div>
				<div class="tab-pane" id="2a">
                     
					<table class="table_1">
						  <tr>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						 	
						  <tr>
							<td><?php echo e($Week->payment); ?></td>
							<td><?php echo e($Week->quantity); ?></td>							
							<td><?php echo e($Week->avg_cost); ?></td>
							</tr>
						</table>
					 
				</div>
               <div class="tab-pane" id="3a">
			   
			      <table class="table_1">
						  <tr>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						 	
						  <tr>
							<td><?php echo e($Month->payment); ?></td>
							<td><?php echo e($Month->quantity); ?></td>							
							<td><?php echo e($Month->avg_cost); ?></td>
							</tr>
						</table>
			   
				</div>
            <div class="tab-pane" id="4a">
			  
			         <table class="table_1">
						  <tr>
						    <th>Sales</th>
							<th>Clothes</th>							
							<th>Avg cost</th>
						  </tr>
						 	
						  <tr>
							<td><?php echo e($Year->payment); ?></td>
							<td><?php echo e($Year->quantity); ?></td>							
							<td><?php echo e($Year->avg_cost); ?></td>
							</tr>
						</table>
			
				</div>
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
   $(document).ready(function() {
		$('.active-report').addClass('active');
		
		var id = $('#cate_id').val();
		
		$.get("<?php echo e(route('clothes.category')); ?>?id="+id)
	  .done(function(data) {
		

		});
		
	
		
		
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>