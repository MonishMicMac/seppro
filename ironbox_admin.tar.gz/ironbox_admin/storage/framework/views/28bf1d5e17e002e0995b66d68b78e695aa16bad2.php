

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">PickUp User Location</h4>
					</div>
					<div class="card-content">
					  <!--<button class="btn btn-primary" id="map_click">
						   Submit
						   <div class="ripple-container"></div>
						</button>-->
					    <input type="hidden" id="pickupId" value="<?php echo e($id); ?>">
						<div id="dvMap" style="width: 1000px; height: 500px;"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>




 <script>
 


$(document).ready(function(){

        //Check if the current URL contains '#' 
        if(document.URL.indexOf("#")==-1)
        {
            // Set the URL to whatever it was plus "#".
            url = document.URL+"#";
            location = "#";

            //Reload the page
            location.reload(true);

        }
    });


 
 
 var id = $('#pickupId').val();
 
 $.get("<?php echo e(route('get.routes')); ?>?id="+id)
	  .done(function(data) {
		   
     var loc = data.location;
	 var pickup = data.pickup;
 
    console.log(loc);
 
 
    var markers = data.location;
	// console.log(pickup[0].lat);
	
    window.onload = function () {
		
		
		var mapOptions = {
            center: new google.maps.LatLng(markers[0].lat, markers[0].lng),
            zoom: 10,
            mapTypeId: 'terrain'
        };
        var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
        var infoWindow_1 = new google.maps.InfoWindow();
		
		
		var j;
	
	//for (j = 0; j < markers.length; j++) { 

	
	var mark = new google.maps.Marker({
        position: new google.maps.LatLng(pickup[0].lat, pickup[0].lng),
        map: map
      });
	  
	  google.maps.event.addListener(mark, 'click', (function(mark, j) {
        return function() {
          infowindow.setContent(markers[0].title);
          infowindow.open(map, mark);
        }
      })(mark, j));
		
		
		 // setInterval('refreshPage()', 500);
        
        var infoWindow = new google.maps.InfoWindow();
        var lat_lng = new Array();
        var latlngbounds = new google.maps.LatLngBounds();
        for (i = 0; i < markers.length; i++) {
            var loc = markers[i]
			
			var icon = "";  
            switch (loc.type) {  
                case "CN":  
                    icon = "red";  
                    break;  
                case "C":  
                    icon = "green";  
                    break;
				case "outlet":  
                    icon = "yellow";  
                    break;
                default:	
                    icon = "blue";	
                     break;					
            } 
		
		  icon = "http://maps.google.com/mapfiles/ms/icons/" + icon + ".png"; 
			
			
            var myLatlng = new google.maps.LatLng(loc.lat, loc.lng);
            lat_lng.push(myLatlng);
            var marker = new google.maps.Marker({
                position: myLatlng,
                map: map,
                title: loc.title,
				animation: google.maps.Animation.BOUNCE,
				icon: new google.maps.MarkerImage(icon) 
            });
            latlngbounds.extend(marker.position);
            (function (marker, loc) {
                google.maps.event.addListener(marker, "click", function (e) {
                    infoWindow.setContent(loc.title);
                    infoWindow.setContent(loc.id);
                    infoWindow.open(map, marker);
                });
            })(marker, loc);
        }
        map.setCenter(latlngbounds.getCenter());
        map.fitBounds(latlngbounds);
 
        //***********ROUTING****************//
 
        //Initialize the Path Array
        var path = new google.maps.MVCArray();
 
        //Initialize the Direction Service
        var service = new google.maps.DirectionsService();
 
        //Set the Path Stroke Color
        var poly = new google.maps.Polyline({ map: map,geodesic: true, strokeColor: '#4986E7' });
     
         
        //Loop and Draw Path Route between the Points on MAP
        for (var i = 0; i < lat_lng.length; i++) {
            if ((i + 1) < lat_lng.length) {
                var src = lat_lng[i];
                var des = lat_lng[i + 1];
                path.push(src);
                poly.setPath(path);
                service.route({
                    origin: src,
                    destination: des,
                    travelMode: google.maps.DirectionsTravelMode.DRIVING
                }, function (result, status) {
                    if (status == google.maps.DirectionsStatus.OK) {
                        for (var i = 0, len = result.routes[0].overview_path.length; i < len; i++) {
                            path.push(result.routes[0].overview_path[i]);
                        }
                    }
                });
            }
        }
    }
	
	});	
	
	
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>