

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
				 <?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PickupUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<h4 class="title">Pickup / delivery - <?php echo e($PickupUser->name); ?></h4>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="card-content">
				<?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PickupUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
				  <div class="box_shadow box_shadow2">
				   <h4 class="yellowtext">Pickup user details</h4>
				    <div class="row">
                      <div class="col-md-6">
					    <div class="user_profile">
						   <img src=" <?php if($PickupUser->image == ''){ echo "http://139.59.37.241/Ironman/public/images/pic.png"; }else{ echo $PickupUser->image; } ?>" class="img-responsive center-block img-circle">
						    
						</div>
						
						<div class="urdetails">
						   <strong>Name :</strong> <?php echo e($PickupUser->name); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Mobile :</strong> <?php echo e($PickupUser->mobile); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Email :</strong> <?php echo e($PickupUser->email); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Alternate number :</strong> <?php echo e($PickupUser->alternate_number); ?>

						</div>
						
				     </div>
					 
					 <div class="col-md-3">
					     <div class="urdetails">
						   <strong>DOB :</strong> <?php echo e($PickupUser->dob); ?>

						</div>
						<div class="urdetails">
						   <strong>Gender :</strong> <?php echo e($PickupUser->gender); ?>

						</div>
						<div class="urdetails">
						   <strong>Address :</strong> <?php echo e($PickupUser->address); ?>

						</div>
					 
					 </div>
					 
					 <div class="col-md-3">
					     <div class="urdetails">
						   <strong>Pickup order :</strong> <?php echo $pickup_count; ?>
						</div>
						
						<div class="urdetails">
						   <strong>delivery order :</strong> <?php echo $delivery_count; ?>
						</div>
						
					</div>	
					 
					 
					 
				    </div>
				  </div>
				   
				   
				   <hr class="border_line">
				   <div class="row">
                        <div class="col-md-6">
                             <h4 class="title">Service Area</h4>
							 <form action="<?php echo e(route('add.new.service')); ?>" method="post" id="allowcateservice"> 
							  <?php echo e(csrf_field()); ?>

							  <div class="col-md-12">
							     <div class="form-group">
								 <label class="control-label">
										warehous
									   <small>*</small>
									  </label>
							      <select class="Select_box1" id="warehousId" name="warehousId">
								      <option value="">Select warehous</option>
									    <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									    <option value="<?php echo e($warehouse->id); ?>" 
										
                                         <?php
										 
										 foreach($User as $PickupUser){
										   
										   if($PickupUser->warehouseId == $warehouse->id){
											   
											   echo "Selected";
										   }
									    }?>

										> warehouse <?php echo e($warehouse->id); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  </Select>
								  <input type="hidden" name="id" value="<?php echo e($PickupUser->id); ?>">
                                 </div>
							  </div>
							  <div class="clearfix"></div>
							  <div class="col-md-12">
							      <div class="form-group">
									  <label class="control-label">
										Pincode
									   <small>*</small>
									  </label>
					  
									<!--<select class="selectpicker" name="pincode" id="pincode" data-live-search="true">-->
									<select class="Select_box1" name="pincode" id="pincode">
									<option value="">Select Area</option>	
									<?php $__currentLoopData = $Area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SelectAreas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($SelectAreas->id); ?>" <?php   
									
									   foreach($User as $PickupUser){
										   
										   if($PickupUser->code == $SelectAreas->code){
											   
											   echo "Selected";
										   }
									   }
									
									?>  data-tokens="<?php echo e($SelectAreas->area); ?>"><?php echo e($SelectAreas->area); ?></option>
									 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
					             </div>
							  </div>
							  <div class="clearfix"></div>
					
					             <div class="col-md-12">
								<button class="btn btn-primary">
								   Submit
								   <div class="ripple-container"></div>
								</button>
								</div>
							  </form>
                        </div>	
                         <div class="col-md-6">
					      <h4 class="title">Block user</h4>
						  
						  <form action="<?php echo e(route('pickup.block')); ?>" method="post" id="pickupblock"> 
								<?php echo e(csrf_field()); ?>

						   <div class="col-md-12">
						    <div class="form-group">
							<input type='hidden' name='userid' value='<?php echo e($PickupUser->id); ?>'>
							<input type='hidden' name='active_user' value='<?php echo e($PickupUser->Is_active); ?>'>
							
							<label class="switch">
							  <input type="checkbox" name="active_user1" <?php if($PickupUser->Is_active == 1){  echo "checked"; } ?> value="<?php echo e($PickupUser->Is_active); ?>">
							  <span class="slider round"></span>
							</label>
						  </div>
						  </div>
						  
						  <div class="col-md-12">
						    <textarea rows="4" cols="50" placeholder="comments" name="comments"></textarea>
						  </div>
						  
						  <div class="clearfix"></div>
					
					             <div class="col-md-12">
								<button class="btn btn-primary">
								   Submit
								   <div class="ripple-container"></div>
								</button>
								</div>
						  
						  </form>
					   </div>
                    						
				   </div>  
				   
				   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				   
				   <!-- <hr class="border_line">-->
					
					
				   <div class="row" style="margin-top:20px;">
				     <div class="col-md-12">
					 <div class="card-header" data-background-color="blue">
						 <h4 class="title">Pickup Service</h4>
					</div>
					 
					   <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<!--<th>TimeSlot</th>-->
										<th>Action</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<!--<th>TimeSlot</th>-->
										<th>Action</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
                                     <?php $__currentLoopData = $UserBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Bookings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($Bookings->bookingId); ?></td>
										<td><?php echo e($Bookings->name); ?></td>
										<td><?php echo e($Bookings->mobile); ?></td>
										<!--<td><?php echo e($Bookings->fromSlots); ?> TO <?php echo e($Bookings->toSlots); ?></td>-->
										<td class="text-right">
											<a href="<?php echo e(route('view.bookings',[$Bookings->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>

									</tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>									
								</tbody>
								
							</table>
					 </div>
					 
				   </div>
				   
				   <div class="row" style="margin-top:20px;">
				     <div class="col-md-12">
					 <div class="card-header" data-background-color="blue">
						<h4 class="title">Delivery Service</h4>
					</div>
					   <table id="datatablesss" class="datatables table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<!--<th>TimeSlot</th>-->
										<th>Action</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<!--<th>TimeSlot</th>-->
										<th>Action</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
                                     <?php $__currentLoopData = $Delivery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $DeliveryService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($DeliveryService->bookingId); ?></td>
										<td><?php echo e($DeliveryService->name); ?></td>
										<td><?php echo e($DeliveryService->mobile); ?></td>
										<!--<td><?php echo e($DeliveryService->fromSlots); ?> TO <?php echo e($DeliveryService->toSlots); ?></td>-->
										<td class="text-right">
											<a href="<?php echo e(route('view.bookings',[$DeliveryService->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>

									</tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>									
								</tbody>
								
							</table>
					 </div>
				   
				   </div>
				   
				   
				   
				   
				   
				</div>
			</div>
		  </div>		
	   </div>	
	</div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
		$('.active-pickup').addClass('active');

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>