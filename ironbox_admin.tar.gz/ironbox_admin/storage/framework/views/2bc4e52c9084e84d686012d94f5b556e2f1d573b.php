
<?php $__env->startSection('content'); ?>


<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Gallery</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					 
                                <form  action="<?php echo e(route('upadte.gallery')); ?>" method="post" id="editgallery" enctype="multipart/form-data">
								   <?php echo e(csrf_field()); ?>

								   <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  <div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Image title
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace" name="title" id="title" value="<?php echo e($photo->title); ?>" type="text" />
										  
										  
									   </div>
									</div> 
									  <input name="id" id="id" value="<?php echo e($photo->id); ?>" type="hidden" />
									<div class="col-md-6">
                           
									  <label class="">
										Image
									  <small>*</small>
									  </label>
									  <input  name="image" id="image" type="file" value="<?php echo e($photo->title); ?>" />
								   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								  </div>
									<div class="clearfix"></div>
									
									<div class="clearfix"></div>
									<div class="col-md-12">
									<button class="btn btn-primary" id="pin_btn">
									   Submit
									   <div class="ripple-container"></div>
									</button>
									</div>
								 </form>
                         					   
					   </div>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>