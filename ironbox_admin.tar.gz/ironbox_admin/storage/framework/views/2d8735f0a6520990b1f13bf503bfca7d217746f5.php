

<?php $__env->startSection('content'); ?>

<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	  <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
				<?php $__currentLoopData = $GetUserDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UserDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<h4 class="title"><?php echo e($UserDetails->name); ?></h4>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
				</div>
				
				<div class="card-content">
				  <?php $__currentLoopData = $GetUserDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UserDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  <div class="box_shadow box_shadow2">
				  <h4 class="yellowtext">User Details</h4>
				   <div class="row">
                    <div class="col-md-6">
                        <div class="user_profile">
						   <img src=" <?php if($UserDetails->image == null){ echo "http://139.59.37.241/Ironman/public/images/pic.png"; }else{ echo $UserDetails->image; } ?>" class="img-responsive  img-circle">
						    
						</div>
                     
 
                     
					  
					    <div class="urdetails">
						   <strong>Name :</strong> <?php echo e($UserDetails->name); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Mobile :</strong> <?php echo e($UserDetails->mobile); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Email :</strong> <?php echo e($UserDetails->email); ?>

						</div>
						
						<div class="urdetails">
						   <strong>DOB :</strong> <?php echo e($UserDetails->dob); ?>

						</div>
					  
					 </div>
					 
					 <div class="col-md-3">
					    <div class="urdetails">
						   <strong>Gender :</strong> <?php echo e($UserDetails->gender); ?>

						</div>
						
						 <div class="urdetails">
						   <strong>Referral Code :</strong> <?php echo e($UserDetails->referral_code); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Wallet amount :</strong>Rs.<?php echo e($UserDetails->wallet_amount); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Joining  date :</strong> <?php echo e($UserDetails->join_date); ?>

						</div>
					 </div>
					 
					  <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <div class="col-md-3">
					    <div class="urdetails">
						   <strong>Total orders :</strong> <?php echo e($ord->total); ?>

						</div>
						<div class="urdetails">
						   <strong>Completed orders :</strong><?php echo e($ord->complete); ?>

						</div>
						 <div class="urdetails">
						   <strong>Pending orders :</strong> <?php echo e($ord->pending); ?>

						</div>
						<div class="urdetails">
						   <strong>Cancelled  orders :</strong> <?php echo e($ord->cancel); ?>

						</div>
					 </div>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				   </div>
				   </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="box_shadow box_shadow6 mt20">
				<h4 class="skybluetext">User Address</h4>
				<div class="row">
				      <div class="col-md-12">
					   
					      <div id="mixedSlider" class="exampleSlider">
                    <div class="MS-content">
					
					  <?php $__currentLoopData = $Address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UserAddr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                           <p><strong>Type</strong> : <?php echo e($UserAddr->title); ?></p>
                            <p><strong>flatNo</strong> : <?php echo e($UserAddr->flatNo); ?></p>
                            <p><strong>Landmark</strong> : <?php echo e($UserAddr->landmark); ?></p>
                            <p><strong>Address</strong> : <?php echo e($UserAddr->address); ?></p>
                            
                        </div>
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="MS-controls">
                        <button class="MS-left"><i class="fa fa-angle-left" aria-hidden="true"></i></button>
                        <button class="MS-right"><i class="fa fa-angle-right" aria-hidden="true"></i></button>
                    </div>
                </div>
					  </div>
				</div>
				</div>
				
				  <a href="<?php echo e(url('UserBookingDown/' . 1 . '')); ?>" class="btn btn-primary btn-r6"> 
						   Download report
						   <div class="ripple-container"></div>
						</a>
				  <div class="row" style="margin-top:40px;">
				      <div class="col-md-12">
					     <div class="card-header" data-background-color="blue">
								<h4 class="title">Booking List</h4>
							</div>
					     <div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $BookingsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $BookingsDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($BookingsDetails->bookingId); ?></td>
										<td><?php echo e($BookingsDetails->bookingDate); ?></td>
										<td><?php echo e($BookingsDetails->fromSlots); ?> -  <?php echo e($BookingsDetails->toSlots); ?></td>
										<td><?php echo e($BookingsDetails->Status); ?></td>


										<td class="text-right">
											<a href="<?php echo e(route('view.bookings',[$BookingsDetails->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
						</div>
					  </div>
				  </div>
				
				
				</div>
				
	      </div>
	    </div>
	  </div>
    </div>
</div>


<script>
        $(document).ready(function () {
            $('.nav-active').addClass('active');
        });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>