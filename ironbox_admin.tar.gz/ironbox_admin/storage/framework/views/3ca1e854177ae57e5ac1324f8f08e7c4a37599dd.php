

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-12">
                             
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="WalletReport"></div>
									<span class="graph_text">Orders</span>
									<span>Dates</span>
                                </div>
                               <div class="card-content">
                                    <div class="col-md-12">
								   <h4 class="title">Wallet amount summary</h4>
								     <table class="table_1">
										  <tr>
											<th>Orders</th>
											<th>Type</th>
											<th>Total amount</th>																			
										  </tr>
										   <?php 
										  if(count($summary) == 0){
											 ?> 
											   <tr>
											   <td colspan="4">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  <?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										  <tr>
											<td><?php echo e($date->orders); ?></td>
											<td><?php echo e($date->type); ?></td>
											<td><?php echo e($date->amount); ?></td>							
										  </tr>
										   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</table>
								   </div>
                                </div>
                            </div>
                         					   
					  
                         </div>					   
					   </div>
					   
					   
					   
					   <div class="row">
						   <div class="col-md-12">
						   <div class="box_shadow box_shadow2">
						      <h4 class="yellowtext">Reports</h4> 
							  <div id="exTab1">
								 <ul  class="nav nav-pills">
									<li class="active">
									   <a  href="#1a" data-toggle="tab" value="1" class="get_wallet_amount">Today</a>
									</li>
									<li><a href="#2a" data-toggle="tab" value="2" class="get_wallet_amount">Weekly</a>
									</li>
									<li><a href="#3a" data-toggle="tab" value="3" class="get_wallet_amount">Monthly</a>
									</li>
									<li><a href="#4a" data-toggle="tab" value="4" class="get_wallet_amount">Yearly</a></li>
									<li><a href="#5a" data-toggle="tab" value="5" class="get_wallet_amount">Custom</a></li>
								 </ul>
								 <div class="tab-content clearfix">
								 
								  
								 
									<div class="tab-pane active" id="1a">
									
									<a href="<?php echo e(route('wallet.report.download',['id'=>1,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">  
								   Download report
								   <div class="ripple-container"></div>
								 </a>
								 
								 <table class="table_1">
								  <tr>								
									<th>Orders</th>							
									<th>Type</th>							
									<th>Amount</th>
								  </tr>
								  
								  <?php 
									  if(count($Days) == 0){
										 ?> 
										   <tr>
										   <td colspan="3">No record</td>
											</tr>
										  <?php
									  }
									  
									  ?>
								   
								  <?php $__currentLoopData = $Days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  <tr>
									<td><?php echo e($Data->orders); ?></td>
									<td><?php echo e($Data->type); ?></td>
									<td><?php echo e($Data->amount); ?></td>
								  </tr>
								   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
									
					                <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingID</th>
										<th>OrderId</th>
										<th>transactionId</th>
										<th>amount</th>
										<th>Status</th>
										<th>Type</th>
										<th>Payment date</th>
										<th class="disabled-sorting text-right">Actions</th>
										
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingID</th>
										<th>OrderId</th>
										<th>transactionId</th>
										<th>amount</th>
										<th>Status</th>
										<th>Type</th>
										<th>Payment date</th>
										<th class="disabled-sorting text-right">Actions</th>
										
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $day_rep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->orderId); ?></td>
										<td><?php echo e($rep->transactionId); ?></td>
										<td><?php echo e($rep->amount); ?></td>
										<td><?php echo e($rep->transation_status); ?></td>
										<td><?php echo e($rep->type); ?></td>
										<td><?php echo e($rep->payment_date); ?></td>
                                        <td class="text-right">
											 <a href="<?php echo e(route('user.details',[$rep->userId])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>

										
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
									  
									</div>
									<div class="tab-pane" id="2a">
									 <a href="<?php echo e(route('wallet.report.download',['id'=>2,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">  
									   Download report
									   <div class="ripple-container"></div>
									</a>
									
								<table class="table_1">
								  <tr>								
									<th>Orders</th>							
									<th>Type</th>							
									<th>Amount</th>
								  </tr>
								    <?php 
									  if(count($Week) == 0){
										 ?> 
										   <tr>
										   <td colspan="3">No record</td>
											</tr>
										  <?php
									  }
									  
									  ?>
								   
								  <?php $__currentLoopData = $Week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  <tr>
									<td><?php echo e($Data->orders); ?></td>
									<td><?php echo e($Data->type); ?></td>
									<td><?php echo e($Data->amount); ?></td>
								  </tr>
								   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
									
									<div class="material-datatables mar20">
									<div class="box_shadow box_shadow2">
								  <h4 class="yellowtext">Weekly Orders</h4>
									<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
											<thead>
												<tr>
													<th>S.No</th>
													<th>BookingID</th>
													<th>OrderId</th>
													<th>transactionId</th>
													<th>amount</th>
													<th>Status</th>
													<th>Type</th>
													<th>Payment date</th>
													<th class="disabled-sorting text-right">Actions</th>
													
												</tr>
											</thead>
											<tfoot>
												<tr>
													<th>S.No</th>
													<th>BookingID</th>
													<th>OrderId</th>
													<th>transactionId</th>
													<th>amount</th>
													<th>Status</th>
													<th>Type</th>
													<th>Payment date</th>
													<th class="disabled-sorting text-right">Actions</th>
													
												</tr>
											</tfoot>
											<tbody>
											 <?php   $count = 1; ?>
											 <?php $__currentLoopData = $week_rep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td><?php echo e($count++); ?></td>
													<td><?php echo e($rep->bookingId); ?></td>
													<td><?php echo e($rep->orderId); ?></td>
													<td><?php echo e($rep->transactionId); ?></td>
													<td><?php echo e($rep->amount); ?></td>
													<td><?php echo e($rep->transation_status); ?></td>
													<td><?php echo e($rep->type); ?></td>
													<td><?php echo e($rep->payment_date); ?></td>
                                                    <td class="text-right">
													 <a href="<?php echo e(route('user.details',[$rep->userId])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
												</td>

													
												</tr>
											   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																							   
											</tbody>
										</table>
										</div>
										</div>
									    
									</div>
									<div class="tab-pane" id="3a">
									 <a href="<?php echo e(route('wallet.report.download',['id'=>3,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">  
									   Download report
									   <div class="ripple-container"></div>
									</a>
									
								<table class="table_1">
								  <tr>								
									<th>Orders</th>							
									<th>Type</th>							
									<th>Amount</th>
								  </tr>
								  
								    <?php 
									  if(count($Month) == 0){
										 ?> 
										   <tr>
										   <td colspan="3">No record</td>
											</tr>
										  <?php
									  }
									  
									  ?>
								   
								  <?php $__currentLoopData = $Month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  <tr>
									<td><?php echo e($Data->orders); ?></td>
									<td><?php echo e($Data->type); ?></td>
									<td><?php echo e($Data->amount); ?></td>
								  </tr>
								   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
									
									<div class="material-datatables mar20">
									<div class="box_shadow box_shadow2">
								  <h4 class="yellowtext">Monthly Orders</h4>
									<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
											<thead>
												<tr>
													<th>S.No</th>
													<th>BookingID</th>
													<th>OrderId</th>
													<th>transactionId</th>
													<th>amount</th>
													<th>Status</th>
													<th>Type</th>
													<th>Payment date</th>
													<th class="disabled-sorting text-right">Actions</th>
													
												</tr>
											</thead>
											<tfoot>
												<tr>
													<th>S.No</th>
													<th>BookingID</th>
													<th>OrderId</th>
													<th>transactionId</th>
													<th>amount</th>
													<th>Status</th>
													<th>Type</th>
													<th>Payment date</th>
													<th class="disabled-sorting text-right">Actions</th>
													
												</tr>
											</tfoot>
											<tbody>
											 <?php   $count = 1; ?>
											 <?php $__currentLoopData = $month_rep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td><?php echo e($count++); ?></td>
													<td><?php echo e($rep->bookingId); ?></td>
													<td><?php echo e($rep->orderId); ?></td>
													<td><?php echo e($rep->transactionId); ?></td>
													<td><?php echo e($rep->amount); ?></td>
													<td><?php echo e($rep->transation_status); ?></td>
													<td><?php echo e($rep->type); ?></td>
													<td><?php echo e($rep->payment_date); ?></td>
                                                    <td class="text-right">
														 <a href="<?php echo e(route('user.details',[$rep->userId])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
													</td>
												</tr>
											   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																							   
											</tbody>
										</table>
										</div>
										</div>
									   
									</div>
									<div class="tab-pane" id="4a">
									 <a href="<?php echo e(route('wallet.report.download',['id'=>4,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">  
									   Download report
									   <div class="ripple-container"></div>
									</a>
									
							    <table class="table_1">
								  <tr>								
									<th>Orders</th>							
									<th>Type</th>							
									<th>Amount</th>
								  </tr>
								  
								  <?php 
									  if(count($Year) == 0){
										 ?> 
										   <tr>
										   <td colspan="3">No record</td>
											</tr>
										  <?php
									  }
									  
									  ?>
								   
								  <?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  <tr>
									<td><?php echo e($Data->orders); ?></td>
									<td><?php echo e($Data->type); ?></td>
									<td><?php echo e($Data->amount); ?></td>
								  </tr>
								   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
									
									<div class="material-datatables mar20">
										<div class="box_shadow box_shadow2">
									  <h4 class="yellowtext">Yearly Orders</h4>
										<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
												<thead>
													<tr>
														<th>S.No</th>
														<th>BookingID</th>
														<th>OrderId</th>
														<th>transactionId</th>
														<th>amount</th>
														<th>Status</th>
														<th>Type</th>
														<th>Payment date</th>
														<th class="disabled-sorting text-right">Actions</th>
														
													</tr>
												</thead>
												<tfoot>
													<tr>
														<th>S.No</th>
														<th>BookingID</th>
														<th>OrderId</th>
														<th>transactionId</th>
														<th>amount</th>
														<th>Status</th>
														<th>Type</th>
														<th>Payment date</th>
														<th class="disabled-sorting text-right">Actions</th>
													</tr>
												</tfoot>
												<tbody>
												 <?php   $count = 1; ?>
												 <?php $__currentLoopData = $year_rep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td><?php echo e($count++); ?></td>
														<td><?php echo e($rep->bookingId); ?></td>
														<td><?php echo e($rep->orderId); ?></td>
														<td><?php echo e($rep->transactionId); ?></td>
														<td><?php echo e($rep->amount); ?></td>
														<td><?php echo e($rep->transation_status); ?></td>
														<td><?php echo e($rep->type); ?></td>
														<td><?php echo e($rep->payment_date); ?></td>

                                                       <td class="text-right">
													 <a href="<?php echo e(route('user.details',[$rep->userId])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
												</td>
														
													</tr>
												   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																								   
												</tbody>
											</table>
											</div>
											</div>
									    
									</div>
									
									<div class="tab-pane" id="5a">
									
									  <form method="post" id="Search_reports" action ="<?php echo e(route('serach.wallet.down')); ?>" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_wallet" name="fromdate" id="walletfrom" type="date"/>
							  <span class="error wallet_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_wallet" name="todate" id="walletto" type="date"/>
							  <span class="error wallet_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
							<th>S.No</th>
							<th>BookingId</th>
							<th>OrderId</th>
							<th>transactionId</th>
							<th>amount</th>
							<th>Status</th>
							<th>Type</th>
							<th>Payment date</th>
							<th>Actions</th>
						  </tr>
						
						    <tbody id="Wallet_report">
                                  <td colspan="9">No record</td>
                            </tbody>
						  
						</table> 
									</div>
									
									
								 </div>
							  </div>
							  </div>
						   </div>
						</div>
					   
					   <!--<div class="row" style="margin-top:20px;">
							<div class="col-lg-12 col-md-12">
								<div class="card">
									<div class="card-header" data-background-color="blue">
										<h4 class="title">Wallet transaction</h4>
									</div>
									<div class="card-content">
										<div class="material-datatables">
											<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
												<thead>
													<tr>
														<th>S.No</th>
														<th>Name</th>
														<th>Mobile</th>
														<th>OrderId</th>
														<th>amount</th>
														<th>Status</th>
														<th>Transaction date</th>
														
													</tr>
												</thead>
												<tfoot>
													<tr>
														<th>S.No</th>
														<th>Name</th>
														<th>Mobile</th>
														<th>OrderId</th>
														<th>amount</th>
														<th>Status</th>
														<th>Transaction date</th>
														
													</tr>
												</tfoot>
												
												<tbody>
												 <?php   $count = 1; ?>
												<?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td><?php echo e($count++); ?></td>
														<td><?php echo e($amount->name); ?></td>
														<td><?php echo e($amount->mobile); ?></td>
														<td><?php echo e($amount->orderId); ?></td>
														<td><?php echo e($amount->amount); ?></td>
														<td><?php echo e($amount->transation_status); ?></td>
														<td><?php echo e($amount->trans_date); ?></td>


														
													</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																								   
												</tbody>
												
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>-->
			
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		$('.active-report').addClass('active');
		$.get("<?php echo e(route('wallet.report.graph')); ?>")
	  .done(function(data) {
		
		// console.log(data);
			demo.WalletChart(data);
							
		});	
		
	
		
		
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>