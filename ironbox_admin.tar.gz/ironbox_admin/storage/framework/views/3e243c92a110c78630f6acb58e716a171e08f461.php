

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Pickup Report</h4>
				</div>
				<div class="card-content">
				   <div class="row">
				        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="orange">
                                    <div class="ct-chart" id="pickupUserGraph"></div>
                                </div>
                               
                             
								<input type='hidden' id="pickupId" value="<?php echo e($userId); ?>">
							
                            </div>
                        </div>
				   </div>
				   
				   
				   <div class="row">
				     <div class="col-md-12">
					    <table class="table_1">
						  <tr>
							<th>Today Report</th>
							<th>Week Report</th>
							<th>Month Report</th>
							<th>Year Report</th>
						  </tr>
						  <tr>
							<td><?php echo e($TodayOrder); ?></td>
							<td><?php echo e($WeekOrder); ?></td>
							<td><?php echo e($MonthOrder); ?></td>
							<td><?php echo e($YearOrder); ?></td> 
						  </tr>
						</table>
					 </div>
				   </div>
				   
				</div>
			</div>
		</div>		
	</div>
	
	
	
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Pickup Report</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Orders </th>
										<th>Date</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Orders </th>
										<th>Date</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Pickup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($GetData->orders); ?></td>
										<td><?php echo e($GetData->order_date); ?></td>
                                        

										<td class="text-right">
										
											
											
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
		// var id = '1';
		
		 var id =  $("#pickupId").val();
		 // alert(id);
		
		var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/PickUpuserGraph',
            data: {_token: csrf,id: id},
            success: function (data) { 
                   // console.log(data);
				   demo.pickupUserChart(data);
            }
        });
		
       // demo.initDashboardPageCharts();
	   
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>