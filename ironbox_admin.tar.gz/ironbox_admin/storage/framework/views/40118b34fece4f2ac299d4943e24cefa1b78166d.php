

<?php $__env->startSection('content'); ?>
<style type="text/css">
	.fa-close{
		margin-top: 17px;
		color: #ff0000;
		font-size: 20px;
	}
</style>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Date Timeslot Assign</h4>
					</div>
					<div class="card-content">
						<form action="<?php echo e(route('admin.datetimeslotassign.action')); ?>" method="post" id="assigntimeslot" enctype="multipart/form-data">
							<?php echo e(csrf_field()); ?>

							<div class="col-md-4">
								<div class="form-group label-floating">
									<select class="form-control" id="month" name="month">
										<option value="">Select Month</option>
										<?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($month==$sel_month): ?>
										<option value="<?php echo e($month); ?>" selected><?php echo e($month); ?></option>
										<?php else: ?>
										<option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>
							<div class="clearfix"></div>

							<?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php
							$sel_leaves=array();
							$leave_reasons=array();
							foreach($all_leaves as $leave){
								$sel_leaves[]=$leave['date'];
								$leave_reasons[$leave['date']]=$leave['reason'];
							}
							?>

							<br>
							<div class="row all_data" style="margin-left: 0% !important;">
								<div class="col-md-3">
									<div class="form-group label-floating">
										<label class="control-label">Date<small>*</small></label>
										<input class="form-control emptyspace date" type="text" value="<?php echo e($date); ?>" readonly />
									</div>
								</div>

								<?php
								$disabled='disabled';
								if($date>=date('Y-m-d')){
									$disabled='';
								}
								?>

								<div class="col-md-6 warehouse_list">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group label-floating">
												<?php if(in_array($date,$sel_leaves)==true): ?>
												<select class="form-control sel_warehouse" date="<?php echo e($date); ?>" <?php echo e($disabled); ?> disabled>
												<?php else: ?>
												<select class="form-control sel_warehouse" date="<?php echo e($date); ?>" <?php echo e($disabled); ?>>
												<?php endif; ?>
													<option value="">Select warehouse</option>
													<?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($warehouse->id); ?>"> <?php echo e($warehouse->name); ?> </option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
											</div>
										</div>

										<div class="col-md-2">
											<div class="leave_check" style="margin-top: 15px;">
												<?php if(in_array($date,$sel_leaves)==true): ?>
												<input type="checkbox" name="leave[]" class="leave" value="<?php echo e($date); ?>" <?php echo e($disabled); ?> checked> Leave
												<?php else: ?>
												<input type="checkbox" name="leave[]" class="leave" value="<?php echo e($date); ?>" <?php echo e($disabled); ?>> Leave
												<?php endif; ?>
											</div>
										</div>

										<div class="col-md-4">
											<?php if(in_array($date,$sel_leaves)==true): ?>
											<div class="form-group label-floating reason_show">
												<label class="control-label">Reason<small>*</small></label>
												<input class="form-control emptyspace" type="text" name="leave_reason_<?php echo e($date); ?>" <?php echo e($disabled); ?> value="<?php echo e($leave_reasons[$date]); ?>">
											</div>
											<?php else: ?>
											<div class="form-group label-floating reason_show" hidden>
												<label class="control-label">Reason<small>*</small></label>
												<input class="form-control emptyspace" type="text" name="leave_reason_<?php echo e($date); ?>" <?php echo e($disabled); ?> value="">
											</div>
											<?php endif; ?>
										</div>
									</div>
									<div class="row warehouses">
										<?php
										$sel_leaves=array();
										foreach($all_leaves as $leave){
											$sel_leaves[]=$leave['date'];
										}

										foreach($fetchArray as $dates_array){
											if(!empty($dates_array[$date])){

												if(in_array($date,$sel_leaves)==true){
													
												}

												foreach($dates_array[$date] as $whs){
													if(!empty($whs)){
														if(!is_array($whs)){
															$pin_id=explode("$",$whs);
															?>
															<div class="every_warehouse">
																<div class="col-md-6">
																	<div class="form-group label-floating">
																		<select class="form-control real_warehouses" readonly>
																			<option value="<?php echo e($pin_id[0]); ?>"><?php echo e($pin_id[1]); ?></option>
																		</select>
																	</div>
																</div>

																<div class="ts_list">
																	<div class="col-md-5">
																		<div class="form-group label-floating">

																			<?php if(in_array($date,$sel_leaves)==true): ?>
																			<select class="form-control sel_timeslot" date="<?php echo e($date); ?>" onchange="sel_timeslot(this)" <?php echo e($disabled); ?> disabled>
																			<?php else: ?>
																			<select class="form-control sel_timeslot" date="<?php echo e($date); ?>" onchange="sel_timeslot(this)" <?php echo e($disabled); ?>>
																			<?php endif; ?>
																				<option value="">Select Time Slot</option>
																				<?php $__currentLoopData = $time_slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time_slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				<option value="<?php echo e($time_slot->id); ?>"> <?php echo e($time_slot->fromSlots.' - '.$time_slot->toSlots); ?> </option>
																				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																			</select>
																		</div>
																	</div>

																	<div class="col-md-1">
																		<?php if($date>=date('Y-m-d')): ?>
																		<a href="javascript:void(0)" onclick="remove_warehouse(this)"><i class="fa fa-close" style="margin-left: 75%;"></i></a>
																		<?php endif; ?>
																	</div>

																	<div class="row time_slots">
																		<?php
																		foreach($fetchArray_ts as $dates_array_ts){
																			if(!empty($dates_array_ts[$date])){
																				if(!empty($dates_array_ts[$date][$whs])){
																					foreach($dates_array_ts[$date][$whs] as $timeslots){
																						if(!empty($timeslots)){
																							$slots=explode("$",$timeslots);

																							$all_details=$date.' $ '.$pin_id[0].' $ '.$slots[0].' $ '.$slots[2];
																							?>

																							<div class="slots_and_counts">
																								<div class="col-md-6"></div>
																								<div class="col-md-3">
																									<div class="form-group label-floating">
																										<select class="form-control tslots" readonly>
																											<option value="<?php echo e($slots[0]); ?>"><?php echo e($slots[1]); ?></option>
																										</select>
																									</div>
																								</div>
																								<div class="col-md-2">
																									<div class="form-group label-floating">
																										<label class="control-label">Slots<small>*</small></label>
																										<?php if(in_array($date,$sel_leaves)==true): ?>
																										<input class="form-control emptyspace slots" type="text" onkeyup="slot_count(this)" value="<?php echo e($slots[2]); ?>" disabled <?php echo e($disabled); ?>>
																										<?php else: ?>
																										<input class="form-control emptyspace slots" type="text" onkeyup="slot_count(this)" value="<?php echo e($slots[2]); ?>" <?php echo e($disabled); ?>>
																										<?php endif; ?>
																										<input type="hidden" class="all_details" name="all_details[]" value="<?php echo e($all_details); ?>">
																									</div>
																								</div>
																								<div class="col-md-1">
																									<?php if($date>=date('Y-m-d')): ?>
																									<a href="javascript:void(0)" onclick="remove_timeslot(this)"><i class="fa fa-close"></i></a>
																									<?php endif; ?>
																								</div>
																							</div>
																							<div class="clearfix"></div>

																							<?php
																						}
																					}
																				}
																			}
																		}
																		?>
																	</div>
																</div>
															</div>

															<div class="clearfix"></div>
															<?php
														}
													}
												}
											}
										}
										?>
									</div>
								</div>

								<div class="time_slots_div" hidden>
									<div class="ts_list">
										<div class="col-md-5">
											<div class="form-group label-floating">
												<select class="form-control sel_timeslot" date="<?php echo e($date); ?>" onchange="sel_timeslot(this)">
													<option value="">Select Time Slot</option>
													<?php $__currentLoopData = $time_slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time_slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($time_slot->id); ?>"> <?php echo e($time_slot->fromSlots.' - '.$time_slot->toSlots); ?> </option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
											</div>
										</div>
										<div class="col-md-1">
											<a href="javascript:void(0)" onclick="remove_warehouse(this)"><i class="fa fa-close" style="margin-left: 75%;"></i></a>
										</div>
										<div class="row time_slots">

										</div>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							<div class="clearfix"></div>
							<button class="btn btn-primary">
								Submit
								<div class="ripple-container"></div>
							</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function(){
		$("#month").change(function(){
			var month=$(this).val();
			window.location.href="<?php echo e(URL::to('DateTimeSlotAssign')); ?>/"+month;
		});

		$(".sel_warehouse").change(function(){
			var id=$(this).val();
			var date=$(this).attr("date");
			var value=$(this).children("option:selected").html();
			var time_slots=$(this).closest(".all_data").find(".time_slots_div").html();

            var sel_warehouses=[];
            $(this).closest(".warehouse_list").find(".real_warehouses").each(function(){
               sel_warehouses.push($(this).val());
            });

            if(jQuery.inArray(id, sel_warehouses) == -1){
            	$(this).closest(".warehouse_list").find(".warehouses").append('<div class="every_warehouse"><div class="col-md-6"><div class="form-group label-floating"><select class="form-control real_warehouses" readonly><option value="'+id+'">'+value+'</option></select></div></div>'+time_slots+'</div><div class="clearfix"></div>');
            }

			$(".sel_warehouse option:selected").prop("selected", false);
		});

		$(".leave").click(function(){
			if($(this).prop("checked")==true){
				$(this).closest(".warehouse_list").find(".sel_warehouse").prop("disabled",true);
				$(this).closest(".warehouse_list").find(".sel_timeslot").prop("disabled",true);
				$(this).closest(".warehouse_list").find(".slots").prop("disabled",true);
				$(this).closest(".warehouse_list").find(".reason_show").show();
			} else {
				$(this).closest(".warehouse_list").find(".sel_warehouse").prop("disabled",false);
				$(this).closest(".warehouse_list").find(".sel_timeslot").prop("disabled",false);
				$(this).closest(".warehouse_list").find(".slots").prop("disabled",false);
				$(this).closest(".warehouse_list").find(".reason_show").hide();
			}
		});
	});

	function sel_timeslot(this1){
		var id=$(this1).val();
		var date=$(this1).attr("date");
		var pin_id=$(this1).closest(".every_warehouse").find(".real_warehouses").val();
		var value=$(this1).children("option:selected").html();


		var sel_timeslots=[];
		$(this1).closest(".every_warehouse").find(".tslots").each(function(){
			sel_timeslots.push($(this).val());
		});

		if(jQuery.inArray(id, sel_timeslots) == -1){
			$(this1).closest(".ts_list").find(".time_slots").append('<div class="slots_and_counts"><div class="col-md-6"></div><div class="col-md-3"><div class="form-group label-floating"><select class="form-control tslots" readonly><option value="'+id+'">'+value+'</option></select></div></div><div class="col-md-2"><div class="form-group label-floating"><label class="control-label">Slots<small>*</small></label><input class="form-control emptyspace" type="text" onkeyup="slot_count(this)"> <input type="hidden" class="all_details" name="all_details[]"></div></div><div class="col-md-1"><a href="javascript:void(0)" onclick="remove_timeslot(this)"><i class="fa fa-close"></i></a></div></div><div class="clearfix"></div>');
		}

		$(".sel_timeslot option:selected").prop("selected", false);
	}

	function slot_count(this1){
		var date=$(this1).closest(".all_data").find(".date").val();
		var warehouse=$(this1).closest(".every_warehouse").find(".real_warehouses").val();
		var time_slots=$(this1).closest(".slots_and_counts").find(".tslots").val();
		var slot_count=$(this1).val();

		var all_details=date+' $ '+warehouse+' $ '+time_slots+' $ '+slot_count;

		$(this1).closest(".slots_and_counts").find(".all_details").val(all_details);

	}

	function remove_timeslot(this1){
		$(this1).closest(".slots_and_counts").remove();
	}

	function remove_warehouse(this1){
		$(this1).closest(".every_warehouse").remove();
	}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>