

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Order List</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>User Name</th>
										<!--<th>Delivery Users</th>-->
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>User Name</th>
										<!--<th>Delivery Users</th>-->
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $BookingsList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($BookingsList->bookingId); ?></td>
										<td><?php echo e($BookingsList->name); ?></td>
										<!--<td><?php echo e($BookingsList->deliveryusers); ?></td>-->
										<td><?php echo e($BookingsList->bookingDate); ?></td>
										<td><?php echo e($BookingsList->fromSlots); ?> -  <?php echo e($BookingsList->toSlots); ?></td>
										<td><?php echo e($BookingsList->Status); ?></td>


										<td class="text-right">
											<a href="<?php echo e(route('view.bookings',[$BookingsList->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>