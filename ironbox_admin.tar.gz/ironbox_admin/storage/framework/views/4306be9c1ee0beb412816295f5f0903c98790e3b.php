<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>IronBox</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
	
    <link href="<?php echo e(asset('css/demo.css')); ?>" rel="stylesheet" />
    <!--  Material Dashboard CSS    -->
    <link href="<?php echo e(asset('css/material-dashboard.css')); ?>" rel="stylesheet" />
    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
</head>
<body>
  <div class="wrapper">
     <div class="sidebar" data-active-color="blue" data-background-color="white">
            <div class="logo">
                <a href="<?php echo e(route('outlet.dashboard')); ?>" class="simple-text">
                    <img src="<?php echo e(asset('images/ironbox.png')); ?>" alt="" class="responsive-img ironbox_logo">
					<span>IronBox</span>
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="<?php echo e(Request::path() == 'outlet/view' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('outlet.dashboard')); ?>">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
					
					<li class="<?php echo e(Request::path() == 'AddManager' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('w.add.manager')); ?>">
                            <i class="material-icons">dashboard</i>
                            <p>Manager</p>
                        </a>
                    </li>
					
					
					

                                     
                </ul>
            </div>
        </div>
		
		<div class="main-panel">
		  <nav class="navbar navbar-transparent navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
							<a href="<?php echo e(route('outlet.logout')); ?>"
                            onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                                   <i class="material-icons">exit_to_app</i>
								   
                                </a>
								<form id="logout-form" action="<?php echo e(route('outlet.logout')); ?>" method="POST" style="display: none;">
                             <?php echo e(csrf_field()); ?>

                         </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
		     <?php echo $__env->yieldContent('content'); ?>
			 
			 
			 <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                            <li>
                                <a href="#">
                                    Home
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Company
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Blog
                                </a>
                            </li>
                        </ul>
                    </nav>
                    
                </div>
            </footer>
		
		</div>
  
  </div>
  
  
  <!--   Core JS Files   -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  

<script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/timepicker.js')); ?>" type="text/javascript"></script>
<script>

</script>
<script src="<?php echo e(asset('js/custom.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.validate.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/form_validation.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>

<script src="<?php echo e(asset('js/material.min.js')); ?>" type="text/javascript"></script>
<!--  Charts Plugin -->
<script src="<?php echo e(asset('js/chartist.min.js')); ?>" type="text/javascript"></script>
<!--  Dynamic Elements plugin -->
<script src="<?php echo e(asset('js/arrive.min.js')); ?>" type="text/javascript"></script>
<!--  PerfectScrollbar Library -->
<script src="<?php echo e(asset('js/perfect-scrollbar.jquery.min.js')); ?>" type="text/javascript"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo e(asset('js/bootstrap-notify.js')); ?>" type="text/javascript"></script>
<!--  datatables Plugin    -->
<script src="<?php echo e(asset('js/jquery.datatables.js')); ?>" type="text/javascript"></script>
<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Material Dashboard javascript methods -->
<script src="<?php echo e(asset('js/material-dashboard.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/demo.js')); ?>" type="text/javascript"></script>



<script type="text/javascript">
    $(document).ready(function() {
        // demo.initDashboardPageCharts();
        $('#datatables').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            responsive: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search records",
            }

        });
    });
	
	$(document).ready(function() {
        // demo.initDashboardPageCharts();
        $('.datatables').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            responsive: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search records",
            }

        });
    });
</script>
<script src="<?php echo e(asset('js/bootstrap-combobox.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/outlet.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBBIoRB70Md6z9oI58trE9QtokUTiNndYo&libraries=places"></script>
<script src="<?php echo e(asset('js/map.js')); ?>" type="text/javascript"></script>

</body>
</html>