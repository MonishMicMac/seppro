

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	  <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">User Details</h4>
				</div>
				
				<div class="card-content">
				  <?php $__currentLoopData = $GetUserDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UserDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				   <div class="row">
                    <div class="col-md-3">
                        <div class="user_profile">
						   <img src=" <?php if($UserDetails->image == null){ echo "http://139.59.37.241/Ironman/public/images/pic.png"; }else{ echo $UserDetails->image; } ?>" class="img-responsive center-block img-circle">
						    
						</div>
                       </div>	
 
                     <div class="col-md-4">
					  
					    <div class="urdetails">
						   <strong>Name :</strong> <?php echo e($UserDetails->name); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Mobile :</strong> <?php echo e($UserDetails->mobile); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Email :</strong> <?php echo e($UserDetails->email); ?>

						</div>
						
						<div class="urdetails">
						   <strong>DOB :</strong> <?php echo e($UserDetails->dob); ?>

						</div>
					  
					 </div>
					 
					 <div class="col-md-4">
					    <div class="urdetails">
						   <strong>Gender :</strong> <?php echo e($UserDetails->gender); ?>

						</div>
						
						 <div class="urdetails">
						   <strong>Referral Code :</strong> <?php echo e($UserDetails->referral_code); ?>

						</div>
						
						<div class="urdetails">
						   <strong>Wallet amount :</strong>Rs.<?php echo e($UserDetails->wallet_amount); ?>

						</div>
					 </div>
					   
				   </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  
				  <div class="row">
				      <div class="col-md-12">
					  <h4>Booking List</h4>
					     <div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $BookingsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $BookingsDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($BookingsDetails->bookingId); ?></td>
										<td><?php echo e($BookingsDetails->bookingDate); ?></td>
										<td><?php echo e($BookingsDetails->fromSlots); ?> -  <?php echo e($BookingsDetails->toSlots); ?></td>
										<td><?php echo e($BookingsDetails->Status); ?></td>


										<td class="text-right">
											<a href="<?php echo e(route('view.bookings',[$BookingsDetails->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
						</div>
					  </div>
				  </div>
				
				
				</div>
				
	      </div>
	    </div>
	  </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>