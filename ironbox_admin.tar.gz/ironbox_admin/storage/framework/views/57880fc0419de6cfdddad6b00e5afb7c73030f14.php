

<?php $__env->startSection('content'); ?>


<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Customer Support</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Comments</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Comments</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Support): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($Support->name); ?></td>
										<td><?php echo e($Support->mobile); ?></td>
										<td><?php echo e($Support->Comments); ?></td>


										<td class="text-right">
								
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>