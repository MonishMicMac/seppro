

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Add Service Area</h4>
				</div>
				<div class="card-content">
				   <form  action="<?php echo e(route('add.service.area')); ?>" method="post" id="servicearea" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					   <div class="col-md-6">
						 <div class="form-group label-floating">
							
							<select  class="form-control" id="warehousename" name="warehousename">
								<option value="">Select warehouse</option>
								<option value="1">warehouse - 1</option>
								<option value="2">warehouse - 2</option>
							</select>
						 </div>
					   </div>
					   
					   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Pincode
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" maxlength ="6" name="pincode" id="pincode" type="text" />
                           </div>
						   <div id="pin_valid"></div>
						   
                        </div>
						
						<div class="clearfix"></div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Areaname
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="areaname" id="areaname" type="text" />
                           </div>
                        </div>
					     
						<div class="clearfix"></div>
						<div class="col-md-12">
						<button class="btn btn-primary" id="pin_btn">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>		
	
	
	
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Service Area List</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Warehouses </th>
										<th>Areaname </th>
										<th>Pincode</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Warehouses </th>
										<th>Areaname </th>
										<th>Pincode</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $code; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PincodeCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($PincodeCode->warehouseId); ?></td>
										<td><?php echo e($PincodeCode->area); ?></td>
										<td><?php echo e($PincodeCode->code); ?></td>


										<td class="text-right">
											<a  data-toggle="modal" data-target="#editpin" class="btn btn-simple btn-warning btn-icon edit pin_edit" value="<?php echo e($PincodeCode->id); ?>" href="" id=""><i class="fa fa-pencil-square-o"></i></a>
											
											<a  onclick="return confirm('Are you sure you want to delete pincode');" class="delete_pin" href="<?php echo e(route('delete.pin')); ?>?id=<?php echo e($PincodeCode->id); ?>"> <i class="fa fa-trash"></i></a>
											
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<div id="editpin" class="modal fade" role="dialog">
          <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
          <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Pincode</h4>
          </div>
          <div class="modal-body">
               <div class="row">
                 <form  action="<?php echo e(route('edit.pin.save')); ?>" id="Editservicearea" method="post">
						<?php echo e(csrf_field()); ?>

						
					<div class="col-md-6">
						 <div class="form-group label-floating">
							<label class="control-label">
								Select warehouses
							    <small>*</small>
							  </label>
							<select  class="select_box" id="editwarehousename" name="warehousename">
								
							</select>
							
							<input type="hidden" id="Epinid" name="id">
						 </div>
					   </div>	
						
                    <div class="col-md-6">
                      <div class="form-group label-floating">
					  <label class="control-label">
						Pincode
					  <small>*</small>
					  </label>
					  <input class="txt_box numbersnot emptyspace numbersOnly" maxlength ="6" name="pincode" id="Epincode" type="text" />
				   </div>
				   <div id="Epin_valid"></div>
                    </div>
					
                    <div class="clearfix"></div>
					
					<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Areaname
                              <small>*</small>
                              </label>
                              <input class="txt_box emptyspace"  name="Eareaname" id="Eareaname" type="text" />
                           </div>
                        </div>
					<div class="clearfix"></div>
                    <button class="btn btn-primary" id="pin_btn1">
                       Submit
                       <div class="ripple-container"></div>
                    </button>
                  </form>
               </div>
          </div>

          </div>
          </div>
          </div>
		  
		  
		  <script>
		  
$(function () {


});
		  
		  $(document).ready(function(){
		$(".delete_pin").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"<?php echo e(route('delete.pin')); ?>?id="+id);
        });

        });
		  </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>