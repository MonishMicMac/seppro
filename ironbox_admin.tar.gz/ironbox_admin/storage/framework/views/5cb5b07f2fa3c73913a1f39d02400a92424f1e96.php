

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PickupUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<h4 class="title"><?php echo e($PickupUser->name); ?> - Report</h4>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="card-content">
				   <div class="row">
				        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="orange">
                                    <div class="ct-chart" id="pickupUserGraph"></div>
									
                                </div>
                               
							   <div class="card-content">
                                    <h4 class="title">Pickup user report</h4>
                                </div>
                             
								<input type='hidden' id="pickupId" value="<?php echo e($userId); ?>">
							
                            </div>
                        </div>
				   </div>
				   
				   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 <h4 class="yellowtext">Reports</h4>
					 
					    

        <div id="exTab1">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab" value="1" class="pickup_graph">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab" value="2" class="pickup_graph">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab" value="3" class="pickup_graph">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab" value="4" class="pickup_graph">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab" value="5" class="pickup_graph">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
			     
				  <a href="<?php echo e(route('pickup.reports',['type'=>'normal','id'=>1,'pickupId'=>$userId])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
							<th>Orders</th>							
							<th>Order for</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						  <?php $__currentLoopData = $Days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->orders); ?></td>
							<td><?php echo e($OrderDay->Pickup); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->total); ?></td>							
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Report</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $TodayOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->bookingDate); ?></td>
										<td><?php echo e($rep->Pickup); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
			  
                     
				</div>
				<div class="tab-pane" id="2a">
				
				<a href="<?php echo e(route('pickup.reports',['type'=>'normal','id'=>2,'pickupId'=>$userId])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
							<th>Orders</th>							
							<th>Order for</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						  <?php $__currentLoopData = $Weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->orders); ?></td>
							<td><?php echo e($OrderDay->Pickup); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->total); ?></td>							
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Report</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $WeekOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->bookingDate); ?></td>
										<td><?php echo e($rep->Pickup); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						
                      
				</div>
               <div class="tab-pane" id="3a">
			   
			   <a href="<?php echo e(route('pickup.reports',['type'=>'normal','id'=>3,'pickupId'=>$userId])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
							<th>Orders</th>							
							<th>Order for</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						  <?php $__currentLoopData = $Months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->orders); ?></td>
							<td><?php echo e($OrderDay->Pickup); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->total); ?></td>							
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						
						
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Month Report</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $MonthOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->bookingDate); ?></td>
										<td><?php echo e($rep->Pickup); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						
						
                   
				</div>
            <div class="tab-pane" id="4a">
                
				 <a href="<?php echo e(route('pickup.reports',['type'=>'normal','id'=>4,'pickupId'=>$userId])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
						
						<table class="table_1">
						  <tr>
							<th>Orders</th>							
							<th>Order for</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  
						  <?php $__currentLoopData = $Years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->orders); ?></td>
							<td><?php echo e($OrderDay->Pickup); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->total); ?></td>							
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Year Report</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Order for</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $YearOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->bookingDate); ?></td>
										<td><?php echo e($rep->Pickup); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						 
				</div>
				
				<div class="tab-pane" id="5a">
				    <form method="post" id="Search_reports" action="<?php echo e(route('pickup.orders.down')); ?>" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="fromdate" id="pickupfrom" type="date"/>
							  <input type='hidden' id="pickupId_1" name="pickupId" value="<?php echo e($userId); ?>">
							  <span class="error pickup_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="todate" id="pickupto" type="date"/>
							  <span class="error pickup_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>BookingId</th>
							<th>Booking date</th>
							<th>Order for</th>
							<th>Status</th>						
							<th>Actions</th>						
						  </tr>
						
                           
						    <tbody id="pickup_report">
                                  <td colspan="5">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
				
				</div>
				
				
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
				   
				</div>
			</div>
		</div>		
	</div>
	
	
	
	
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		$('.active-pickup').addClass('active');
		 var id =  $("#pickupId").val();
		var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/PickUpuserGraph',
            data: {_token: csrf,id: id},
            success: function (data) { 
				   demo.pickupUserChart(data);
            }
        });
		
	   
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>