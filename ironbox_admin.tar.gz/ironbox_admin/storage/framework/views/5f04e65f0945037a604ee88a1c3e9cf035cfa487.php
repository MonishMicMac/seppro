

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
   <a href="<?php echo e(route('download.orders',['type'=>'total'])); ?>" class="btn btn-primary btn-rit"> 
						   Download report
						   <div class="ripple-container"></div>
						</a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Order List</h4>
					</div>
					
					<div class="card-content">
					
					<div class="row">
					  <div class="col-lg-12 col-md-12">
					     <form  action="<?php echo e(route('search.order.list')); ?>" method="get" id="AddComplaints" enctype="multipart/form-data">
			
					           <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control" name="fromdate"  type="text" placeholder="DD-MM-YYYY" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" / title="Please Enter DD-MM-YYYY this format only ">
                           </div>
						  </div>
						  
						  <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control" name="todate" type="text"  placeholder="DD-MM-YYYY" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{4}" / title="Please Enter DD-MM-YYYY this format only"/>
							  <span class="error area_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-3">
									   <div class="form-group">
										  <label class="control-label">
											BookingId
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace" name="bookId" id="bookId" type="text" />
									   </div>
									</div>
						  
						  <div class="col-md-3">
						     <button class="btn btn-primary" type="submit">
						   Search
						   <div class="ripple-container"></div>
						</button>
						
						<button class="btn btn-primary" name="orderlist" value="download" type="submit" style="padding:13px!important;">
						   Download
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  
					     </form>
					  </div>
					</div>
					
						<div class="material-datatables">
							<table id="datatbles" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>User Name</th>
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>User Name</th>
										<th>Booking Date</th>
										<th>Time Slot</th>
										<th>Status</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
								<?php   
								
								if(count($Bookings) == 0){
									
									?>
									<tr colspan="4">
										<td><b>No record</b></td>
										
									</tr>
									
									<?php
									
								}
								
								?>
								
								  <?php  if(count($Bookings) > 0)  {$i = $Bookings->perPage() * ($Bookings->currentPage() - 1); }
                                
                            ?>
								<?php $__currentLoopData = $Bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $BookingsList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($i+1); ?></td>
										<td><?php echo e($BookingsList->bookingId); ?></td>
										<td><?php echo e($BookingsList->name); ?></td>
										<td><?php echo e($BookingsList->bookingDate); ?></td>
										<td><?php echo e($BookingsList->fromSlots); ?> -  <?php echo e($BookingsList->toSlots); ?></td>
										<td><?php echo e($BookingsList->Status); ?>  <?php if($BookingsList->cancelReason != null): ?> / CANCELLED <?php endif; ?></td>


										<td class="text-right">
											<a href="<?php echo e(route('view.bookings',[$BookingsList->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
											<a onclick="return confirm('Are you sure you want to cancel order');" class="delete_order" href="<?php echo e(route('delete.order')); ?>?id=<?php echo e($BookingsList->id); ?>" data-toggle="tooltip" data-original-title="Cancel"> <i class="fa fa-trash"></i></a>
										</td>
									</tr>
									<?php  $i++;   ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
					   <?php if($Bookings): ?>
						 <?php echo $Bookings->links(); ?>

					   <?php endif; ?>
					 
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

		  <script>
		  
$(function () {


});
		  
		  $(document).ready(function(){
		$(".delete_order").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"<?php echo e(route('delete.timeslot')); ?>?id="+id);
        });

        });

		  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>