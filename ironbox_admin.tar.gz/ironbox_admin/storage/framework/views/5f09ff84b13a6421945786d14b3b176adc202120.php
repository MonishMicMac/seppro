

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">PickUp User Location</h4>
					</div>
					<div class="card-content">
					  <!--<button class="btn btn-primary" id="map_click">
						   Submit
						   <div class="ripple-container"></div>
						</button>-->
					
						<div id="map" style="width: 1000px; height: 500px;"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>