

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-6">
						<h4 class="title">Monthly sales clothes vs quantity</h4>
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="dailySales"></div>
                                </div>
                                <div class="card-content">
                                    
                                </div>
                            </div>
                         </div>	

							<div class="col-md-6">
							<h4 class="title">Monthly sales clothes vs amount</h4>
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="dailySalesRevenue"></div>
                                </div>
                                <div class="card-content">
                                    
                                </div>
                                </div>
                            </div>
                    
					         <div class="clearfix"></div>
							 
							 <div class="col-md-12">
								   <h4 class="title">Category total summary</h4>
								     <table class="table_1">
										  <tr>
											<th>Category name</th>							
											<th>Quantity</th>							
											<th>Total amount</th>							
										  </tr>
										   <?php 
										  if(count($summary) == 0){
											 ?> 
											   <tr>
											   <td colspan="4">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  <?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										  <tr>
											<td><?php echo e($date->name); ?></td>							
											<td><?php echo e($date->qty); ?></td>							
											<td><?php echo e($date->price_amount); ?></td>							
										   
										  </tr>
										   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</table>
								   </div>
							 
							
					   </div>
					   
					 
					   
					   
					   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 
					    <h4 class="yellowtext">Reports</h4> 

        <div id="exTab1" class="">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab" value="1" class="get_category_value">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab" value="2" class="get_category_value">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab" value="3" class="get_category_value">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab" value="4" class="get_category_value">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab" value="5" class="get_category_value">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">
			    <div class="tab-pane active" id="1a">
				 <a href="<?php echo e(route('clothe.report.download',['id'=>1,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     <table class="table_1">
						  <tr>
						    <th>Clothes</th>
							<th>Quantity</th>							
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($Day) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->name); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->price_amount); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
				</div>
				<div class="tab-pane" id="2a">
				
				 <a href="<?php echo e(route('clothe.report.download',['id'=>2,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     
                   <table class="table_1">
						  <tr>
						    <th>Clothes</th>
							<th>Quantity</th>							
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($Week) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->name); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->price_amount); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					 
				</div>
                <div class="tab-pane" id="3a">
				<a href="<?php echo e(route('clothe.report.download',['id'=>3,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     <table class="table_1">
						  <tr>
						    <th>Clothes</th>
							<th>Quantity</th>							
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($Month) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->name); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->price_amount); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
				</div>
                <div class="tab-pane" id="4a">
				<a href="<?php echo e(route('clothe.report.download',['id'=>4,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a>
                     <table class="table_1">
						  <tr>
						    <th>Clothes</th>
							<th>Quantity</th>							
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($Year) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->name); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->price_amount); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>   
				</div>
				
				 <div class="tab-pane" id="5a">
				 
				    <form method="post" id="Search_report" action="<?php echo e(route('cate.clothes.down')); ?>" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					      <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_cate" name="fromdate" id="clothesfrom" type="date"/>
							  <span class="error clothes_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_cate" name="todate" id="clothesto" type="date"/>
							  <span class="error clothes_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-3">
							 <div class="form-group">
								<label class="control-label">
                                Category
                              <small>*</small>
                              </label>
								<select  class="form-control custom_graph_cate" id="cateId" name="cateId">
									<option value="">Select Category</option>
									<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									
                                      <option value="<?php echo e($data->id); ?>"> <?php echo e($data->name); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							 </div>
						   </div>
						  
						  <div class="col-md-3">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>Clothes category</th>
						    <th>quantity</th>
							<th>Amount</th>							
						  </tr>
						
                           
						    <tbody id="Cloth_report">
                                  <td colspan="3">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
				 
				 </div>
				
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		
		$('.active-report').addClass('active');
		
		$.get("<?php echo e(route('month.cloth.sales')); ?>")
	  .done(function(data) {
		
			demo.SalesChart(data);
							
		});	
		
	  $.get("<?php echo e(route('month.cloth.revenue')); ?>")
	  .done(function(data) {
			demo.ClothRevenue(data);
							
		});	
		
		
		
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>