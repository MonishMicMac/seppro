

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Categories</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					 
                                <form  action="<?php echo e(route('add.main.category')); ?>" method="post" id="addmaincategory" enctype="multipart/form-data">
								   <?php echo e(csrf_field()); ?>

								  <div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Category Name
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace" name="cname" id="cname" type="text" />
									   </div>
									</div> 
									
									<div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Price
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace numbersOnly" name="price" id="price" type="text" />
									   </div>
									</div> 
									<div class="clearfix"></div>
									<div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Quantity
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace numbersOnly" name="quantity" id="quantity" type="text" />
									   </div>
									</div> 
									
									<div class="clearfix"></div>
									<div class="col-md-12">
									<button class="btn btn-primary" id="pin_btn">
									   Submit
									   <div class="ripple-container"></div>
									</button>
									</div>
								 </form>
                         					   
					   </div>
					   
					   <div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Categories List</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Price</th>
										<th>Qty</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Price</th>
										<th>Qty</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $CategoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($Category->name); ?></td>
										<td><?php echo e($Category->price); ?></td>
										<td><?php echo e($Category->Qty); ?></td>


										<td class="text-right">
											<a  data-toggle="modal" data-target="#editcategory" class="btn btn-simple btn-warning btn-icon edit edit_categorylist" value="<?php echo e($Category->id); ?>" href="" ><i class="fa fa-pencil-square-o"></i></a>
											
											<a  onclick="return confirm('Are you sure you want to delete category');" class="delete_main_cate" href="<?php echo e(route('delete.main.cate')); ?>?id=<?php echo e($Category->id); ?>" data-toggle="tooltip" data-original-title="Delete"> <i class="fa fa-trash"></i></a>
											
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<div id="editcategory" class="modal fade" role="dialog">
          <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
          <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Category</h4>
          </div>
          <div class="modal-body">
               <div class="row">
                 <form  action="<?php echo e(route('update.category')); ?>" id="addmaincategory5" method="post" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						
		
						
                    <div class="col-md-6">
                      <div class="form-group label-floating">
					  <label class="control-label">
						Category Name
					  <small>*</small>
					  </label>
					  <input class="txt_box emptyspace" name="cname" id="Enames" type="text" />
				   </div>
                    </div>
					
					<div class="col-md-6">
                      <div class="form-group label-floating">
					  <label class="control-label">
						Price
					  <small>*</small>
					  </label>
					  <input class="txt_box numbersnot emptyspace numbersOnly" name="price" id="Eprice" type="text" />
					  
					  <input type="hidden" id="Eid" name="id">
					  
				   </div>
				
                    </div>
					
                    <div class="clearfix"></div>
					
					<div class="col-md-6">
                      <div class="form-group label-floating">
					  <label class="control-label">
						Quantity
					  <small>*</small>
					  </label>
					  <input class="txt_box numbersnot emptyspace numbersOnly" name="quantity" id="Eqty" type="text" />
				   </div>
                    </div>
					<div class="clearfix"></div>
                    <button class="btn btn-primary" id="">  
                       Submit
                       <div class="ripple-container"></div>
                    </button>
                  </form>
               </div>
          </div>

          </div>
          </div>
          </div>

	  <script>
		  
$(function () {


});
		  
		  $(document).ready(function(){
		$(".delete_main_cate").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"<?php echo e(route('delete.pin')); ?>?id="+id);
        });

        });
		  </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>