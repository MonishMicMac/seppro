<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>

<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">


<style type="text/css">
	
	.content-sec {
		padding: 0 15px;
		font-family: 'PT Sans', sans-serif; 	
	}

	.content-sec h1 {
    	text-align: left;
    	text-transform: uppercase;
    	font-weight: bold;
    	font-size: 16px;
    	color: #272727;
}


	.content-sec p {
		text-align: left;
		font-size: 14px;

	}

	.content-sec h2 {
		text-align: left;
		font-weight: bold;
		font-size: 14px;
		color: #272727;
	}

	

</style>

</head>
<body>

	<div class="text-area">

			<div class="content-sec">
			
				<h1 style="text-align: center;"><u>Kebijakan Privasi</u></h1>

				
				

				<p>Kebijakan Privasi ini menjelaskan bagaimana informasi dikumpulkan, digunakan dan diungkapkan oleh kami
					ketika anda menggunakan website kami atau menggunakan aplikasi mobile. Tidak diberlakukan untuk website
					pihak ketiga, layanan atau aplikasi yang mungkin diakses menggunakan layanan kami.</p>
                <h1>Pengumpulan Informasi</h1>
				
				
				<p>Kami mengumpulkan informasi tertentu yang anda berikan ketika menggunakan layanan kami, seperti ketika anda
					membuat akun. Informasi ini kemungkinan berisi nama, email, nomor telepon dan lokasi. Kami juga akan
					mengumpulkan kontak informasi dari teman anda, jika anda memilih untuk menghubungkan kontak dan
					informasi buku alamat dengan akun anda, jadi anda dapat terhubung dengan teman anda ketika menggunakan
					layanan kami.</p>
					
			    <p>Kami juga secara otomatis mengumpulkan informasi tertentu ketika anda menggunakan layanan kami, seperti
				Internet Protocol (IP) address (ketika anda menggunakan browser), Sistem Operasi, Tipe Browser, link yang
				merujuk ke website kami, lokasi anda (jika anda mengaktifkan fitur ini) , dan pengenal ponsel (jika anda
				menggunakan ponsel) . Anda dapat mengaktifkan atau menon-aktifkan layanan lokasi ketika anda menggunakan
				layanan kami kapanpun. Baik dengan browser maupun dengan ponsel.</p>
				
				<p>Kami juga secara otomatis mengumpulkan informasi tertentu melalui penggunaan “cookies.” Cookies adalah
				sebuah data berukuran kecil yang ditempatkan di browser anda yang bertujuan untuk membantu kami untuk
				lebih memahami bagaimana anda berinteraksi dengan atau menggunakan website kami. Kebanyakan browser
				menerima cookies secara otomatis. Anda dapat menginstruksikan browser anda, dengan mengedit pada pilihan
				options untuk menerima cookies secara otomatis atau meminta izin terlebih dahulu sebelum menerima cookies
				dari website yang anda kunjungi.</p>

				<h1>Bagaimana informasi digunakan</h1>

				<h2>Kami menggunakan informasi yang kami kumpulkan untuk tujuan yang dijelaskan seperti di bawah ini :</h2>
				
				<p>1. Untuk menyediakan layanan kami dan layanan yang terkait atau informasi dari permintaan anda, dan
				jika ada untuk memproses dan menyelesaikan seluruh transaksi; untuk menanggapi email anda,
				pengajuan, pertanyaan, komentar, permintaan, dan keluhan dan layanan pelanggan.</p>
				
				<p>2. Untuk mempersonalisasikan dan meningkatkan layanan kami, fungsionalitas, pengalaman dan user
				experience ketika anda menggunakan layanan kami</p>
				
				<p>3. Untuk memantau dan menganalisis penggunaan dan tren pada layanan kami dan situs/aplikasi kami</p> 
				
				<p>4. Untuk mengirimkan konfirmasi, update, peringatan keamanan, dukungan dan pesan administratif dan
				operasi dari layanan kami</p>
				
				<p>5. Untuk mengirimkan rekomendasi dan iklan yang sesuai dengan minat dan kepentingan anda.</p>
				<p>6. Untuk mencari dan menghubungkan dengan teman anda (sesuai dengan instruksi anda)</p>
				<p>7. Untuk berinteraksi menggunakan layanan kami dengan teman anda, dan</p>
				<p>8. Untuk tujuan lainnya</p>
				

		

				<h1>Penyebaran Informasi</h1>

				<h2>Kami tidak akan menyebarkan informasi personal yang telah kami kumpulkan dari anda, kecuali seperti yang di
				jelaskan dibawah ini :</h2>

				
				<p>1. Ketika anda memberikan persetujuan untuk melakukannya, termasuk jika kami memberitahu anda
				bahwa informasi yang anda berikan akan dibagikan dengan cara tertentu dan anda memberikan
				informasi tersebut;</p>
				
				<p>2. Ketika anda secara nyata mengizinkan Horeee untuk melihat rincian kontak anda pada penyedia jasa
				dan/atau barang sehingga mereka secara langsung akan menghubungi anda sesuai dengan permintaan
				yang telah anda ajukan;</p>
				
				<p>3. Dengan layanan jejaring sosial dan website tertentu, jika anda mengizinkan untuk berbagi;</p> 
				
				<p>4. Dengan teman anda yang ingin anda hubungkan , dan berdasarkan pengaturan yang telah diatur pada
				akun anda;</p>
				
				<p>5. Dengan penyedia jasa dan/atau barang yang telah bekerja sama dengan kami dalam koneksi dengan
				operasi dari layanan dan website kami (penyedia jasa dan/atau barang tersebut dapat mengakses data
				personal, namun hanya sejauh yang diperlukan untuk melakukan layanan atas nama kami dan
				diwajibkan untuk tidak mengungkapkan informasi tersebut atau digunakan untuk tujuan lain);</p>
				
				<p>6. Kami mungkin mengumpulkan informasi dan bukan informasi pribadi dengan pihak ketiga untuk industri
				analisis, profil demografis, penelitian , analisis dan tujuan lain yang sejenis;</p>
				
				<p>7. Ketika kami percaya bahwa kami berwenang secara hukum atau diperlukan untuk melakukan sesuatu
				yang beralasan atau diperlukan untuk mematuhi hukum atau proses hukum atau menanggapi
				permintaan yang sah atas otoritas hukum, termasuk menanggapi pemanggilan dari pengadilan, surat
				perintah, atau perintah pengadilan;</p>
				
				
				<p>8. Untuk menegakkan atau menerapkan kebijakan privasi ini, syarat dan ketentuan penggunaan kami atau
				perjanjian lainnya, dan ;</p>
				
				<p>9. Sehubungan dengan penggabungan usaha, penjualan aset perusahaan , pembiayaan atau akuisisi atau
				dalam situasi lain dimana informasi dapat diungkapkan atau dipindahkan sebagai salah satu aset bisnis
				kami.</p>

			

				<h2>Kami mungkin akan membagikan informasi atau informasi tanpa nama (tentang anda namun tidak
				mengidentifikasikan anda) dengan pihak ketiga:</h2>

				<p>1. Untuk kebutuhan analisis untuk membantu kami lebih baik memahami siapa yang menggunakan
				layanan kami dan bagaimana ;</p>
				<p>2. Untuk meningkatkan relevansi dari iklan yang anda lihat tentang layanan kami dan untuk menyesuaikan
				mereka dengan kepentingan anda; dan</p>
				<p>3. Untuk analisa industri, profil demografi , penelitian , analisis dan tujuan lain yang sejenis.</p>
				

				<h1>Tautan ke situs lain</h1>
				
				<p>Layanan kami akan mengandung tautan ke pihak ketiga. Setiap informasi yang anda berikan melalui pihak ketiga
				ini diberikan secara langsung kepada pemilik dari website atau layanan dan tunduk pada syarat dan kebijakan
				mereka, termasuk privasi dan praktek pengumpulan data. Kebijakan privasi kami tidak berlaku untuk layanan
				pihak ketiga tersebut. Kami tidak bertanggung jawab atas privasi dan keamanan dan kebijakan dari setiap layanan
				pihak ketiga.</p>
				
				<h1>Ukuran keamanan</h1>
				<p>Kami memperkerjakan administrasi, fisik dan langkah-langkah elektronik yang dirancang untuk melindungi
				informasi anda dari akses yang tidak sah, namun, meskipun kami telah melakukan upaya tersebut, tidak ada
				keamanan yang sempurna atau tidak tertembus dan tidak ada metode transmisi data yang dapat menjamin
				terhadap intersepsi atau jenis lain dari penyalahgunaan. Dalam peristiwa informasi pribadi anda terganggu akibat
				pelanggaran keamanan, kami akan segera memberitahu anda jika informasi pribadi anda telah terganggu sesuai
				dengan persyaratan oleh hukum yang berlaku.</p>
				
				<h1>Akses Informasi</h1>
				
				<p>Jika anda ingin kami untuk menghapus informasi personal dari sistem kami, silahkan hubungi kami dari di (email)
				dengan permintaan kepada kami untuk meghapus informasi pribadi dari database kami. Kami akan
				menggunakan upaya yang wajar secara komersil untuk menghormati permohonan anda. Namun, kami akan
				menyimpan salinan arsip catatan anda seperti yang dipersyaratkan oleh hukum atau untuk tujuan bisnis yang
				sah lainnya.</p>
				
			</div>						

	</div>

</body>

</html>
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																												