

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Add Time Slot </h4>
				</div>
				<div class="card-content">
				   <form  action="<?php echo e(route('add.slot')); ?>" method="post" id="TimeSlot" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					   
					   
					   <div class="col-md-6">
                      <div class="form-group label-floating">
					  <label class="control-label">
						From slot
					  <small>*</small>
					  </label>
					  <input class="txt_box without_ampm" name="Fslot" type="text" data-timepicker />
				   </div>
                    </div>
					
					<div class="col-md-6">
					
					<div class="form-group label-floating">
					  <label class="control-label">
						To slot
					  <small>*</small>
					  </label>
					  <input class="txt_box without_ampm" name="Tslot" type="text" data-timepicker />
				   </div>
                       
                    </div>
					     
						<div class="clearfix"></div>
						<div class="col-md-6">
						<button class="btn btn-primary" id="pin_btn">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>
	
	
	
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Time Slots</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>From slot </th>
										<th>To slot</th>
										<th>TimeSlot</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>From slot </th>
										<th>To slot</th>
										<th>TimeSlot</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $slot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TimeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($TimeSlot->fromSlots); ?></td>
										<td><?php echo e($TimeSlot->toSlots); ?></td>
										<td><?php echo e($TimeSlot->TimeSlot); ?></td>
                                        

										<td class="text-right">
											<a  data-toggle="modal" data-target="#editslot" class="btn btn-simple btn-warning btn-icon edit slot_edit" value="<?php echo e($TimeSlot->id); ?>" href="" id=""><i class="fa fa-pencil-square-o"></i></a>
											
											<a  onclick="return confirm('Are you sure you want to delete pincode');" class="delete_Slot" href="<?php echo e(route('delete.timeslot')); ?>?id=<?php echo e($TimeSlot->id); ?>"> <i class="fa fa-trash"></i></a>
											
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<div id="editslot" class="modal fade" role="dialog">
          <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
          <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Time Slot</h4>
          </div>
          <div class="modal-body">
               <div class="row">
                 <form  action="<?php echo e(route('update.slot')); ?>" id="EditSlot" method="post">
						<?php echo e(csrf_field()); ?>

						
		
						
                    <div class="col-md-6">
                      <div class="form-group label-floating">
					  <label class="control-label">
						From slot
					  <small>*</small>
					  </label>
					  <input class="txt_box without_ampm" name="Fslot" id="Efromslot" type="text" />
				   </div>
                    </div>
					
					<div class="col-md-6">
                      <div class="form-group label-floating">
					  <label class="control-label">
						To slot
					  <small>*</small>
					  </label>
					  <input class="txt_box without_ampm" name="Tslot" id="Etoslot" type="text" />
					  
					  <input type="hidden" id="Eslotid" name="id">
					  
				   </div>
				
                    </div>
					
                    <div class="clearfix"></div>
					
					
                    <button class="btn btn-primary" id="pin_btn1">
                       Submit
                       <div class="ripple-container"></div>
                    </button>
                  </form>
               </div>
          </div>

          </div>
          </div>
          </div>


  
		  <script>
		  
$(function () {


});
		  
		  $(document).ready(function(){
		$(".delete_Slot").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"<?php echo e(route('delete.timeslot')); ?>?id="+id);
        });

        });
		  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>