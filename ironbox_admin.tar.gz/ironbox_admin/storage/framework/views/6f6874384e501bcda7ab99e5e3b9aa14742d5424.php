

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Assign orders</h4>
				</div>
				<div class="card-content">
				    <div class="row">
                    <div class="col-md-3">
                        <div class="user_profile">
						   <img src=" <?php if($Assign->image == null){ echo "http://139.59.37.241/Ironman/public/images/pic.png"; }else{ echo $Assign->image; } ?>" class="img-responsive center-block img-circle">
						    
						</div>
                       </div>	
 
                     <div class="col-md-4">
					  
					    <div class="urdetails">
						   <strong>BookingId :</strong> <?php echo e($Assign->bookingId); ?> 
						</div>
					    <div class="urdetails"> 
						   <strong>Name :</strong> <?php echo e($Assign->username); ?> 
						</div>
					    
						 <div class="urdetails"> 
						   <strong>Pickup user :</strong> <?php echo e($Assign->pickup_username); ?>

						 </div>
						
						<div class="urdetails"> 
						   <strong>delivery user :</strong> <?php echo e($delivery->delivery_username); ?>

						</div>
						
						<div class="urdetails"> 
						   <strong>Booking date :</strong> <?php echo e($delivery->bookingDate); ?>

						</div>
						
						<div class="urdetails"> 
						   <strong>Time slot :</strong> <?php echo e($delivery->fromSlots); ?> - <?php echo e($delivery->toSlots); ?>

						</div>
						

					 </div>
					 
					   
				   </div>
				   
				   
				   <div class="row">
				      <div class="col-md-6">
					    
					      <form  action="<?php echo e(route('assign.pickup')); ?>" method="post" id="assign_pickup" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					   <div class="col-md-12">
					   <h4>Assign pick user</h4>
						 <div class="form-group label-floating">
							 <label>Select pick user</label>
							<select  class="select_box_2" id="pickup_user" name="pickup_user">
								<option value="">Select pick users</option>
								<?php foreach($Area as $GetArea){  ?>
								<option value="<?php echo $GetArea->id; ?>"  

                                 <?php
								 
								 if($GetArea->id ==  $Assign->pickup_user){
									 
									 
									 echo "selected";
								 }
								 ?>

								><?php echo $GetArea->name; ?></option>
								<?php } ?>
							</select>
						 </div>
					   </div>
					   
                     <input type="hidden" name="bookingId" value="<?php echo e($delivery->book_id); ?>">
						<div class="clearfix"></div>
						<div class="col-md-12">
						<button class="btn btn-primary" id="pin_btn">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
					  
					  </div>
					  
					  
					  <div class="col-md-6">
					    
					      <form  action="<?php echo e(route('assign.delivery')); ?>" method="post" id="assign_delivery" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					   <div class="col-md-12">
					   <h4>Assign delivery user</h4>
						 <div class="form-group label-floating">
							 <label>Select delivery user</label>
							<select  class="select_box_2" id="delivery_user" name="delivery_user">
								<option value="">Select delivery users</option>
								<?php foreach($Area as $GetArea){  ?>
								<option value="<?php echo $GetArea->id; ?>"  

                                 <?php
								 
								 if($GetArea->id ==  $delivery->delivery_user){
									 
									 
									 echo "selected";
								 }
								 ?>

								><?php echo $GetArea->name; ?></option>
								<?php }?>
							</select>
						 </div>
					   </div>
					   <input type="hidden" name="bookingId" value="<?php echo e($delivery->book_id); ?>">

						<div class="clearfix"></div>
						<div class="col-md-12">
						<button class="btn btn-primary" id="pin_btn">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
					  
					  </div>
					  
					  
					  
				   </div>
				   
				</div>
			</div>
		</div>		
	</div>		
	
	
	
		
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>