

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	   <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Promo Code</h4>
				</div>
				<div class="card-content">
				   <form  action="<?php echo e(route('add.new.promo')); ?>" method="post" id="AddPromocode" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					   
					   
					   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                promocode
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace" maxlength ="6" name="promocode" id="promocode" type="text" />
							  <p id="promo_valid"></p>
                           </div>
                        </div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Discount
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly"  name="discount" id="discount" type="text" />
                           </div>
                        </div>
						
						<div class="clearfix"></div>
						
						<!--<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Maximum discount
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" name="max_amount" id="max_amount" type="text" />
                           </div>
                        </div>-->
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Expiry from
                              <small>*</small>
                              </label>
                              <input class="form-control" name="expiry_from" id="expiry_from" type="date"/>
                           </div>
                        </div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Expiry to
                              <small>*</small>
                              </label>
                              <input class="form-control" name="expiry_to" id="expiry_to" type="date"  />
                           </div>
                        </div>	
						
	                    <div class="clearfix"></div>	

                        

                        					
    						
					    <div class="clearfix"></div>

                         <div class="col-md-6">
						 <div class="form-group label-floating is-empty">
							<select class="form-control" id="payment_type" name="payment_type">
								<option value="">Select offer type</option>
								<!--<option value="All">All</option>-->
								<option value="Wallet">Wallet</option>
								<option value="Booking">Booking</option>
							</select>
						 <span class="material-input"></span></div>
					   </div>
					   
						<div class="col-md-6">
						<p>
                           <input type="checkbox" id="no_expiry" name="no_expiry" value="Yes">
						   <label for="no_expiry" class="lab">No expiry: </label>
						   </p>
                        </div>	

						<div class="clearfix"></div>	

                        <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Discription
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="description" id="description" type="text" />
                           </div>
                        </div>						

						<div class="col-md-6">
						 <div class="file-upload">
                              <label class="">
                                Images
                              <small>*</small>
                              </label>
                              <input class="upload_img_file" name="image" id="image" accept="image/*" type="file">
							  </div>
                             <div class="img_pre1">							  
                               <img class='img img_preview' src='' style="display:none;"/>
							  </div> 
                          </div>
						
                      <!--<div class="col-md-6">
                          <?php $__currentLoopData = $Pincode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetPincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  
						  <input type="checkbox" id="pincode" name="pincode[]" value="<?php echo e($GetPincode->id); ?>">  <?php echo e($GetPincode->area); ?> 
						  
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  
                      </div>	-->

                    <!--- <div class="col-md-6">
                      <div class="form-group">
						 <label>Service Area</label>
						 <select id="areapincode" name="pincode[]" multiple class="form-control" >
						 <?php $__currentLoopData = $Pincode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetPincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <option value="<?php echo e($GetPincode->id); ?>"><?php echo e($GetPincode->area); ?></option>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						 </select>
						</div>					  
						</div>-->
						
						<div class="clearfix"></div>
						<div class="col-md-12">
						<button class="btn btn-primary" id="promo_btn2">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
					 
					 <div class="row">
					   <div class="col-md-12">
					     
						 <div class="card">
							<div class="card-header" data-background-color="blue">
								<h4 class="title">Promocode list</h4>
							</div>
							<div class="card-content">
								<div class="material-datatables">
									<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
										<thead>
											<tr>
												<th>S.No</th>
												<th>Promocode</th>
												<th>Discount</th>
												<th>Offer type</th>
												<th class="text-right">Actions</th>
											</tr>
										</thead>
										<tfoot>
											<tr>
												<th>S.No</th>
												<th>Promocode</th>
												<th>Discount</th>
												<th>Offer type</th>
												<th class="text-right">Actions</th>
											</tr>
										</tfoot>
										
										<tbody>
										 <?php   $count = 1; ?>
										<?php $__currentLoopData = $Promocode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetPromo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($count++); ?></td>
												<td><?php echo e($GetPromo->promocode); ?></td>
												<td><?php echo e($GetPromo->discount); ?>%</td>
												<td><?php echo e($GetPromo->offer_type); ?></td>
												

												<td class="text-right">
												 <a href="<?php echo e(route('edit.promo',[$GetPromo->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-pencil-square-o"></i></a>
												 
												 <a  onclick="return confirm('Are you sure you want to delete pincode');" class="delete_promo" href="<?php echo e(route('delete.promo')); ?>?id=<?php echo e($GetPromo->id); ?>"> <i class="fa fa-trash"></i></a>
												 
												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																						   
										</tbody>
										
									</table>
								</div>
							</div>
						</div>
					   </div>
					 </div>
					 
					 
				</div>
			</div>
		</div>		
	</div>
	
	</div>
</div>



		  <script>
		  
$(function () {


});
		  
		  $(document).ready(function(){
		$(".delete_promo").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"<?php echo e(route('delete.pin')); ?>?id="+id);
        });

        });
		  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>