

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Pickup Report</h4>
				</div>
				<div class="card-content">
				   <div class="row">
				        <div class="col-md-12">
                            <div class="card">
                               <!-- <div class="card-header card-chart" data-background-color="orange">
                                    <div class="ct-chart" id="pickupUserGraph"></div>
                                </div>
                               
                                <div class="card-content">
                                    <h4 class="title">Vendor vs cost</h4>
                                </div>-->
								
								<div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="CategoryClothesRep"></div>
                                </div>
                                <div class="card-content">
                                   <h4 class="title">Clothes category</h4>
                                </div>
								
								<div class="col-md-6">
								<label>Select Category * </label>
								 <select class="select_box" id="Main_Category_id" name="Main_Category"> 
                                       <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>									  
                                      <option value="<?php echo e($Cate->id); ?>"> <?php echo e($Cate->name); ?> </option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								
								</div>
								
								<input type='hidden' id="vendorId" value="<?php echo e($userId); ?>">
								<input type='hidden' id="category_id" value="<?php echo e($cate_first->id); ?>">
							
                            </div>
                        </div>
				   </div>
				   
				   
				   <div class="row">
					   <div class="card-content">
					   <div class="box_shadow box_shadow1">
                                    <h4 class="greentext">Clothes report</h4> 
                               
					   <form method="post" id="Search_reports" action="<?php echo e(route('vendor.clothes.down')); ?>" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					      <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="fromdate" id="vendorfrom" type="date"/>
							  <input type='hidden' id="vendorId_1" name="vendorId" value="<?php echo e($userId); ?>">
							  <span class="error vendor_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-4">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small> 
                              </label>
                              <input class="form-control" name="todate" id="vendorto" type="date"/>
							  <span class="error vendor_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-4">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>Clothes</th>
						    <th>Orders</th>
						    <th>quantity</th>
							<th>Amount</th>							
						  </tr>
						
                           
						    <tbody id="Vendor_report">
                                  <td colspan="4">No record</td>
                            </tbody>
						   
						 
						  
						</table> 
						  
					   </div>
					   </div>
					   </div>
				   
				   
                     <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 <h4 class="yellowtext">Reports</h4>
					   

        <div id="exTab1" class="">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab">Yearly</a></li>
		</ul>

			<div class="tab-content clearfix">
			    <div class="tab-pane active" id="1a">
				  
				     <a href="<?php echo e(route('vendor.reports',['id'=>1,'vendorId'=>$userId])); ?>" class="btn btn-primary down_btn3">
						   Download report
						   <div class="ripple-container"></div>
						</a>
				  
				  <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
										
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($Order->groupName); ?> / <?php echo e($Order->name); ?></td>
										<td><?php echo e($Order->orders); ?></td>
										<td><?php echo e($Order->quantity); ?></td>
										<td><?php echo e($Order->amount); ?></td>
										
                                        

									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
                     
				</div>
				<div class="tab-pane" id="2a">
				
				 <a href="<?php echo e(route('vendor.reports',['id'=>2,'vendorId'=>$userId])); ?>" class="btn btn-primary down_btn3">
						   Download report
						   <div class="ripple-container"></div>
						</a>
				
                    <table id="" class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
										
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($Order->groupName); ?> / <?php echo e($Order->name); ?></td>
										<td><?php echo e($Order->orders); ?></td>
										<td><?php echo e($Order->quantity); ?></td>
										<td><?php echo e($Order->amount); ?></td>
										
                                        

									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
				   
				</div>
                <div class="tab-pane" id="3a">
				
				<a href="<?php echo e(route('vendor.reports',['id'=>3,'vendorId'=>$userId])); ?>" class="btn btn-primary down_btn3">
						   Download report
						   <div class="ripple-container"></div>
						</a>
				
				  <table id="" class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
										
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($Order->groupName); ?> / <?php echo e($Order->name); ?></td>
										<td><?php echo e($Order->orders); ?></td>
										<td><?php echo e($Order->quantity); ?></td>
										<td><?php echo e($Order->amount); ?></td>
										
                                        

									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
                     
				</div>
                <div class="tab-pane" id="4a">
				
				<a href="<?php echo e(route('vendor.reports',['id'=>4,'vendorId'=>$userId])); ?>" class="btn btn-primary down_btn3">
						   Download report
						   <div class="ripple-container"></div>
						</a>
				  
				   <table id="" class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Orders </th>
										<th>Quantity </th>
										<th>Amount </th>
										
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($Order->groupName); ?> / <?php echo e($Order->name); ?></td>
										<td><?php echo e($Order->orders); ?></td>
										<td><?php echo e($Order->quantity); ?></td>
										<td><?php echo e($Order->amount); ?></td>
										
                                        

									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
                       
				</div>
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
				   
				</div>
			</div>
		</div>		
	</div>
	
	
	
	

	</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script type="text/javascript">

 $('#Main_Category_id').on('change',function(){
 var cate_id = $(this).val();
 var id =  $("#vendorId").val();

  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/VendorClothesGraph',
            data: {_token: csrf,id: id,cate_id: cate_id},
            success: function (data) { 
				   // demo.pickupUserChart(data);
				   // console.log(data);
				   demo.CategoryClothesRep(data);
            }
        });

 });

    $(document).ready(function() {
		$('.active-report').addClass('active');
		// var id = '1'; category_id
		
		 // var id =  $("#vendorId").val();

		 var cate_id = $("#category_id").val();
 var id =  $("#vendorId").val();

  var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/VendorClothesGraph',
            data: {_token: csrf,id: id,cate_id: cate_id},
            success: function (data) { 
				
				   demo.CategoryClothesRep(data);
            }
        });
		
		
		
		// var csrf = $('meta[name="csrf-token"]').attr('content');	
        $.ajax({
            type: "GET",
            url:  base_url+'/VendorGraph',
            data: {_token: csrf,id: id},
            success: function (data) { 
				   demo.pickupUserChart(data);
            }
        });
		
	   
    });
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>