

<?php $__env->startSection('content'); ?>


<div class="content">
	<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12">
		   <a href="<?php echo e(url('UserWalletReport/' . $id . '')); ?>" class="btn btn-primary down_btn">
			   Download report
			   <div class="ripple-container"></div>
			</a> 
		</div>		
	</div>
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Users wallet transctions</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>OrderId </th>
										<th>TransactionId</th>
										<th>bookingId</th>
										<th>Amount</th>
										<th>Status</th>
										<th>Type</th>
										<th>Payment date</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>OrderId </th>
										<th>TransactionId</th>
										<th>bookingId</th>
										<th>Amount</th>
										<th>Status</th>
										<th>Type</th>
										<th>Payment date</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Transc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $List): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($List->orderId); ?></td>
										<td><?php echo e($List->transactionId); ?></td>
										<td><?php echo e($List->bookingId); ?></td>
										<td><?php echo e($List->amount); ?></td>
										<td><?php echo e($List->transation_status); ?></td>
										<td><?php echo e($List->type); ?></td>
										<td><?php echo e($List->payment_date); ?></td>
									</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		$('.nav-active').addClass('active');

	
		
		
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>