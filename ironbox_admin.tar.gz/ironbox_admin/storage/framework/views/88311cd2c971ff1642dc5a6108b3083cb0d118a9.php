
<html lang='en'>
  <head>
	  <style>
		 .block{width: 446px;margin: 0 auto;padding: 12px;border:1px solid #000;}
		 .left{float:left;}
		 .top_head{display: inline-block;width:100%;}
		 .top_table{width:100%;}
		 .right{float:left;position:relative;left:100px}
		 .logo{float: left;}
		 .logo img{width:54px;height:50px;}
		 .addr{width:200px;}
		  p{padding:0; margin:0;}
		  h5,h3{padding:0; margin:0;}
		  .mr15{margin-top:15px;}
		  .border{border: 1px dashed #000; margin-top:15px;}
		  .pickup {text-align:center;}
  
		 tr.line td {
  border-top:1pt solid black;
}
	  </style>
  </head>
  <body>
	<div class='block'>
	<div class='top_head'>
		 <div class='logo'>
			<img src='http://139.59.37.241/Ironman/public/images/ironbox.png'>
		 </div>
		 <div class='top_table'>
		   <table style='margin-left: 15%;'>
			  <tr>
				<td>25-07-2018</td>
			  </tr>
			   <tr>
				<td>TimeSlot : 09:00 - 12:00</td>
			  </tr>
			</table>
			</div>
		</div>
		<div class='mr15'>
		   <p><strong>Address :</strong></p>
		   <p class='addr'>40/156, Tirumurthy Nagar, Nungambakkam, Chennai, Tamil Nadu 600034, India</p>
		</div>
		
		<div class='userdetails mr15'>
		 <h5>Mohamed Abbas</h5>
		 <p> Your Booking id for the service : 1323</p>
		</div>
		
		<hr class='border'>
		
		<div class='pickup'>
		  <h3>PICKUP SUCCESSFUL</h3>
		  <p>Pickup time : 12:00</p>
		  <p>Total clothes : 10</p>
		</div>
		
		<hr class='border'>
		<div class='uaddress'>
		   <h3>Address :</h3>
		   <p>40/156, Tirumurthy Nagar, Nungambakkam, Chennai</p>
		</div>
		<hr class='border'>
		
		<div class='clothes'>
		  <h3>Bill :</h3>
		  <table style='width:100%'>
		  <tr>
		  <?php $__currentLoopData = $Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<td><?php echo e($a->id); ?></td>
			<td>Smith</td>
			<td>50</td>
		  </tr>
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  <tr class='line'>
			  <td colspan='1'></td>
			  <td>Service taxes</td>
			  <td>34</td>
			  </tr>
			  <tr>
			  <td colspan='1'></td>
			  <td>Total</td>
			  <td>345</td>
			  </tr>
		</table>
		
		</div>
	</div>
  </body>
</html>


