

<?php $__env->startSection('content'); ?>


<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Edit Service Area</h4>
				</div>
				<div class="card-content">
				   <form  action="<?php echo e(route('update.pincode.area')); ?>" method="post" id="servicearea" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					    <?php $__currentLoopData = $pincode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					   <div class="col-md-6">
						 <div class="form-group label-floating">
							
							<select  class="form-control" id="warehousename" name="warehousename">
							<option value="">Select warehouse</option>
							  <?php $__currentLoopData = $outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Out): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($Out->id); ?>" <?php if($Out->id == $data->warehouseId): ?> Selected <?php endif; ?>><?php echo e($Out->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						 </div>
					   </div>
					   
					   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Pincode
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" maxlength ="6" name="pincode" id="Epincode" type="text" value="<?php echo e($data->code); ?>" />
                           </div>
						   <div id="Epin_valid"></div>
						   <input type='hidden' name="id" value=" <?php echo e($data->id); ?>"/>
                        </div>
						
						<div class="clearfix"></div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Areaname
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="areaname" id="areaname" type="text" value="<?php echo e($data->area); ?>"/>
                           </div>
                        </div>
					      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="clearfix"></div>
						<div class="col-md-12">
						<button class="btn btn-primary" id="pin_btn1">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>		
	</div>
</div>




		  
		  
		  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>