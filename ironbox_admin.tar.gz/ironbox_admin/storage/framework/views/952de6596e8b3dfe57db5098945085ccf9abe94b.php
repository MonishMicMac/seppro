

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Pickup User</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Phone Number</th>
										<th>Email</th>
										<th>Areaname</th>
										<th>Pincode</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name</th>
										<th>Phone Number</th>
										<th>Email</th>
										<th>Areaname</th>
										<th>Pincode</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UserList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($UserList->name); ?></td>
										<td><?php echo e($UserList->mobile); ?></td>
										<td><?php echo e($UserList->email); ?></td>
										<td><?php echo e($UserList->area); ?></td>
										<td><?php echo e($UserList->code); ?></td>


										<td class="text-right">
											<a href="<?php echo e(route('edit.pickupuser',[$UserList->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-pencil-square-o"></i></a>
											<!--<input type="checkbox" <?php if($UserList->Is_active == 1){  echo "checked"; } ?> value="<?php echo e($UserList->id); ?>" name="check" class="Is_active" >-->
											
											<!--<p class="ch_box">-->
      <input type="checkbox" <?php if($UserList->Is_active == 1){  echo "checked"; } ?> value="<?php echo e($UserList->id); ?>" class="Is_active" id="test5" />
     <!-- <label for="test5"></label>
    </p>-->
	
	                     <a href="<?php echo e(route('getpickup.report',[$UserList->id])); ?>" value="<?php echo e($UserList->id); ?>" class="btn btn-simple btn-info btn-icon like pickup_report"><i class="fa fa-bar-chart"></i></a>
						 
						 
						 <a href="<?php echo e(route('pickup.order.assign',[$UserList->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-fax"></i></a>
						 
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>

		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>