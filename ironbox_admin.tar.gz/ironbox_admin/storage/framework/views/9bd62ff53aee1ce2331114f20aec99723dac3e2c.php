

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-12">
                             
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="CategoryClothesRep"></div>
                                </div>
                                <div class="card-content">
                                   <h4 class="title">Clothes reports</h4>
                                </div>
								
								<div class="col-md-6">
							 <div class="form-group">
								 <label>Select category</label>   
								<select class="select_box" id="Main_Category" name="Main_Category"> 
								      <option value=""> select category </option>
                                       <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>									  
                                      <option value="<?php echo e($Cate->id); ?>"> <?php echo e($Cate->name); ?> </option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<span class="main_cate error">Please select category</span>
                             <input type='hidden' value="<?php echo e($id); ?>" id="cate_id">
						   </div>
								
                            </div>
							
							<div class="col-md-6">
							 <div class="form-group">
								 <label>Select Type</label>   
								<select class="select_box" id="clothes_type" name="clothes_type">  
                                      <option value=""> select type </option> 								  
                                      <option value="1"> Day </option>
                                      <option value="2"> Weekly </option>
                                      <option value="3"> Monthly </option>
                                      <option value="4"> Yearly </option>
                                       
								</select>
								<span class="main_type error">Please select type</span>
                             <input type='hidden' value="<?php echo e($id); ?>" id="cate_id">
						   </div>
								
                            </div>
							
                            </div>
                         					   
					  
                         </div>					   
					   </div>
					   
					   
					 
					   
					   
					   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 <h4 class="yellowtext">Reports</h4>
					 
					   

        <div id="exTab1" class="">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab">Yearly</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
    
	                   <a href="<?php echo e(url('Categoty_Clothes/' . 1 . '')); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                  <?php $__currentLoopData = $Day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  <tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($OrderDay->groupName); ?> / <?php echo e($OrderDay->name); ?></td>
										<td><?php echo e($OrderDay->orders); ?></td>							
										<td><?php echo e($OrderDay->quantity); ?></td>
										<td><?php echo e($OrderDay->amount); ?></td>
									   
									  </tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>											   
								</tbody>
							</table>
							</div>
							</div>
   
                       
 					
				</div>
				<div class="tab-pane" id="2a">
                     
					 <a href="<?php echo e(url('Categoty_Clothes/' . 2 . '')); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
					 
                  <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                  <?php $__currentLoopData = $Week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  <tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($OrderDay->groupName); ?> / <?php echo e($OrderDay->name); ?></td>
										<td><?php echo e($OrderDay->orders); ?></td>							
										<td><?php echo e($OrderDay->quantity); ?></td>
										<td><?php echo e($OrderDay->amount); ?></td>
									   
									  </tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>											   
								</tbody>
							</table>
							</div>
							</div>  
					 
				</div>
               <div class="tab-pane" id="3a">
			   
			   <a href="<?php echo e(url('Categoty_Clothes/' . 3 . '')); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
			   
                     <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Monthly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                  <?php $__currentLoopData = $Month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  <tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($OrderDay->groupName); ?> / <?php echo e($OrderDay->name); ?></td>
										<td><?php echo e($OrderDay->orders); ?></td>							
										<td><?php echo e($OrderDay->quantity); ?></td>
										<td><?php echo e($OrderDay->amount); ?></td>
									   
									  </tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>											   
								</tbody>
							</table>
							</div>
							</div> 
				</div>
                <div class="tab-pane" id="4a">
                   
				   <a href="<?php echo e(url('Categoty_Clothes/' . 4 . '')); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
				   
				   <div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Yearly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Colthes</th>
										<th>Total orders</th>							
										<th>Quantity</th>
										<th>Total amount</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                  <?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									  <tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($OrderDay->groupName); ?> / <?php echo e($OrderDay->name); ?></td>
										<td><?php echo e($OrderDay->orders); ?></td>							
										<td><?php echo e($OrderDay->quantity); ?></td>
										<td><?php echo e($OrderDay->amount); ?></td>
									   
									  </tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>											   
								</tbody>
							</table>
							</div>
							</div>
				   
				</div>
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
   $(document).ready(function() {
		$('.active-report').addClass('active');
		
		var id = $('#cate_id').val();
		var type = 6;
		
		$.get("<?php echo e(route('clothes.category')); ?>?id="+id+"type="+type)
	  .done(function(data) {
			console.log(data);

			demo.CategoryClothesRep(data);
		});
		
	
		
		
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>