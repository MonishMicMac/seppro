

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">View complients</h4>
				</div>
				<div class="card-content">
				
				
				   <div class="row">
				     <div class="complient ht">
                                    <div class="box_shadow box_shadow2">
                                       <h4 class="yellowtext">Complients Details</h4>
                                       <div class="right_box">
									    <?php $__currentLoopData = $Support; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $View): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <div class="urdetails">
                                             <strong>ComplientId :</strong> <?php echo e($View->complaint_id); ?>

                                          </div>
                                          <div class="urdetails">
                                             <strong>Name :</strong> <?php echo e($View->name); ?>

                                          </div>
                                          <div class="urdetails">
                                             <strong>Mobile :</strong> <?php echo e($View->mobile); ?>

                                          </div>
										  <div class="urdetails">
                                             <strong>Complients type:</strong>  <?php echo e($View->complaints_type); ?>

                                          </div>
										  <div class="urdetails">
                                             <strong>Complients date:</strong>  <?php echo e($View->comp_date); ?>

                                          </div>
                                          <div class="urdetails">
                                             <strong>Comments :</strong>  <?php echo e($View->Comments); ?>

                                          </div>
										  
										  <form  action="<?php echo e(route('update.complient')); ?>" method="post"  enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

										  
										  <label class="switch">
  <input type="checkbox" name="active_user1" <?php if($View->Is_open == 1){  echo "checked"; } ?> value="<?php echo e($View->Is_open); ?>">
  <span class="slider round"></span>
</label> 

<div class="clearfix"></div>

<input type="hidden" name="complaint_id" value="<?php echo e($View->id); ?>">
<input type="hidden" name="Is_open" value="<?php echo e($View->Is_open); ?>">

<div class="col-md-12 center">

<button class="btn btn-primary" id="pin_btn">
						   Submit
						   <div class="ripple-container"></div>
						</button>
</div>

</form>
										  
										  
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                       </div>
                                      
                                    </div>
                                 </div>
				   
				   </div>
				    
					   
					   
					  
					 
				</div>
			</div>
		</div>		
	</div>
	

	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		$('.active-support').addClass('active');

    });
</script>
  
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>