

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Edit bookings</h4>
					</div>
					<div class="card-content">
					<div class="row">
							  <?php $__currentLoopData = $Bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('UserDetails/' . $Book->userId . '')); ?>" class="bl0"> 
								  <div class="col-md-4 ht250">
                                    <div class="box_shadow box_shadow1">
                                       <h4 class="greentext">User Details</h4>
									    <div class="urdetails">
                                             <strong>BookingId :</strong> <?php echo e($Book->bookingId); ?>

                                         </div>
                                       <div class="urdetails">
                                          <strong>Name :</strong> <?php echo e($Book->username); ?>

                                       </div>
                                       <div class="urdetails">
                                          <strong>Email :</strong> <?php echo e($Book->useremail); ?>

                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong> <?php echo e($Book->usermobile); ?>

                                       </div>
                                       <div class="urdetails">
                                          <strong>Alternate :</strong> <?php echo e($Book->user_al_number); ?>

                                       </div>
									   <div class="urdetails">
                                             <strong>Pickup date :</strong> <?php echo e($Book->bookingDate); ?>

                                          </div>
                                          <div class="urdetails">
                                             <strong>TimeSlot :</strong> <?php echo e($Book->fromSlots); ?> - <?php echo e($Book->toSlots); ?>

                                          </div>
                                    </div>
                                 </div></a>
								
                                 <div class="col-md-8 ht250">
                                    <div class="box_shadow box_shadow2">
                                       <h4 class="yellowtext">Bookings Details</h4>
                                        <table class="booktable" style="width:100%">
                                                <thead>
                                                 <tr>
                                                    <th>S.no</th>
                                                    <th>Category</th>
                                                    <th>Name</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                 </tr>
                                                 </thead>
                                                 <tbody>
												 <?php $count = 1; ?>
												<?php $__currentLoopData = $GetOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <tr>
                                                     <td><?php echo e($count++); ?></td>
													<td><?php echo e($Orders->groupName); ?></td>
													<td><?php echo e($Orders->name); ?></td>
													<td><?php echo e($Orders->quantity); ?></td>
													<td><?php echo e($Orders->amount); ?></td>
                                                 </tr>
												  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Total Amount</td>
													<td>Rs.<?php echo e($Book->totalPayment + $Book->discount_amount); ?></td>
                                                 </tr>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Discount Amount</td>
													<td>Rs.<?php echo e($Book->discount_amount); ?></td>
                                                 </tr>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Grand total</td>
                                                    <td>Rs.<?php echo $Book->totalPayment + $Book->discount_amount - $Book->discount_amount; ?></td>
                                                 </tr>
                                              </tbody>
                                           </table>
                                    </div>
                                 </div>
								 
                              </div>
							 
					
                       <div class="row">
					 
						<form  action="<?php echo e(route('update.Bookings')); ?>" method="post" id="updateBookings" enctype="multipart/form-data">
						   <?php echo e(csrf_field()); ?>

						   
						   <div class="row pad20">
							  <div class="col-md-12 ">
							  <div class="box_shadow box_shadow6">
							   <h4 class="skybluetext">Orders</h4>
							  <div class="tab_border">
								 <table class="table2 test" style="width:100%">
									<thead>
								 <tr>
								 <th> <button type="button"  class="btn btn-danger delete" ><i class="fa fa-trash-o" aria-hidden="true"></button></th>
								   <th class="text-center">Clothes</th>
								   <th class="text-center">Quantity</th>
								   <th></th>
								   <th><button type="button"  class="btn btn-primary addmore"><i class="fa fa-plus" aria-hidden="true"></i></button></th>
								 </tr>
							   </thead>
							    <input type="hidden" name="bookingId" value="<?php echo e($Book->id); ?>">
							   <tbody class="detail">
								<?php $__currentLoopData = $GetOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							   <tr>
							   <td><input class="case remove_check" type="checkbox"/></td>
								   <td>
								<select class="form-control valid1" name="clothes[]" required="true">
									<option value="">Select Clothes</option>
										 <?php $__currentLoopData = $Clothes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 <option value="<?php echo e($cloth->id); ?>" <?php if($order->categoryId == $cloth->id): ?>  selected <?php endif; ?>  > <?php echo e($cloth->groupName); ?> / <?php echo e($cloth->name); ?></option>
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
									 </select>
									  </td>
									  <td>
										<input type="text" class="form-control numbersnot emptyspace numbersOnly" name="qty[]" required="true" placeholder="Quantity" value="<?php echo e($order->quantity); ?>" style="margin-left: 11px;">
								   </td>
									  <td></td>
								   </tr>
								  
 								   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							   </tbody>
							 </table>
							  </div>
							  </div>
							  </div>
						   </div>
						    <div class="clearfix"></div>
									<div class="col-md-12">
									<div class="center">
									<button class="btn btn-primary" id="pin_btn">
									   Submit
									   <div class="ripple-container"></div>
									</button>
									</div>
									</div>
						 </form>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				   
					   </div>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<script>

$('.active-order').addClass('active');

var i=$('table tr').length;
$(".addmore").click(function(e){
      var table = $('.table2');
    var rows = table.find('tr');
    var error = 0;

    for (i = 0; i < rows.length; i++) {
      var cell = rows.eq(i).find('td');
      for (a = 0; a < cell.length; a++) {
        var input = cell.eq(a).find(':input');

        if (input.val() === "") {
          input.css("border", "solid 1px red");
          error++;
        } else {
          input.css("border", "solid 1px rgb(169, 169, 169)");
        }
      }
    }

    if (error > 0){
      return false;
    } else {
	    $(".test").append("<tr><td><input class='case remove_check' type='checkbox'/></td><td><select class='form-control'  name='clothes[]'><option value=''>Select clothes</option> <?php $__currentLoopData = $Clothes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value='<?php echo e($cloth->id); ?>'><?php echo e($cloth->groupName); ?> / <?php echo e($cloth->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td> <input class='emptyspace form-control' type='text' name='qty[]' required='true' placeholder='Quantity' style='margin-left: 11px;' ></td><td></td></tr>");
	}
	});


	//deletes the selected table rows
$(".delete").on('click', function() {
	$('.case:checkbox:checked').parents("tr").remove();
	$('#check_all').prop("checked", false);
	var count=$('.table2 tbody tr').length;
	if(count<=0){
		$('.addmore').click();
		}
	calculateTotal();
});


</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>