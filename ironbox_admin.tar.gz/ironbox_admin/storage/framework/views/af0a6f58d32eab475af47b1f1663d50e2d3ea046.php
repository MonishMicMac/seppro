

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-12">
                             
					       <input type ='hidden' id="outletId" value="<?php echo $id; ?>">
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="HighestOrder"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Highest order area </h4>
                                </div>
                            </div>
                         					   
					  
                         </div>					   
					   </div>
					   
					   
					   <div class="row">
				     <div class="col-md-12">
					 
					   <a href="<?php echo e(url('OutletPinReport/' . $id . '')); ?>" class="btn btn-primary down_btn">
						   Download report
						   <div class="ripple-container"></div>
						</a> 

        <div id="exTab1" class="">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab">Yearly</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
                     <table class="table_1">
						  <tr>
						    <th>Code</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php 
						  if(count($Day) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->code); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>							
							<td><?php echo e($OrderDay->qty); ?></td>
							<td>Rs.<?php echo e($OrderDay->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
				</div>
				<div class="tab-pane" id="2a">
                     
                    <table class="table_1">
						  <tr>
						    <th>Code</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php $__currentLoopData = $Week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->code); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>							
							<td><?php echo e($OrderDay->qty); ?></td>
							<td>Rs.<?php echo e($OrderDay->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					 
				</div>
               <div class="tab-pane" id="3a">
                    <table class="table_1">
						  <tr>
						    <th>Code</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php $__currentLoopData = $Month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->code); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>							
							<td><?php echo e($OrderDay->qty); ?></td>
							<td>Rs.<?php echo e($OrderDay->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
				</div>
            <div class="tab-pane" id="4a">
                   <table class="table_1">
						  <tr>
						    <th>Code</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						  <?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->code); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>							
							<td><?php echo e($OrderDay->qty); ?></td>
							<td>Rs.<?php echo e($OrderDay->total); ?></td>
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
				</div>
			</div>
  </div>



 


					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		
		$('.active-report').addClass('active');
		
		 var id = $('#outletId').val();
		
		$.get("<?php echo e(route('outlet.code.graph')); ?>?id="+id)
		  .done(function(data) {
			   
				demo.HighestOrderChart(data);
								
			});	
		
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.outlet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>