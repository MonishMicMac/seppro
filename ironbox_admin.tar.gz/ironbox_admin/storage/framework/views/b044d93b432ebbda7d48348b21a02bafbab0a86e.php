

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Assing pickup / delivery person</h4>
				</div>
				<div class="card-content">
	
				   <div class="box_shadow box_shadow2">
				       <h4 class="yellowtext">Assign pickup</h4>
				        <form  action="<?php echo e(route('assign.pending.update')); ?>" method="post" id="UpdatePickup" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>


                        <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label>
                                Pickup Users
                              </label>
                               <select class="select_box_2" id="pickup_user" name="pickup_user">
								    <option value="">Select pick person</option>
									<?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PickupUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($PickupUser->id); ?>"><?php echo e($PickupUser->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								
                           </div>
						   Check all: <input type="checkbox" class="checkAllbox"  id="checkall">
                        </div>
						
						<div class="col-md-6">
						       <label class="lb2">
                                Comments
                              </label>
                           <textarea rows="4" cols="50" name="comments"></textarea>
                        </div>
                    
						 
						<div class="clearfix"></div>
						<div class="row" style="margin-top:30px;">
						  <div class="col-md-12">
						  <div class="card">
						        <div class="card-content">
								<div class="card-header" data-background-color="blue">
							  <h5 class="title col3">Pickup orders</h5>
						   </div>
						<div class="material-datatables">
						   
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
									    <th></th>
										<th>S.No</th>
										<th>BookingId </th>
										<th>Booking Date</th>
										<th>Name</th>
										<th>Order for</th>
										<th>Status</th>
										<th>Mobile</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th></th>
										<th>S.No</th>
										<th>BookingId </th>
										<th>Booking Date</th>
										<th>Name</th>
										<th>Order for</th>
										<th>Status</th>
										<th>Mobile</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetBookings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><input type="checkbox" class="checked5 checkedboxclick" name="bookingId[]" value="<?php echo e($GetBookings->id); ?>"></td>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($GetBookings->bookingId); ?></td>
										<td><?php echo e($GetBookings->bookingDate); ?></td>
										<td><?php echo e($GetBookings->name); ?></td>
										<td><?php echo e($GetBookings->order_for); ?></td>
										<td><?php echo e($GetBookings->Status); ?></td>
										<td><?php echo e($GetBookings->mobile); ?></td>
                                        
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
					<div class="col-md-6">
						<button class="btn btn-primary" id="assign_btn" style="display:none">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					</div>
					</div>
						  </div>
						  
					 </form>
						</div>
						
	
						
						
						
				   </div>
				   
				</div>
			</div>
		</div>		
	</div>
	
	
	
		
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		$('.active-pickup').addClass('active');

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>