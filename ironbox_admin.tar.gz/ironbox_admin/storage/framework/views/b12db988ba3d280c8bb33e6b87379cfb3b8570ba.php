

<?php $__env->startSection('content'); ?>


<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>

   <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Add Complaints</h4>
				</div>
				<div class="card-content">
				   <form  action="<?php echo e(route('add.complients')); ?>" method="post" id="AddComplaints" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					   
					   
					   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Mobile No
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" maxlength ="10" name="mobile" id="mobile" type="text" />
							  <?php if(session()->has('error_message')): ?>
								   <p class="error">
									<?php echo e(session()->get('error_message')); ?>

								</p>
								<?php endif; ?>
                           </div>
						   
						   <div class="form-group label-floating">
                             <!-- <label class="control-label">
                                Complaints
                              <small>*</small>
                              </label>-->
                             <select class="form-control" id="type_complaints" name="type_complaints">
							   <option value="">Select Complaints type</option>
							   <option value="cloth damage">Cloth damage</option>
							   <option value="Not proper ironing">Not proper ironing</option>
							 </select>
                           </div> 

                           <div class="form-group label-floating">
                              <label class="control-label">
                                Complaints
                              <small>*</small>
                              </label>
                              <input class="form-control  emptyspace" name="complaints" id="complaints" type="text" />
                           </div> 

						   
                          </div>
						 
						<div class="col-md-6">
                            <div class="box_shadow box_shadow2">
				                <h4 class="yellowtext">User Details</h4> 
								 
								<div class="urdetails">
								   <strong >Name :</strong> <span id="username"></span>
								</div>
								
								<div class="urdetails">
								   <strong>Mobile :</strong> <span id="usermobile"></span>
								</div>
								
								<div class="urdetails">
								   <strong>Email :</strong> <span id="useremail"></span>
								</div>
								 
							</div> 	
                        </div>
						
						<div class="clearfix"></div>

						
						<div class="col-md-12">
						<button class="btn btn-primary" id="pin_btn">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>	


	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Customer complients</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Complaint Id</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Comments</th>
										<th>Types</th>
										<th>Open / Not</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Complaint Id</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Comments</th>
										<th>Types</th>
										<th>Open / Not</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Support): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($Support->complaint_id); ?></td>
										<td><?php echo e($Support->name); ?></td>
										<td><?php echo e($Support->mobile); ?></td>
										<td><?php echo e($Support->Comments); ?></td>
										<td><?php echo e($Support->complaints_type); ?></td>
										<td><?php if($Support->Is_open == 1): ?> open <?php else: ?> Not open <?php endif; ?></td>


										<td class="text-right">
								          <a href="<?php echo e(route('view.complient',[$Support->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>