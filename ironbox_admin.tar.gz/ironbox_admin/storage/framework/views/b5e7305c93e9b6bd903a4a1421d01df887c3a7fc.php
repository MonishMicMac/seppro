

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	   <div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Sub Category</h4>
					</div>
					<div class="card-content">
						<form  action="<?php echo e(route('update.category.items')); ?>" method="post" id="editaddsubcategoty" enctype="multipart/form-data">
					     <?php echo e(csrf_field()); ?>

						 
						 <?php $__currentLoopData = $Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						   <div class="col-md-6">
							 <div class="form-group label-floating">
								
								<select  class="form-control" id="MainCategory" name="MainCategory">
									<option value="">Select Category</option>
									<?php $__currentLoopData = $Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CategoryList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									
                                    <option value="<?php echo e($CategoryList->id); ?>"
									  
									   <?php
                                          foreach($Items as $GetItems){
											  
											  if($CategoryList->id == $GetItems->categoryId){
												  
												  echo "Selected";
											  }
										  }
                                         ?>									   
									  
									  > <?php echo e($CategoryList->name); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							 </div>
						   </div>
						   
						   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Name
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="name" id="name" type="text" value="<?php echo e($GetItems->name); ?>" />
                            </div>
                            <input type="hidden" name="id" value="<?php echo e($GetItems->id); ?>">
                          </div>
						  <div class="clearfix"></div>
						  <div class="col-md-6">
                           
                              <label class="">
                                Image
                              <small>*</small>
                              </label>
                              <input class=""  name="image" id="image" type="file" />
                           

                          </div>
						  <p><?php echo e($GetItems->groupName); ?></p>
						  <div class="col-md-6">
						 <div class="form-group label-floating">
							
							<select  class="form-control" id="groupname" name="groupname">
								<option value="">Select GroupName</option>
								<?php $__currentLoopData = $Group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetGroupName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($GetGroupName->name); ?>"
								
								   <?php
                                        if($GetGroupName->name == $GetItems->groupName){
											
											
											echo "Selected";
										}
										 
                                    ?>	
								
								><?php echo e($GetGroupName->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						 </div>
					   </div>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						  <div class="clearfix"></div>
						<button class="btn btn-primary">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						   
						 </form>
					</div>
				</div>
			</div>
		</div>
	
	
	
	
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>