

<?php $__env->startSection('content'); ?>


<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
<a href="<?php echo e(route('download.user.list')); ?>" class="btn btn-primary btn-rit"> 
						   Download report
						   <div class="ripple-container"></div>
						</a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Users List</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Email</th>
										<th>DOB</th>
										<th>Gender</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Email</th>
										<th>DOB</th>
										<th>Gender</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $UserList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $List): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($List->name); ?></td>
										<td><?php echo e($List->mobile); ?></td>
										<td><?php echo e($List->email); ?></td>
										<td><?php echo e($List->dob); ?></td>
										<td><?php echo e($List->gender); ?></td>


										<td class="text-right">
											<!--<a  data-toggle="modal" data-target="#Viewuser" class="btn btn-simple btn-warning btn-icon edit View_user" value="<?php echo e($List->id); ?>" href="" id=""><i class="fa fa-pencil-square-o"></i></a>-->
											
											<a href="<?php echo e(route('user.details',[$List->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
											
											<a href="<?php echo e(route('wallet.trans',[$List->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-google-wallet"></i></a>
											
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>