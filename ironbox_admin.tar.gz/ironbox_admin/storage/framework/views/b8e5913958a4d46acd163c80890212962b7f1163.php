

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Add Outlet</h4>
				</div>
				<div class="card-content">
				   <form  action="<?php echo e(route('add.outlet')); ?>" method="post" id="Outlet" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>


                      <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Outlet Name
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace"  name="outletname" id="outletname" type="text" />
                           </div>
                        </div>
                    
					
						<div class="col-md-6">
							<div class="form-group label-floating">
							  <label class="control-label">
								Address
							  <small>*</small>
							  </label>
							  <input class="form-control emptyspace"  name="address" id="address" type="text" />
						   </div>
						</div>
					    <div class="clearfix"></div>
					     
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Latitude
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" name="latitude" id="latitude" type="text" />
                           </div>
						   
                        </div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Longitude
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" name="longitude" id="longitude" type="text" />
                           </div>
                        </div>
						 
						<div class="clearfix"></div>
						<div class="col-md-6">
						<button class="btn btn-primary">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>
	
	
	
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Outlets</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Address</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Address</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetOutlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($GetOutlet->name); ?></td>
										<td><?php echo e($GetOutlet->address); ?></td>
                                        

										<td class="text-right">
											
											<a  data-toggle="modal" data-target="#editoutlet" class="btn btn-simple btn-warning btn-icon edit outlet_edit" value="<?php echo e($GetOutlet->id); ?>" href=""><i class="fa fa-pencil-square-o"></i></a>
											
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<div id="editoutlet" class="modal fade" role="dialog">
          <div class="modal-dialog">

          <!-- Modal content-->
          <div class="modal-content">
          <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Outlet</h4>
          </div>
          <div class="modal-body">
               <div class="row">
                 <form  action="<?php echo e(route('update.outlet')); ?>" id="EditOutlet" method="post">
						<?php echo e(csrf_field()); ?>

						
		              <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Outlet Name
                              <small>*</small>
                              </label>
                              <input class="txt_box  emptyspace"  name="outletname" id="Out_name" type="text" />
                           </div>
                        </div>
                    
					
						<div class="col-md-6">
							<div class="form-group label-floating">
							  <label class="control-label">
								Address
							  <small>*</small>
							  </label>
							  <input class="txt_box  emptyspace"  name="address" id="Out_address" type="text" />
						   </div>
						</div>
					    <div class="clearfix"></div>
					     
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Latitude
                              <small>*</small>
                              </label>
                              <input class="txt_box  numbersnot emptyspace numbersOnly" name="latitude" id="Out_latitude" type="text" />
                           </div>
						   <input type='hidden' id='out_id' name="id" >
                        </div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Longitude
                              <small>*</small>
                              </label>
                              <input class="txt_box  numbersnot emptyspace numbersOnly" name="longitude" id="Out_longitude" type="text" />
                           </div>
                        </div>
						 
						<div class="clearfix"></div>
						<div class="col-md-6">
						<button class="btn btn-primary">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
						
                    
                  </form>
               </div>
          </div>

          </div>
          </div>
          </div>


  
		  <script>
		  
$(function () {


});
		  
		  $(document).ready(function(){
		$(".delete_Slot").on('click',function () {

            var id = $(this).attr('value');

            $('#yes-btn').attr('href',"<?php echo e(route('delete.timeslot')); ?>?id="+id);
        });

        });
		  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>