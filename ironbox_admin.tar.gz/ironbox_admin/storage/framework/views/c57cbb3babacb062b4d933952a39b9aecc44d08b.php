

<?php $__env->startSection('content'); ?>
<div class="content">
   <div class="container-fluid">
       <div class="row">
			
		<div class="col-lg-3 col-md-6 col-sm-6">
		<a href="#">
			<div class="card card-stats">
				<div class="card-header" data-background-color="orange">
					 <i class="fa fa-users"></i>
				</div>

				<?php   $id; ?>
				<input type ='hidden' id="outletId" value="<?php echo $id; ?>">
				<div class="card-content">
					<p class="category">Users</p>
					<h3 class="title"><?php echo e($Users); ?>

					</h3>
				</div>
			</div>
			</a>
		</div>	


           <div class="col-lg-3 col-md-6 col-sm-6">
			<a href="<?php echo e(route('pickupuser.list')); ?>">
				<div class="card card-stats">
					<div class="card-header" data-background-color="green">
						<i class="material-icons">store</i>
					</div>
					<div class="card-content">
						<p class="category">Pickup users</p>
						<h3 class="title"><?php echo e($PickupUser); ?></h3>
					</div>
				</div>
				</a>
			</div>	

            <div class="col-lg-3 col-md-6 col-sm-6">
				<a href="<?php echo e(route('ironing.vendor')); ?>">
					<div class="card card-stats">
						<div class="card-header" data-background-color="red">
							<i class="material-icons">info_outline</i>
						</div>
						<div class="card-content">
							<p class="category">Ironing vendor</p>
							<h3 class="title"><?php echo e($Ironing); ?></h3>
						</div>
					</div>
					</a>
				</div>	

               <div class="col-lg-3 col-md-6 col-sm-6">
				<a href="<?php echo e(route('order.list')); ?>">
					<div class="card card-stats">
						<div class="card-header" data-background-color="blue">
							<i class="fa fa-list-ul"></i>
						</div>
						<div class="card-content">
							<p class="category">Total orders</p>
							<h3 class="title"><?php echo e($Bookings); ?></h3>
						</div>
					</div>
					</a>
				</div>		

               <div class="row">
                     <div class="col-md-6">  
					   <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="dailySales"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Daily sales clothes vs quantity</h4>
                                   <!-- <p class="category">
                                        <span class="text-success"><i class="fa fa-long-arrow-up"></i> 55% </span> increase in today sales.</p>-->
                                </div>
                               <!-- <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">access_time</i> updated 4 minutes ago
                                    </div>
                                </div>-->
                            </div>
                     </div>
					 
					 
					 <div class="col-md-6">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="PaymentTypeChart"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Daily payment type</h4>
                                   <!-- <p class="category">Last Campaign Performance</p>-->
                                </div>
                                <!--<div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">access_time</i> campaign sent 2 days ago
                                    </div>
                                </div>-->
                            </div>
                        </div>
						
					   <div class="clearfix"></div>
					    <div class="col-md-6">
                             
					 
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="MostBooking"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Most booking user</h4>
                                </div>
                            </div>
                         					   
					  
                         </div>	

                       <div class="col-md-6">
                            <div class="card">
                                <div class="card-header card-chart" data-background-color="green">
                                    <div class="ct-chart" id="dailySalesRevenue"></div>
                                </div>
                                <div class="card-content">
                                    <h4 class="title">Daily sales clothes vs amount</h4>
                                </div>
                                </div>
                            </div>						 
					
					 
               </div>					 
					
       </div>
   </div>
</div>



<script>

        $(document).ready(function () {
            $('.active-board').addClass('active');
			
			
			
			var id = $('#outletId').val();
			$.get("<?php echo e(route('outlet.sales')); ?>?id="+id)
			  .done(function(data) {
				
					demo.SalesChart(data);
					
				});	
				
				
				$.get("<?php echo e(route('outlet.payment')); ?>?id="+id)
			  .done(function(data) {
				
					demo.PaymentTypeChart(data);
					
									
				});	
				
			$.get("<?php echo e(route('outlet.most.order')); ?>?id="+id)
			  .done(function(data) {
					
					demo.MostBooking(data);
									
				});	
				
				$.get("<?php echo e(route('outlet.cloth.graph')); ?>?id="+id)
			  .done(function(data) {
					console.log(data);
					demo.ClothRevenue(data);  
									
				});	
			
        });
		
		
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.outlet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>