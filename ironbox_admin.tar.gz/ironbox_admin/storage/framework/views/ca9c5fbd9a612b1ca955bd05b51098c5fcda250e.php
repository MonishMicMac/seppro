

<?php $__env->startSection('content'); ?>
<div class="content">
   <div class="container-fluid">
       <div class="row">
			
			<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Service Area List</h4>
						<?php $id; ?>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Areaname </th>
										<th>Pincode</th>
										<!--<th class="text-right">Actions</th>-->
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Areaname </th>
										<th>Pincode</th>
										<!--<th class="text-right">Actions</th>-->
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $code; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PincodeCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($PincodeCode->area); ?></td>
										<td><?php echo e($PincodeCode->code); ?></td>


										<!--<td class="text-right">
											<a  data-toggle="modal" data-target="#editpin" class="btn btn-simple btn-warning btn-icon edit pin_edit" value="<?php echo e($PincodeCode->id); ?>" href="" id=""><i class="fa fa-pencil-square-o"></i></a>
											
											<a  onclick="return confirm('Are you sure you want to delete pincode');" class="delete_pin" href="<?php echo e(route('delete.pin')); ?>?id=<?php echo e($PincodeCode->id); ?>"> <i class="fa fa-trash"></i></a>
											
										</td>-->
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
					
       </div>
   </div>
</div>



<script>
        $(document).ready(function () {
            $('.active-service').addClass('active');
        });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.outlet', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>