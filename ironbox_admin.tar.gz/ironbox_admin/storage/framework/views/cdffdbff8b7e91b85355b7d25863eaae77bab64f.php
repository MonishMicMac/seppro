

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">New booking</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					 
                                <form  action="" method="post" id="addmaincategory" enctype="multipart/form-data">
								   <?php echo e(csrf_field()); ?>

								  <div class="col-md-6">
									   <div class="form-group label-floating">
										  <label class="control-label">
											Mobile
										  <small>*</small>
										  </label>
										  <input class="form-control emptyspace" name="booking_mobile" id="booking_mobile" type="text" />
									   </div>
									   
									   <div class="form-group">
										  <label class="control-label">
											Date
										  <small>*</small>
										  </label>
										  <input class="form-control  numbersOnly" name="book_date" id="book_date" type="date" />
									   </div>
									   
									   <div class="form-group">
										  <select class="form-control" id="time_slots" name="time_slots">
										   <?php $__currentLoopData = $slot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    <option><?php echo e($time->fromSlots); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										  </select>
									   </div>
									   
									   <div class="form-group">
										  <select class="form-control" id="useraddr" name="useraddr">
									
										    <option>select address</option>

										  </select>
									   </div>
									   
									</div> 
									
									<div class="col-md-6">
									   
									</div> 
									
									
									<div class="clearfix"></div>
									<div class="col-md-12">
									<button class="btn btn-primary" id="pin_btn">
									   Submit
									   <div class="ripple-container"></div>
									</button>
									</div>
								 </form>
                         					   
					   </div>
					   
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>