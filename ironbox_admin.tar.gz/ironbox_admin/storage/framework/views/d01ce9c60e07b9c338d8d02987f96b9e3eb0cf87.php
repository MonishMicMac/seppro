

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Reports</h4>
					</div>
					<div class="card-content">
                       <div class="row">
					    <div class="col-md-12">
							<h4 class="title">Highest order area vs bookings</h4>
                           <div class="card">
                                <div class="card-header card-chart" data-background-color="red">
                                    <div class="ct-chart" id="HighestOrder"></div>
									<span class="graph_text">Orders</span>
									<span>Pincode</span>
                                </div>
                                <div class="card-content">
                                   
								   <div class="col-md-12">
								   <h4 class="title">Pincode orders total summary</h4>
								     <table class="table_1">
										  <tr>
											<th>Pincode</th>
											<th>Total orders</th>							
											<th>Total quantity</th>							
											<th>Total amount</th>							
										  </tr>
										   <?php 
										  if(count($summary) == 0){
											 ?> 
											   <tr>
											   <td colspan="4">No record</td>
												</tr>
											  <?php
										  }
										  
										  ?>
										  <?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										  <tr>
											<td><?php echo e($date->code); ?></td>
											<td><?php echo e($date->orders); ?></td>							
											<td><?php echo e($date->qty); ?></td>							
											<td><?php echo e($date->total); ?></td>							
										   
										  </tr>
										   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</table>
								   </div>
                                </div>
                            </div>
                         					   
					  
                         </div>					   
					   </div>
					   

					   
					   <div class="row">
				     <div class="col-md-12">
				     <div class="box_shadow box_shadow2">
					 
					   <h4 class="yellowtext">Reports</h4> 

        <div id="exTab1">	
         <ul  class="nav nav-pills">
			<li class="active">
        <a  href="#1a" data-toggle="tab" value="1" class="get_slot_value">Today</a>
			</li>
			<li><a href="#2a" data-toggle="tab" value="2" class="get_slot_value">Weekly</a>
			</li>
			<li><a href="#3a" data-toggle="tab" value="3" class="get_slot_value">Monthly</a>
			</li>
  		<li><a href="#4a" data-toggle="tab" value="4" class="get_slot_value">Yearly</a></li>
  		<li><a href="#5a" data-toggle="tab" value="5" class="get_slot_value">Custom</a></li>
		</ul>

			<div class="tab-content clearfix">
			  <div class="tab-pane active" id="1a">
			  

			  
			  <a href="<?php echo e(route('area.report',['id'=>1,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
			  
                     <table class="table_1">
						  <tr>
						    <th>Code</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($Day) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->code); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->total); ?></td>							
							
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Today Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $Dayrep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->bookingDate); ?></td>
										<td><?php echo e($rep->code); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
				<div class="tab-pane" id="2a">
                     
					 <a href="<?php echo e(route('area.report',['id'=>2,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
					 
                   <table class="table_1">
						  <tr>
						    <th>Code</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($Week) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->code); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->total); ?></td>							
				
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Weekly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $Weekrep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->bookingDate); ?></td>
										<td><?php echo e($rep->code); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
					 
				</div>
               <div class="tab-pane" id="3a">
			   
			   <a href="<?php echo e(route('area.report',['id'=>3,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
			   
                    <table class="table_1">
						  <tr>
						    <th>Code</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($Month) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->code); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->total); ?></td>							
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Monthly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $Monthrep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->bookingDate); ?></td>
										<td><?php echo e($rep->code); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
            <div class="tab-pane" id="4a">
			
			<a href="<?php echo e(route('area.report',['id'=>4,'type'=>'normal'])); ?>" class="btn btn-primary down_btn2">
						   Download report
						   <div class="ripple-container"></div>
						</a> 
			
                   <table class="table_1">
						  <tr>
						   <th>Code</th>
							<th>Orders</th>							
							<th>Quantity</th>
							<th>Total amount</th>
						  </tr>
						   <?php 
						  if(count($Year) == 0){
							 ?> 
							   <tr>
							   <td colspan="4">No record</td>
							    </tr>
							  <?php
						  }
						  
						  ?>
						  <?php $__currentLoopData = $Year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OrderDay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <tr>
							<td><?php echo e($OrderDay->code); ?></td>
							<td><?php echo e($OrderDay->orders); ?></td>
							<td><?php echo e($OrderDay->qty); ?></td>							
							<td><?php echo e($OrderDay->total); ?></td>							
                           
						  </tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						
						
						<div class="material-datatables mar20">
						<div class="box_shadow box_shadow2">
				      <h4 class="yellowtext">Yearly Orders</h4>
						<table class="table table-striped table-no-bordered table-hover datatables" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Booking date</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Booking date</th>
										<th>Pincode</th>
										<th>Status</th>
										<th class="disabled-sorting text-right">Actions</th>
									</tr>
								</tfoot>
								<tbody>
				                 <?php   $count = 1; ?>
				                 <?php $__currentLoopData = $Yearrep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($rep->bookingId); ?></td>
										<td><?php echo e($rep->bookingDate); ?></td>
										<td><?php echo e($rep->code); ?></td>
										<td><?php echo e($rep->Status); ?></td>


										<td class="text-right">
											 <a href="<?php echo e(route('view.bookings',[$rep->id])); ?>" class="btn btn-simple btn-info btn-icon like" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
										</td>
									</tr>
		                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
							</table>
							</div>
							</div>
						
				</div>
				
				<div class="tab-pane" id="5a">
				    <form method="post" id="" action ="<?php echo e(route('serach.pincode.down')); ?>" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					      <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                From date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_pin" name="fromdate" id="areafrom" type="date"/>
							  <span class="error area_from">Please select date</span>
                           </div>
						  </div>
						  <div class="col-md-3">
						    <div class="form-group">
                              <label class="control-label">
                                To date
                              <small>*</small>
                              </label>
                              <input class="form-control custom_graph_pin" name="todate" id="areato" type="date"/>
							  <span class="error area_to">Please select date</span>
                           </div>
						  </div>
						  
						  <div class="col-md-3">
							 <div class="form-group">
								<label class="control-label">
                                Pincode
                              <small>*</small>
                              </label>
								<select  class="form-control custom_graph_pin" id="pinId" name="pinId">
									<option value="">Select Pincode</option>
									<?php $__currentLoopData = $pincode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									
                                      <option value="<?php echo e($pin->id); ?>"> <?php echo e($pin->code); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							 </div>
						   </div>
						   
						 
						  
						 <div class="col-md-3">
						     <button class="btn btn-primary" type="submit">
						   Download report
						   <div class="ripple-container"></div>
						</button>
						  </div>
						  </form>
						  
						  <div class="clearfix"></div>
						  
						  <table class="table_1">
						  <tr>
						    <th>BookingId</th>
						    <th>Booking date</th>
							<th>Pincode</th>							
							<th>Action</th>
						  </tr>
						  
						  
						  <tbody id="area_report">
                                  <td colspan="5">No record</td>  
                            </tbody>
						</table>
						  
						  
				  
				</div>
				
			</div>
  </div>



 


					 </div>
					 </div>
				   </div>
					   
					   
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script type="text/javascript">
    $(document).ready(function() {
		$('.active-report').addClass('active');

		$.get("<?php echo e(route('high.order.graph')); ?>")
	  .done(function(data) {

			demo.HighestOrderChart(data);
							
		});	
		
		
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>