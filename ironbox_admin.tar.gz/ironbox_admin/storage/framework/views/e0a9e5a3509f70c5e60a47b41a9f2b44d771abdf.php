

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<form method="post" id="Search_appactive_report" action ="<?php echo e(route('user.inactive.use')); ?>" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

			<div class="col-md-3">
			 <div class="form-group">
				<label class="control-label">
                No.of.Days
              <small>*</small>
              </label>
				<select  class="form-control custom_graph_status2" id="noofdays" name="noofdays">
					 <option value="">Select type</option>
					
                      <option value="10">10</option>
                      <option value="15">15</option>
                      <option value="30">30</option>
				</select>
			 </div>
		   </div>
		<div class="col-md-9">	   
			<a href="<?php echo e(route('user.not.report',['id'=>10,'type'=>'normal'])); ?>" class="btn btn-primary down_btn" id="but1"  style="display: none;">
			   Download report
			   <div class="ripple-container"></div>
			</a> 
			<a href="<?php echo e(route('user.not.report',['id'=>15,'type'=>'normal'])); ?>" class="btn btn-primary down_btn" id="but2"  style="display: none;">
			   Download report
			   <div class="ripple-container"></div>
			</a>
			<a href="<?php echo e(route('user.not.report',['id'=>30,'type'=>'normal'])); ?>" class="btn btn-primary down_btn "id="but3">
			   Download report
			   <div class="ripple-container"></div>
			</a>
		</div>			
	</form>
	</div>
	
	
	
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">User List</h4>
					</div>
					<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Email</th>
										<th>Last booking date</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>Name </th>
										<th>Mobile</th>
										<th>Email</th>
										<th>Last booking date</th>
									</tr>
								</tfoot>
								
								<tbody id="default_result">
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $List): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($List->name); ?></td>
										<td><?php echo e($List->mobile); ?></td>
										<td><?php echo e($List->email); ?></td>
										<td><?php echo e($List->last_booking); ?></td>
                                        

										
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								<tbody id="inactive_report">
								</tbody>
								
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<script type="text/javascript">
    $(document).ready(function() {
		$('.active-report').addClass('active');
		
    });
</script>


  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>