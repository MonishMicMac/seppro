

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
	<div class="container-fluid">
	  <div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
			   <div class="card-header" data-background-color="blue">
					<h4 class="title">Promo Code</h4>
				</div>
				 <div class="card-content">
			        
					 <form  action="<?php echo e(route('update.promo')); ?>" method="post" id="EditPromocode" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>

					   
					   <?php $__currentLoopData = $Promocode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					   <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                promocode
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace" maxlength ="6" name="promocode" id="promocode_name" type="text"  value="<?php echo e($GetCode->promocode); ?>"/>
							  <p id="promo_valid"></p>
                           </div>
                        </div>
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Discount
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly"  name="discount" id="discount" type="text" value="<?php echo e($GetCode->discount); ?>" />
                           </div>
                        </div>
						
						<div class="clearfix"></div>
						
						<!--<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Maximum discount
                              <small>*</small>
                              </label>
                              <input class="form-control numbersnot emptyspace numbersOnly" name="max_amount" id="max_amount" type="text" value="<?php echo e($GetCode->maximum_amount); ?>" />
                           </div>
                        </div>-->
						
						<div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Expiry from
                              
                              </label>
                              <input class="form-control" name="expiry_from" id="expiry_from" type="date" value="<?php echo e($GetCode->expiry_from); ?>"/>
                           </div>
                        </div>
						
						 <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Expiry to
                              
                              </label>
                              <input class="form-control" name="expiry_to" id="expiry_to" type="date" value="<?php echo e($GetCode->expiry_to); ?>" />
                           </div>
                        </div>	
						
	                  	

                       

                       
					    <div class="clearfix"></div>

                         <div class="col-md-6">
						 <div class="form-group label-floating is-empty">
							<select class="form-control" id="payment_type" name="payment_type">
								<option value="">Select offer type *</option>
								<option <?php if($GetCode->offer_type == "Wallet") { echo "selected"; } ?> value="Wallet">Wallet</option>
								<option <?php if($GetCode->offer_type == "Booking") { echo "selected"; } ?> value="Booking">Booking</option>
							</select>
						 <span class="material-input"></span></div>
					   </div>	
					   
					    <div class="col-md-6">
                           No expiry: <input type="checkbox" <?php if($GetCode->no_expiry == "Yes") { echo "checked"; } ?> id="no_expiry" name="no_expiry" value="Yes">
                        </div>						
    					<input type="hidden" name="id" id="promocode_id" value="<?php echo e($GetCode->id); ?>">	
						
						<div class="clearfix"></div>	

                        <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label class="control-label">
                                Discription
                              <small>*</small>
                              </label>
                              <input class="form-control emptyspace" value="<?php echo e($GetCode->description); ?>" name="description" id="description" type="text" />
                           </div>
                        </div>	
						
						<div class="col-md-6">
						 <div class="file-upload">
                              <label class="">
                                Images
                              
                              </label>
                              <input class="upload_img_file" name="image" id="image" accept="image/*" type="file">
							  </div>
                             <div class="img_pre1">							  
                               <img class='img img_preview' src='http://139.59.37.241/Ironman/public/images/offers/<?php echo e($GetCode->images); ?>' />
							  </div> 
                          </div>

                        <!-- <div class="col-md-6">
                          <?php foreach($Pincode as $GetPincode){
							  
							  ?>
						  
						  <input type="checkbox" id="pincode" name="pincode[]" <?php 
						  
						         foreach($Area as $SelectAreas){
									 
									 if($GetPincode->id == $SelectAreas->serviceArea_Id){
										 
										 echo "checked";
									 }
								 }



						  ?>  
						  
						  
						            value="<?php echo $GetPincode->id;?>">  <?php echo $GetPincode->area;?>
						  
						  <?php } ?>
						  
                      </div>	-->					   
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						<div class="clearfix"></div>
						<button class="btn btn-primary" id="promo_btn3">
						   Submit
						   <div class="ripple-container"></div>
						</button>
					 </form>
			
			     </div>
			   </div>
			</div>
		</div>	
	
	
	
		</div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
		$('.active-promo').addClass('active');

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>