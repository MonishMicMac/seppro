

<?php $__env->startSection('content'); ?>
<style type="text/css">
	.fa-close{
		margin-top: 17px;
		color: #ff0000;
		font-size: 20px;
	}
</style>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header" data-background-color="blue">
						<h4 class="title">Credit Points</h4>
					</div>
					<div class="card-content">
						<form action="<?php echo e(route('admin.creditpoints.action')); ?>" method="post" id="assigntimeslot" enctype="multipart/form-data">
							<?php echo e(csrf_field()); ?>

							
							<br><br>

							<?php $__currentLoopData = $credit_points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-6">
								<div class="form-group label-floating">
									<label class="control-label">Refferal Points<small>*</small></label>
									<input class="form-control emptyspace" name="refferal_points" type="text" value="<?php echo e($credits['refferal_points']); ?>" />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group label-floating">
									<label class="control-label">Reffered Points<small>*</small></label>
									<input class="form-control emptyspace" name="reffered_points" type="text" value="<?php echo e($credits['reffered_points']); ?>" />
								</div>
							</div>
							<div class="clearfix"></div>

							<div class="col-md-6">
								<div class="form-group label-floating">
									<label class="control-label">Points Per Order<small>*</small></label>
									<input class="form-control emptyspace" name="per_order" type="text" value="<?php echo e($credits['per_order']); ?>" />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group label-floating">
									<label class="control-label">Valid Days<small>*</small></label>
									<input class="form-control emptyspace" name="exp_days" type="text" value="<?php echo e($credits['exp_days']); ?>" />
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							<div class="clearfix"></div>
							<button class="btn btn-primary">
								Submit
								<div class="ripple-container"></div>
							</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>