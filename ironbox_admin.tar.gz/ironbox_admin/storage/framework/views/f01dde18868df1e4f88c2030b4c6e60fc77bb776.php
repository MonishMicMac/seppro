

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">Assing pickup</h4>
				</div>
				<div class="card-content">
				   <form  action="" method="post" id="" enctype="multipart/form-data">
					   <?php echo e(csrf_field()); ?>


                        <div class="col-md-6">
                           <div class="form-group label-floating">
                              <label>
                                Pickup Users
                              </label>
                               <select class="select_box_2 " id="pickup_user" name="pickup_user">
								    <option value="">Select pick users</option>
									<?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PickupUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($PickupUser->id); ?>"><?php echo e($PickupUser->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                           </div>
                        </div>
                    
						 
						<div class="clearfix"></div>
						
						<div class="card-content">
						<div class="material-datatables">
							<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
									    <th></th>
										<th>S.No</th>
										<th>BookingId </th>
										<th>Booking Date</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th></th>
										<th>S.No</th>
										<th>BookingId </th>
										<th>Booking Date</th>
										<th class="text-right">Actions</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
								<?php $__currentLoopData = $Bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GetBookings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><input type="checkbox" class="checked5 checkedboxclick" name="bookingId[]" value="<?php echo e($GetBookings->bookingId); ?>"></td>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($GetBookings->bookingId); ?></td>
										<td><?php echo e($GetBookings->bookingDate); ?></td>
                                        

										<td class="text-right">
											
											
											
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																				   
								</tbody>
								
							</table>
						</div>
					</div>
						
						
						<div class="col-md-6">
						<button class="btn btn-primary">
						   Submit
						   <div class="ripple-container"></div>
						</button>
						</div>
					 </form>
				</div>
			</div>
		</div>		
	</div>
	
	
	
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>