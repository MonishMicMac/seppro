

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
	
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-header" data-background-color="blue">
					<h4 class="title">PickupUser Details</h4>
				</div>
				<div class="card-content">
				<?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PickupUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
				<div class="row">
                    <div class="col-md-12">
                        <div class="profile_pic">
						   <img src=" <?php if($PickupUser->image == ''){ echo "http://139.59.37.241/Ironman/public/images/pic.png"; }else{ echo $PickupUser->image; } ?>" class="img-responsive center-block img-circle">
						    
						</div>
                    </div>					
				</div>
				   <div class="row">
				      
					  <div class="col-md-12">
					      <table class="table">
							<thead>
							  <tr>
								<th>Name</th>
								<th>Mobile</th>
								<th>Email</th>
								<th>Alternate Number</th>
								<th>DOB</th>
								<th>Gender</th>
								<th>Address</th>
							  </tr>
							</thead>
							<tbody>
							  <tr>
								<td><?php echo e($PickupUser->name); ?></td>
								<td><?php echo e($PickupUser->mobile); ?></td>
								<td><?php echo e($PickupUser->email); ?></td>
								<td><?php echo e($PickupUser->alternate_number); ?></td>
								<td><?php echo e($PickupUser->dob); ?></td>
								<td><?php echo e($PickupUser->gender); ?></td>
								<td><?php echo e($PickupUser->address); ?></td>
							  </tr>
							</tbody>
						  </table>
					  </div>
					  
				   </div>
				   
				   <hr class="border_line">
				   <div class="row">
                        <div class="col-md-12">
                             <h4 class="title">Service Area</h4>
							 <form action="<?php echo e(route('add.new.service')); ?>" method="post" id="allowcateservice"> 
							  <?php echo e(csrf_field()); ?>

							  <div class="col-md-6">
							     <div class="form-group">
								 <label class="control-label">
										warehous
									   <small>*</small>
									  </label>
							      <select class="Select_box1" id="warehousId" name="warehousId">
								      <option value="">Select warehous</option>
									    <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									    <option value="<?php echo e($warehouse->id); ?>" 
										
                                         <?php
										 
										 foreach($User as $PickupUser){
										   
										   if($PickupUser->warehouseId == $warehouse->id){
											   
											   echo "Selected";
										   }
									    }?>

										> warehouse <?php echo e($warehouse->id); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  </Select>
								  <input type="hidden" name="id" value="<?php echo e($PickupUser->id); ?>">
                                 </div>
							  </div>
							  
							  <div class="col-md-6">
							      <div class="form-group">
									  <label class="control-label">
										Pincode
									   <small>*</small>
									  </label>
					  
									<!--<select class="selectpicker" name="pincode" id="pincode" data-live-search="true">-->
									<select class="Select_box1" name="pincode" id="pincode">
									<option value="">Select Area</option>	
									<?php $__currentLoopData = $Area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SelectAreas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($SelectAreas->id); ?>" <?php   
									
									   foreach($User as $PickupUser){
										   
										   if($PickupUser->code == $SelectAreas->code){
											   
											   echo "Selected";
										   }
									   }
									
									?>  data-tokens="<?php echo e($SelectAreas->area); ?>"><?php echo e($SelectAreas->area); ?></option>
									 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
					             </div>
							  </div>
							  <div class="clearfix"></div>
					
					             <div class="center">
								<button class="btn btn-primary">
								   Submit
								   <div class="ripple-container"></div>
								</button>
								</div>
							  </form>
                        </div>	

                    						
				   </div>
				   
				   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				   
				    <hr class="border_line">
				   <div class="row">
				     <div class="col-md-6">
					  <h4 class="title">Pickup Service</h4>
					   <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<!--<th>TimeSlot</th>-->
										<th>Action</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<!--<th>TimeSlot</th>-->
										<th>Action</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
                                     <?php $__currentLoopData = $UserBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Bookings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($Bookings->bookingId); ?></td>
										<td><?php echo e($Bookings->name); ?></td>
										<td><?php echo e($Bookings->mobile); ?></td>
										<!--<td><?php echo e($Bookings->fromSlots); ?> TO <?php echo e($Bookings->toSlots); ?></td>-->
										<td class="text-right">
											<a href="<?php echo e(route('view.bookings',[$Bookings->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>

									</tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>									
								</tbody>
								
							</table>
					 </div>
					 
					 <div class="col-md-6">
					  <h4 class="title">Delivery Service</h4>
					   <table id="datatablesss" class="datatables table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
								<thead>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<!--<th>TimeSlot</th>-->
										<th>Action</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>S.No</th>
										<th>BookingId</th>
										<th>Name</th>
										<th>Mobile</th>
										<!--<th>TimeSlot</th>-->
										<th>Action</th>
									</tr>
								</tfoot>
								
								<tbody>
								 <?php   $count = 1; ?>
                                     <?php $__currentLoopData = $Delivery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $DeliveryService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($count++); ?></td>
										<td><?php echo e($DeliveryService->bookingId); ?></td>
										<td><?php echo e($DeliveryService->name); ?></td>
										<td><?php echo e($DeliveryService->mobile); ?></td>
										<!--<td><?php echo e($DeliveryService->fromSlots); ?> TO <?php echo e($DeliveryService->toSlots); ?></td>-->
										<td class="text-right">
											<a href="<?php echo e(route('view.bookings',[$DeliveryService->id])); ?>" class="btn btn-simple btn-info btn-icon like"><i class="fa fa-eye"></i></a>
										</td>

									</tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>									
								</tbody>
								
							</table>
					 </div>
					 
				   </div>
				   
				   
				   
				   
				   
				</div>
			</div>
		  </div>		
	   </div>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>