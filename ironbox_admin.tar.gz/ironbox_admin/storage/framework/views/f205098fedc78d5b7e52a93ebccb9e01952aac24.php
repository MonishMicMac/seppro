

<?php $__env->startSection('content'); ?>
<div class="content">
<a  href="<?php echo e(URL::previous()); ?>" class="btn btn-primary bt-size"><i class="fa fa-arrow-left">  </i><span class="btn6">Back</span></a>
<?php if(count($GetOrders) > 0 ){?>
 <?php $__currentLoopData = $Bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php if($Book->Status == 'CONFIRMED'): ?>
<a href="<?php echo e(url('EditOrders/' . $Book->id . '')); ?>" class="btn btn-primary btn-rit"> 
						   Edit Bookings
						   <div class="ripple-container"></div>
						</a>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php } ?>
               <div class="container-fluid">
                  <div class="row">
                     <div class="col-lg-12 col-md-12">
                        <div class="card">
                           <div class="card-header" data-background-color="blue">
                              <h4 class="title">View Booking Details</h4>
                           </div>
                           <div class="card-content">
                              <div class="row">
							  <?php $__currentLoopData = $Bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('UserDetails/' . $Book->userId . '')); ?>" class="bl0"> 
								  <div class="col-md-4 ht250">
                                    <div class="box_shadow box_shadow1">
                                       <h4 class="greentext">User Details</h4>
                                       <div class="urdetails">
                                          <strong>Name :</strong> <?php echo e($Book->username); ?>

                                       </div>
                                       <div class="urdetails">
                                          <strong>Email :</strong> <?php echo e($Book->useremail); ?>

                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong> <?php echo e($Book->usermobile); ?>

                                       </div>
                                       <div class="urdetails">
                                          <strong>Alternate :</strong> <?php echo e($Book->user_al_number); ?>

                                       </div>
                                    </div>
                                 </div></a>
								
                                 <div class="col-md-8 ht250">
                                    <div class="box_shadow box_shadow2">
                                       <h4 class="yellowtext">Bookings Details</h4>
                                       <div class="right_box">
                                          <div class="urdetails">
                                             <strong>BookingId :</strong> <?php echo e($Book->bookingId); ?>

                                          </div>
										  
                                          <div class="urdetails">
                                             <strong>Pickup date :</strong> <?php echo e($Book->bookingDate); ?>

                                          </div>
                                          <div class="urdetails">
                                             <strong>TimeSlot :</strong> <?php echo e($Book->fromSlots); ?> - <?php echo e($Book->toSlots); ?>

                                          </div>
										  <div class="urdetails">
                                             <strong>Payment type :</strong> <?php echo e($Book->paymentType); ?>

                                          </div>
                                          <div class="urdetails">
                                             <strong>Promocode :</strong>  <?php echo e($Book->promocode); ?>

                                          </div>
                                       </div>
                                       <div class="left_box">
                                          <div class="urdetails">
                                             <strong>Flat No :</strong> <?php echo e($Book->flatNo); ?>

                                          </div>
                                          <div class="urdetails">
                                             <strong>Landmark :</strong> <?php echo e($Book->landmark); ?>

                                          </div>
                                          <div class="urdetails">
                                             <strong>Address :</strong> <?php echo e($Book->address); ?>

                                          </div>
                                       </div>
                                    </div>
                                 </div>
								 
                              </div>
                              <hr>
                              <div class="row">
                                 <div class="col-md-4 ht300">
                                    <div class="box_shadow box_shadow3">
									 <a href="<?php echo e(url('EditPickupUser/' . $Book->pickupDeliveryUserId . '')); ?>" class="bl0"> 
                                       <h4 class="redtext">PickupMan Details</h4>
                                       <div class="urdetails">
                                          <strong>Name :</strong> <?php echo e($Book->pickupusers); ?>

                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong> <?php echo e($Book->pick_us_mobile); ?>

                                       </div>
									   </a>
									   <?php $__currentLoopData = $Deliveyuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $DeliveryMan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									    <a href="<?php echo e(url('EditPickupUser/' . $DeliveryMan->DeliveryUserId . '')); ?>" class="bl0"> 
                                       <h4 class="redtext">DeliveryMan Details</h4>

                                       <div class="urdetails">
                                          <strong>Name :</strong> <?php echo e($DeliveryMan->name); ?>

                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong> <?php echo e($DeliveryMan->mobile); ?>

                                       </div>
									   </a>
									   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </div>
                                 </div>
								  
								  <?php $__currentLoopData = $Ironing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $IroningVendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="col-md-3 ht300">
                                    <div class="box_shadow box_shadow4">
									<a href="<?php echo e(url('VendorDetails/' . $IroningVendor->VendorUserId . '')); ?>" class="bl0"> 
                                       <h4 class="bluetext">Ironing Vendor</h4>
                                       <div class="urdetails">
                                          <strong>Name :</strong><?php echo e($IroningVendor->name); ?>

                                       </div>
                                       <div class="urdetails">
                                          <strong>Mobile :</strong><?php echo e($IroningVendor->mobile); ?>

                                       </div>
									   <div class="urdetails">
                                          <strong>Start date / time :</strong><?php echo e($Book->work_date); ?>, <?php echo e($Book->work_time); ?>

                                       </div>
									   <div class="urdetails">
                                          <strong>End date / time :</strong><?php echo e($Book->wr_end_date); ?>, <?php echo e($Book->wr_end_time); ?>

                                       </div>
									   </a>
                                    </div>
                                 </div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php if(count($GetOrders) > 0 ){?>
                                 <div class="col-md-5 ht300">
                                    <div class="box_shadow box_shadow5">
                                       <h4 class="purpletext">Booking Items</h4>
									  
                                       <div class="table-responsive tblebook">
                                            <table class="booktable" style="width:100%">
                                                <thead>
                                                 <tr>
                                                    <th>S.no</th>
                                                    <th>Category</th>
                                                    <th>Name</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                 </tr>
                                                 </thead>
                                                 <tbody>
												 <?php $count = 1; ?>
												<?php $__currentLoopData = $GetOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <tr>
                                                     <td><?php echo e($count++); ?></td>
													<td><?php echo e($Orders->groupName); ?></td>
													<td><?php echo e($Orders->name); ?></td>
													<td><?php echo e($Orders->quantity); ?></td>
													<td><?php echo e($Orders->amount); ?></td>
                                                 </tr>
												  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Total</td>
												
													
													<td>Rs.<?php if($Book->first_offer == 1){ echo $Book->totalPayment +50; }else{ echo $Book->totalPayment + $Book->discount_amount;} ?></td>    
                                                 </tr>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Discount</td>
													<td>Rs.<?php echo e($Book->discount_amount); ?></td>
                                                 </tr>
                                                 <tr>
                                                    <td colspan="3"></td>
                                                    <td>Grand total</td>
                                                    <td>Rs.<?php if($Book->first_offer == 1){  
													echo $Book->totalPayment;
													}else{ 
													echo $Book->totalPayment + $Book->discount_amount - $Book->discount_amount; 
													}?></td>
                                                 </tr>
                                              </tbody>
                                           </table>
                                       </div>
                                       
                                    </div>
                                 </div>
								 
								 <?php } ?>
                              </div>
                              <div class="row top-pad">
                                 <div class="col-md-12">
                                    <div class="box_shadow box_shadow6 mt20">
                                       <h4 class="skybluetext">Order Status</h4>
                                       <table style="width:100%" class="ta4">
                                          <tbody>
                                             <tr>
                                                <th>Booked on</th>
                                                <th>On the way to pickup</th>
                                                <th>Pickup success</th>
                                                <th>On the way to delivery</th>
                                                <th>Delivery success</th>
                                                <th>Bill Image</th>
                                                <th>Cancelled</th>
                                             </tr>
                                             <tr>
                                                <td> <?php if($Book->ConfirmOrder == 1): ?> Yes <?php else: ?> No <?php endif; ?></td>
												<td><?php if($Book->WaytoPickup == 1): ?> Yes <?php else: ?> No <?php endif; ?></td>
												<td><?php if($Book->PickupSuccess == 1): ?> Yes <?php else: ?> No <?php endif; ?></td>
												<td><?php if($Book->WaytoDelivery == 1): ?> Yes <?php else: ?> No <?php endif; ?></td>
                        <td><?php if($Book->DeliverySuccess == 1): ?> Yes <?php else: ?> No <?php endif; ?></td>	
                        <td rowspan="2"><?php if(!$Book->bill_image): ?> Not Available <?php else: ?> <img src="<?php echo e($Book->bill_image); ?>" style="width: 150px;height: 50px;"> <?php endif; ?></td>
												<td><?php if($Book->reasons == null): ?> No <?php else: ?> Yes <?php endif; ?></td>
                                             </tr>
                                             <tr>
                                                <td><?php echo e($Book->order_date); ?> <br> <?php echo e($Book->order_time); ?></td>
												<td><?php echo e($Book->WaytoPick_date); ?> <br> <?php echo e($Book->WaytoPick_time); ?></td>
												<td><?php echo e($Book->pick_date); ?> <br> <?php echo e($Book->pick_time); ?></td>
												<td><?php echo e($Book->Waytodeliv_date); ?> <br> <?php echo e($Book->Waytodeliv_time); ?></td>
												<td><?php echo e($Book->delivery_date); ?> <br> <?php echo e($Book->delivery_time); ?></td>
												<td><?php echo e($Book->cancel_date); ?> <br> <?php echo e($Book->cancel_time); ?></td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                 </div>
                              </div>
							  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							  
							  <?php if(count($Rating) > 0){ ?>
							  
							  <div class="row">
                                 <div class="col-md-12">
                                    <div class="box_shadow box_shadow6 mt20">
                                       <h4 class="skybluetext">Ratings</h4>
									     <table style="width:100%" class="ta4">
                                          <tbody>
                                             <tr>
                                                <th>Pickup</th>
                                                <th>Service</th>
                                                <th>Delivery</th>
                                                <th>Comments</th>
                                             </tr>
											 
											 <?php $__currentLoopData = $Rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											   <td><?php echo e($Rate->forPickup); ?></td>
											   <td><?php echo e($Rate->forService); ?></td>
											   <td><?php echo e($Rate->forDelivery); ?></td>
											   <td><?php echo e($Rate->comments); ?></td>

											 
											 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											 
										</tbody>
									   </table>
							      </div>
							    </div>
							  </div>
							  
							  <?php  } ?>
							  
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
			
			<script type="text/javascript">
    $(document).ready(function() {
		$('.active-order').addClass('active');

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>