<?php


$data     = array(
				'User' => 'rupeshkumar',
				'Password' => '12345'
			);
			// Send the POST request with cURL
			$ch       = curl_init('http://websmsapp.in/api/mt/GetBalance?');
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$response = curl_exec($ch);
			curl_close($ch);
			// Process your response here
		    echo json_encode($response);

?>